# Rouz Up Academy - Deployment Guide

## Project Overview
This is a complete online academy platform with financial education courses, interactive goal planning tools, games, and progress tracking.

## Technology Stack
- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI**: Tailwind CSS + shadcn/ui components
- **Authentication**: Replit Auth integration
- **Payment**: Stripe integration ready

## Key Features
1. **Course Management**: Multiple courses (Banking, Business, Trust, Estate Planning, etc.)
2. **Interactive Tools**: Goal planners, calculators, progress trackers
3. **Gamification**: Baby Steps Challenge, financial games, quizzes
4. **Responsive Design**: Mobile-first approach
5. **User Authentication**: Secure login system
6. **Progress Tracking**: User dashboard with completion stats

## Installation Instructions

### Prerequisites
- Node.js 20+
- PostgreSQL database
- npm or yarn package manager

### Environment Variables
Create a `.env` file with:
```
DATABASE_URL=your_postgresql_connection_string
REPLIT_DB_URL=your_database_url
STRIPE_SECRET_KEY=your_stripe_secret_key
NODE_ENV=development
```

### Setup Steps
1. Clone/download the project files
2. Install dependencies: `npm install`
3. Set up database: `npm run db:push`
4. Start development: `npm run dev`
5. Build for production: `npm run build`
6. Start production: `npm run start`

## File Structure
```
├── client/               # Frontend React app
│   ├── src/
│   │   ├── pages/       # All course and game pages
│   │   ├── components/  # Reusable UI components
│   │   └── lib/         # Utilities and configurations
├── server/              # Backend Express server
├── shared/              # Shared types and schemas
├── public/              # Static assets
└── attached_assets/     # Course images and resources
```

## Key Pages
- `/` - Landing page with course overview
- `/setting-goals` - Enhanced goal planning tools
- `/baby-steps-challenge` - Dave Ramsey's financial game
- `/banking-course` - Complete banking education module
- `/courses` - Course catalog
- `/dashboard` - User progress tracking

## Deployment Options
1. **Replit**: Already configured for Replit deployment
2. **Vercel/Netlify**: Frontend deployment with serverless functions
3. **Digital Ocean/AWS**: Full-stack deployment with database
4. **Self-hosted**: VPS with PostgreSQL

## Production Considerations
- Configure HTTPS for Stripe payments
- Set up proper database backups
- Configure Content Security Policy
- Set up monitoring and logging
- Optimize images and assets

## Support
This platform includes comprehensive financial education tools with interactive features designed for student engagement and progress tracking.