import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, DollarSign, CreditCard, PiggyBank, TrendingUp, Shield, Calculator } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import BusinessQuiz from "@/components/BusinessQuiz";

export default function BankingCourse() {
  const [activeModule, setActiveModule] = useState<number | null>(null);
  const [activeQuiz, setActiveQuiz] = useState<string | null>(null);

  const getModuleLink = (title: string) => {
    switch (title) {
      case "Banking Basics":
        return "/banking-basics";
      case "Saving vs. Growing":
        return "/saving-vs-growing";
      case "Account Types":
        return "/account-types";
      case "Compound Interest":
        return "/compound-interest";
      case "Investing Basics":
        return "/investing-basics";
      case "Setting Financial Goals":
        return "/setting-goals";
      default:
        return "/banking-course";
    }
  };

  const courseModules = [
    {
      title: "🏦 Banking Basics - Your Money's New Home!",
      description: "Think of banks as super-safe piggy banks that actually pay YOU to keep your money there! Learn how banks work and why they're your first step to financial freedom.",
      step: 1,
      stepDescription: "Ever wonder where your money goes when you put it in the bank? Spoiler alert: it doesn't just sit there! Banks use your money to help other people while keeping it 100% safe for you. Plus, they pay you interest - it's like getting paid just for saving! 💰",
      emoji: "🏦",
      funFact: "Did you know? The word 'bank' comes from the Italian word 'banco' meaning bench - because early bankers sat on benches in the marketplace!"
    },
    {
      title: "💰 Saving vs. Growing - Level Up Your Money Game!",
      description: "Saving is like keeping your money in a basic starter Pokémon - it's safe, but it won't evolve! Learn how to make your money grow and multiply like magic.",
      step: 2,
      stepDescription: "Imagine if every dollar you saved could multiply itself over time! That's exactly what happens when you move from just saving to actually growing your money. It's like planting money seeds that turn into money trees! 🌱➡️🌳",
      emoji: "💰",
      funFact: "If you save $1 a day starting at age 12, by age 65 you could have over $100,000 just from compound interest!"
    },
    {
      title: "🎯 Account Types - Choose Your Financial Superpower!",
      description: "Different accounts have different superpowers! Some are great for saving, others for growing wealth. Learn which account gives you the powers you need!",
      step: 3,
      stepDescription: "Just like choosing a character in a video game, different bank accounts have different special abilities. Checking accounts are like your everyday wallet, savings accounts are your treasure chest, and investment accounts are your wealth-building machines! 🎮",
      emoji: "🎯",
      funFact: "The average teen who starts investing at 15 will have 10 times more money at retirement than someone who starts at 25!"
    },
    {
      title: "🚀 Compound Interest - The 8th Wonder of the World!",
      description: "Albert Einstein called it the most powerful force in the universe! Compound interest is like having money that makes more money, which makes even MORE money!",
      step: 4,
      stepDescription: "Compound interest is basically your money having babies, and then those baby dollars have babies too! It starts slow but becomes INSANELY powerful over time. It's like a financial snowball that gets bigger and bigger as it rolls! ❄️➡️⛄➡️🏔️",
      emoji: "🚀",
      funFact: "If you invested just $100 at age 12 with 7% compound interest, it would be worth over $2,800 by the time you're 65!"
    },
    {
      title: "📈 Investing Basics - Make Your Money Work While You Sleep!",
      description: "Imagine your money going to work for you 24/7, even while you're sleeping, gaming, or hanging with friends! Learn how investing can make you wealthy without lifting a finger.",
      step: 5,
      stepDescription: "Investing is like having a team of money workers who never take a break! While you're living your life, your investments are out there making more money for you. It's the ultimate passive income hack! 😴💰",
      emoji: "📈",
      funFact: "Warren Buffett made 99% of his wealth after age 50, but he started investing at age 11! Time is your superpower!"
    },
    {
      title: "🎯 Setting Financial Goals - Dream Big, Plan Smart!",
      description: "Turn your wildest dreams into achievable financial goals! Whether it's buying your first car, college funds, or starting a business - we'll show you how to make it happen!",
      step: 6,
      stepDescription: "Goals without a plan are just wishes! Learn how to turn 'someday I want...' into 'by this date I will have...' Whether you want the latest gaming setup, your dream car, or to start your own business, we'll create your roadmap to success! 🗺️✨",
      emoji: "🎯",
      funFact: "People who write down their goals are 42% more likely to achieve them than those who don't!"
    }
  ];

  if (activeQuiz) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto p-6">
          <div className="mb-6">
            <Button 
              onClick={() => setActiveQuiz(null)}
              variant="outline"
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Course
            </Button>
          </div>
          <BusinessQuiz moduleType={activeQuiz as any} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Fun Teen-Friendly Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-4xl">🏦</div>
              <div>
                <h1 className="text-3xl font-bold text-white">Banking for Starters</h1>
                <p className="text-blue-100 text-lg">Your Money's Epic Adventure Begins Here! 💰✨</p>
              </div>
            </div>
            <Link href="/">
              <Button variant="outline" size="sm" className="bg-white/20 text-white border-white/30 hover:bg-white/30 font-medium backdrop-blur-sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Academy
              </Button>
            </Link>
          </div>
          
          {/* Fun badges for teens */}
          <div className="flex flex-wrap gap-3 mt-6">
            <div className="bg-yellow-400 text-purple-900 px-4 py-2 text-sm font-bold rounded-full">
              🎯 Ages 12+ Friendly
            </div>
            <div className="bg-green-400 text-purple-900 px-4 py-2 text-sm font-bold rounded-full">
              🎮 Gamified Learning
            </div>
            <div className="bg-pink-400 text-purple-900 px-4 py-2 text-sm font-bold rounded-full">
              💎 Level Up Your Skills
            </div>
          </div>
        </div>
      </div>



      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Learning Modules Header */}
        <div className="mb-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">🎓 Your Banking Adventure Levels!</h2>
          <p className="text-lg text-gray-600">
            Complete each level to unlock your money superpowers and become a banking legend! 🚀💰
          </p>
          <div className="mt-6 flex justify-center">
            <div className="bg-gradient-to-r from-purple-100 to-blue-100 px-6 py-3 rounded-full">
              <span className="text-purple-800 font-bold">🎮 Choose Your Learning Path Below!</span>
            </div>
          </div>
        </div>

        {/* Epic Adventure Modules Section */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <div className="inline-block bg-gradient-to-r from-yellow-400 to-orange-400 text-purple-900 px-6 py-3 rounded-full text-lg font-bold mb-4 animate-pulse">
              🎮 EPIC QUEST MODULES 🎮
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Adventure!</h3>
            <p className="text-lg text-gray-600">Complete each epic quest to unlock your next money superpower! 🚀💰</p>
          </div>

          {/* Super Fun Module Cards for Teens! */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {courseModules.map((module, index) => (
              <div key={index} className="bg-gradient-to-br from-white to-blue-50 rounded-2xl border-2 border-blue-200 p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer group">
                {/* Fun emoji header */}
                <div className="text-center mb-4">
                  <div className="text-4xl mb-2">{module.emoji}</div>
                  <div className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    Level {index + 1}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3 text-center group-hover:text-blue-600 transition-colors">{module.title}</h3>
                <p className="text-gray-600 mb-4 text-center">{module.description}</p>
                
                {/* Fun fact box */}
                {module.funFact && (
                  <div className="bg-yellow-100 border-l-4 border-yellow-400 p-3 mb-4 rounded-r-lg">
                    <p className="text-yellow-800 text-sm font-medium">
                      💡 Fun Fact: {module.funFact}
                    </p>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-purple-600 font-semibold bg-purple-100 px-3 py-1 rounded-full">
                    ⏱️ {module.duration || '30 min'}
                  </span>
                  <Link href={getModuleLink(module.title)}>
                    <Button className="bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600 px-6 py-2 text-sm rounded-full font-bold transform hover:scale-105 transition-all duration-200">
                      🚀 Start Quest!
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Epic Quest Progression Map */}
        <div className="mt-16 bg-gradient-to-br from-purple-50 to-blue-50 rounded-3xl p-8">
          <div className="text-center mb-8">
            <h3 className="text-4xl font-bold text-gray-900 mb-4">🗺️ Your Epic Quest Map!</h3>
            <p className="text-lg text-gray-600">Follow the adventure path to unlock all your money superpowers! 🚀</p>
          </div>
          
          <div className="relative">
            {/* Quest progression line */}
            <div className="absolute left-8 top-12 bottom-12 w-1 bg-gradient-to-b from-blue-400 via-purple-400 to-pink-400 rounded-full"></div>
            
            <div className="space-y-8">
              <div className="relative flex items-center">
                <div className="absolute left-4 w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm animate-pulse">1</div>
                <div className="ml-20 bg-gradient-to-r from-blue-100 to-blue-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-blue-300">
                  <div className="flex items-center mb-3">
                    <div className="text-3xl mr-3">🏦</div>
                    <h4 className="text-xl font-bold text-blue-900">Quest 1: Banking Basics - Your Money's New Home!</h4>
                  </div>
                  <p className="text-blue-800">Ever wonder where your money goes when you put it in the bank? Spoiler alert: it doesn't just sit there! Banks use your money to help other people while keeping it 100% safe for you. Plus, they pay you interest - it's like getting paid just for saving! 💰</p>
                </div>
              </div>
              
              <div className="relative flex items-center">
                <div className="absolute left-4 w-8 h-8 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">2</div>
                <div className="ml-20 bg-gradient-to-r from-green-100 to-green-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-green-300">
                  <div className="flex items-center mb-3">
                    <div className="text-3xl mr-3">💰</div>
                    <h4 className="text-xl font-bold text-green-900">Quest 2: Saving vs. Growing - Level Up Your Money Game!</h4>
                  </div>
                  <p className="text-green-800">Imagine if every dollar you saved could multiply itself over time! That's exactly what happens when you move from just saving to actually growing your money. It's like planting money seeds that turn into money trees! 🌱➡️🌳</p>
                </div>
              </div>
              
              <div className="relative flex items-center">
                <div className="absolute left-4 w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-sm">3</div>
                <div className="ml-20 bg-gradient-to-r from-purple-100 to-purple-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-purple-300">
                  <div className="flex items-center mb-3">
                    <div className="text-3xl mr-3">🎯</div>
                    <h4 className="text-xl font-bold text-purple-900">Quest 3: Account Types - Choose Your Financial Superpower!</h4>
                  </div>
                  <p className="text-purple-800">Just like choosing a character in a video game, different bank accounts have different special abilities. Checking accounts are like your everyday wallet, savings accounts are your treasure chest, and investment accounts are your wealth-building machines! 🎮</p>
                </div>
              </div>
              
              <div className="relative flex items-center">
                <div className="absolute left-4 w-8 h-8 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm">4</div>
                <div className="ml-20 bg-gradient-to-r from-orange-100 to-orange-200 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-orange-300">
                  <div className="flex items-center mb-3">
                    <div className="text-3xl mr-3">🎯</div>
                    <h4 className="text-xl font-bold text-orange-900">Quest 4: Setting Financial Goals - Dream Big, Plan Smart!</h4>
                  </div>
                  <p className="text-orange-800">Goals without a plan are just wishes! Learn how to turn 'someday I want...' into 'by this date I will have...' Whether you want the latest gaming setup, your dream car, or to start your own business, we'll create your roadmap to success! 🗺️✨</p>
                </div>
              </div>
              
              <div className="relative flex items-center">
                <div className="absolute left-4 w-8 h-8 bg-gradient-to-r from-pink-500 to-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm animate-bounce">🏆</div>
                <div className="ml-20 bg-gradient-to-r from-pink-100 to-red-100 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 border-pink-300">
                  <div className="flex items-center mb-3">
                    <div className="text-3xl mr-3">🎮</div>
                    <h4 className="text-xl font-bold text-red-900">Final Boss: Test Your Money Mastery!</h4>
                  </div>
                  <p className="text-red-800">Ready for the ultimate challenge? Take our epic quizzes and use the money growth calculator to prove you've mastered all your banking superpowers! Show the world you're ready to build an empire! 👑💰</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

                    {/* Module Content */}
                    {index === 0 && (
                      <div className="mt-6 p-6 bg-green-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Banking Basics</h3>
                        <p className="text-gray-700 mb-4">
                          Banks are financial institutions that help people manage their money safely and conveniently. Understanding how banks work is essential for your financial success.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">What Banks Do</h4>
                        <div className="grid md:grid-cols-2 gap-4 mb-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                            <h5 className="font-bold text-lg text-green-600 mb-2">💰 Store Your Money</h5>
                            <p className="text-gray-700 text-sm">
                              Banks keep your money safe and secure, much safer than keeping cash at home.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h5 className="font-bold text-lg text-blue-600 mb-2">📈 Help Money Grow</h5>
                            <p className="text-gray-700 text-sm">
                              Through savings accounts and CDs, banks pay you interest to keep your money with them.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-purple-500">
                            <h5 className="font-bold text-lg text-purple-600 mb-2">💳 Provide Services</h5>
                            <p className="text-gray-700 text-sm">
                              Banks offer debit cards, online banking, mobile apps, and many other convenient services.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                            <h5 className="font-bold text-lg text-orange-600 mb-2">🏠 Lend Money</h5>
                            <p className="text-gray-700 text-sm">
                              Banks provide loans for cars, homes, education, and business ventures.
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("banking")}
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            🎯 QUIZ TIME! Test Your Banking Knowledge! 📊
                          </Button>
                        </div>
                      </div>
                    )}

                    {index === 1 && (
                      <div className="mt-6 p-6 bg-blue-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Bank Accounts</h3>
                        <p className="text-gray-700 mb-4">
                          Different types of bank accounts serve different purposes. Knowing which account to use when can save you money and help you reach your financial goals faster.
                        </p>
                        
                        <div className="grid md:grid-cols-1 gap-4 mb-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h5 className="font-bold text-lg text-blue-600 mb-2">🏦 Checking Accounts</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Perfect for daily spending and bill payments. Usually comes with a debit card and checkbook.
                            </p>
                            <div className="text-xs text-gray-500">Best for: Daily expenses, bill payments, ATM access</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                            <h5 className="font-bold text-lg text-green-600 mb-2">🐷 Savings Accounts</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Earn interest while keeping your money safe. Great for emergency funds and short-term goals.
                            </p>
                            <div className="text-xs text-gray-500">Best for: Emergency funds, short-term savings goals</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-purple-500">
                            <h5 className="font-bold text-lg text-purple-600 mb-2">📈 Money Market Accounts</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Higher interest rates than savings accounts, but may require higher minimum balances.
                            </p>
                            <div className="text-xs text-gray-500">Best for: Larger savings amounts, better interest rates</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                            <h5 className="font-bold text-lg text-orange-600 mb-2">🎯 Certificates of Deposit (CDs)</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Lock in your money for a set time period to earn higher interest rates.
                            </p>
                            <div className="text-xs text-gray-500">Best for: Money you won't need for months or years</div>
                          </div>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("accounts")}
                            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            💳 ACCOUNTS CHALLENGE! Show Your Skills! 🏆
                          </Button>
                        </div>
                      </div>
                    )}

                    {index === 2 && (
                      <div className="mt-6 p-6 bg-purple-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Credit & Loans</h3>
                        <p className="text-gray-700 mb-4">
                          Credit is borrowing money with a promise to pay it back. Understanding credit is crucial for your financial future - it affects everything from renting an apartment to buying a car.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">Building Good Credit</h4>
                        <div className="bg-white p-4 rounded-lg mb-6">
                          <ul className="list-disc list-inside text-gray-700 space-y-2">
                            <li>Pay all bills on time, every time</li>
                            <li>Keep credit card balances low (under 30% of limit)</li>
                            <li>Don't apply for too many credit cards at once</li>
                            <li>Keep old accounts open to maintain credit history</li>
                            <li>Monitor your credit report regularly</li>
                            <li>Start with a student or secured credit card</li>
                          </ul>
                        </div>
                        
                        <div className="bg-red-100 p-4 rounded-lg border-l-4 border-red-500 mb-6">
                          <h4 className="font-bold text-red-700 mb-2">⚠️ Avoid These Credit Mistakes</h4>
                          <ul className="text-red-700 text-sm space-y-1">
                            <li>• Making only minimum payments on credit cards</li>
                            <li>• Using credit cards for everyday expenses you can't afford</li>
                            <li>• Ignoring your credit score and reports</li>
                            <li>• Co-signing loans without understanding the risks</li>
                          </ul>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("credit")}
                            className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            💎 CREDIT MASTERY! Build Your Future! ⭐
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {/* Course Complete CTA */}
        <div className="mt-16 text-center bg-gradient-to-r from-green-500 to-blue-600 rounded-2xl p-8 text-white">
          <h3 className="text-2xl font-bold mb-4">Ready to Master Banking? 🚀</h3>
          <p className="text-lg mb-6">
            Complete all modules and quizzes to earn your Banking for Starters certificate!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3 font-bold rounded-lg"
            >
              🎓 Start Your Banking Journey
            </Button>
            <Link href="/games">
              <Button variant="outline" className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-3 font-bold rounded-lg">
                🎮 Explore More Courses
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}