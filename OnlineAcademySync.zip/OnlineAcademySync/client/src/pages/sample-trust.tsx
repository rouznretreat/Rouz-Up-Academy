import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function SampleTrust() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => setLocation("/estate-planning-course")}
          className="mb-4"
        >
          ← Back to Documents
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-green-700">Sample Revocable Living Trust</CardTitle>
            <p className="text-gray-600">Educational example of trust structure and provisions</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
              <div className="text-center font-bold text-lg mb-6">
                THE JENNIFER ANNE THOMPSON<br/>
                REVOCABLE LIVING TRUST<br/>
                DATED OCTOBER 15, 2024
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold mb-2">ARTICLE I - CREATION OF TRUST</h4>
                  <p>JENNIFER ANNE THOMPSON, as Settlor, hereby transfers and delivers to herself, as Trustee, the property described in Schedule A attached hereto, to be held, administered and distributed according to the terms of this Trust Agreement.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE II - TRUST NAME</h4>
                  <p>This trust shall be known as "THE JENNIFER ANNE THOMPSON REVOCABLE LIVING TRUST DATED OCTOBER 15, 2024."</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE III - DISTRIBUTIONS DURING SETTLOR'S LIFETIME</h4>
                  <p>During the Settlor's lifetime, the Trustee shall distribute to or for the benefit of the Settlor such amounts of the net income and principal as the Settlor may request from time to time. Any net income not distributed shall be added to principal.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE IV - DISTRIBUTIONS DURING INCAPACITY</h4>
                  <p>If the Settlor becomes incapacitated, the Trustee shall distribute such amounts of income and principal as may be necessary for the Settlor's health, education, maintenance and support, taking into account other resources available to the Settlor.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE V - DISTRIBUTIONS AFTER DEATH</h4>
                  <p>Upon the Settlor's death, the Trustee shall:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>A. Pay all debts, funeral expenses, and costs of administration.</li>
                    <li>B. Distribute $25,000 to the American Red Cross.</li>
                    <li>C. Distribute the remainder equally to the Settlor's children: RYAN MICHAEL THOMPSON and EMILY SARAH THOMPSON.</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE VI - SUCCESSOR TRUSTEE</h4>
                  <p>If the Settlor is unable to serve as Trustee, DAVID WILLIAM THOMPSON shall serve as Successor Trustee. If he is unable to serve, FIRST NATIONAL BANK OF TEXAS shall serve as Successor Trustee.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE VII - POWERS OF TRUSTEE</h4>
                  <p>The Trustee shall have all powers necessary to administer this trust, including but not limited to:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>• Buy, sell, and manage real estate</li>
                    <li>• Invest in stocks, bonds, and mutual funds</li>
                    <li>• Collect income and pay expenses</li>
                    <li>• Hire professional advisors</li>
                    <li>• Make tax elections</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE VIII - REVOCATION</h4>
                  <p>The Settlor reserves the right to amend or revoke this trust in whole or in part at any time during her lifetime by written instrument delivered to the Trustee.</p>
                </div>

                <div className="mt-6">
                  <p>IN WITNESS WHEREOF, the Settlor has executed this Trust Agreement on the date first written above.</p>
                  <div className="mt-4 grid grid-cols-2 gap-8">
                    <div>
                      <p>_________________________________</p>
                      <p>JENNIFER ANNE THOMPSON, Settlor</p>
                    </div>
                    <div>
                      <p>_________________________________</p>
                      <p>JENNIFER ANNE THOMPSON, Trustee</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-green-50 p-4 rounded border border-green-300">
              <h4 className="font-bold text-green-700 mb-2">Trust Features Demonstrated:</h4>
              <ul className="text-sm text-green-700 space-y-1">
                <li>• <strong>Revocable</strong> - Can be changed or cancelled during lifetime</li>
                <li>• <strong>Self-Trusteed</strong> - Settlor maintains control as trustee</li>
                <li>• <strong>Incapacity Planning</strong> - Provides for management if unable to act</li>
                <li>• <strong>Successor Trustees</strong> - Named alternatives to continue management</li>
                <li>• <strong>Distribution Instructions</strong> - Clear directions for asset distribution</li>
                <li>• <strong>Comprehensive Powers</strong> - Trustee authority for all necessary actions</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}