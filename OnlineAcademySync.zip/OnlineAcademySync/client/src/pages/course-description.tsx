import { useState } from "react";
import { useRoute } from "wouter";
import { ArrowLeft, PlayCircle, CheckCircle, Clock, Users, Star, BookOpen, Trophy, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";

export default function CourseDescription() {
  const [match, params] = useRoute("/course-description/:id");
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const courseId = params?.id;

  // Course data based on ID
  const getCourseData = (id: string) => {
    const courses: { [key: string]: any } = {
      "7": { // Credit for Starters
        title: "Credit for Starters",
        subtitle: "Master Your Financial Superpower! 💳",
        description: "Learn how to build amazing credit from scratch and unlock your financial future! This teen-friendly course teaches you everything about credit scores, credit cards, and building wealth through smart credit use.",
        duration: "2-3 hours",
        level: "Beginner",
        students: 1247,
        rating: "4.9",
        price: "Free",
        features: [
          "🎮 Interactive credit score simulator",
          "💳 How to get your first credit card", 
          "📊 Understanding credit reports like a pro",
          "🚀 Building credit from zero to hero",
          "💰 Using credit to build wealth",
          "🛡️ Protecting yourself from credit mistakes"
        ],
        modules: [
          {
            title: "Credit 101 - Your Financial Superpower Origin Story!",
            lessons: 6,
            duration: "30 min"
          },
          {
            title: "Credit Cards - Master the Plastic Power!",
            lessons: 6,
            duration: "35 min"
          },
          {
            title: "Credit Building Strategies - Level Up Fast!",
            lessons: 6,
            duration: "40 min"
          },
          {
            title: "Credit Score Hacks - Become a Financial Ninja!",
            lessons: 6,
            duration: "25 min"
          }
        ],
        color: "from-purple-600 to-pink-600",
        icon: "💳"
      },
      "1": { // Banking for Starters
        title: "Banking for Starters",
        subtitle: "Your Money's New Best Friend! 🏦",
        description: "Discover how banks work and learn to manage your money like a financial wizard! Perfect for teens ready to take control of their financial future.",
        duration: "2 hours",
        level: "Beginner",
        students: 2156,
        rating: "4.8",
        price: "Free",
        features: [
          "🏦 How banks actually work (secrets revealed!)",
          "💰 Choosing the perfect bank account",
          "📱 Mobile banking like a tech pro",
          "💸 Avoiding sneaky fees forever",
          "🎯 Setting up automatic savings",
          "📊 Understanding interest rates"
        ],
        modules: [
          {
            title: "Banking Basics - Your Money's Home Base!",
            lessons: 5,
            duration: "25 min"
          },
          {
            title: "Account Types - Choose Your Financial Weapon!",
            lessons: 4,
            duration: "20 min"
          },
          {
            title: "Digital Banking - Tech Your Way to Wealth!",
            lessons: 6,
            duration: "35 min"
          },
          {
            title: "Smart Banking Strategies - Level Up Your Game!",
            lessons: 5,
            duration: "40 min"
          }
        ],
        color: "from-blue-600 to-green-600",
        icon: "🏦"
      },
      // Add more courses as needed
    };
    
    return courses[id] || {
      title: "Course Not Found",
      subtitle: "Oops! This course doesn't exist yet.",
      description: "This course is still being developed. Check back soon!",
      duration: "TBD",
      level: "Beginner",
      students: 0,
      rating: "0",
      price: "Free",
      features: [],
      modules: [],
      color: "from-gray-400 to-gray-600",
      icon: "📚"
    };
  };

  const course = getCourseData(courseId || "");

  const handleBack = () => {
    window.location.href = "/";
  };

  const handleAccessCourse = () => {
    if (course.title === "Credit for Starters") {
      window.location.href = "/credit-starters";
    } else if (course.title === "Banking for Starters") {
      window.location.href = "/banking-course";
    } else {
      window.location.href = `/course/${courseId}`;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="pt-16">
        {/* Hero Section */}
        <div className={`relative overflow-hidden bg-gradient-to-r ${course.color}`}>
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative max-w-6xl mx-auto px-6 py-16">
            <Button 
              onClick={handleBack}
              className="mb-6 bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm border border-white/30"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="bg-white/20 text-white text-sm px-4 py-2 rounded-full mb-4 backdrop-blur-sm">
                  {course.level} • {course.price}
                </Badge>
                <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
                  {course.title}
                </h1>
                <p className="text-2xl text-white/90 mb-6">
                  {course.subtitle}
                </p>
                <p className="text-lg text-white/80 leading-relaxed mb-8">
                  {course.description}
                </p>
                
                <div className="flex flex-wrap gap-6 text-white/90 mb-8">
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 mr-2" />
                    {course.duration}
                  </div>
                  <div className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    {course.students.toLocaleString()} students
                  </div>
                  <div className="flex items-center">
                    <Star className="w-5 h-5 mr-2 fill-current" />
                    {course.rating} rating
                  </div>
                </div>

                <Button 
                  onClick={handleAccessCourse}
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-purple-50 font-bold text-lg px-8 py-4"
                >
                  🚀 Start Learning Now!
                </Button>
              </div>

              <div className="text-center">
                <div className="text-8xl mb-6">{course.icon}</div>
                <Card className="bg-white/20 backdrop-blur-sm border-white/30">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-white mb-4">What You'll Learn</h3>
                    <div className="space-y-2">
                      {course.features.slice(0, 3).map((feature: string, index: number) => (
                        <div key={index} className="flex items-center text-white/90">
                          <CheckCircle className="w-4 h-4 mr-3 flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        {/* Course Content */}
        <div className="max-w-6xl mx-auto px-6 py-12">
          {/* Features Section */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-3xl text-center">🎯 What You'll Master</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {course.features.map((feature: string, index: number) => (
                  <div key={index} className="flex items-center p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Course Modules */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-3xl text-center">📚 Course Modules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {course.modules.map((module: any, index: number) => (
                  <div key={index} className="p-6 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-bold text-gray-900">{module.title}</h3>
                      <Badge className="bg-blue-100 text-blue-700">
                        Module {index + 1}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <BookOpen className="w-4 h-4 mr-1" />
                        {module.lessons} lessons
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {module.duration}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* CTA Section */}
          <div className="text-center">
            <Card className={`bg-gradient-to-r ${course.color} text-white border-0 max-w-4xl mx-auto`}>
              <CardContent className="p-12">
                <div className="text-6xl mb-6">{course.icon}</div>
                <h3 className="text-4xl font-bold mb-4">Ready to Start Your Journey?</h3>
                <p className="text-xl mb-8 text-white/90">
                  Join {course.students.toLocaleString()}+ students who are already mastering their financial future!
                </p>
                <Button 
                  onClick={handleAccessCourse}
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-purple-50 font-bold text-xl px-12 py-6"
                >
                  🎯 Access Course Now!
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}