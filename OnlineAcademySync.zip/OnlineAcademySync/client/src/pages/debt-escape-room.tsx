import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Lock, Key, DollarSign, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DebtScenario {
  id: number;
  title: string;
  totalDebt: number;
  monthlyIncome: number;
  minimumPayments: number;
  description: string;
  challenge: string;
}

const debtScenarios: DebtScenario[] = [
  {
    id: 1,
    title: "The Credit Card Trap",
    totalDebt: 5000,
    monthlyIncome: 2500,
    minimumPayments: 150,
    description: "You have $5,000 in credit card debt at 18% interest. Making only minimum payments means you'll pay for 47 years!",
    challenge: "Find the key to escape by choosing the right debt strategy."
  },
  {
    id: 2, 
    title: "Student Loan Mountain",
    totalDebt: 25000,
    monthlyIncome: 3500,
    minimumPayments: 300,
    description: "You graduated with $25,000 in student loans. Multiple payment options confuse you - which path leads to freedom?",
    challenge: "Navigate through payment plan options to find the fastest escape route."
  },
  {
    id: 3,
    title: "Car Loan Quicksand",
    totalDebt: 15000,
    monthlyIncome: 3000,
    minimumPayments: 350,
    description: "Your car loan has you trapped with high monthly payments. The car is already worth less than you owe!",
    challenge: "Solve the underwater loan puzzle to break free."
  }
];

interface Strategy {
  name: string;
  paymentAmount: number;
  timeToFreedom: number;
  totalInterest: number;
  description: string;
  isCorrect: boolean;
}

export default function DebtEscapeRoom() {
  const [currentScenario, setCurrentScenario] = useState<DebtScenario | null>(null);
  const [selectedStrategy, setSelectedStrategy] = useState<Strategy | null>(null);
  const [gameComplete, setGameComplete] = useState(false);
  const [keysFound, setKeysFound] = useState(0);
  const [attempts, setAttempts] = useState(0);

  const getStrategies = (scenario: DebtScenario): Strategy[] => {
    const extraPayment = Math.min(scenario.monthlyIncome * 0.2, 500);
    
    return [
      {
        name: "Minimum Payment Forever",
        paymentAmount: scenario.minimumPayments,
        timeToFreedom: 47, // Very long time
        totalInterest: scenario.totalDebt * 2.5,
        description: "Keep paying the minimum and hope for the best",
        isCorrect: false
      },
      {
        name: "Debt Avalanche Method",
        paymentAmount: scenario.minimumPayments + extraPayment,
        timeToFreedom: Math.ceil(scenario.totalDebt / (scenario.minimumPayments + extraPayment) / 12),
        totalInterest: scenario.totalDebt * 0.3,
        description: "Pay extra toward highest interest rate debt first",
        isCorrect: true
      },
      {
        name: "Debt Snowball Method", 
        paymentAmount: scenario.minimumPayments + extraPayment * 0.8,
        timeToFreedom: Math.ceil(scenario.totalDebt / (scenario.minimumPayments + extraPayment * 0.8) / 12),
        totalInterest: scenario.totalDebt * 0.4,
        description: "Pay extra toward smallest debt first for motivation",
        isCorrect: true
      },
      {
        name: "Ignore It and Hope",
        paymentAmount: 0,
        timeToFreedom: 999,
        totalInterest: scenario.totalDebt * 5,
        description: "Maybe it will go away if I don't look at it",
        isCorrect: false
      }
    ];
  };

  const selectScenario = (scenario: DebtScenario) => {
    setCurrentScenario(scenario);
    setSelectedStrategy(null);
    setAttempts(0);
  };

  const tryStrategy = (strategy: Strategy) => {
    setSelectedStrategy(strategy);
    setAttempts(attempts + 1);
    
    if (strategy.isCorrect) {
      setKeysFound(keysFound + 1);
      setTimeout(() => {
        if (keysFound + 1 >= 3) {
          setGameComplete(true);
        } else {
          setCurrentScenario(null);
        }
      }, 3000);
    }
  };

  const resetGame = () => {
    setCurrentScenario(null);
    setSelectedStrategy(null);
    setGameComplete(false);
    setKeysFound(0);
    setAttempts(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-black text-white">
      <div className="bg-black/50 shadow-sm border-b border-red-600 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2 text-white border-red-400 hover:bg-red-800">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-red-100">🔓 Debt Escape Room</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-bold">{keysFound}/3 Keys</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {!currentScenario && !gameComplete && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">🔒</div>
            <h2 className="text-4xl font-bold text-red-100 mb-4">Welcome to the Debt Escape Room</h2>
            <p className="text-xl text-red-200 mb-8 max-w-3xl mx-auto">
              You're trapped by debt! Solve 3 different debt scenarios to collect keys and escape. 
              Choose the wrong strategy and you'll be stuck forever!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {debtScenarios.map((scenario) => (
                <div 
                  key={scenario.id}
                  className="bg-red-800/50 rounded-xl p-6 border-2 border-red-600 hover:border-yellow-400 cursor-pointer transition-all hover:scale-105"
                  onClick={() => selectScenario(scenario)}
                >
                  <div className="text-4xl mb-4">🔐</div>
                  <h3 className="text-xl font-bold text-red-100 mb-3">{scenario.title}</h3>
                  <div className="space-y-2 text-red-200">
                    <div className="flex justify-between">
                      <span>Debt:</span>
                      <span className="font-bold text-red-400">${scenario.totalDebt.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Income:</span>
                      <span className="font-bold text-green-400">${scenario.monthlyIncome.toLocaleString()}/mo</span>
                    </div>
                  </div>
                  <p className="text-sm text-red-300 mt-4">{scenario.challenge}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentScenario && !selectedStrategy && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-red-800/50 rounded-xl p-8 mb-8 border-2 border-red-600">
              <div className="text-center mb-6">
                <div className="text-6xl mb-4">⚠️</div>
                <h2 className="text-3xl font-bold text-red-100 mb-4">{currentScenario.title}</h2>
                <p className="text-xl text-red-200 mb-4">{currentScenario.description}</p>
                <p className="text-lg text-yellow-300">{currentScenario.challenge}</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-red-400">${currentScenario.totalDebt.toLocaleString()}</div>
                  <div className="text-red-200">Total Debt</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-green-400">${currentScenario.monthlyIncome.toLocaleString()}</div>
                  <div className="text-red-200">Monthly Income</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-orange-400">${currentScenario.minimumPayments}</div>
                  <div className="text-red-200">Min Payment</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-400">{attempts}/3</div>
                  <div className="text-red-200">Attempts</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {getStrategies(currentScenario).map((strategy, index) => (
                <div 
                  key={index}
                  className="bg-black/30 rounded-xl p-6 border-2 border-red-600 hover:border-yellow-400 cursor-pointer transition-all hover:scale-105"
                  onClick={() => tryStrategy(strategy)}
                >
                  <h3 className="text-xl font-bold text-red-100 mb-3">{strategy.name}</h3>
                  <p className="text-red-200 mb-4">{strategy.description}</p>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-red-300">Monthly Payment:</span>
                      <span className="font-bold">${strategy.paymentAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-red-300">Time to Freedom:</span>
                      <span className="font-bold">{strategy.timeToFreedom === 999 ? 'Never' : `${strategy.timeToFreedom} years`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-red-300">Total Interest:</span>
                      <span className="font-bold text-red-400">${strategy.totalInterest.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {selectedStrategy && (
          <div className="max-w-2xl mx-auto text-center py-12">
            <div className="text-8xl mb-6">
              {selectedStrategy.isCorrect ? '🗝️' : '💀'}
            </div>
            <h2 className="text-3xl font-bold mb-4">
              {selectedStrategy.isCorrect ? 'Key Found!' : 'Wrong Choice!'}
            </h2>
            {selectedStrategy.isCorrect ? (
              <div className="space-y-4">
                <p className="text-xl text-green-300">
                  Excellent! You found the key by choosing {selectedStrategy.name}!
                </p>
                <p className="text-red-200">
                  This strategy will save you thousands in interest and get you debt-free faster!
                </p>
                {keysFound + 1 < 3 && (
                  <p className="text-yellow-300">
                    Collect {3 - keysFound - 1} more keys to escape!
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xl text-red-300">
                  That strategy will keep you trapped! Try again.
                </p>
                <p className="text-red-200">
                  {selectedStrategy.name} will cost you ${selectedStrategy.totalInterest.toLocaleString()} in interest!
                </p>
                <Button 
                  onClick={() => setSelectedStrategy(null)}
                  className="bg-red-600 hover:bg-red-700 mt-4"
                >
                  Try Again
                </Button>
              </div>
            )}
          </div>
        )}

        {gameComplete && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">🎉</div>
            <h2 className="text-4xl font-bold text-yellow-300 mb-4">FREEDOM!</h2>
            <p className="text-xl text-green-300 mb-6">
              You've escaped the debt trap! You now know the strategies to become debt-free faster.
            </p>
            
            <div className="bg-green-800/30 rounded-xl p-6 max-w-2xl mx-auto mb-8">
              <h3 className="text-xl font-bold text-green-300 mb-4">What You Learned:</h3>
              <ul className="text-left space-y-2 text-green-200">
                <li>• Minimum payments keep you trapped for decades</li>
                <li>• Debt avalanche method saves the most money</li>
                <li>• Debt snowball method provides motivation</li>
                <li>• Paying extra toward debt creates freedom faster</li>
                <li>• Ignoring debt makes it grow exponentially</li>
              </ul>
            </div>
            
            <Button 
              onClick={resetGame}
              className="bg-yellow-600 hover:bg-yellow-700 text-black font-bold px-8 py-3"
            >
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}