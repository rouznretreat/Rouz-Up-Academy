import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import Header from "@/components/Header";
import { 
  CreditCard, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  DollarSign, 
  Shield, 
  AlertTriangle,
  CheckCircle,
  Info,
  Trophy,
  Star,
  Target
} from "lucide-react";

interface CreditScenario {
  id: number;
  title: string;
  description: string;
  options: {
    text: string;
    impact: number;
    explanation: string;
  }[];
}

interface UserCreditData {
  creditScore: number;
  history: {
    scenario: string;
    choice: string;
    impact: number;
    newScore: number;
    date: string;
  }[];
  accounts: {
    type: string;
    status: string;
    balance: number;
    limit: number;
    paymentHistory: string;
    ageOfAccount: string;
  }[];
  inquiries: string[];
}

export default function CreditCourse() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentModule, setCurrentModule] = useState("welcome");
  const [userCredit, setUserCredit] = useState<UserCreditData>({
    creditScore: 300,
    history: [],
    accounts: [
      {
        type: 'Tutorial Account',
        status: 'Open',
        balance: 0,
        limit: 100,
        paymentHistory: 'N/A',
        ageOfAccount: '0 months'
      }
    ],
    inquiries: []
  });
  const [selectedScenario, setSelectedScenario] = useState<CreditScenario | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [lastChoice, setLastChoice] = useState<any>(null);

  const scenarios: CreditScenario[] = [
    {
      id: 1,
      title: "Pay Bills On Time",
      description: "You have the option to pay your phone bill on time or delay it by a week.",
      options: [
        {
          text: "Pay on time",
          impact: 10,
          explanation: "Paying bills on time is one of the most important factors in building a good credit score. It shows lenders you're reliable."
        },
        {
          text: "Pay late (1 week)",
          impact: -15,
          explanation: "Late payments can significantly hurt your credit score, especially if they're reported to credit bureaus."
        }
      ]
    },
    {
      id: 2,
      title: "Credit Card Usage",
      description: "You have a credit card with a $500 limit. How much should you spend this month?",
      options: [
        {
          text: "Spend $150 (30%)",
          impact: 5,
          explanation: "Using 30% or less of your credit limit is generally good for your credit score."
        },
        {
          text: "Spend $450 (90%)",
          impact: -20,
          explanation: "Using more than 90% of your credit limit can significantly hurt your credit score due to high utilization."
        },
        {
          text: "Don't use the card at all",
          impact: -5,
          explanation: "Not using your credit card at all doesn't help build credit history. Some usage is better than none."
        }
      ]
    },
    {
      id: 3,
      title: "Credit Check Decision",
      description: "A store offers you a discount if you apply for their store credit card. What do you do?",
      options: [
        {
          text: "Apply for the card",
          impact: -8,
          explanation: "Applying for credit causes a hard inquiry, which can temporarily lower your score. Only apply when you really need credit."
        },
        {
          text: "Decline the offer",
          impact: 0,
          explanation: "Good choice! Avoiding unnecessary credit applications helps protect your credit score."
        }
      ]
    },
    {
      id: 4,
      title: "Emergency Fund vs Credit",
      description: "You need $200 for car repairs. You can either use your emergency fund or put it on a credit card.",
      options: [
        {
          text: "Use emergency fund",
          impact: 5,
          explanation: "Using your emergency fund prevents debt and shows good financial planning."
        },
        {
          text: "Use credit card and pay minimum",
          impact: -10,
          explanation: "Only paying minimums leads to interest charges and potential debt problems."
        },
        {
          text: "Use credit card but pay it off quickly",
          impact: 2,
          explanation: "Using credit responsibly and paying it off quickly can actually help build credit history."
        }
      ]
    }
  ];

  const courseModules = [
    {
      id: "welcome",
      title: "🎯 Welcome to Credit 101",
      description: "Learn credit basics today, succeed financially tomorrow",
      icon: Target,
      color: "from-blue-500 to-purple-600"
    },
    {
      id: "basics",
      title: "💳 Credit Score Basics",
      description: "Understanding what credit scores are and why they matter",
      icon: CreditCard,
      color: "from-green-500 to-blue-600"
    },
    {
      id: "factors",
      title: "📊 What Affects Your Score",
      description: "The 5 key factors that determine your credit score",
      icon: TrendingUp,
      color: "from-purple-500 to-pink-600"
    },
    {
      id: "scenarios",
      title: "🎮 Interactive Scenarios",
      description: "Practice making financial decisions and see their impact",
      icon: Trophy,
      color: "from-orange-500 to-red-600"
    },
    {
      id: "report",
      title: "📋 Understanding Credit Reports",
      description: "Learn how to read and check your credit report",
      icon: Shield,
      color: "from-teal-500 to-green-600"
    },
    {
      id: "building",
      title: "🚀 Building Good Credit",
      description: "Practical tips for building and maintaining excellent credit",
      icon: Star,
      color: "from-indigo-500 to-purple-600"
    }
  ];

  const getCreditRating = (score: number) => {
    if (score >= 750) return { rating: 'Excellent', color: 'text-green-600', bgColor: 'bg-green-100' };
    if (score >= 700) return { rating: 'Good', color: 'text-blue-600', bgColor: 'bg-blue-100' };
    if (score >= 650) return { rating: 'Fair', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    if (score >= 600) return { rating: 'Poor', color: 'text-orange-600', bgColor: 'bg-orange-100' };
    return { rating: 'Very Poor', color: 'text-red-600', bgColor: 'bg-red-100' };
  };

  const handleScenarioChoice = (scenario: CreditScenario, choice: any) => {
    const newScore = Math.max(300, Math.min(850, userCredit.creditScore + choice.impact));
    const historyEntry = {
      scenario: scenario.title,
      choice: choice.text,
      impact: choice.impact,
      newScore,
      date: new Date().toLocaleDateString()
    };

    setUserCredit(prev => ({
      ...prev,
      creditScore: newScore,
      history: [...prev.history, historyEntry]
    }));

    setLastChoice({ scenario, choice, newScore });
    setShowResult(true);
    setSelectedScenario(null);
  };

  const creditRating = getCreditRating(userCredit.creditScore);

  const renderWelcome = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Credit for Starters</h1>
        <p className="text-xl text-gray-600 mb-8">Learn credit basics today, succeed financially tomorrow</p>
        
        <div className="mx-auto w-48 h-48 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-8">
          <div className="text-center text-white">
            <div className="text-2xl font-bold">CREDIT</div>
            <div className="text-4xl font-bold">101</div>
          </div>
        </div>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Welcome to Credit for Starters! This interactive course helps teens learn about credit scores through realistic scenarios. 
          Perfect for ages 12-18 to build financial literacy.
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>🎯 What You'll Learn</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>What credit scores are and why they matter</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>5 key factors that affect your credit</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>How to read a credit report</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Building good credit habits</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🎮 Interactive Learning</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-yellow-600" />
              <span>Real-world financial scenarios</span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-yellow-600" />
              <span>See immediate impact of decisions</span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-yellow-600" />
              <span>Track your virtual credit score</span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-yellow-600" />
              <span>Build confidence with money</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-center">
        <Button 
          onClick={() => setCurrentModule("basics")}
          size="lg"
          className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
        >
          Start Learning! 🚀
        </Button>
      </div>
    </div>
  );

  const renderBasics = () => (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-gray-900">💳 Credit Score Basics</h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>What is a Credit Score?</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              A credit score is like a report card for how you handle money. It's a number between 300-850 that tells lenders 
              how likely you are to pay back money you borrow.
            </p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>300-599: Very Poor</span>
                <span className="text-red-600">❌</span>
              </div>
              <div className="flex justify-between">
                <span>600-649: Poor</span>
                <span className="text-orange-600">⚠️</span>
              </div>
              <div className="flex justify-between">
                <span>650-699: Fair</span>
                <span className="text-yellow-600">⚡</span>
              </div>
              <div className="flex justify-between">
                <span>700-749: Good</span>
                <span className="text-blue-600">👍</span>
              </div>
              <div className="flex justify-between">
                <span>750-850: Excellent</span>
                <span className="text-green-600">🌟</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Why Does It Matter?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <DollarSign className="h-5 w-5 text-green-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Lower Interest Rates</h4>
                  <p className="text-sm text-gray-600">Save thousands on loans and credit cards</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-blue-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Better Approval Odds</h4>
                  <p className="text-sm text-gray-600">Get approved for apartments, cars, and more</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Star className="h-5 w-5 text-purple-600 mt-1" />
                <div>
                  <h4 className="font-semibold">More Opportunities</h4>
                  <p className="text-sm text-gray-600">Access to better financial products</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          💡 <strong>Fun Fact:</strong> Most people don't get their first credit score until they're 18 and get their first credit card. 
          Learning about it now gives you a huge head start!
        </AlertDescription>
      </Alert>

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setCurrentModule("welcome")}>
          ← Back
        </Button>
        <Button onClick={() => setCurrentModule("factors")}>
          Next: What Affects Your Score →
        </Button>
      </div>
    </div>
  );

  const renderFactors = () => (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-gray-900">📊 What Affects Your Credit Score</h2>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-600 font-bold">35%</div>
              Payment History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-3">
              This is the #1 factor! Do you pay your bills on time? Even one late payment can hurt your score.
            </p>
            <div className="bg-green-50 border-l-4 border-green-400 p-4">
              <p className="text-sm">💡 <strong>Pro Tip:</strong> Set up automatic payments to never miss a due date!</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-bold">30%</div>
              Credit Utilization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-3">
              How much of your available credit are you using? Keep it under 30% of your limit.
            </p>
            <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
              <p className="text-sm">💡 <strong>Example:</strong> If your credit limit is $1,000, try to keep your balance under $300.</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 font-bold">15%</div>
              Length of Credit History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              How long have you had credit accounts? Older accounts help your score, so don't close your first credit card!
            </p>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">10%</div>
                Credit Mix
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Having different types of credit (cards, loans) can help, but don't worry about this when starting out.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-bold">10%</div>
                New Credit
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm">
                Don't apply for too much credit at once. Each application can temporarily lower your score.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setCurrentModule("basics")}>
          ← Back
        </Button>
        <Button onClick={() => setCurrentModule("scenarios")}>
          Next: Try Interactive Scenarios →
        </Button>
      </div>
    </div>
  );

  const renderScenarios = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">🎮 Interactive Credit Scenarios</h2>
        <p className="text-lg text-gray-600 mb-6">
          Practice making financial decisions and see how they affect your credit score!
        </p>
        
        {/* Current Credit Score Display */}
        <Card className="max-w-md mx-auto mb-8">
          <CardHeader>
            <CardTitle>Your Current Credit Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className={`text-4xl font-bold ${creditRating.color} mb-2`}>
                {userCredit.creditScore}
              </div>
              <Badge className={`${creditRating.bgColor} ${creditRating.color} border-0`}>
                {creditRating.rating}
              </Badge>
              <div className="mt-4">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>300</span>
                  <span>850</span>
                </div>
                <Progress 
                  value={((userCredit.creditScore - 300) / 550) * 100} 
                  className="h-3"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Scenarios Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {scenarios.map((scenario) => (
          <Card key={scenario.id} className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg">{scenario.title}</CardTitle>
              <CardDescription>{scenario.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    className="w-full" 
                    onClick={() => setSelectedScenario(scenario)}
                  >
                    Make Your Choice
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>{scenario.title}</DialogTitle>
                    <DialogDescription>{scenario.description}</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    {scenario.options.map((option, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className="w-full text-left justify-start h-auto p-4"
                        onClick={() => handleScenarioChoice(scenario, option)}
                      >
                        <div>
                          <div className="font-medium">{option.text}</div>
                          <div className={`text-sm mt-1 ${option.impact > 0 ? 'text-green-600' : option.impact < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                            Impact: {option.impact > 0 ? '+' : ''}{option.impact} points
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Results Dialog */}
      <Dialog open={showResult} onOpenChange={setShowResult}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {lastChoice?.choice.impact > 0 ? (
                <TrendingUp className="h-5 w-5 text-green-600" />
              ) : lastChoice?.choice.impact < 0 ? (
                <TrendingDown className="h-5 w-5 text-red-600" />
              ) : (
                <Info className="h-5 w-5 text-gray-600" />
              )}
              Result: {lastChoice?.choice.text}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-600">{lastChoice?.choice.explanation}</p>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center">
                <span>Score Change:</span>
                <span className={`font-bold ${lastChoice?.choice.impact > 0 ? 'text-green-600' : lastChoice?.choice.impact < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                  {lastChoice?.choice.impact > 0 ? '+' : ''}{lastChoice?.choice.impact}
                </span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span>New Score:</span>
                <span className="font-bold text-lg">{lastChoice?.newScore}</span>
              </div>
            </div>
            <Button onClick={() => setShowResult(false)} className="w-full">
              Continue Learning
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Credit History */}
      {userCredit.history.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>📊 Your Credit Journey</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {userCredit.history.slice(-5).map((entry, index) => (
                <div key={index} className="flex justify-between items-center py-2 border-b last:border-b-0">
                  <div>
                    <div className="font-medium">{entry.scenario}</div>
                    <div className="text-sm text-gray-600">{entry.choice}</div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold ${entry.impact > 0 ? 'text-green-600' : entry.impact < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                      {entry.impact > 0 ? '+' : ''}{entry.impact}
                    </div>
                    <div className="text-sm text-gray-600">{entry.newScore}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setCurrentModule("factors")}>
          ← Back
        </Button>
        <Button onClick={() => setCurrentModule("report")}>
          Next: Understanding Credit Reports →
        </Button>
      </div>
    </div>
  );

  const renderReport = () => (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-gray-900">📋 Understanding Credit Reports</h2>
      
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          A credit report is like a detailed report card that shows your entire credit history. 
          Here's what you'll find on yours:
        </AlertDescription>
      </Alert>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>📋 Your Sample Credit Report</CardTitle>
            <CardDescription>This shows what a real credit report looks like</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Personal Info Section */}
              <div>
                <h4 className="font-semibold text-lg mb-3">Personal Information</h4>
                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-sm text-gray-600">Name:</span>
                      <div className="font-medium">Student User</div>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600">Age:</span>
                      <div className="font-medium">16 years old</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Accounts Section */}
              <div>
                <h4 className="font-semibold text-lg mb-3">Credit Accounts</h4>
                <div className="space-y-3">
                  {userCredit.accounts.map((account, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <span className="text-sm text-gray-600">Account Type:</span>
                          <div className="font-medium">{account.type}</div>
                        </div>
                        <div>
                          <span className="text-sm text-gray-600">Status:</span>
                          <div className="font-medium text-green-600">{account.status}</div>
                        </div>
                        <div>
                          <span className="text-sm text-gray-600">Balance/Limit:</span>
                          <div className="font-medium">${account.balance}/${account.limit}</div>
                        </div>
                        <div>
                          <span className="text-sm text-gray-600">Age:</span>
                          <div className="font-medium">{account.ageOfAccount}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Inquiries Section */}
              <div>
                <h4 className="font-semibold text-lg mb-3">Recent Credit Inquiries</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  {userCredit.inquiries.length === 0 ? (
                    <p className="text-gray-600">No recent credit inquiries - Great job!</p>
                  ) : (
                    <div className="space-y-2">
                      {userCredit.inquiries.map((inquiry, index) => (
                        <div key={index} className="flex justify-between">
                          <span>{inquiry}</span>
                          <span className="text-sm text-gray-600">Recent</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🔍 How to Check for Errors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Check Personal Information</h4>
                  <p className="text-sm text-gray-600">Make sure your name, address, and other details are correct</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Review All Accounts</h4>
                  <p className="text-sm text-gray-600">Look for accounts you don't recognize or incorrect balances</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Check Payment History</h4>
                  <p className="text-sm text-gray-600">Make sure all payments are recorded accurately</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-orange-600 mt-1" />
                <div>
                  <h4 className="font-semibold">Dispute Errors Immediately</h4>
                  <p className="text-sm text-gray-600">Contact the credit bureau right away if you find mistakes</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setCurrentModule("scenarios")}>
          ← Back
        </Button>
        <Button onClick={() => setCurrentModule("building")}>
          Next: Building Good Credit →
        </Button>
      </div>
    </div>
  );

  const renderBuilding = () => (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-gray-900">🚀 Building Good Credit</h2>
      
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-500" />
              The Golden Rules of Credit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-blue-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Always Pay On Time</h4>
                    <p className="text-sm text-gray-600">Set up automatic payments to never miss a due date</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <TrendingDown className="h-5 w-5 text-green-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Keep Balances Low</h4>
                    <p className="text-sm text-gray-600">Use less than 30% of your available credit</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-purple-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Keep Old Accounts Open</h4>
                    <p className="text-sm text-gray-600">Longer credit history helps your score</p>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-orange-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Limit New Applications</h4>
                    <p className="text-sm text-gray-600">Only apply for credit when you really need it</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-teal-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Monitor Your Report</h4>
                    <p className="text-sm text-gray-600">Check for errors and fraud regularly</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <DollarSign className="h-5 w-5 text-green-600 mt-1" />
                  <div>
                    <h4 className="font-semibold">Pay More Than Minimum</h4>
                    <p className="text-sm text-gray-600">Pay off balances quickly to save on interest</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🎯 Credit Building Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold">18+</span>
                </div>
                <div>
                  <h4 className="font-semibold">Get Your First Credit Card</h4>
                  <p className="text-sm text-gray-600">Start with a student card or secured card</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 font-bold">3-6</span>
                </div>
                <div>
                  <h4 className="font-semibold">Build Payment History (Months)</h4>
                  <p className="text-sm text-gray-600">Make small purchases and pay them off in full</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <span className="text-purple-600 font-bold">1+</span>
                </div>
                <div>
                  <h4 className="font-semibold">See Score Improvement (Years)</h4>
                  <p className="text-sm text-gray-600">Consistent good habits lead to excellent credit</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>🎉 Congratulations!</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                <Trophy className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-xl font-bold">You've Completed Credit for Starters!</h3>
              <p className="text-gray-600">
                You now understand the basics of credit scores, what affects them, and how to build excellent credit. 
                Remember: good credit habits start early and compound over time!
              </p>
              <div className="grid md:grid-cols-3 gap-4 mt-6">
                <Badge variant="secondary" className="p-3">
                  ✅ Credit Basics Mastered
                </Badge>
                <Badge variant="secondary" className="p-3">
                  🎮 Scenarios Completed
                </Badge>
                <Badge variant="secondary" className="p-3">
                  📊 Ready to Build Credit
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <Button variant="outline" onClick={() => setCurrentModule("report")}>
          ← Back
        </Button>
        <Button onClick={() => setCurrentModule("welcome")} className="bg-gradient-to-r from-green-500 to-blue-600">
          🏆 Course Complete! Start Over?
        </Button>
      </div>
    </div>
  );

  const renderCurrentModule = () => {
    switch (currentModule) {
      case "welcome": return renderWelcome();
      case "basics": return renderBasics();
      case "factors": return renderFactors();
      case "scenarios": return renderScenarios();
      case "report": return renderReport();
      case "building": return renderBuilding();
      default: return renderWelcome();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Module Navigation */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 justify-center">
            {courseModules.map((module) => {
              const IconComponent = module.icon;
              return (
                <Button
                  key={module.id}
                  variant={currentModule === module.id ? "default" : "outline"}
                  onClick={() => setCurrentModule(module.id)}
                  className={`${currentModule === module.id ? `bg-gradient-to-r ${module.color} text-white` : ''}`}
                >
                  <IconComponent className="h-4 w-4 mr-2" />
                  {module.title}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Main Content */}
        {renderCurrentModule()}
      </div>
    </div>
  );
}