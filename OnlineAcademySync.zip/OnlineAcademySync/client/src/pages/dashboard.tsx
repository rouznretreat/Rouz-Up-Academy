import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, Clock, Award, TrendingUp, Play, CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/enrollments"],
  });

  const inProgressCourses = enrollments.filter(e => e.progress > 0 && e.progress < 100);
  const completedCourses = enrollments.filter(e => e.progress === 100);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white lg:hidden flex flex-col justify-center items-center space-y-8 text-xl font-semibold text-gray-800">
          <a href="/" className="hover:text-blue-600 transition-colors">Home</a>
          <a href="/courses" className="hover:text-blue-600 transition-colors">Courses</a>
          <a href="/subscribe" className="hover:text-blue-600 transition-colors">Membership</a>
          <Button 
            onClick={() => window.location.href = '/api/logout'}
            variant="outline"
            className="px-8 py-3 rounded-full font-semibold"
          >
            Sign Out
          </Button>
        </div>
      )}

      {/* Page Header */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Learning <span className="relative">Dashboard
                <div className="absolute bottom-0 left-0 w-full h-2 bg-yellow-400 rounded -z-10"></div>
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Track your progress and continue your financial education journey, {user?.firstName || 'Student'}.
            </p>
          </div>

          {/* Membership Status */}
          <div className="max-w-md mx-auto">
            <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
              <div className="flex items-center justify-center mb-2">
                <Badge 
                  variant={user?.membershipTier === 'free' ? 'secondary' : 'default'}
                  className="text-lg px-4 py-2"
                >
                  {user?.membershipTier?.toUpperCase() || 'FREE'} MEMBER
                </Badge>
              </div>
              {user?.membershipTier === 'free' && (
                <p className="text-sm text-gray-600 mb-4">Upgrade for unlimited access to all courses</p>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Overview */}
      {stats && (
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <BookOpen className="w-8 h-8 text-blue-600" />
                  <span className="text-sm font-medium text-gray-500">Courses</span>
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.coursesCompleted}</div>
                <div className="text-sm text-gray-600">Completed</div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <Clock className="w-8 h-8 text-yellow-500" />
                  <span className="text-sm font-medium text-gray-500">Hours</span>
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.totalHours}</div>
                <div className="text-sm text-gray-600">Learning Time</div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <Award className="w-8 h-8 text-green-500" />
                  <span className="text-sm font-medium text-gray-500">Certificates</span>
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.certificates}</div>
                <div className="text-sm text-gray-600">Earned</div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <TrendingUp className="w-8 h-8 text-indigo-500" />
                  <span className="text-sm font-medium text-gray-500">Progress</span>
                </div>
                <div className="text-3xl font-bold text-gray-900">{stats.overallProgress}%</div>
                <div className="text-sm text-gray-600">Overall</div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Continue Learning */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Continue Learning</h3>
              
              {inProgressCourses.length === 0 ? (
                <div className="text-center py-8">
                  <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">No courses in progress</p>
                  <Button onClick={() => window.location.href = '/courses'}>
                    Browse Courses
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {inProgressCourses.map((enrollment) => (
                    <div key={enrollment.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl">
                      <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center">
                        <BookOpen className="w-8 h-8 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{enrollment.course.title}</h4>
                        <div className="mt-2">
                          <Progress value={enrollment.progress} className="w-full" />
                        </div>
                        <div className="text-sm text-gray-600 mt-1">{enrollment.progress}% Complete</div>
                      </div>
                      <Button className="bg-blue-600 text-white hover:bg-blue-700">
                        <Play className="w-4 h-4 mr-2" />
                        Continue
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Achievements */}
            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Recent Achievements</h3>
              
              {completedCourses.length === 0 ? (
                <div className="text-center py-8">
                  <Award className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">No achievements yet</p>
                  <p className="text-sm text-gray-500">Complete your first course to earn an achievement!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Course Master Achievement */}
                  {stats && stats.coursesCompleted >= 10 && (
                    <div className="flex items-center space-x-4 p-4 bg-yellow-50 rounded-xl border border-yellow-200">
                      <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                        <Award className="w-6 h-6 text-yellow-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Course Master</h4>
                        <p className="text-sm text-gray-600">Completed 10+ courses</p>
                      </div>
                    </div>
                  )}

                  {/* Perfect Score Achievement */}
                  {stats && stats.overallProgress === 100 && (
                    <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-xl border border-green-200">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Perfect Progress</h4>
                        <p className="text-sm text-gray-600">100% overall completion rate</p>
                      </div>
                    </div>
                  )}

                  {/* Recent Completions */}
                  {completedCourses.slice(0, 3).map((enrollment) => (
                    <div key={enrollment.id} className="flex items-center space-x-4 p-4 bg-blue-50 rounded-xl border border-blue-200">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Course Completed</h4>
                        <p className="text-sm text-gray-600">{enrollment.course.title}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* All Enrollments */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">My Courses</h3>
              <Button 
                onClick={() => window.location.href = '/courses'}
                variant="outline"
              >
                Browse More Courses
              </Button>
            </div>

            {enrollments.length === 0 ? (
              <div className="text-center py-8">
                <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h4 className="text-xl font-semibold text-gray-900 mb-2">No courses enrolled</h4>
                <p className="text-gray-600 mb-6">Start your financial education journey by enrolling in a course</p>
                <Button onClick={() => window.location.href = '/courses'}>
                  Browse Courses
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {enrollments.map((enrollment) => (
                  <div key={enrollment.id} className="border border-gray-200 rounded-xl p-4 hover:shadow-lg transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-gray-900">{enrollment.course.title}</h4>
                      {enrollment.progress === 100 ? (
                        <Badge className="bg-green-100 text-green-800">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completed
                        </Badge>
                      ) : enrollment.progress > 0 ? (
                        <Badge variant="secondary">In Progress</Badge>
                      ) : (
                        <Badge variant="outline">Not Started</Badge>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">{enrollment.course.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{enrollment.progress}%</span>
                      </div>
                      <Progress value={enrollment.progress} className="w-full" />
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">{enrollment.course.level}</span>
                      <Button size="sm" className="bg-blue-600 text-white hover:bg-blue-700">
                        {enrollment.progress === 0 ? 'Start' : 'Continue'}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
