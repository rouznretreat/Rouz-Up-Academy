import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Clock, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import VirtualBankAccount from "@/components/VirtualBankAccount";
import AccountComparison from "@/components/AccountComparison";

export default function BankingCourse() {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("learn");

  const courseModules = [
    {
      id: "banking-basics",
      title: "Banking Basics + Learning Path",
      description: "Master the fundamentals: How banks work, your financial journey roadmap, and why banking is your first step to building wealth. This foundational module sets up your entire money success story!"
    },
    {
      id: "saving-vs-growing",
      title: "Saving vs. Growing",
      description: "Discover why simply saving isn't enough and how to make your money work for you."
    },
    {
      id: "account-types",
      title: "Account Types",
      description: "Explore different banking and investment accounts and which ones are best for your goals."
    },
    {
      id: "compound-interest",
      title: "Compound Interest",
      description: "Understand how compound interest works and why it's called the 'eighth wonder of the world'."
    },
    {
      id: "investing-basics",
      title: "Investing Basics",
      description: "Learn the fundamentals of investing and how you can start building wealth for your future."
    },
    {
      id: "setting-goals",
      title: "Setting Financial Goals",
      description: "Learn how to set achievable financial goals and create a plan to reach them."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Attractive Header */}
      <div className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="text-5xl">🏦</div>
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">Banking for Starters</h1>
                <p className="text-xl text-blue-100">Your journey to financial freedom starts here! 💰✨</p>
              </div>
            </div>
            <Link href="/">
              <Button variant="outline" size="sm" className="bg-white/20 text-white border-white/30 hover:bg-white/30 font-medium backdrop-blur-sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Academy
              </Button>
            </Link>
          </div>
          
          {/* Achievement badges */}
          <div className="flex flex-wrap gap-3">
            <div className="bg-yellow-400 text-blue-900 px-4 py-2 text-sm font-bold rounded-full">
              🎯 Perfect for Teens
            </div>
            <div className="bg-green-400 text-blue-900 px-4 py-2 text-sm font-bold rounded-full">
              🎮 Interactive Learning
            </div>
            <div className="bg-pink-400 text-blue-900 px-4 py-2 text-sm font-bold rounded-full">
              💎 Build Wealth Skills
            </div>
            <div className="bg-purple-400 text-blue-900 px-4 py-2 text-sm font-bold rounded-full">
              🚀 6 Power Modules
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <div 
              onClick={() => setActiveTab("learn")}
              className={`px-3 py-4 text-sm font-medium cursor-pointer transition-colors ${
                activeTab === "learn" 
                  ? "text-blue-600 border-b-2 border-blue-600" 
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              📚 Learn
            </div>
            <div 
              onClick={() => setActiveTab("tools")}
              className={`px-3 py-4 text-sm font-medium cursor-pointer transition-colors ${
                activeTab === "tools" 
                  ? "text-blue-600 border-b-2 border-blue-600" 
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              🧮 Tools
            </div>
            <div 
              onClick={() => setActiveTab("games")}
              className={`px-3 py-4 text-sm font-medium cursor-pointer transition-colors ${
                activeTab === "games" 
                  ? "text-blue-600 border-b-2 border-blue-600" 
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              🎮 Games
            </div>
            <div 
              onClick={() => setActiveTab("goals")}
              className={`px-3 py-4 text-sm font-medium cursor-pointer transition-colors ${
                activeTab === "goals" 
                  ? "text-blue-600 border-b-2 border-blue-600" 
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              🎯 Goals
            </div>
            <div 
              onClick={() => setActiveTab("banking")}
              className={`px-3 py-4 text-sm font-medium cursor-pointer transition-colors ${
                activeTab === "banking" 
                  ? "text-blue-600 border-b-2 border-blue-600" 
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              🏦 Banking
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "learn" && (
          <>
            {/* Learning Modules Header */}
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">🎓 Master Your Money Skills</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Complete these powerful modules to unlock your financial superpowers! Each lesson builds on the last to create your wealth-building foundation.
              </p>
            </div>

            {/* Module Cards - Box Layout with 2 per row */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {courseModules.map((module, index) => (
                <div key={module.id} className="bg-white rounded-xl border-2 border-gray-200 p-6 hover:shadow-lg hover:border-blue-300 transition-all duration-300 group">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                          {module.title}
                        </h3>
                        <Badge variant="secondary" className="mt-1">
                          <Clock className="w-3 h-3 mr-1" />
                          15-20 min
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {module.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-green-600 font-medium bg-green-100 px-3 py-1 rounded-full">
                        📚 Essential
                      </span>
                    </div>
                    <Link href={`/${module.id}`}>
                      <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white hover:from-blue-600 hover:to-cyan-600 px-6 py-2 rounded-full font-medium">
                        Start Module
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {activeTab === "tools" && (
          <>
            {/* Financial Tools Header */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Financial Calculators</h2>
              <p className="text-lg text-gray-600">
                Use these powerful tools to plan your financial future and make smart money decisions.
              </p>
            </div>

            {/* Calculator Cards */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Link href="/allowance-calculator">
                  <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow cursor-pointer">
                    <div className="text-3xl mb-3">💰</div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Allowance Calculator</h3>
                    <p className="text-gray-600 mb-4">Plan how to manage your allowance, set savings goals, and track your spending.</p>
                    <Button className="bg-green-600 text-white hover:bg-green-700 px-4 py-2 text-sm w-full">
                      Use Calculator
                    </Button>
                  </div>
                </Link>

              <Link href="/savings-growth-calculator">
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="text-3xl mb-3">📈</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Savings Growth Calculator</h3>
                  <p className="text-gray-600 mb-4">See how your savings can grow over time with compound interest.</p>
                  <Button className="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 text-sm w-full">
                    Use Calculator
                  </Button>
                </div>
              </Link>

              <Link href="/savings-goal-calculator">
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="text-3xl mb-3">🎯</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Savings Goal Calculator</h3>
                  <p className="text-gray-600 mb-4">Calculate how much you need to save each month to reach your financial goals.</p>
                  <Button className="bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 text-sm w-full">
                    Use Calculator
                  </Button>
                </div>
              </Link>
            </div>
          </>
        )}

        {activeTab === "games" && (
          <>
            {/* Games Header */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Financial Games</h2>
              <p className="text-lg text-gray-600">
                Have fun while learning important money concepts with these interactive games.
              </p>
            </div>

            {/* Financial Game Center */}
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Financial Game Center</h3>
              
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* Real Estate Banking Game */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">🏠</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Real Estate Banking Game</h4>
                  <p className="text-gray-600 mb-4">Learn real estate investing and banking decisions through interactive gameplay.</p>
                  <Link href="/real-estate-banking-game">
                    <Button className="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 text-sm w-full">
                      Play Game
                    </Button>
                  </Link>
                </div>

                {/* Baby Steps Savings Challenge */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">👶</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Baby Steps Savings Challenge</h4>
                  <p className="text-gray-600 mb-4">Follow Dave Ramsey's 7 steps to financial freedom.</p>
                  <Link href="/baby-steps-challenge">
                    <Button className="bg-green-600 text-white hover:bg-green-700 px-4 py-2 text-sm w-full">
                      Start Challenge
                    </Button>
                  </Link>
                </div>

                {/* Coin Flip Challenge */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">🪙</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Coin Flip Challenge</h4>
                  <p className="text-gray-600 mb-4">Learn about probability and risk by betting on coin flips.</p>
                  <Link href="/coin-flip-game">
                    <Button className="bg-yellow-600 text-white hover:bg-yellow-700 px-4 py-2 text-sm w-full">
                      Flip Coins
                    </Button>
                  </Link>
                </div>

                {/* Career & Income Game */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">💼</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Career & Income Game</h4>
                  <p className="text-gray-600 mb-4">Simulate 5 years of career and financial decisions.</p>
                  <Link href="/career-income-game">
                    <Button className="bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 text-sm w-full">
                      Start Journey
                    </Button>
                  </Link>
                </div>

                {/* Budget Blaster */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">💥</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Budget Blaster</h4>
                  <p className="text-gray-600 mb-4">Manage your money through 4 weeks of unexpected events.</p>
                  <Link href="/budget-blaster">
                    <Button className="bg-red-600 text-white hover:bg-red-700 px-4 py-2 text-sm w-full">
                      Start Game
                    </Button>
                  </Link>
                </div>

                {/* Stock Market Simulator */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">📈</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Stock Market Simulator</h4>
                  <p className="text-gray-600 mb-4">Buy and sell stocks to grow your investment portfolio.</p>
                  <Link href="/stock-simulator">
                    <Button className="bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 text-sm w-full">
                      Trade Stocks
                    </Button>
                  </Link>
                </div>

                {/* Debt Escape Room */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">🔓</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Debt Escape Room</h4>
                  <p className="text-gray-600 mb-4">Solve debt puzzles to escape the debt trap forever!</p>
                  <Link href="/debt-escape-room">
                    <Button className="bg-red-600 text-white hover:bg-red-700 px-4 py-2 text-sm w-full">
                      Break Free
                    </Button>
                  </Link>
                </div>

                {/* Money Time Travel */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">⏰</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Money Time Travel</h4>
                  <p className="text-gray-600 mb-4">See how starting age affects your wealth at retirement.</p>
                  <Link href="/money-time-travel">
                    <Button className="bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 text-sm w-full">
                      Time Travel
                    </Button>
                  </Link>
                </div>

                {/* Banking Trivia Showdown */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">🏆</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Banking Trivia Showdown</h4>
                  <p className="text-gray-600 mb-4">Test your banking knowledge with rapid-fire questions!</p>
                  <Link href="/banking-trivia-showdown">
                    <Button className="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 text-sm w-full">
                      Start Quiz
                    </Button>
                  </Link>
                </div>

                {/* Savings Challenge Game */}
                <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                  <div className="text-3xl mb-3">🎯</div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">Savings Challenge</h4>
                  <p className="text-gray-600 mb-4">Complete real savings goals with unexpected events!</p>
                  <Link href="/savings-challenge-game">
                    <Button className="bg-green-600 text-white hover:bg-green-700 px-4 py-2 text-sm w-full">
                      Take Challenge
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "goals" && (
          <>
            {/* Goals Header */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Financial Goals</h2>
              <p className="text-lg text-gray-600">
                Set and track your financial goals to build wealth over time.
              </p>
            </div>
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🎯</div>
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Goal Tracking Coming Soon!</h3>
              <p className="text-gray-500">Advanced goal setting features are in development.</p>
            </div>
          </>
        )}

        {activeTab === "banking" && (
          <>
            {/* Banking Header */}
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Virtual Banking Simulator</h2>
              <p className="text-lg text-gray-600">
                Practice real banking skills with our virtual bank account simulator.
              </p>
            </div>
            
            {/* Virtual Bank Account Simulator */}
            <VirtualBankAccount />
          </>
        )}

        {activeTab === "learn" && (
          <>



          </>
        )}
      </div>
    </div>
  );
}