import { useState } from "react";
import { ArrowLeft, PlayCircle, CheckCircle, DollarSign, TrendingUp, Star, Book, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import CashFlowQuiz from "@/components/CashFlowQuiz";
import BusinessGlossary from "@/components/BusinessGlossary";
import BusinessQuiz from "@/components/BusinessQuiz";

export default function BusinessCourse() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeModule, setActiveModule] = useState(0);
  const [showCashFlowQuiz, setShowCashFlowQuiz] = useState(false);
  const [activeQuiz, setActiveQuiz] = useState<string | null>(null);

  const courseModules = [
    {
      title: "Cash Flow Quadrant",
      lessons: [
        "Understanding the Cash Flow Quadrant",
        "E - Employee: Working for Someone Else",
        "S - Self-Employed: Owning Your Job", 
        "B - Business Owner: Creating Systems",
        "I - Investor: Money Working for You",
        "Your Path to Financial Freedom",
        "Moving from Left Side to Right Side",
        "Find Your Quadrant Quiz"
      ],
      description: "A concept developed by Robert Kiyosaki that helps you understand the four different ways people make money and your path to financial freedom."
    },
    {
      title: "What is a Business",
      lessons: [
        "Understanding Business as a Legal Entity",
        "The Concept of Corporate Personhood",
        "Limited Liability Protection",
        "Business vs. Hobby",
        "Rights and Responsibilities",
        "Test Your Knowledge Quiz"
      ],
      description: "Learn how a business is more than just selling products - it's a separate legal entity with its own rights and responsibilities."
    },
    {
      title: "Business Structures",
      lessons: [
        "Choosing the Right Entity",
        "Sole Proprietorship",
        "Partnership",
        "Limited Liability Company (LLC)",
        "Corporation",
        "Considerations When Choosing",
        "Test Your Knowledge Quiz"
      ],
      description: "Explore different business structures and their legal and tax implications to choose the right entity for your business."
    },
    {
      title: "Business Finance",
      lessons: [
        "Understanding Business Finance",
        "The Three Key Financial Statements", 
        "Income Statement",
        "Balance Sheet",
        "Cash Flow Statement",
        "Financial Planning Basics",
        "Test Your Knowledge Quiz"
      ],
      description: "Learn the basics of business finance, including income statements, balance sheets, and cash flow."
    },
    {
      title: "Marketing Basics",
      lessons: [
        "What is Marketing?",
        "The Marketing Mix: The 4 Ps",
        "Understanding Your Target Audience",
        "Customer Research Methods",
        "Marketing Channels",
        "Digital Marketing Fundamentals",
        "Test Your Knowledge Quiz"
      ],
      description: "Discover the fundamentals of marketing and how to reach your target audience effectively."
    },
    {
      title: "Business Glossary",
      lessons: [],
      description: "Essential business terms and definitions to help you understand key concepts throughout your learning journey."
    }
  ];

  if (showCashFlowQuiz) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setShowCashFlowQuiz(false)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Course
            </Button>
          </div>
          
          <CashFlowQuiz />
        </div>
      </div>
    );
  }

  if (activeQuiz) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveQuiz(null)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Course
            </Button>
          </div>
          
          <BusinessQuiz moduleType={activeQuiz as "business" | "structures"} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Welcome Section - Authentic Layout */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-green-500 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center mb-8">
            <Button 
              onClick={() => window.history.back()}
              size="sm"
              className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-4 py-2 text-sm"
            >
              <ArrowLeft className="w-3 h-3 mr-2" />
              Back to Academy
            </Button>
            
            <Button 
              size="sm"
              className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-4 py-2 text-sm"
            >
              <Star className="w-3 h-3 mr-2" />
              My Badges
            </Button>
          </div>
          
          <h1 className="text-5xl lg:text-6xl font-bold mb-6">Welcome to Rouz Up!</h1>
          <p className="text-2xl text-white/90 mb-8">
            Your adventure to becoming a future business superstar starts here!
          </p>
          
          <div className="flex justify-center">
            <Button 
              size="lg"
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            >
              Start Your Journey <TrendingUp className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Business Modules Section - 2-Column Card Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Business Modules</h1>
          </div>
          
          {/* 2-Column Grid Layout */}
          <div className="grid grid-cols-2 gap-6">
            {courseModules.map((module, index) => (
              <div 
                key={index} 
                className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow duration-200 group cursor-pointer"
                onClick={() => setActiveModule(index)}
              >
                <div className="relative bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
                  <div className="absolute top-2 left-2">
                    <div className="bg-green-500 text-white text-xs px-2 py-1 rounded">
                      FREE
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs flex items-center">
                    <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                    4.8
                  </div>
                  <div className="mt-4 text-center">
                    <h3 className="font-bold text-lg text-gray-900 mb-1">{module.title}</h3>
                  </div>
                </div>
                
                <div className="p-4">
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{module.description}</p>
                  
                  <div className="flex items-center justify-between mb-3 text-xs text-gray-500">
                    <div className="flex items-center">
                      <PlayCircle className="w-3 h-3 mr-1" />
                      {module.lessons?.length || 0} lessons
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      45 min
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mb-3">
                    <span className="font-bold text-sm text-gray-900">Free</span>
                    <span className="text-xs text-gray-500">Beginner</span>
                  </div>
                  
                  <Button 
                    className="w-full bg-blue-600 text-white hover:bg-blue-700 text-xs py-2"
                  >
                    🚀 Start Learning
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          {/* Active Module Content */}
          <div className="mt-12">
            {courseModules.map((module, index) => (
              activeModule === index && (
                <Card key={index} className="bg-white shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-2xl">{module.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    
                    {index === 0 && (
                      <div className="mt-6 p-6 bg-green-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Understanding the Cash Flow Quadrant</h3>
                        <p className="text-gray-700 mb-6">
                          The Cash Flow Quadrant is a concept developed by Robert Kiyosaki that helps you understand the four different ways people make money:
                        </p>
                        
                        <div className="grid md:grid-cols-2 gap-6 mb-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-red-500">
                            <h4 className="font-bold text-lg text-red-600 mb-2">E - Employee</h4>
                            <p className="text-gray-700 text-sm">
                              Employees work for someone else. They have job security and a regular paycheck, but limited income potential and control.
                            </p>
                            <div className="mt-2 text-xs text-gray-500">You have a job</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                            <h4 className="font-bold text-lg text-orange-600 mb-2">S - Self-Employed</h4>
                            <p className="text-gray-700 text-sm">
                              Self-employed people own their own job. They have more control but still trade time for money - when they stop working, the income stops.
                            </p>
                            <div className="mt-2 text-xs text-gray-500">You own a job</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h4 className="font-bold text-lg text-blue-600 mb-2">B - Business Owner</h4>
                            <p className="text-gray-700 text-sm">
                              Business owners create systems that generate money even when they're not personally working. They leverage other people's time and skills.
                            </p>
                            <div className="mt-2 text-xs text-gray-500">You own a system</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                            <h4 className="font-bold text-lg text-green-600 mb-2">I - Investor</h4>
                            <p className="text-gray-700 text-sm">
                              Investors make money from their investments - their money works for them. This can include stocks, real estate, or businesses they invest in.
                            </p>
                            <div className="mt-2 text-xs text-gray-500">Money works for you</div>
                          </div>
                        </div>
                        
                        <div className="bg-white p-6 rounded-lg">
                          <h4 className="font-bold text-lg mb-3">Your Path to Financial Freedom</h4>
                          <p className="text-gray-700 mb-4">
                            Moving from the left side (E and S) to the right side (B and I) of the quadrant is how many people achieve financial freedom. The right side offers more leverage, potential for passive income, and tax advantages.
                          </p>
                          <p className="text-gray-700 mb-4">
                            Take the quiz to discover which quadrant best matches your current mindset and where you might want to focus your future efforts!
                          </p>
                          
                          <Button 
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-6 py-3 rounded-lg font-semibold transform hover:scale-105 transition-all duration-200"
                            onClick={() => setShowCashFlowQuiz(true)}
                          >
                            🎯 DISCOVER YOUR MONEY SUPERPOWER! 💰✨
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {index === 1 && (
                      <div className="mt-6 p-6 bg-blue-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Understanding Business as a Legal Entity</h3>
                        <p className="text-gray-700 mb-4">
                          A business is more than just selling products or services. In legal terms, a business is considered a separate "person" with its own rights and responsibilities.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">The Concept of "Corporate Personhood"</h4>
                        <p className="text-gray-700 mb-3">
                          One of the most important concepts in business law is that a corporation is treated as a separate legal entity from its owners. This means:
                        </p>
                        <ul className="list-disc list-inside text-gray-700 mb-4 space-y-1">
                          <li>A business can enter contracts</li>
                          <li>A business can own property</li>
                          <li>A business can sue and be sued</li>
                          <li>A business pays its own taxes</li>
                          <li>A business can continue to exist even if ownership changes</li>
                        </ul>
                        
                        <h4 className="text-lg font-bold mb-3">Limited Liability</h4>
                        <p className="text-gray-700 mb-4">
                          Perhaps the biggest advantage of establishing a formal business entity is limited liability. This means that the owners' personal assets are separate from the company's liabilities. If the business fails or is sued, the owners' personal property is typically protected.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">Business vs. Hobby</h4>
                        <p className="text-gray-700 mb-4">
                          The IRS distinguishes between businesses and hobbies. A true business is operated with the intent to make a profit. Even if you're earning money from something you love, it needs to be structured properly to be considered a business.
                        </p>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("business")}
                            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            🧠 QUIZ TIME! Are You Business Smart? 🚀
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {index === 2 && (
                      <div className="mt-6 p-6 bg-purple-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Business Structures: Choosing the Right Entity</h3>
                        <p className="text-gray-700 mb-6">
                          The business structure you choose will have legal and tax implications. Here are the most common types of business structures:
                        </p>
                        
                        <div className="space-y-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-red-500">
                            <h4 className="font-bold text-lg mb-2">Sole Proprietorship</h4>
                            <p className="text-gray-700 text-sm mb-3">
                              This is the simplest business structure where one person owns and operates the business. The business and the owner are the same legal entity.
                            </p>
                            <div className="text-sm">
                              <p className="font-semibold text-green-600">Advantages:</p>
                              <p className="text-gray-600 mb-2">Easy to form, complete control, minimal legal restrictions</p>
                              <p className="font-semibold text-red-600">Disadvantages:</p>
                              <p className="text-gray-600">Unlimited personal liability, harder to raise money</p>
                            </div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                            <h4 className="font-bold text-lg mb-2">Partnership</h4>
                            <p className="text-gray-700 text-sm mb-3">
                              A partnership is a single business where two or more people share ownership.
                            </p>
                            <div className="text-sm">
                              <p className="font-semibold text-green-600">Advantages:</p>
                              <p className="text-gray-600 mb-2">Easy to establish, shared financial commitment</p>
                              <p className="font-semibold text-red-600">Disadvantages:</p>
                              <p className="text-gray-600">Unlimited liability, potential conflicts between partners</p>
                            </div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h4 className="font-bold text-lg mb-2">Limited Liability Company (LLC)</h4>
                            <p className="text-gray-700 text-sm mb-3">
                              An LLC combines the pass-through taxation of a partnership or sole proprietorship with the limited liability of a corporation.
                            </p>
                            <div className="text-sm">
                              <p className="font-semibold text-green-600">Advantages:</p>
                              <p className="text-gray-600 mb-2">Limited personal liability, less paperwork than corporations</p>
                              <p className="font-semibold text-red-600">Disadvantages:</p>
                              <p className="text-gray-600">More expensive to form than sole proprietorships</p>
                            </div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                            <h4 className="font-bold text-lg mb-2">Corporation</h4>
                            <p className="text-gray-700 text-sm mb-3">
                              A corporation is a legal entity separate from its owners, with its own rights and responsibilities.
                            </p>
                            <div className="text-sm">
                              <p className="font-semibold text-green-600">Advantages:</p>
                              <p className="text-gray-600 mb-2">Limited liability, ability to raise capital through stock sales</p>
                              <p className="font-semibold text-red-600">Disadvantages:</p>
                              <p className="text-gray-600">Expensive to form, extensive record-keeping requirements</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg mt-6">
                          <h4 className="font-bold text-lg mb-3">Considerations When Choosing a Structure</h4>
                          <ul className="list-disc list-inside text-gray-700 space-y-1">
                            <li>Liability protection</li>
                            <li>Tax implications</li>
                            <li>Cost of formation</li>
                            <li>Fundraising needs</li>
                            <li>Management structure</li>
                            <li>Future business goals</li>
                          </ul>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("structures")}
                            className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            💪 CHALLENGE TIME! Master Business Structures! 🏆
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {index === 3 && (
                      <div className="mt-6 p-6 bg-indigo-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Understanding Business Finance</h3>
                        <p className="text-gray-700 mb-4">
                          Finance is the language of business. To be successful, you need to understand how money flows through your business.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">The Three Key Financial Statements</h4>
                        <p className="text-gray-700 mb-4">
                          There are three financial statements that every business owner should understand:
                        </p>
                        
                        <div className="grid md:grid-cols-1 gap-4 mb-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-indigo-500">
                            <h5 className="font-bold text-lg text-indigo-600 mb-2">1. Income Statement</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Shows your revenue, expenses, and profit over a period of time. This tells you if your business is making money.
                            </p>
                            <div className="text-xs text-gray-500">Also called: Profit & Loss Statement (P&L)</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h5 className="font-bold text-lg text-blue-600 mb-2">2. Balance Sheet</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Shows what your business owns (assets) and what it owes (liabilities) at a specific point in time.
                            </p>
                            <div className="text-xs text-gray-500">Formula: Assets = Liabilities + Equity</div>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                            <h5 className="font-bold text-lg text-green-600 mb-2">3. Cash Flow Statement</h5>
                            <p className="text-gray-700 text-sm mb-2">
                              Shows how cash moves in and out of your business. This is crucial for understanding your liquidity.
                            </p>
                            <div className="text-xs text-gray-500">Cash is the lifeblood of any business</div>
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg mb-6">
                          <h4 className="font-bold text-lg mb-3">Why Financial Literacy Matters</h4>
                          <ul className="list-disc list-inside text-gray-700 space-y-2">
                            <li>Make informed business decisions</li>
                            <li>Identify profitable opportunities</li>
                            <li>Manage cash flow effectively</li>
                            <li>Attract investors and secure loans</li>
                            <li>Plan for growth and expansion</li>
                          </ul>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("finance")}
                            className="w-full bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            💰 QUIZ TIME! Test Your Finance Knowledge! 📊
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {index === 4 && (
                      <div className="mt-6 p-6 bg-pink-50 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">What is Marketing?</h3>
                        <p className="text-gray-700 mb-4">
                          Marketing is how businesses identify, reach, and communicate with customers. It's about understanding what people want and showing them how your product or service meets their needs.
                        </p>
                        
                        <h4 className="text-lg font-bold mb-3">The Marketing Mix: The 4 Ps</h4>
                        
                        <div className="grid md:grid-cols-2 gap-4 mb-6">
                          <div className="bg-white p-4 rounded-lg border-l-4 border-pink-500">
                            <h5 className="font-bold text-lg text-pink-600 mb-2">Product</h5>
                            <p className="text-gray-700 text-sm">
                              What you're selling and how it meets customer needs. This includes features, quality, design, and benefits.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-purple-500">
                            <h5 className="font-bold text-lg text-purple-600 mb-2">Price</h5>
                            <p className="text-gray-700 text-sm">
                              How much you charge and how it reflects value. Consider costs, competition, and customer willingness to pay.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                            <h5 className="font-bold text-lg text-blue-600 mb-2">Place</h5>
                            <p className="text-gray-700 text-sm">
                              Where and how customers can buy your product. This includes distribution channels and locations.
                            </p>
                          </div>
                          
                          <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                            <h5 className="font-bold text-lg text-orange-600 mb-2">Promotion</h5>
                            <p className="text-gray-700 text-sm">
                              How you communicate with customers about your product. Includes advertising, social media, and PR.
                            </p>
                          </div>
                        </div>
                        
                        <div className="bg-white p-4 rounded-lg mb-6">
                          <h4 className="font-bold text-lg mb-3">Understanding Your Target Audience</h4>
                          <p className="text-gray-700 mb-3">
                            Before you can market effectively, you need to know who your customers are:
                          </p>
                          <ul className="list-disc list-inside text-gray-700 space-y-1">
                            <li>What are their demographics (age, income, location)?</li>
                            <li>What problems do they need solved?</li>
                            <li>Where do they spend their time?</li>
                            <li>How do they prefer to communicate?</li>
                            <li>What influences their buying decisions?</li>
                          </ul>
                        </div>
                        
                        <div className="mt-6">
                          <Button 
                            onClick={() => setActiveQuiz("marketing")}
                            className="w-full bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
                          >
                            🎯 MARKETING CHALLENGE! Show Your Skills! 🚀
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {index === 5 && (
                      <div className="mt-6">
                        <BusinessGlossary />
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}