import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Video, Calendar, Users, Clock, Award } from "lucide-react";

export default function Zoom() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Zoom Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Live Learning Sessions</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join our interactive Zoom sessions for personalized financial education and Q&A with our expert instructors.
          </p>
        </div>

        {/* Live Sessions Overview */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <Card>
            <CardHeader className="text-center">
              <Video className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>Weekly Workshops</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">Interactive group sessions covering different financial topics each week.</p>
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-blue-800">Every Tuesday</p>
                <p className="text-sm text-blue-600">7:00 PM - 8:30 PM EST</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Users className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <CardTitle>1-on-1 Mentoring</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">Personalized coaching sessions tailored to your specific financial goals.</p>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-green-800">By Appointment</p>
                <p className="text-sm text-green-600">30-60 minute sessions</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Award className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>Masterclasses</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">Deep-dive sessions on advanced topics with industry experts.</p>
              <div className="bg-purple-50 p-3 rounded-lg">
                <p className="text-sm font-medium text-purple-800">Monthly</p>
                <p className="text-sm text-purple-600">2-3 hour sessions</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Sessions */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Upcoming Sessions</h2>
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Credit Building Bootcamp</h3>
                      <p className="text-gray-600">Learn the fundamentals of building and improving your credit score</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          Tuesday, May 28th
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          7:00 PM - 8:30 PM EST
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-blue-600 text-white hover:bg-blue-700">
                    Register
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-100 p-3 rounded-lg">
                      <Calendar className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Business Structure Masterclass</h3>
                      <p className="text-gray-600">Deep dive into choosing the right business entity for your venture</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          Saturday, June 1st
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          10:00 AM - 1:00 PM EST
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-green-600 text-white hover:bg-green-700">
                    Register
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-purple-100 p-3 rounded-lg">
                      <Calendar className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Estate Planning Q&A</h3>
                      <p className="text-gray-600">Ask questions about wills, trusts, and protecting your legacy</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          Tuesday, June 4th
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          7:00 PM - 8:30 PM EST
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-purple-600 text-white hover:bg-purple-700">
                    Register
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* How to Join */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>How to Join Our Zoom Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 font-bold text-lg">1</span>
                </div>
                <h3 className="font-semibold mb-2">Register</h3>
                <p className="text-gray-600 text-sm">Click the register button for any session you'd like to attend.</p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 font-bold text-lg">2</span>
                </div>
                <h3 className="font-semibold mb-2">Get the Link</h3>
                <p className="text-gray-600 text-sm">You'll receive a Zoom link and session details via email.</p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 font-bold text-lg">3</span>
                </div>
                <h3 className="font-semibold mb-2">Join & Learn</h3>
                <p className="text-gray-600 text-sm">Click the link at session time and start learning with our community!</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Membership Benefits */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-8 rounded-2xl">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Premium Members Get More</h2>
            <p className="text-xl mb-6">Unlock exclusive live session benefits with your membership</p>
            
            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-8">
              <div className="bg-white/10 p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-2">Unlimited Access</h3>
                <p className="text-white/90">Join all weekly workshops and Q&A sessions at no extra cost</p>
              </div>
              
              <div className="bg-white/10 p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-2">Recording Access</h3>
                <p className="text-white/90">Can't make it live? Access recordings of all sessions you're registered for</p>
              </div>
              
              <div className="bg-white/10 p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-2">Priority Q&A</h3>
                <p className="text-white/90">Your questions get answered first during live sessions</p>
              </div>
              
              <div className="bg-white/10 p-6 rounded-lg">
                <h3 className="font-semibold text-lg mb-2">1-on-1 Sessions</h3>
                <p className="text-white/90">VIP members get monthly personal mentoring sessions included</p>
              </div>
            </div>
            
            <Link href="/subscribe">
              <Button className="bg-yellow-400 text-gray-900 hover:bg-yellow-300 px-8 py-3 rounded-lg font-semibold">
                Upgrade Membership
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}