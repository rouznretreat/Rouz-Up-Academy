import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, GraduationCap, Briefcase, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Career {
  id: string;
  title: string;
  education: string;
  startingSalary: number;
  fiveYearSalary: number;
  description: string;
  icon: string;
}

const careers: Career[] = [
  {
    id: 'retail',
    title: 'Retail Sales Associate',
    education: 'High School Diploma',
    startingSalary: 25000,
    fiveYearSalary: 32000,
    description: 'Work in stores helping customers and managing inventory.',
    icon: '🛍️'
  },
  {
    id: 'trades',
    title: 'Electrician',
    education: 'Trade School (2 years)',
    startingSalary: 45000,
    fiveYearSalary: 65000,
    description: 'Install and maintain electrical systems in homes and businesses.',
    icon: '⚡'
  },
  {
    id: 'associate',
    title: 'Medical Assistant',
    education: 'Associate Degree (2 years)',
    startingSalary: 35000,
    fiveYearSalary: 42000,
    description: 'Help doctors and nurses in healthcare settings.',
    icon: '🏥'
  },
  {
    id: 'bachelor',
    title: 'Software Developer',
    education: 'Bachelor\'s Degree (4 years)',
    startingSalary: 70000,
    fiveYearSalary: 95000,
    description: 'Create apps, websites, and computer programs.',
    icon: '💻'
  },
  {
    id: 'masters',
    title: 'Physical Therapist',
    education: 'Master\'s Degree (6 years)',
    startingSalary: 85000,
    fiveYearSalary: 95000,
    description: 'Help patients recover from injuries and improve mobility.',
    icon: '🏃‍♂️'
  }
];

interface FinancialDecision {
  year: number;
  event: string;
  options: { choice: string; impact: number; description: string }[];
}

const financialDecisions: FinancialDecision[] = [
  {
    year: 2,
    event: "You want to buy a car",
    options: [
      { choice: "Buy a reliable used car ($8,000)", impact: -8000, description: "Good transportation, reasonable cost" },
      { choice: "Buy a new car ($25,000)", impact: -25000, description: "Nice car but high payments" },
      { choice: "Keep using public transport", impact: 0, description: "Save money but less convenient" }
    ]
  },
  {
    year: 3,
    event: "You have extra money to invest",
    options: [
      { choice: "Start investing $200/month", impact: 2400, description: "Begin building wealth early" },
      { choice: "Save it all in savings account", impact: 1200, description: "Safe but lower returns" },
      { choice: "Spend on lifestyle upgrades", impact: -2000, description: "Enjoy now but no future growth" }
    ]
  },
  {
    year: 4,
    event: "Considering additional education",
    options: [
      { choice: "Take professional courses ($3,000)", impact: -3000, description: "Improve skills for promotions" },
      { choice: "Get industry certification ($1,000)", impact: -1000, description: "Moderate investment in skills" },
      { choice: "Skip additional education", impact: 0, description: "Keep current income level" }
    ]
  }
];

export default function CareerIncomeGame() {
  const [gameStep, setGameStep] = useState<'career' | 'simulation' | 'results'>('career');
  const [selectedCareer, setSelectedCareer] = useState<Career | null>(null);
  const [currentYear, setCurrentYear] = useState(1);
  const [totalSavings, setTotalSavings] = useState(0);
  const [decisions, setDecisions] = useState<string[]>([]);
  const [currentDecision, setCurrentDecision] = useState<FinancialDecision | null>(null);

  const selectCareer = (career: Career) => {
    setSelectedCareer(career);
    setGameStep('simulation');
    setTotalSavings(career.startingSalary * 0.1); // Start with 10% saved from first year
  };

  const handleDecision = (choice: string, impact: number, description: string) => {
    setTotalSavings(totalSavings + impact);
    setDecisions([...decisions, `Year ${currentYear}: ${choice} - ${description}`]);
    
    if (currentYear >= 5) {
      setGameStep('results');
    } else {
      setCurrentYear(currentYear + 1);
      setCurrentDecision(null);
    }
  };

  const nextYear = () => {
    const yearDecision = financialDecisions.find(d => d.year === currentYear);
    if (yearDecision) {
      setCurrentDecision(yearDecision);
    } else {
      // Auto-advance years without decisions
      const currentSalary = selectedCareer!.startingSalary + 
        ((selectedCareer!.fiveYearSalary - selectedCareer!.startingSalary) / 4) * (currentYear - 1);
      setTotalSavings(totalSavings + currentSalary * 0.1);
      
      if (currentYear >= 5) {
        setGameStep('results');
      } else {
        setCurrentYear(currentYear + 1);
      }
    }
  };

  const restartGame = () => {
    setGameStep('career');
    setSelectedCareer(null);
    setCurrentYear(1);
    setTotalSavings(0);
    setDecisions([]);
    setCurrentDecision(null);
  };

  const getCurrentSalary = () => {
    if (!selectedCareer) return 0;
    return selectedCareer.startingSalary + 
      ((selectedCareer.fiveYearSalary - selectedCareer.startingSalary) / 4) * (currentYear - 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100">
      <div className="bg-white shadow-sm border-b p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">💼 Career & Income Game</h1>
          {selectedCareer && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Year {currentYear}/5</span>
              <DollarSign className="w-5 h-5 text-green-600" />
              <span className="text-lg font-bold text-green-600">
                ${totalSavings.toLocaleString()}
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {gameStep === 'career' && (
          <div>
            <div className="text-center mb-12">
              <div className="text-6xl mb-4">🎯</div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Choose Your Career Path
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                See how education and career choices affect your financial future over 5 years. 
                Each path has different starting salaries and growth potential.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {careers.map((career) => (
                <div 
                  key={career.id}
                  className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all cursor-pointer border-2 border-transparent hover:border-purple-300"
                  onClick={() => selectCareer(career)}
                >
                  <div className="text-4xl mb-4 text-center">{career.icon}</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{career.title}</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-4 h-4 text-blue-600" />
                      <span className="text-sm text-gray-600">{career.education}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      <span className="text-sm text-gray-600">
                        Start: ${career.startingSalary.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-purple-600" />
                      <span className="text-sm text-gray-600">
                        Year 5: ${career.fiveYearSalary.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500 mt-4">{career.description}</p>
                  <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
                    Choose This Path
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {gameStep === 'simulation' && !currentDecision && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📊</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Year {currentYear} - {selectedCareer?.title}
            </h2>
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
              <div className="text-2xl font-bold text-green-600 mb-4">
                Current Salary: ${getCurrentSalary().toLocaleString()}
              </div>
              <div className="text-lg text-gray-600 mb-6">
                Total Savings: ${totalSavings.toLocaleString()}
              </div>
              <Button onClick={nextYear} className="bg-indigo-600 hover:bg-indigo-700 px-8 py-3">
                Continue to Year {currentYear + 1}
              </Button>
            </div>
          </div>
        )}

        {currentDecision && (
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
            <div className="text-4xl mb-4 text-center">🤔</div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">
              Year {currentYear}: {currentDecision.event}
            </h3>
            <div className="space-y-4">
              {currentDecision.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleDecision(option.choice, option.impact, option.description)}
                  className="w-full p-4 text-left border-2 border-gray-200 rounded-lg hover:border-purple-400 hover:bg-purple-50 transition-all"
                >
                  <div className="font-semibold text-gray-900">{option.choice}</div>
                  <div className="text-sm text-gray-600 mt-1">{option.description}</div>
                  <div className={`text-sm font-bold mt-2 ${option.impact >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {option.impact >= 0 ? '+' : ''}${option.impact.toLocaleString()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {gameStep === 'results' && (
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
            <div className="text-6xl mb-4 text-center">🎉</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
              5-Year Financial Journey Complete!
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Your Career</h3>
                <div className="text-4xl mb-2">{selectedCareer?.icon}</div>
                <div className="text-lg font-semibold">{selectedCareer?.title}</div>
                <div className="text-gray-600">Final Salary: ${selectedCareer?.fiveYearSalary.toLocaleString()}</div>
              </div>
              
              <div className="text-center">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Total Savings</h3>
                <div className="text-4xl font-bold text-green-600 mb-2">
                  ${totalSavings.toLocaleString()}
                </div>
                <div className="text-gray-600">Accumulated over 5 years</div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h4 className="text-lg font-bold text-gray-900 mb-4">Your Financial Decisions:</h4>
              <div className="space-y-2">
                {decisions.map((decision, index) => (
                  <div key={index} className="text-gray-700">{decision}</div>
                ))}
              </div>
            </div>

            <div className="text-center">
              <Button 
                onClick={restartGame}
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3"
              >
                Try Different Career Path
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}