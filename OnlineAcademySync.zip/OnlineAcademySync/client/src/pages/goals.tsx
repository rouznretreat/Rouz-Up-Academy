import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import VisualGoalTracker from "@/components/VisualGoalTracker";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Target, TrendingUp, Calendar, DollarSign } from "lucide-react";

interface StandardGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  category: string;
  monthlyContribution: number;
  priority: 'high' | 'medium' | 'low';
}

export default function Goals() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTracker, setActiveTracker] = useState<'visual' | 'standard'>('visual');
  const [standardGoals, setStandardGoals] = useState<StandardGoal[]>([
    {
      id: '1',
      name: 'Emergency Fund',
      targetAmount: 1000,
      currentAmount: 250,
      deadline: '2025-12-31',
      category: 'Safety Net',
      monthlyContribution: 100,
      priority: 'high'
    },
    {
      id: '2',
      name: 'New Phone',
      targetAmount: 800,
      currentAmount: 320,
      deadline: '2025-08-15',
      category: 'Technology',
      monthlyContribution: 80,
      priority: 'medium'
    },
    {
      id: '3',
      name: 'College Fund',
      targetAmount: 5000,
      currentAmount: 1200,
      deadline: '2026-06-01',
      category: 'Education',
      monthlyContribution: 200,
      priority: 'high'
    }
  ]);
  const [newGoal, setNewGoal] = useState({
    name: '',
    targetAmount: '',
    deadline: '',
    category: '',
    monthlyContribution: ''
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Goals Hero Section */}
      <section className="bg-gradient-to-br from-purple-600 via-purple-700 to-pink-600 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">🎯 Your Financial Goals</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Set savings goals and track your progress with two powerful tracking methods.
          </p>
          
          {/* Tracker Toggle */}
          <div className="flex justify-center space-x-4 mt-8">
            <Button 
              onClick={() => setActiveTracker('visual')}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeTracker === 'visual' 
                ? 'bg-white text-purple-600 shadow-lg' 
                : 'bg-purple-500/30 text-white hover:bg-purple-500/50'
              }`}
            >
              <Target className="w-5 h-5 mr-2" />
              Visual Tracker
            </Button>
            <Button 
              onClick={() => setActiveTracker('standard')}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeTracker === 'standard' 
                ? 'bg-white text-purple-600 shadow-lg' 
                : 'bg-purple-500/30 text-white hover:bg-purple-500/50'
              }`}
            >
              <TrendingUp className="w-5 h-5 mr-2" />
              Standard Tracker
            </Button>
          </div>
        </div>
      </section>

      {/* Tracker Content */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {activeTracker === 'visual' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Visual Goal Tracker</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  See your progress come to life with our engaging visual goal tracker.
                </p>
              </div>
              <VisualGoalTracker />
            </div>
          )}

          {activeTracker === 'standard' && (
            <div>
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Standard Goal Tracker</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  Detailed goal management with progress tracking and monthly contributions.
                </p>
              </div>

              {/* Add New Goal Form */}
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="w-5 h-5 mr-2 text-green-600" />
                    Add New Goal
                  </CardTitle>
                  <CardDescription>
                    Create a new savings goal with detailed tracking information.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="goalName">Goal Name</Label>
                      <Input 
                        id="goalName"
                        placeholder="e.g., New Gaming Setup"
                        value={newGoal.name}
                        onChange={(e) => setNewGoal({...newGoal, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="targetAmount">Target Amount ($)</Label>
                      <Input 
                        id="targetAmount"
                        type="number"
                        placeholder="1000"
                        value={newGoal.targetAmount}
                        onChange={(e) => setNewGoal({...newGoal, targetAmount: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="deadline">Deadline</Label>
                      <Input 
                        id="deadline"
                        type="date"
                        value={newGoal.deadline}
                        onChange={(e) => setNewGoal({...newGoal, deadline: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input 
                        id="category"
                        placeholder="e.g., Technology"
                        value={newGoal.category}
                        onChange={(e) => setNewGoal({...newGoal, category: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="monthlyContribution">Monthly Contribution ($)</Label>
                      <Input 
                        id="monthlyContribution"
                        type="number"
                        placeholder="100"
                        value={newGoal.monthlyContribution}
                        onChange={(e) => setNewGoal({...newGoal, monthlyContribution: e.target.value})}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button className="w-full bg-green-600 hover:bg-green-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Goal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Goals List */}
              <div className="grid gap-6">
                {standardGoals.map((goal) => {
                  const progressPercentage = (goal.currentAmount / goal.targetAmount) * 100;
                  const remainingAmount = goal.targetAmount - goal.currentAmount;
                  const monthsToGoal = Math.ceil(remainingAmount / goal.monthlyContribution);
                  
                  return (
                    <Card key={goal.id} className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-bold text-gray-900 mb-1">{goal.name}</h3>
                            <p className="text-sm text-gray-600">{goal.category} • Deadline: {new Date(goal.deadline).toLocaleDateString()}</p>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                            goal.priority === 'high' ? 'bg-red-100 text-red-800' :
                            goal.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {goal.priority.toUpperCase()} PRIORITY
                          </div>
                        </div>

                        <div className="mb-4">
                          <div className="flex justify-between text-sm font-medium mb-2">
                            <span>${goal.currentAmount.toLocaleString()} saved</span>
                            <span>${goal.targetAmount.toLocaleString()} goal</span>
                          </div>
                          <Progress value={progressPercentage} className="h-3" />
                          <p className="text-xs text-gray-600 mt-1">{progressPercentage.toFixed(1)}% complete</p>
                        </div>

                        <div className="grid grid-cols-3 gap-4 text-center border-t pt-4">
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <DollarSign className="w-4 h-4 text-green-600 mr-1" />
                              <span className="text-sm font-medium text-gray-700">Remaining</span>
                            </div>
                            <p className="text-lg font-bold text-gray-900">${remainingAmount.toLocaleString()}</p>
                          </div>
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <Calendar className="w-4 h-4 text-blue-600 mr-1" />
                              <span className="text-sm font-medium text-gray-700">Monthly</span>
                            </div>
                            <p className="text-lg font-bold text-gray-900">${goal.monthlyContribution}</p>
                          </div>
                          <div>
                            <div className="flex items-center justify-center mb-1">
                              <Target className="w-4 h-4 text-purple-600 mr-1" />
                              <span className="text-sm font-medium text-gray-700">ETA</span>
                            </div>
                            <p className="text-lg font-bold text-gray-900">{monthsToGoal} months</p>
                          </div>
                        </div>

                        <div className="flex space-x-3 mt-4">
                          <Button size="sm" variant="outline" className="flex-1">
                            Add Payment
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            Edit Goal
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}