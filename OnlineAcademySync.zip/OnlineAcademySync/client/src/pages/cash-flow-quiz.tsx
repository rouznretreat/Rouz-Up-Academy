import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, User, Briefcase, Building, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QuizQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    quadrant: 'E' | 'S' | 'B' | 'I';
  }[];
}

const questions: QuizQuestion[] = [
  {
    id: 1,
    question: "When you think about your ideal work day, what sounds best?",
    options: [
      { text: "Having a steady schedule and knowing exactly what to do", quadrant: 'E' },
      { text: "Being my own boss and controlling my own work", quadrant: 'S' },
      { text: "Leading a team and building something big", quadrant: 'B' },
      { text: "Making money while I sleep or relax", quadrant: 'I' }
    ]
  },
  {
    id: 2,
    question: "What motivates you most about money?",
    options: [
      { text: "Having a reliable paycheck I can count on", quadrant: 'E' },
      { text: "Earning more when I work harder", quadrant: 'S' },
      { text: "Building wealth through systems and people", quadrant: 'B' },
      { text: "Watching my money grow automatically", quadrant: 'I' }
    ]
  },
  {
    id: 3,
    question: "How do you feel about taking risks?",
    options: [
      { text: "I prefer safe, predictable choices", quadrant: 'E' },
      { text: "I'll take risks if I can control the outcome", quadrant: 'S' },
      { text: "I'll take big risks if the reward is worth it", quadrant: 'B' },
      { text: "I take calculated risks based on research", quadrant: 'I' }
    ]
  },
  {
    id: 4,
    question: "What's your dream work situation?",
    options: [
      { text: "A great job at a stable company with good benefits", quadrant: 'E' },
      { text: "Running my own successful practice or business", quadrant: 'S' },
      { text: "Building a company that runs without me", quadrant: 'B' },
      { text: "Living off investment income", quadrant: 'I' }
    ]
  },
  {
    id: 5,
    question: "How do you prefer to learn new things?",
    options: [
      { text: "Through training programs and structured courses", quadrant: 'E' },
      { text: "By doing it myself and learning from mistakes", quadrant: 'S' },
      { text: "By finding mentors and building networks", quadrant: 'B' },
      { text: "By studying markets and successful strategies", quadrant: 'I' }
    ]
  },
  {
    id: 6,
    question: "What scares you most about money?",
    options: [
      { text: "Not having enough for basic needs", quadrant: 'E' },
      { text: "Having to depend on someone else", quadrant: 'S' },
      { text: "Missing out on big opportunities", quadrant: 'B' },
      { text: "Making bad investment decisions", quadrant: 'I' }
    ]
  },
  {
    id: 7,
    question: "How do you handle stress?",
    options: [
      { text: "I prefer routines and clear expectations", quadrant: 'E' },
      { text: "I work harder to solve the problem myself", quadrant: 'S' },
      { text: "I delegate and find people to help", quadrant: 'B' },
      { text: "I step back and analyze the situation", quadrant: 'I' }
    ]
  },
  {
    id: 8,
    question: "What's most important for your future?",
    options: [
      { text: "Job security and retirement benefits", quadrant: 'E' },
      { text: "Being recognized as an expert in my field", quadrant: 'S' },
      { text: "Building something that lasts beyond me", quadrant: 'B' },
      { text: "Achieving financial freedom", quadrant: 'I' }
    ]
  },
  {
    id: 9,
    question: "How do you feel about working with others?",
    options: [
      { text: "I like being part of a team with clear roles", quadrant: 'E' },
      { text: "I prefer to work alone or in small groups", quadrant: 'S' },
      { text: "I enjoy leading and inspiring teams", quadrant: 'B' },
      { text: "I like working with other smart investors", quadrant: 'I' }
    ]
  },
  {
    id: 10,
    question: "What would you do with extra time?",
    options: [
      { text: "Spend it with family and enjoy hobbies", quadrant: 'E' },
      { text: "Use it to improve my skills and services", quadrant: 'S' },
      { text: "Look for new business opportunities", quadrant: 'B' },
      { text: "Research new investment opportunities", quadrant: 'I' }
    ]
  }
];

export default function CashFlowQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (quadrant: string) => {
    const newAnswers = [...answers, quadrant];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateResult = () => {
    const counts = { E: 0, S: 0, B: 0, I: 0 };
    answers.forEach(answer => {
      counts[answer as keyof typeof counts]++;
    });

    const maxCount = Math.max(...Object.values(counts));
    const result = Object.keys(counts).find(key => counts[key as keyof typeof counts] === maxCount);
    return result as 'E' | 'S' | 'B' | 'I';
  };

  const getQuadrantInfo = (quadrant: 'E' | 'S' | 'B' | 'I') => {
    const info = {
      E: {
        title: "Employee",
        icon: "💼",
        description: "You work for someone else.",
        detail: "Stable income but limited growth.",
        traits: [
          "You value security and stability",
          "You prefer clear instructions and structure",
          "You like having benefits and a steady paycheck",
          "You enjoy being part of a team"
        ]
      },
      S: {
        title: "Self-Employed",
        icon: "👩‍⚕️",
        description: "You own your job.",
        detail: "Higher income but more time needed.",
        traits: [
          "You like being your own boss",
          "You prefer to control your own destiny",
          "You're willing to work hard for success",
          "You value expertise and specialization"
        ]
      },
      B: {
        title: "Business Owner",
        icon: "🏢",
        description: "People work for you in your system.",
        detail: "High income with less time invested.",
        traits: [
          "You enjoy leading and building teams",
          "You think big and take calculated risks",
          "You like creating systems and processes",
          "You want to build something lasting"
        ]
      },
      I: {
        title: "Investor",
        icon: "📈",
        description: "Your money works for you.",
        detail: "Highest income with least time spent.",
        traits: [
          "You think long-term about wealth",
          "You enjoy analyzing opportunities",
          "You want financial freedom",
          "You understand the power of compound growth"
        ]
      }
    };
    return info[quadrant];
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResults(false);
  };

  if (showResults) {
    const result = calculateResult();
    const quadrantInfo = getQuadrantInfo(result);

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 shadow-lg">
          <div className="max-w-4xl mx-auto">
            <Link href="/banking-course">
              <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-50 bg-white transition-colors mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Games
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Your Money Personality Result</h1>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {/* Result Card */}
          <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-2 border-green-300">
            <CardHeader className="text-center">
              <div className="text-6xl mb-4">{quadrantInfo.icon}</div>
              <CardTitle className="text-3xl text-green-800">{quadrantInfo.title}</CardTitle>
              <p className="text-lg text-green-700">{quadrantInfo.description}</p>
              <p className="text-green-600">{quadrantInfo.detail}</p>
            </CardHeader>
            <CardContent>
              <h3 className="text-xl font-bold mb-4 text-green-800">Your Personality Traits:</h3>
              <ul className="space-y-2">
                {quadrantInfo.traits.map((trait, index) => (
                  <li key={index} className="flex items-center text-green-700">
                    <span className="text-green-500 mr-2">✓</span>
                    {trait}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* All Quadrants Reference */}
          <Card>
            <CardHeader>
              <CardTitle>Understanding All Four Quadrants</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {(['E', 'S', 'B', 'I'] as const).map((q) => {
                  const info = getQuadrantInfo(q);
                  return (
                    <div key={q} className={`p-4 rounded-lg border-2 ${result === q ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex items-center mb-2">
                        <span className="text-2xl mr-3">{info.icon}</span>
                        <div>
                          <h4 className="font-bold">{info.title}</h4>
                          <p className="text-sm text-gray-600">{info.description}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-center space-x-4">
            <Button onClick={restartQuiz} className="bg-green-600 hover:bg-green-700">
              Take Quiz Again
            </Button>
            <Link href="/banking-course">
              <Button variant="outline">
                Back to Banking Course
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-50 bg-white transition-colors mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Games
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Cash Flow Quadrant Quiz</h1>
          <p className="text-lg text-green-100">Discover which of Robert Kiyosaki's four quadrants matches your personality</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {currentQuestion === 0 && (
          <>
            {/* Introduction */}
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">The Money Personality Quiz</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-6">
                  Everyone has a different way they like to earn money! This quiz is based on Robert Kiyosaki's Cash Flow Quadrant, 
                  and it will show you which of these four money types matches your personality:
                </p>
                
                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-3">💼</span>
                      <div>
                        <h4 className="font-bold text-blue-800">Employee</h4>
                        <p className="text-sm text-blue-600">You work for someone else.</p>
                        <p className="text-xs text-blue-500">Stable income but limited growth.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-3">👩‍⚕️</span>
                      <div>
                        <h4 className="font-bold text-green-800">Self-Employed</h4>
                        <p className="text-sm text-green-600">You own your job.</p>
                        <p className="text-xs text-green-500">Higher income but more time needed.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-3">🏢</span>
                      <div>
                        <h4 className="font-bold text-purple-800">Business Owner</h4>
                        <p className="text-sm text-purple-600">People work for you in your system.</p>
                        <p className="text-xs text-purple-500">High income with less time invested.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-3">📈</span>
                      <div>
                        <h4 className="font-bold text-yellow-800">Investor</h4>
                        <p className="text-sm text-yellow-600">Your money works for you.</p>
                        <p className="text-xs text-yellow-500">Highest income with least time spent.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-bold mb-2">How This Quiz Works:</h4>
                  <p className="text-gray-700">
                    Answer 10 simple questions, and we'll show you which money type matches your personality best! 
                    There are no right or wrong answers - it's all about what you like. Knowing your money personality 
                    can help you understand what kinds of jobs or careers might make you happiest in the future.
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="text-center">
              <Button onClick={() => setCurrentQuestion(1)} className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Start Personality Quiz
              </Button>
            </div>
          </>
        )}

        {currentQuestion > 0 && (
          <>
            {/* Progress */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-600">Question {currentQuestion} of {questions.length}</span>
                  <div className="w-64 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(currentQuestion / questions.length) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Question */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">{questions[currentQuestion - 1].question}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {questions[currentQuestion - 1].options.map((option, index) => (
                    <Button
                      key={index}
                      onClick={() => handleAnswer(option.quadrant)}
                      variant="outline"
                      className="w-full text-left p-4 h-auto justify-start hover:bg-green-50"
                    >
                      {option.text}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}