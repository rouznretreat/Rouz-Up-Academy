import { useState } from "react";
import { ArrowLeft, PlayCircle, CheckCircle, Clock, Users, Star, BookOpen, DollarSign, TrendingUp, Building2, Target, Trophy, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import BusinessQuiz from "@/components/BusinessQuiz";
import BusinessGlossary from "@/components/BusinessGlossary";

export default function BusinessForStarters() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeModule, setActiveModule] = useState(0);
  const [activeTab, setActiveTab] = useState("home");
  const [activeQuiz, setActiveQuiz] = useState<string | null>(null);
  const [showGlossary, setShowGlossary] = useState(false);

  const businessModules = [
    {
      title: "Young Entrepreneur Mindset",
      duration: "15 min",
      lessons: 6,
      description: "Develop the mindset of a successful young entrepreneur. Learn to think like a business owner before you turn 18.",
      topics: [
        "Why Start Young?",
        "The Entrepreneur vs Employee Mindset", 
        "Spotting Opportunities in Your Daily Life",
        "Building Confidence as a Young Leader",
        "Learning from Failure",
        "Setting Your First Business Goal"
      ],
      completed: false
    },
    {
      title: "Business Ideas for Teens",
      duration: "20 min", 
      lessons: 8,
      description: "Discover profitable business ideas perfect for teenagers. From digital services to local solutions.",
      topics: [
        "Service-Based Businesses for Teens",
        "Digital Business Opportunities",
        "Local Community Solutions",
        "Seasonal Business Ideas",
        "Social Media & Content Creation",
        "Tutoring & Teaching Services",
        "Creative & Artistic Ventures",
        "Finding Your Niche"
      ],
      completed: false
    },
    {
      title: "Getting Started Legally",
      duration: "18 min",
      lessons: 7,
      description: "Learn how to start a business as a minor. Understand the legal basics without complicated jargon.",
      topics: [
        "Can Minors Start Businesses?",
        "Working with Parents/Guardians",
        "Basic Business Registration",
        "Understanding Taxes (Simple Version)",
        "Protecting Your Business Name",
        "Insurance Basics for Young Entrepreneurs",
        "Record Keeping Made Easy"
      ],
      completed: false
    },
    {
      title: "Money Management for Young Business Owners",
      duration: "22 min",
      lessons: 9,
      description: "Master the financial side of business with teen-friendly explanations and practical examples.",
      topics: [
        "Separating Business & Personal Money",
        "Pricing Your Products/Services",
        "Understanding Profit vs Revenue",
        "Basic Budgeting for Business",
        "Tracking Income & Expenses",
        "Saving for Business Growth",
        "When to Invest Back in Your Business",
        "Understanding ROI (Return on Investment)",
        "Building Your First Emergency Fund"
      ],
      completed: false
    },
    {
      title: "Marketing Like a Pro (Teen Edition)",
      duration: "25 min",
      lessons: 10,
      description: "Learn marketing strategies that work for young entrepreneurs using platforms you already know and love.",
      topics: [
        "Understanding Your Target Customer",
        "Social Media Marketing Basics", 
        "Creating Content That Sells",
        "Word-of-Mouth Marketing",
        "Building Your Personal Brand",
        "Networking as a Teen Entrepreneur",
        "Customer Service Excellence",
        "Getting Reviews & Testimonials",
        "Free Marketing Strategies",
        "Measuring What Works"
      ],
      completed: false
    },
    {
      title: "Scaling & Growing Your Business",
      duration: "20 min",
      lessons: 8,
      description: "Take your business to the next level. Learn when and how to grow your teenage business venture.",
      topics: [
        "Recognizing Growth Opportunities",
        "When to Hire Help",
        "Automating Your Business",
        "Expanding Your Product/Service Line",
        "Managing Increased Demand",
        "Reinvesting Profits Wisely",
        "Planning for the Future",
        "Exit Strategies for Teen Businesses"
      ],
      completed: false
    }
  ];

  const progressStats = {
    modulesCompleted: 0,
    totalModules: businessModules.length,
    overallProgress: 0,
    certificatesEarned: 0
  };

  if (activeQuiz) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveQuiz(null)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Course
            </Button>
          </div>
          
          <BusinessQuiz moduleType={activeQuiz as "business" | "structures" | "finance" | "marketing"} />
        </div>
      </div>
    );
  }

  if (showGlossary) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => setShowGlossary(false)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Course
            </Button>
          </div>
          
          <BusinessGlossary />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Course Header */}
      <section className="bg-gradient-to-br from-purple-600 via-blue-600 to-green-500 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-6xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="flex-1 text-center lg:text-left">
              <div className="flex items-center gap-3 justify-center lg:justify-start mb-4">
                <Button 
                  onClick={() => window.history.back()}
                  size="sm"
                  className="bg-white text-purple-600 hover:bg-gray-100 font-semibold"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Academy
                </Button>
                <Badge className="bg-green-500 text-white">FREE COURSE</Badge>
              </div>
              
              <h1 className="text-4xl lg:text-5xl font-bold mb-4">
                Business for Starters
              </h1>
              <p className="text-xl text-white/90 mb-6">
                Your entrepreneurial journey starts here! Learn to build and run businesses before you turn 18.
              </p>
              
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>2 hours total</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>For teens ages 13-18</span>
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 fill-yellow-400" />
                  <span>4.9 rating</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 max-w-sm">
              <h3 className="text-lg font-semibold mb-4">Course Progress</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Overall Progress</span>
                    <span>{progressStats.overallProgress}%</span>
                  </div>
                  <Progress value={progressStats.overallProgress} className="h-2" />
                </div>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold">{progressStats.modulesCompleted}</div>
                    <div className="text-xs">Modules Complete</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{progressStats.certificatesEarned}</div>
                    <div className="text-xs">Certificates</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Navigation Tabs */}
      <section className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto">
            {[
              { id: "home", label: "Home", icon: BookOpen },
              { id: "modules", label: "Modules", icon: PlayCircle },
              { id: "quiz", label: "Quiz", icon: Target },
              { id: "glossary", label: "Glossary", icon: Star },
              { id: "tools", label: "Tools", icon: Trophy }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-2 py-4 px-2 border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === id
                    ? "border-purple-600 text-purple-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="max-w-6xl mx-auto px-4">
          
          {activeTab === "home" && (
            <div className="space-y-8">
              {/* Welcome Message */}
              <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="bg-purple-600 p-3 rounded-full">
                      <Lightbulb className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 mb-3">
                        Welcome to Your Entrepreneurial Journey! 🚀
                      </h2>
                      <p className="text-gray-700 mb-4">
                        You're about to learn the secrets of successful young entrepreneurs. This course will give you the confidence and knowledge to start your own business while you're still in your teens - giving you a massive headstart over your peers!
                      </p>
                      <div className="grid md:grid-cols-3 gap-4 mt-6">
                        <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                          <Building2 className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                          <div className="font-semibold">Build Your Empire</div>
                          <div className="text-sm text-gray-600">Start creating wealth early</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                          <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                          <div className="font-semibold">Financial Freedom</div>
                          <div className="text-sm text-gray-600">Learn to make money work for you</div>
                        </div>
                        <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                          <Star className="w-8 h-8 text-green-600 mx-auto mb-2" />
                          <div className="font-semibold">Future Success</div>
                          <div className="text-sm text-gray-600">Develop millionaire mindset</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <div className="grid md:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-purple-600">{businessModules.length}</div>
                    <div className="text-sm text-gray-600">Learning Modules</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-blue-600">48</div>
                    <div className="text-sm text-gray-600">Practical Lessons</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-green-600">2</div>
                    <div className="text-sm text-gray-600">Hours of Content</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-orange-600">∞</div>
                    <div className="text-sm text-gray-600">Future Potential</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "modules" && (
            <div>
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Business Learning Modules</h2>
                <p className="text-gray-600">Master entrepreneurship step by step with our youth-focused curriculum</p>
              </div>
              
              <div className="grid gap-6">
                {businessModules.map((module, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="bg-purple-100 p-3 rounded-full">
                          <span className="text-purple-600 font-bold">{index + 1}</span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-xl font-semibold">{module.title}</h3>
                            {module.completed && <CheckCircle className="w-5 h-5 text-green-500" />}
                          </div>
                          <p className="text-gray-600 mb-4">{module.description}</p>
                          
                          <div className="flex items-center gap-6 text-sm text-gray-500 mb-4">
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {module.duration}
                            </div>
                            <div className="flex items-center gap-1">
                              <PlayCircle className="w-4 h-4" />
                              {module.lessons} lessons
                            </div>
                          </div>
                          
                          <div className="border-t pt-4">
                            <div className="text-sm font-medium text-gray-700 mb-2">Topics covered:</div>
                            <div className="grid md:grid-cols-2 gap-1 text-sm text-gray-600">
                              {module.topics.slice(0, 4).map((topic, topicIndex) => (
                                <div key={topicIndex} className="flex items-center gap-1">
                                  <span className="w-1 h-1 bg-purple-400 rounded-full"></span>
                                  {topic}
                                </div>
                              ))}
                              {module.topics.length > 4 && (
                                <div className="text-purple-600">+{module.topics.length - 4} more...</div>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex gap-3 mt-4">
                            <Button className="bg-purple-600 hover:bg-purple-700">
                              <PlayCircle className="w-4 h-4 mr-2" />
                              Start Module
                            </Button>
                            <Button variant="outline">
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {activeTab === "quiz" && (
            <div className="text-center space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Test Your Business Knowledge</h2>
                <p className="text-gray-600">Take quizzes to reinforce what you've learned and earn certificates</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" 
                      onClick={() => setActiveQuiz("business")}>
                  <CardContent className="p-6 text-center">
                    <div className="bg-blue-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <Target className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Business Fundamentals Quiz</h3>
                    <p className="text-gray-600 mb-4">Test your understanding of basic business concepts</p>
                    <Button className="w-full">Take Quiz</Button>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-lg transition-shadow cursor-pointer"
                      onClick={() => setActiveQuiz("structures")}>
                  <CardContent className="p-6 text-center">
                    <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <Building2 className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Business Structures Quiz</h3>
                    <p className="text-gray-600 mb-4">Learn about different types of business entities</p>
                    <Button className="w-full">Take Quiz</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "glossary" && (
            <div className="text-center space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Business Glossary</h2>
                <p className="text-gray-600">Essential business terms every young entrepreneur should know</p>
              </div>
              
              <Button 
                onClick={() => setShowGlossary(true)}
                size="lg"
                className="bg-purple-600 hover:bg-purple-700"
              >
                <BookOpen className="w-5 h-5 mr-2" />
                Open Business Glossary
              </Button>
            </div>
          )}

          {activeTab === "tools" && (
            <div className="text-center space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Business Tools & Resources</h2>
                <p className="text-gray-600">Practical tools to help you start and grow your business</p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6 text-center">
                    <DollarSign className="w-12 h-12 text-green-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Pricing Calculator</h3>
                    <p className="text-gray-600 mb-4">Calculate the right price for your products/services</p>
                    <Button variant="outline" className="w-full">Coming Soon</Button>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6 text-center">
                    <TrendingUp className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Profit Tracker</h3>
                    <p className="text-gray-600 mb-4">Track your income and expenses</p>
                    <Button variant="outline" className="w-full">Coming Soon</Button>
                  </CardContent>
                </Card>
                
                <Card className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6 text-center">
                    <Star className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Business Plan Template</h3>
                    <p className="text-gray-600 mb-4">Create your first business plan</p>
                    <Button variant="outline" className="w-full">Coming Soon</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}