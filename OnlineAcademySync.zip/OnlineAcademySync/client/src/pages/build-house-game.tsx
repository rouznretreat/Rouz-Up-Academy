import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft, Home, DollarSign, Calculator, TrendingUp, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface HouseOption {
  id: string;
  name: string;
  price: number;
  downPaymentPercent: number;
  monthlyMaintenance: number;
  description: string;
  location: string;
  image: string;
}

interface PlayerFinances {
  savings: number;
  monthlyIncome: number;
  monthlyExpenses: number;
  creditScore: number;
  currentStep: number;
  selectedHouse: HouseOption | null;
  downPayment: number;
  mortgageAmount: number;
  monthlyPayment: number;
  interestRate: number;
  loanTerm: number;
}

interface GameStep {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

export default function BuildHouseGame() {
  const [gameStarted, setGameStarted] = useState(false);
  const [playerFinances, setPlayerFinances] = useState<PlayerFinances>({
    savings: 15000,
    monthlyIncome: 4000,
    monthlyExpenses: 2500,
    creditScore: 720,
    currentStep: 1,
    selectedHouse: null,
    downPayment: 0,
    mortgageAmount: 0,
    monthlyPayment: 0,
    interestRate: 0,
    loanTerm: 30
  });
  const [gameComplete, setGameComplete] = useState(false);
  const [savingMonths, setSavingMonths] = useState(0);

  const houseOptions: HouseOption[] = [
    {
      id: "starter",
      name: "Cozy Starter Home",
      price: 180000,
      downPaymentPercent: 5,
      monthlyMaintenance: 200,
      description: "Perfect first home with 2 bedrooms, 1 bathroom in a quiet neighborhood",
      location: "Suburban Area",
      image: "🏠"
    },
    {
      id: "family",
      name: "Family Dream Home",
      price: 320000,
      downPaymentPercent: 10,
      monthlyMaintenance: 400,
      description: "Spacious 4 bedroom, 3 bathroom home with a big backyard",
      location: "Great School District",
      image: "🏡"
    },
    {
      id: "luxury",
      name: "Luxury Estate",
      price: 550000,
      downPaymentPercent: 20,
      monthlyMaintenance: 800,
      description: "5 bedroom mansion with pool, gourmet kitchen, and premium finishes",
      location: "Exclusive Neighborhood",
      image: "🏰"
    },
    {
      id: "condo",
      name: "Modern Condo",
      price: 240000,
      downPaymentPercent: 10,
      monthlyMaintenance: 350,
      description: "2 bedroom downtown condo with city views and modern amenities",
      location: "City Center",
      image: "🏢"
    }
  ];

  const gameSteps: GameStep[] = [
    {
      id: 1,
      title: "Financial Assessment",
      description: "Review your current financial situation and creditworthiness",
      completed: playerFinances.currentStep > 1
    },
    {
      id: 2,
      title: "Choose Your Dream Home",
      description: "Browse available homes and select one within your budget",
      completed: playerFinances.currentStep > 2
    },
    {
      id: 3,
      title: "Calculate Down Payment",
      description: "Determine how much you need to save for the down payment",
      completed: playerFinances.currentStep > 3
    },
    {
      id: 4,
      title: "Get Pre-Approved",
      description: "Apply for mortgage pre-approval based on your finances",
      completed: playerFinances.currentStep > 4
    },
    {
      id: 5,
      title: "Plan Your Savings",
      description: "Create a savings plan to reach your down payment goal",
      completed: playerFinances.currentStep > 5
    },
    {
      id: 6,
      title: "Close on Your Home",
      description: "Complete the home purchase and move in!",
      completed: gameComplete
    }
  ];

  const calculateMortgage = (principal: number, rate: number, years: number) => {
    const monthlyRate = rate / 100 / 12;
    const numPayments = years * 12;
    const monthlyPayment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
                          (Math.pow(1 + monthlyRate, numPayments) - 1);
    return monthlyPayment;
  };

  const getInterestRate = (creditScore: number) => {
    if (creditScore >= 740) return 6.5;
    if (creditScore >= 680) return 7.0;
    if (creditScore >= 620) return 7.5;
    return 8.5;
  };

  const selectHouse = (house: HouseOption) => {
    const downPayment = house.price * (house.downPaymentPercent / 100);
    const mortgageAmount = house.price - downPayment;
    const interestRate = getInterestRate(playerFinances.creditScore);
    const monthlyPayment = calculateMortgage(mortgageAmount, interestRate, 30);

    setPlayerFinances(prev => ({
      ...prev,
      selectedHouse: house,
      downPayment,
      mortgageAmount,
      monthlyPayment,
      interestRate,
      currentStep: 3
    }));
  };

  const proceedToNextStep = () => {
    setPlayerFinances(prev => ({
      ...prev,
      currentStep: prev.currentStep + 1
    }));
  };

  const calculateSavingTime = () => {
    if (!playerFinances.selectedHouse) return 0;
    
    const monthlyLeftover = playerFinances.monthlyIncome - playerFinances.monthlyExpenses;
    const remainingNeeded = playerFinances.downPayment - playerFinances.savings;
    
    if (remainingNeeded <= 0) return 0;
    if (monthlyLeftover <= 0) return 999; // Can't save
    
    return Math.ceil(remainingNeeded / monthlyLeftover);
  };

  const completePurchase = () => {
    setGameComplete(true);
    setSavingMonths(calculateSavingTime());
  };

  const resetGame = () => {
    setGameStarted(false);
    setGameComplete(false);
    setSavingMonths(0);
    setPlayerFinances({
      savings: 15000,
      monthlyIncome: 4000,
      monthlyExpenses: 2500,
      creditScore: 720,
      currentStep: 1,
      selectedHouse: null,
      downPayment: 0,
      mortgageAmount: 0,
      monthlyPayment: 0,
      interestRate: 0,
      loanTerm: 30
    });
  };

  const startGame = () => {
    setGameStarted(true);
  };

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-4 shadow-lg">
          <div className="max-w-4xl mx-auto">
            <Link href="/games">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Games
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">🏠 Build the House Game</h1>
            <p className="text-lg text-blue-100">Plan and save for your dream home!</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {/* What You'll Learn */}
          <Card>
            <CardHeader>
              <CardTitle className="text-blue-600">What You'll Learn:</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-gray-700">This game teaches you the complete home buying process:</p>
                <ul className="space-y-2 text-gray-600">
                  <li>🏦 How mortgages and interest rates work</li>
                  <li>💰 Calculating down payments and monthly payments</li>
                  <li>📊 Understanding credit scores and loan approval</li>
                  <li>💡 Creating a realistic savings plan</li>
                  <li>🏠 Choosing a home within your budget</li>
                  <li>📈 Long-term financial planning for homeownership</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Your Starting Financial Profile */}
          <Card>
            <CardHeader>
              <CardTitle className="text-green-600">Your Starting Financial Profile</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Current Savings:</span>
                    <span className="font-bold text-green-600">${playerFinances.savings.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Monthly Income:</span>
                    <span className="font-bold text-blue-600">${playerFinances.monthlyIncome.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Monthly Expenses:</span>
                    <span className="font-bold text-red-600">${playerFinances.monthlyExpenses.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Credit Score:</span>
                    <span className="font-bold text-purple-600">{playerFinances.creditScore}</span>
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-bold text-blue-800 mb-2">Monthly Budget Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Income:</span>
                      <span className="text-green-600">+${playerFinances.monthlyIncome}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Expenses:</span>
                      <span className="text-red-600">-${playerFinances.monthlyExpenses}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-bold">
                      <span>Available for Savings:</span>
                      <span className="text-blue-600">${playerFinances.monthlyIncome - playerFinances.monthlyExpenses}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Game Steps Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-600">Your Home Buying Journey</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {gameSteps.map((step, index) => (
                  <div key={step.id} className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-bold">
                      {step.id}
                    </div>
                    <div>
                      <div className="font-medium">{step.title}</div>
                      <div className="text-sm text-gray-600">{step.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Button onClick={startGame} className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-4">
            Start Your Home Buying Journey
          </Button>
        </div>
      </div>
    );
  }

  if (gameComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-4 shadow-lg">
          <div className="max-w-6xl mx-auto">
            <Link href="/games">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Games
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">🎉 Congratulations! You're a Homeowner!</h1>
            <p className="text-lg text-blue-100">You've successfully planned and purchased your dream home!</p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-4 space-y-6">
          {/* Success Summary */}
          <Card className="border-green-300 bg-green-50">
            <CardHeader>
              <CardTitle className="text-green-600">🏠 Your New Home Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="text-6xl mb-4 text-center">{playerFinances.selectedHouse?.image}</div>
                  <h3 className="text-xl font-bold mb-2">{playerFinances.selectedHouse?.name}</h3>
                  <p className="text-gray-600 mb-2">{playerFinances.selectedHouse?.description}</p>
                  <p className="text-sm text-gray-500">📍 {playerFinances.selectedHouse?.location}</p>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Home Price:</span>
                    <span className="font-bold">${playerFinances.selectedHouse?.price.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Down Payment:</span>
                    <span className="font-bold text-green-600">${playerFinances.downPayment.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mortgage Amount:</span>
                    <span className="font-bold">${playerFinances.mortgageAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Interest Rate:</span>
                    <span className="font-bold">{playerFinances.interestRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Payment:</span>
                    <span className="font-bold text-blue-600">${playerFinances.monthlyPayment.toFixed(0)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Impact */}
          <Card>
            <CardHeader>
              <CardTitle>Your Financial Journey</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{savingMonths} months</div>
                  <div className="text-sm text-gray-600">Time needed to save down payment</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">${playerFinances.creditScore >= 740 ? "Great" : "Good"}</div>
                  <div className="text-sm text-gray-600">Credit score rating</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    ${((playerFinances.monthlyPayment + (playerFinances.selectedHouse?.monthlyMaintenance || 0))).toFixed(0)}
                  </div>
                  <div className="text-sm text-gray-600">Total monthly housing cost</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Key Lessons */}
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-600">What You Learned</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-gray-800 mb-3">💡 Key Financial Concepts:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>✓ Down payments reduce monthly mortgage payments</li>
                    <li>✓ Credit scores significantly impact interest rates</li>
                    <li>✓ Monthly housing costs include mortgage + maintenance</li>
                    <li>✓ Saving consistently helps reach financial goals</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-3">🏠 Home Buying Process:</h4>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>✓ Always get pre-approved before house hunting</li>
                    <li>✓ Consider total monthly costs, not just mortgage</li>
                    <li>✓ Location affects both price and lifestyle</li>
                    <li>✓ Financial planning makes homeownership possible</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <Card className="bg-orange-50 border-orange-200">
            <CardHeader>
              <CardTitle className="text-orange-800">🚀 Ready for Real Life?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-orange-700 mb-4">
                Now that you understand the home buying process, start building these habits in real life:
              </p>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h5 className="font-bold mb-2">Start Today:</h5>
                  <ul className="space-y-1 text-orange-600">
                    <li>• Open a savings account for your future home</li>
                    <li>• Track your spending to maximize savings</li>
                    <li>• Learn about credit scores and how to improve them</li>
                  </ul>
                </div>
                <div>
                  <h5 className="font-bold mb-2">Long-term Goals:</h5>
                  <ul className="space-y-1 text-orange-600">
                    <li>• Research neighborhoods you might like</li>
                    <li>• Set a realistic timeline for homeownership</li>
                    <li>• Continue learning about real estate investing</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button onClick={resetGame} className="flex-1 bg-blue-600 hover:bg-blue-700">
              Try Different Scenarios
            </Button>
            <Link href="/games" className="flex-1">
              <Button variant="outline" className="w-full">
                Play More Games
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-4 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <Link href="/games">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Games
            </Button>
          </Link>
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">🏠 Build the House Game</h1>
              <p className="text-lg text-blue-100">Step {playerFinances.currentStep} of 6</p>
            </div>
            <Home className="w-12 h-12" />
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Progress Bar */}
        <Card>
          <CardContent className="p-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>{playerFinances.currentStep}/6 Steps Complete</span>
              </div>
              <Progress value={(playerFinances.currentStep / 6) * 100} className="h-3" />
            </div>
          </CardContent>
        </Card>

        {/* Current Financial Status */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-sm text-gray-600">Savings</div>
              <div className="text-xl font-bold text-green-600">${playerFinances.savings.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <div className="text-sm text-gray-600">Monthly Income</div>
              <div className="text-xl font-bold text-blue-600">${playerFinances.monthlyIncome.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Calculator className="w-8 h-8 mx-auto mb-2 text-red-600" />
              <div className="text-sm text-gray-600">Monthly Expenses</div>
              <div className="text-xl font-bold text-red-600">${playerFinances.monthlyExpenses.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <div className="text-sm text-gray-600">Credit Score</div>
              <div className="text-xl font-bold text-purple-600">{playerFinances.creditScore}</div>
            </CardContent>
          </Card>
        </div>

        {/* Step Content */}
        {playerFinances.currentStep === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Financial Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-bold text-blue-800 mb-3">Your Financial Health Check</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-medium mb-2">Monthly Cash Flow:</h5>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>Income:</span>
                          <span className="text-green-600">+${playerFinances.monthlyIncome}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Expenses:</span>
                          <span className="text-red-600">-${playerFinances.monthlyExpenses}</span>
                        </div>
                        <div className="border-t pt-1 flex justify-between font-bold">
                          <span>Available:</span>
                          <span className="text-blue-600">+${playerFinances.monthlyIncome - playerFinances.monthlyExpenses}</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h5 className="font-medium mb-2">Credit Score Analysis:</h5>
                      <div className="text-sm">
                        <div>Score: <span className="font-bold">{playerFinances.creditScore}</span></div>
                        <div>Rating: <span className="font-bold text-green-600">
                          {playerFinances.creditScore >= 740 ? "Excellent" :
                           playerFinances.creditScore >= 680 ? "Good" :
                           playerFinances.creditScore >= 620 ? "Fair" : "Poor"}
                        </span></div>
                        <div>Est. Rate: <span className="font-bold">{getInterestRate(playerFinances.creditScore)}%</span></div>
                      </div>
                    </div>
                  </div>
                </div>
                <Button onClick={proceedToNextStep} className="w-full bg-blue-600 hover:bg-blue-700">
                  Continue to House Selection
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {playerFinances.currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Choose Your Dream Home</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {houseOptions.map((house) => {
                  const downPaymentNeeded = house.price * (house.downPaymentPercent / 100);
                  const canAfford = playerFinances.savings >= downPaymentNeeded;
                  
                  return (
                    <Card key={house.id} className={`cursor-pointer transition-all ${canAfford ? 'hover:shadow-lg border-green-200' : 'opacity-75 border-red-200'}`}>
                      <CardHeader>
                        <div className="text-center">
                          <div className="text-4xl mb-2">{house.image}</div>
                          <CardTitle className="text-lg">{house.name}</CardTitle>
                          <div className="text-2xl font-bold text-blue-600">${house.price.toLocaleString()}</div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <p className="text-sm text-gray-600">{house.description}</p>
                          <div className="flex items-center text-sm text-gray-500">
                            <MapPin className="w-4 h-4 mr-1" />
                            {house.location}
                          </div>
                          
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span>Down Payment ({house.downPaymentPercent}%):</span>
                              <span className={canAfford ? "text-green-600" : "text-red-600"}>
                                ${downPaymentNeeded.toLocaleString()}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span>Monthly Maintenance:</span>
                              <span>${house.monthlyMaintenance}</span>
                            </div>
                          </div>
                          
                          {canAfford ? (
                            <Button 
                              onClick={() => selectHouse(house)}
                              className="w-full bg-green-600 hover:bg-green-700"
                            >
                              Select This Home
                            </Button>
                          ) : (
                            <Button variant="outline" disabled className="w-full">
                              Need ${(downPaymentNeeded - playerFinances.savings).toLocaleString()} More
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {playerFinances.currentStep === 3 && playerFinances.selectedHouse && (
          <Card>
            <CardHeader>
              <CardTitle>Step 3: Down Payment Calculation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-gray-800 mb-3">Selected Home</h4>
                  <div className="text-center mb-4">
                    <div className="text-4xl mb-2">{playerFinances.selectedHouse.image}</div>
                    <h5 className="font-bold">{playerFinances.selectedHouse.name}</h5>
                    <p className="text-sm text-gray-600">{playerFinances.selectedHouse.location}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-3">Financial Breakdown</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span>Home Price:</span>
                      <span className="font-bold">${playerFinances.selectedHouse.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Down Payment ({playerFinances.selectedHouse.downPaymentPercent}%):</span>
                      <span className="font-bold text-green-600">${playerFinances.downPayment.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Mortgage Amount:</span>
                      <span className="font-bold">${playerFinances.mortgageAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Your Current Savings:</span>
                      <span className="font-bold text-blue-600">${playerFinances.savings.toLocaleString()}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between">
                      <span>Amount Needed:</span>
                      <span className={`font-bold ${playerFinances.downPayment <= playerFinances.savings ? 'text-green-600' : 'text-red-600'}`}>
                        ${Math.max(0, playerFinances.downPayment - playerFinances.savings).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <Button onClick={proceedToNextStep} className="w-full mt-6 bg-blue-600 hover:bg-blue-700">
                Get Pre-Approved for Mortgage
              </Button>
            </CardContent>
          </Card>
        )}

        {playerFinances.currentStep === 4 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 4: Mortgage Pre-Approval</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-bold text-green-800 mb-3">✅ Pre-Approval Approved!</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Loan Amount:</span>
                      <span className="font-bold">${playerFinances.mortgageAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Interest Rate:</span>
                      <span className="font-bold">{playerFinances.interestRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Loan Term:</span>
                      <span className="font-bold">30 years</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Monthly Payment:</span>
                      <span className="font-bold text-green-600">${playerFinances.monthlyPayment.toFixed(0)}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-3">Total Monthly Housing Costs</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Mortgage Payment:</span>
                      <span>${playerFinances.monthlyPayment.toFixed(0)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Maintenance/HOA:</span>
                      <span>${playerFinances.selectedHouse?.monthlyMaintenance}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-bold">
                      <span>Total Monthly:</span>
                      <span className="text-blue-600">
                        ${(playerFinances.monthlyPayment + (playerFinances.selectedHouse?.monthlyMaintenance || 0)).toFixed(0)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 p-3 bg-blue-50 rounded">
                    <div className="text-xs text-blue-800">
                      <strong>Affordability Check:</strong> This represents{' '}
                      {(((playerFinances.monthlyPayment + (playerFinances.selectedHouse?.monthlyMaintenance || 0)) / playerFinances.monthlyIncome) * 100).toFixed(1)}%{' '}
                      of your monthly income. Financial experts recommend keeping housing costs under 28%.
                    </div>
                  </div>
                </div>
              </div>
              <Button onClick={proceedToNextStep} className="w-full mt-6 bg-blue-600 hover:bg-blue-700">
                Create Savings Plan
              </Button>
            </CardContent>
          </Card>
        )}

        {playerFinances.currentStep === 5 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 5: Savings Plan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-bold text-blue-800 mb-3">Savings Timeline</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Down Payment Needed:</span>
                        <span className="font-bold">${playerFinances.downPayment.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Current Savings:</span>
                        <span className="font-bold">${playerFinances.savings.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Still Need:</span>
                        <span className="font-bold text-red-600">
                          ${Math.max(0, playerFinances.downPayment - playerFinances.savings).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Monthly Savings Potential:</span>
                        <span className="font-bold text-green-600">
                          ${playerFinances.monthlyIncome - playerFinances.monthlyExpenses}
                        </span>
                      </div>
                      <div className="border-t pt-2 flex justify-between">
                        <span>Time to Save:</span>
                        <span className="font-bold text-blue-600">
                          {calculateSavingTime() === 0 ? "Ready Now!" : 
                           calculateSavingTime() > 100 ? "Need higher income" :
                           `${calculateSavingTime()} months`}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-bold text-gray-800 mb-3">Savings Tips</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li>🎯 Set up automatic transfers to savings</li>
                      <li>💡 Cut unnecessary expenses to save more</li>
                      <li>📈 Consider a high-yield savings account</li>
                      <li>💼 Look for additional income opportunities</li>
                      <li>🏦 Keep savings separate from checking</li>
                      <li>📊 Track your progress monthly</li>
                    </ul>
                  </div>
                </div>
                
                {playerFinances.downPayment <= playerFinances.savings ? (
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h4 className="font-bold text-green-800 mb-2">🎉 Congratulations!</h4>
                    <p className="text-green-700">You already have enough savings for the down payment! You're ready to close on your home.</p>
                  </div>
                ) : (
                  <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                    <h4 className="font-bold text-orange-800 mb-2">💪 Keep Saving!</h4>
                    <p className="text-orange-700">
                      You need ${(playerFinances.downPayment - playerFinances.savings).toLocaleString()} more. 
                      At your current saving rate, you'll be ready in {calculateSavingTime()} months!
                    </p>
                  </div>
                )}
                
                <Button onClick={proceedToNextStep} className="w-full bg-blue-600 hover:bg-blue-700">
                  Complete Home Purchase
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {playerFinances.currentStep === 6 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 6: Closing Day!</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-6">
                <div className="text-6xl">{playerFinances.selectedHouse?.image}</div>
                <h3 className="text-2xl font-bold">Welcome to Your New Home!</h3>
                <p className="text-gray-600">
                  You've successfully navigated the home buying process. Time to get the keys and move in!
                </p>
                
                <div className="bg-green-50 p-6 rounded-lg">
                  <h4 className="font-bold text-green-800 mb-4">Final Purchase Summary</h4>
                  <div className="grid md:grid-cols-2 gap-6 text-sm">
                    <div className="text-left">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Home:</span>
                          <span className="font-bold">{playerFinances.selectedHouse?.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Purchase Price:</span>
                          <span className="font-bold">${playerFinances.selectedHouse?.price.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Down Payment:</span>
                          <span className="font-bold">${playerFinances.downPayment.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Mortgage:</span>
                          <span className="font-bold">${playerFinances.mortgageAmount.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Monthly Payment:</span>
                          <span className="font-bold">${playerFinances.monthlyPayment.toFixed(0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Interest Rate:</span>
                          <span className="font-bold">{playerFinances.interestRate}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Button onClick={completePurchase} className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                  🎉 Complete Purchase & Get Keys!
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}