import { useState, useEffect } from "react";
import { Check, Star, Crown, Zap, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import { Link } from "wouter";

export default function Membership() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    // Load Stripe pricing table script
    const script = document.createElement('script');
    script.src = 'https://js.stripe.com/v3/pricing-table.js';
    script.async = true;
    document.head.appendChild(script);

    return () => {
      // Cleanup script when component unmounts
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  const subscriptionTiers = [
    {
      id: "starter",
      name: "Starter",
      price: 19,
      period: "month",
      description: "Perfect for beginners starting their financial journey",
      icon: <Star className="w-8 h-8" />,
      color: "from-blue-500 to-blue-600",
      features: [
        "Access to Credit for Starters course",
        "Banking for Starters course", 
        "Interactive credit simulator",
        "Basic financial calculators",
        "Community access",
        "Mobile app access",
        "Email support"
      ],
      courses: ["Credit for Starters", "Banking for Starters"]
    },
    {
      id: "pro",
      name: "Pro", 
      price: 39,
      period: "month",
      description: "Complete financial education for serious learners",
      icon: <Crown className="w-8 h-8" />,
      color: "from-purple-500 to-purple-600",
      popular: true,
      features: [
        "Everything in Starter",
        "Business for Starters course",
        "Advanced credit strategies",
        "Investment fundamentals",
        "Business planning tools",
        "Priority community support",
        "Live Q&A sessions (monthly)",
        "Certificate of completion",
        "Progress tracking & analytics"
      ],
      courses: ["All Foundation Courses", "Business Fundamentals", "Investment Basics"]
    },
    {
      id: "elite",
      name: "Elite",
      price: 79,
      period: "month", 
      description: "Premium tier with advanced wealth-building strategies",
      icon: <Zap className="w-8 h-8" />,
      color: "from-yellow-500 to-amber-600",
      features: [
        "Everything in Pro",
        "Trust for Starters course",
        "Estate Planning for Starters",
        "Advanced tax strategies", 
        "One-on-one coaching session (monthly)",
        "Custom financial planning",
        "Exclusive mastermind community",
        "Early access to new courses",
        "Lifetime access guarantee",
        "Direct instructor access"
      ],
      courses: ["All Courses", "Premium Content", "Exclusive Materials"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <Link href="/courses">
              <Button className="mb-6 bg-white/20 text-white border-white/30 hover:bg-white/30">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Courses
              </Button>
            </Link>
            
            <h1 className="text-5xl font-bold text-white mb-6">
              🚀 Rouz Up Academy Memberships
            </h1>
            <p className="text-xl text-purple-100 mb-8 leading-relaxed">
              Join thousands of students building their financial future with our comprehensive subscription tiers. 
              Get unlimited access to all courses, tools, and community support!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <Badge className="bg-yellow-400 text-purple-900 px-6 py-2 text-lg font-bold">
                💰 Cancel Anytime
              </Badge>
              <Badge className="bg-green-400 text-purple-900 px-6 py-2 text-lg font-bold">
                🎯 Start Today
              </Badge>
              <Badge className="bg-pink-400 text-purple-900 px-6 py-2 text-lg font-bold">
                🏆 Build Wealth
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Subscription Tiers */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Financial Success Plan</h2>
            <p className="text-lg text-gray-600">Select the subscription tier that matches your learning goals and budget</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {subscriptionTiers.map((tier, index) => (
              <Card 
                key={tier.id}
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105 ${
                  tier.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                }`}
              >
                {tier.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-center py-2 text-sm font-bold">
                    🔥 MOST POPULAR
                  </div>
                )}
                
                <CardHeader className={`text-center pb-8 bg-gradient-to-br ${tier.color} text-white ${tier.popular ? 'pt-12' : 'pt-8'}`}>
                  <div className="mx-auto mb-4 text-white">
                    {tier.icon}
                  </div>
                  <CardTitle className="text-2xl font-bold mb-2">{tier.name}</CardTitle>
                  <p className="text-blue-100 mb-4">{tier.description}</p>
                  <div className="text-center">
                    <span className="text-4xl font-bold">${tier.price}</span>
                    <span className="text-blue-100">/{tier.period}</span>
                  </div>
                </CardHeader>

                <CardContent className="p-8">
                  <ul className="space-y-4 mb-8">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <Check className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Included Courses:</h4>
                    <div className="flex flex-wrap gap-2">
                      {tier.courses.map((course, courseIndex) => (
                        <Badge key={courseIndex} variant="outline" className="text-xs">
                          {course}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button 
                    className={`w-full py-3 text-lg font-semibold transition-all duration-200 bg-gradient-to-r ${tier.color} text-white hover:opacity-90 hover:scale-105`}
                  >
                    Start {tier.name} Plan
                  </Button>
                  
                  <p className="text-center text-sm text-gray-500 mt-3">
                    Cancel anytime • No setup fees
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose a Subscription?</h2>
            <p className="text-lg text-gray-600">Get more value and continuous learning with our membership model</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white mb-4">
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Continuous Updates</h3>
                <p className="text-gray-600">New courses and content added regularly at no extra cost</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white mb-4">
                  <Crown className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Community Access</h3>
                <p className="text-gray-600">Connect with other learners and get support on your journey</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white mb-4">
                  <Zap className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Better Value</h3>
                <p className="text-gray-600">Access multiple courses for less than the price of one individual course</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Compare Plans</h2>
            <p className="text-lg text-gray-600">See what's included in each subscription tier</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-200 p-4 text-left">Features</th>
                  <th className="border border-gray-200 p-4 text-center">Starter</th>
                  <th className="border border-gray-200 p-4 text-center bg-purple-50">Pro</th>
                  <th className="border border-gray-200 p-4 text-center">Elite</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">Credit for Starters</td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">Banking for Starters</td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">Business for Starters</td>
                  <td className="border border-gray-200 p-4 text-center">-</td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">Trust & Estate Planning</td>
                  <td className="border border-gray-200 p-4 text-center">-</td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50">-</td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">Community Access</td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="border border-gray-200 p-4 font-medium">One-on-One Coaching</td>
                  <td className="border border-gray-200 p-4 text-center">-</td>
                  <td className="border border-gray-200 p-4 text-center bg-purple-50">-</td>
                  <td className="border border-gray-200 p-4 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Can I cancel anytime?</h3>
                <p className="text-gray-600">Yes! You can cancel your subscription at any time with no cancellation fees. You'll continue to have access until the end of your current billing period.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Can I upgrade or downgrade my plan?</h3>
                <p className="text-gray-600">Absolutely! You can change your subscription tier at any time. Upgrades take effect immediately, while downgrades take effect at your next billing cycle.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">What payment methods do you accept?</h3>
                <p className="text-gray-600">We accept all major credit cards, debit cards, and digital wallets through our secure Stripe payment processing.</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-2">Is there a free trial?</h3>
                <p className="text-gray-600">We offer a 7-day free trial for new members on the Pro plan. You can explore all features before your subscription begins.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Financial Future?
          </h2>
          <p className="text-xl text-purple-100 mb-8">
            Join thousands of students who are already building wealth with Rouz Up Academy!
          </p>
          <Button 
            size="lg"
            className="bg-yellow-400 text-purple-900 hover:bg-yellow-300 px-8 py-4 rounded-xl font-bold text-lg"
          >
            Start Your Free Trial Today
            <Zap className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>
    </div>
  );
}