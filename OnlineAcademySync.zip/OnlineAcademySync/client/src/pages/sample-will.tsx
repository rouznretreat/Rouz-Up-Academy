import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function SampleWill() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => setLocation("/estate-planning-course")}
          className="mb-4"
        >
          ← Back to Documents
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-blue-700">Sample Last Will and Testament</CardTitle>
            <p className="text-gray-600">Educational example showing proper will structure and language</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
              <div className="text-center font-bold text-lg mb-6">
                LAST WILL AND TESTAMENT<br/>
                OF<br/>
                SARAH ELIZABETH MARTINEZ
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold mb-2">ARTICLE I - EXORDIUM</h4>
                  <p>I, SARAH ELIZABETH MARTINEZ, a resident of Harris County, Texas, being of sound mind and disposing memory, do hereby make, publish and declare this to be my Last Will and Testament, hereby revoking all former wills and codicils by me at any time heretofore made.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE II - FAMILY INFORMATION</h4>
                  <p>I am married to MICHAEL ROBERT MARTINEZ. I have two children now living, namely: ISABELLA MARIE MARTINEZ, born March 15, 2010, and DIEGO ANTONIO MARTINEZ, born September 22, 2012. All references in this Will to "my children" refer to the above-named children and to any children hereafter born to or adopted by me.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE III - PAYMENT OF DEBTS</h4>
                  <p>I direct that all my just debts, funeral expenses, and costs of administration of my estate be paid as soon as practicable after my death.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE IV - SPECIFIC BEQUESTS</h4>
                  <p>I give and bequeath the following specific gifts:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>A. To my daughter, ISABELLA MARIE MARTINEZ, my grandmother's diamond ring and jewelry box.</li>
                    <li>B. To my son, DIEGO ANTONIO MARTINEZ, my father's watch collection and tools.</li>
                    <li>C. To the Houston Food Bank, the sum of Five Thousand Dollars ($5,000).</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE V - RESIDUARY ESTATE</h4>
                  <p>All the rest, residue and remainder of my estate, both real and personal, of whatsoever kind and wheresoever situated, I give, devise and bequeath to my husband, MICHAEL ROBERT MARTINEZ, if he survives me by thirty (30) days. If my husband does not survive me by thirty (30) days, then I give, devise and bequeath my residuary estate in equal shares to my children, ISABELLA MARIE MARTINEZ and DIEGO ANTONIO MARTINEZ.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE VI - EXECUTOR</h4>
                  <p>I hereby nominate and appoint my husband, MICHAEL ROBERT MARTINEZ, as Executor of this Will. If he is unable or unwilling to serve, I nominate my sister, MARIA ELENA RODRIGUEZ, as alternate Executor. I direct that no bond shall be required of any Executor.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ARTICLE VII - GUARDIAN</h4>
                  <p>If at my death any of my children are minors, I nominate my sister, MARIA ELENA RODRIGUEZ, as Guardian of the person and property of such minor children.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">TESTIMONIUM</h4>
                  <p>IN WITNESS WHEREOF, I have hereunto set my hand this _____ day of __________, 2024.</p>
                  <div className="mt-4 text-right">
                    <p>_________________________________</p>
                    <p>SARAH ELIZABETH MARTINEZ, Testator</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ATTESTATION CLAUSE</h4>
                  <p>The foregoing instrument was signed and published by SARAH ELIZABETH MARTINEZ as her Last Will and Testament in our presence, and we, at her request and in her presence and in the presence of each other, have subscribed our names as witnesses thereto.</p>
                  
                  <div className="mt-4 space-y-3">
                    <div>
                      <p>_________________________________   Date: __________</p>
                      <p>Witness Name: _____________________</p>
                      <p>Address: __________________________</p>
                    </div>
                    <div>
                      <p>_________________________________   Date: __________</p>
                      <p>Witness Name: _____________________</p>
                      <p>Address: __________________________</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-blue-50 p-4 rounded border border-blue-300">
              <h4 className="font-bold text-blue-700 mb-2">Key Elements Demonstrated:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• <strong>Exordium</strong> - Establishes testator's identity and mental capacity</li>
                <li>• <strong>Revocation Clause</strong> - Cancels all previous wills</li>
                <li>• <strong>Family Information</strong> - Identifies spouse and children</li>
                <li>• <strong>Specific Bequests</strong> - Individual gifts to named beneficiaries</li>
                <li>• <strong>Residuary Clause</strong> - Disposes of remaining estate</li>
                <li>• <strong>Executor Appointment</strong> - Names estate administrator</li>
                <li>• <strong>Guardian Nomination</strong> - Provides for minor children</li>
                <li>• <strong>Proper Attestation</strong> - Witness requirements</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}