import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Clock, TrendingUp, Calendar, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TimeScenario {
  age: number;
  title: string;
  description: string;
  monthlyAmount: number;
  years: number;
  interestRate: number;
}

const timeScenarios: TimeScenario[] = [
  {
    age: 16,
    title: "The Early Bird",
    description: "Start investing at 16 with money from your part-time job",
    monthlyAmount: 50,
    years: 49, // Until 65
    interestRate: 0.07
  },
  {
    age: 22,
    title: "The College Graduate", 
    description: "Start investing after college graduation",
    monthlyAmount: 150,
    years: 43, // Until 65
    interestRate: 0.07
  },
  {
    age: 30,
    title: "The Career Starter",
    description: "Start investing when career gets serious",
    monthlyAmount: 300,
    years: 35, // Until 65
    interestRate: 0.07
  },
  {
    age: 40,
    title: "The Mid-Life Awakening",
    description: "Finally start investing at 40",
    monthlyAmount: 500,
    years: 25, // Until 65
    interestRate: 0.07
  }
];

interface TimeResult {
  totalContributed: number;
  finalAmount: number;
  interestEarned: number;
}

export default function MoneyTimeTravel() {
  const [selectedScenario, setSelectedScenario] = useState<TimeScenario | null>(null);
  const [results, setResults] = useState<TimeResult[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const [currentYear, setCurrentYear] = useState(2024);

  const calculateCompoundInterest = (monthly: number, years: number, rate: number): TimeResult => {
    const monthlyRate = rate / 12;
    const totalMonths = years * 12;
    const totalContributed = monthly * totalMonths;
    
    // Future value of annuity formula
    const finalAmount = monthly * (((1 + monthlyRate) ** totalMonths - 1) / monthlyRate);
    const interestEarned = finalAmount - totalContributed;
    
    return {
      totalContributed,
      finalAmount,
      interestEarned
    };
  };

  const travelToScenario = (scenario: TimeScenario) => {
    setSelectedScenario(scenario);
    setCurrentYear(scenario.age + 2000); // Simulate being that age
    const result = calculateCompoundInterest(scenario.monthlyAmount, scenario.years, scenario.interestRate);
    setResults([result]);
  };

  const compareAllScenarios = () => {
    const allResults = timeScenarios.map(scenario => 
      calculateCompoundInterest(scenario.monthlyAmount, scenario.years, scenario.interestRate)
    );
    setResults(allResults);
    setShowComparison(true);
    setSelectedScenario(null);
  };

  const getYearlyBreakdown = (scenario: TimeScenario) => {
    const breakdown = [];
    let balance = 0;
    const monthlyRate = scenario.interestRate / 12;
    
    for (let year = 1; year <= Math.min(scenario.years, 10); year++) {
      for (let month = 1; month <= 12; month++) {
        balance = balance * (1 + monthlyRate) + scenario.monthlyAmount;
      }
      breakdown.push({
        year: scenario.age + year,
        balance: balance,
        contributed: scenario.monthlyAmount * 12 * year
      });
    }
    return breakdown;
  };

  const resetGame = () => {
    setSelectedScenario(null);
    setResults([]);
    setShowComparison(false);
    setCurrentYear(2024);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      <div className="bg-black/50 shadow-sm border-b border-purple-600 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2 text-white border-purple-400 hover:bg-purple-800">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-purple-100">⏰ Money Time Travel Machine</h1>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-400" />
            <span className="text-blue-400 font-bold">{currentYear}</span>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {!selectedScenario && !showComparison && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">🕰️</div>
            <h2 className="text-4xl font-bold text-purple-100 mb-4">Travel Through Time</h2>
            <p className="text-xl text-purple-200 mb-8 max-w-3xl mx-auto">
              See how starting to invest at different ages affects your wealth! 
              The power of compound interest over time will shock you.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {timeScenarios.map((scenario, index) => (
                <div 
                  key={index}
                  className="bg-purple-800/50 rounded-xl p-6 border-2 border-purple-600 hover:border-blue-400 cursor-pointer transition-all hover:scale-105"
                  onClick={() => travelToScenario(scenario)}
                >
                  <div className="text-4xl mb-4">
                    {scenario.age === 16 ? '👶' : scenario.age === 22 ? '🎓' : scenario.age === 30 ? '💼' : '😰'}
                  </div>
                  <h3 className="text-lg font-bold text-purple-100 mb-2">{scenario.title}</h3>
                  <div className="space-y-2 text-sm text-purple-200">
                    <div>Start at age {scenario.age}</div>
                    <div>${scenario.monthlyAmount}/month</div>
                    <div>{scenario.years} years</div>
                  </div>
                  <p className="text-xs text-purple-300 mt-4">{scenario.description}</p>
                </div>
              ))}
            </div>

            <Button 
              onClick={compareAllScenarios}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
            >
              🔮 Compare All Time Periods
            </Button>
          </div>
        )}

        {selectedScenario && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-purple-800/50 rounded-xl p-8 mb-8 border-2 border-purple-600">
              <div className="text-center mb-6">
                <div className="text-6xl mb-4">⏰</div>
                <h2 className="text-3xl font-bold text-purple-100 mb-2">Welcome to {currentYear}!</h2>
                <h3 className="text-2xl text-blue-300 mb-4">{selectedScenario.title}</h3>
                <p className="text-lg text-purple-200">{selectedScenario.description}</p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-400">{selectedScenario.age}</div>
                  <div className="text-purple-200">Starting Age</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-green-400">${selectedScenario.monthlyAmount}</div>
                  <div className="text-purple-200">Per Month</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-400">{selectedScenario.years}</div>
                  <div className="text-purple-200">Years</div>
                </div>
                <div className="bg-black/30 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-purple-400">7%</div>
                  <div className="text-purple-200">Annual Return</div>
                </div>
              </div>

              {results.length > 0 && (
                <div className="bg-black/30 rounded-xl p-6 mb-6">
                  <h3 className="text-2xl font-bold text-purple-100 mb-4">🔮 Your Financial Future at 65:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-400 mb-2">
                        ${results[0].totalContributed.toLocaleString()}
                      </div>
                      <div className="text-purple-200">Total You Invested</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-400 mb-2">
                        ${results[0].interestEarned.toLocaleString()}
                      </div>
                      <div className="text-purple-200">Interest Earned</div>
                    </div>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-yellow-400 mb-2">
                        ${results[0].finalAmount.toLocaleString()}
                      </div>
                      <div className="text-purple-200">Final Amount</div>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-black/20 rounded-lg p-4">
                <h4 className="text-lg font-bold text-purple-100 mb-3">First 10 Years Progress:</h4>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
                  {getYearlyBreakdown(selectedScenario).map((year, index) => (
                    <div key={index} className="text-center">
                      <div className="font-bold text-blue-300">Age {year.year}</div>
                      <div className="text-green-300">${Math.round(year.balance).toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-center space-y-4">
              <Button 
                onClick={compareAllScenarios}
                className="bg-blue-600 hover:bg-blue-700 px-6 py-3 mr-4"
              >
                Compare All Ages
              </Button>
              <Button 
                onClick={resetGame}
                variant="outline"
                className="text-white border-purple-400 hover:bg-purple-800 px-6 py-3"
              >
                Reset Time Machine
              </Button>
            </div>
          </div>
        )}

        {showComparison && (
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">📊</div>
              <h2 className="text-3xl font-bold text-purple-100 mb-4">The Shocking Truth About Time</h2>
              <p className="text-lg text-purple-200">See how starting age dramatically affects your wealth at retirement (age 65)</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {timeScenarios.map((scenario, index) => (
                <div key={index} className="bg-purple-800/50 rounded-xl p-6 border-2 border-purple-600">
                  <div className="text-center mb-4">
                    <div className="text-3xl mb-2">
                      {scenario.age === 16 ? '👶' : scenario.age === 22 ? '🎓' : scenario.age === 30 ? '💼' : '😰'}
                    </div>
                    <h3 className="text-lg font-bold text-purple-100">{scenario.title}</h3>
                    <div className="text-sm text-purple-300">Start at {scenario.age}</div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-purple-200">Monthly:</span>
                      <span className="font-bold text-green-400">${scenario.monthlyAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-200">Years:</span>
                      <span className="font-bold text-blue-400">{scenario.years}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-200">Total Invested:</span>
                      <span className="font-bold text-blue-300">${results[index]?.totalContributed.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-purple-600 pt-3">
                      <div className="flex justify-between">
                        <span className="text-purple-200">Final Amount:</span>
                        <span className="font-bold text-yellow-400 text-lg">${results[index]?.finalAmount.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-red-800/50 to-green-800/50 rounded-xl p-8 border-2 border-yellow-400">
              <h3 className="text-2xl font-bold text-yellow-300 mb-4 text-center">🤯 Mind-Blowing Comparison</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="text-center">
                  <div className="text-4xl mb-2">👶➡️💰</div>
                  <h4 className="text-xl font-bold text-green-400 mb-2">Early Bird (Age 16)</h4>
                  <div className="text-3xl font-bold text-green-400 mb-2">
                    ${results[0]?.finalAmount.toLocaleString()}
                  </div>
                  <div className="text-green-300">Invested only ${results[0]?.totalContributed.toLocaleString()}</div>
                </div>
                
                <div className="text-center">
                  <div className="text-4xl mb-2">😰➡️💸</div>
                  <h4 className="text-xl font-bold text-red-400 mb-2">Late Starter (Age 40)</h4>
                  <div className="text-3xl font-bold text-red-400 mb-2">
                    ${results[3]?.finalAmount.toLocaleString()}
                  </div>
                  <div className="text-red-300">Invested ${results[3]?.totalContributed.toLocaleString()}</div>
                </div>
              </div>
              
              <div className="text-center mt-6 p-4 bg-yellow-400/20 rounded-lg">
                <div className="text-2xl font-bold text-yellow-300 mb-2">
                  Difference: ${((results[0]?.finalAmount || 0) - (results[3]?.finalAmount || 0)).toLocaleString()}
                </div>
                <div className="text-yellow-200">
                  Starting 24 years earlier with less money results in way more wealth!
                </div>
              </div>
            </div>

            <div className="text-center mt-8">
              <Button 
                onClick={resetGame}
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3"
              >
                Reset Time Machine
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}