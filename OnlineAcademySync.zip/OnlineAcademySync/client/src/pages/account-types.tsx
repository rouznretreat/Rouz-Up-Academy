import { Link } from "wouter";
import { useState } from "react";
import BankingQuiz from "@/components/BankingQuiz";
import { ArrowLeft, CreditCard, PiggyBank, TrendingUp, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import BackToTop from "@/components/BackToTop";

export default function AccountTypes() {
  const [showQuiz, setShowQuiz] = useState(false);

  if (showQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
        <div className="bg-white shadow-sm border-b p-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Account Types
            </Button>
          </div>
        </div>
        <div className="p-4">
          <BankingQuiz moduleType="account-types" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Banking Modules
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white py-8">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-block bg-purple-500 text-purple-100 px-4 py-2 rounded-full text-sm font-medium mb-4">
            💎 Teen Money Mastery Module
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Account Types for Teens</h1>
          <p className="text-xl text-purple-100 mb-6">Choose Your Financial Superpower! 🚀</p>
          <div className="inline-block bg-white text-purple-600 px-6 py-3 rounded-full font-bold shadow-lg">
            🏆 Build Your Perfect Banking Setup
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-4 -mt-6 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          
          {/* Teen-Specific Account Guide */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-purple-600 mb-6 text-center">🎯 Perfect Accounts for Teens & Young Adults</h2>
            
            {/* Teen Checking Account */}
            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border-l-4 border-blue-500 p-6 rounded-lg mb-6">
              <div className="flex items-center mb-4">
                <CreditCard className="w-8 h-8 text-blue-600 mr-3" />
                <h3 className="text-2xl font-bold text-blue-800">Teen Checking Account (Ages 13-17)</h3>
                <span className="ml-auto bg-green-500 text-white px-3 py-1 rounded-full text-sm font-bold">ESSENTIAL</span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-blue-700 mb-3">✨ Perfect For:</h4>
                  <ul className="space-y-2 text-blue-800">
                    <li>• Daily spending money</li>
                    <li>• Part-time job paychecks</li>
                    <li>• Learning to manage money</li>
                    <li>• Building banking habits</li>
                    <li>• Online purchases</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-blue-700 mb-3">🎁 Teen Benefits:</h4>
                  <ul className="space-y-2 text-blue-800">
                    <li>• No monthly fees (usually)</li>
                    <li>• Parent oversight/joint account</li>
                    <li>• Debit card included</li>
                    <li>• Mobile banking access</li>
                    <li>• Financial education resources</li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4 p-4 bg-white rounded-lg border border-blue-200">
                <p className="text-blue-800"><strong>💡 Pro Tip:</strong> Many banks offer special teen accounts that become regular checking accounts when you turn 18. Look for ones with no overdraft fees!</p>
              </div>
            </div>

            {/* High-Yield Savings */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-l-4 border-green-500 p-6 rounded-lg mb-6">
              <div className="flex items-center mb-4">
                <PiggyBank className="w-8 h-8 text-green-600 mr-3" />
                <h3 className="text-2xl font-bold text-green-800">High-Yield Savings Account</h3>
                <span className="ml-auto bg-yellow-500 text-white px-3 py-1 rounded-full text-sm font-bold">MUST HAVE</span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-green-700 mb-3">💰 Perfect For:</h4>
                  <ul className="space-y-2 text-green-800">
                    <li>• Emergency fund (3-6 months expenses)</li>
                    <li>• Big purchase goals (car, college)</li>
                    <li>• Money you won't need for months</li>
                    <li>• Building your financial safety net</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-green-700 mb-3">🚀 Benefits:</h4>
                  <ul className="space-y-2 text-green-800">
                    <li>• 4-5% interest (vs 0.01% regular savings)</li>
                    <li>• Your money grows while you sleep!</li>
                    <li>• FDIC insured (100% safe)</li>
                    <li>• Easy online access</li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4 p-4 bg-white rounded-lg border border-green-200">
                <p className="text-green-800"><strong>🎯 Teen Goal:</strong> Start with $100 and add $25-50 per month. In one year, you'll have $500+ with interest!</p>
              </div>
            </div>

            {/* Student Investment Account */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 border-l-4 border-purple-500 p-6 rounded-lg mb-6">
              <div className="flex items-center mb-4">
                <TrendingUp className="w-8 h-8 text-purple-600 mr-3" />
                <h3 className="text-2xl font-bold text-purple-800">Custodial Investment Account (Under 18)</h3>
                <span className="ml-auto bg-purple-500 text-white px-3 py-1 rounded-full text-sm font-bold">WEALTH BUILDER</span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-purple-700 mb-3">🚀 Perfect For:</h4>
                  <ul className="space-y-2 text-purple-800">
                    <li>• Long-term wealth building</li>
                    <li>• College fund investments</li>
                    <li>• Learning about stocks</li>
                    <li>• Money you won't need for 5+ years</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-purple-700 mb-3">💎 Benefits:</h4>
                  <ul className="space-y-2 text-purple-800">
                    <li>• Potential for 7-10% annual returns</li>
                    <li>• Start building generational wealth</li>
                    <li>• Learn investing with parent guidance</li>
                    <li>• Compound growth over decades</li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4 p-4 bg-white rounded-lg border border-purple-200">
                <p className="text-purple-800"><strong>🌟 Amazing Fact:</strong> $1,000 invested at age 16 could be worth $50,000+ by retirement through compound growth!</p>
              </div>
            </div>

            {/* CD Account for Teens */}
            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 border-l-4 border-orange-500 p-6 rounded-lg mb-6">
              <div className="flex items-center mb-4">
                <Clock className="w-8 h-8 text-orange-600 mr-3" />
                <h3 className="text-2xl font-bold text-orange-800">Certificate of Deposit (CD)</h3>
                <span className="ml-auto bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">SAFE GROWTH</span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-orange-700 mb-3">⏰ Perfect For:</h4>
                  <ul className="space-y-2 text-orange-800">
                    <li>• Money for specific future goals</li>
                    <li>• Higher interest than savings</li>
                    <li>• Teaching patience and planning</li>
                    <li>• Guaranteed growth</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-orange-700 mb-3">🏆 Benefits:</h4>
                  <ul className="space-y-2 text-orange-800">
                    <li>• 4-6% guaranteed interest</li>
                    <li>• Forces you to save long-term</li>
                    <li>• FDIC insured (100% safe)</li>
                    <li>• Available in 6 month to 5 year terms</li>
                  </ul>
                </div>
              </div>
              
              <div className="mt-4 p-4 bg-white rounded-lg border border-orange-200">
                <p className="text-orange-800"><strong>💡 Teen Strategy:</strong> Use a 1-year CD for prom/graduation money, or 4-year CD that matures when you graduate!</p>
              </div>
            </div>
          </div>

          {/* Account Comparison Chart */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">📊 Quick Comparison Guide</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse bg-white rounded-lg shadow-lg">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                    <th className="border border-gray-300 p-4 text-left font-bold">Account Type</th>
                    <th className="border border-gray-300 p-4 text-center font-bold">Interest Rate</th>
                    <th className="border border-gray-300 p-4 text-center font-bold">Access</th>
                    <th className="border border-gray-300 p-4 text-center font-bold">Best For</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-blue-50">
                    <td className="border border-gray-300 p-4 font-semibold text-blue-800">Teen Checking</td>
                    <td className="border border-gray-300 p-4 text-center">0-0.1%</td>
                    <td className="border border-gray-300 p-4 text-center">🟢 Immediate</td>
                    <td className="border border-gray-300 p-4 text-center">Daily spending</td>
                  </tr>
                  <tr className="bg-green-50">
                    <td className="border border-gray-300 p-4 font-semibold text-green-800">High-Yield Savings</td>
                    <td className="border border-gray-300 p-4 text-center">4-5%</td>
                    <td className="border border-gray-300 p-4 text-center">🟡 Same day</td>
                    <td className="border border-gray-300 p-4 text-center">Emergency fund</td>
                  </tr>
                  <tr className="bg-purple-50">
                    <td className="border border-gray-300 p-4 font-semibold text-purple-800">Investment Account</td>
                    <td className="border border-gray-300 p-4 text-center">7-10%*</td>
                    <td className="border border-gray-300 p-4 text-center">🟡 2-3 days</td>
                    <td className="border border-gray-300 p-4 text-center">Wealth building</td>
                  </tr>
                  <tr className="bg-orange-50">
                    <td className="border border-gray-300 p-4 font-semibold text-orange-800">Certificate of Deposit</td>
                    <td className="border border-gray-300 p-4 text-center">4-6%</td>
                    <td className="border border-gray-300 p-4 text-center">🔴 Fixed term</td>
                    <td className="border border-gray-300 p-4 text-center">Specific goals</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-600 mt-2 text-center">*Investment returns vary and are not guaranteed</p>
          </div>

          {/* Teen Action Plan */}
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 p-8 rounded-lg border border-cyan-200">
            <h2 className="text-3xl font-bold text-cyan-800 mb-6 text-center">🎯 Your Teen Banking Action Plan</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-cyan-700 mb-4">🚀 Start Today (Ages 13-15):</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-cyan-500 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                    <p className="text-cyan-800">Open a teen checking account with parent</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-cyan-500 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                    <p className="text-cyan-800">Start high-yield savings with $25-50</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-cyan-500 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                    <p className="text-cyan-800">Set up automatic savings from allowance/jobs</p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-cyan-700 mb-4">💰 Level Up (Ages 16-18):</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                    <p className="text-cyan-800">Add custodial investment account</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold">5</div>
                    <p className="text-cyan-800">Consider CD for graduation/college money</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold">6</div>
                    <p className="text-cyan-800">Build credit history (with parent help)</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-8 p-6 bg-white rounded-lg border border-cyan-200">
              <h4 className="font-bold text-cyan-800 mb-3 text-center">🏆 The Ultimate Teen Money Setup:</h4>
              <p className="text-cyan-700 text-center">
                <strong>Checking Account</strong> (spending) + <strong>High-Yield Savings</strong> (emergency fund) + 
                <strong>Investment Account</strong> (wealth building) = Financial Success! 🎉
              </p>
            </div>
          </div>
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">🎯</div>
            <h2 className="text-3xl font-bold text-gray-900">Find Your Perfect Account!</h2>
            <p className="text-gray-600 mt-2">Different accounts for different financial goals</p>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-purple-500">
            <div className="flex items-center mb-4">
              <div className="text-3xl mr-4">💡</div>
              <h2 className="text-3xl font-bold text-gray-900">Understanding Different Account Types</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">
              Different financial accounts serve different purposes. Choosing the right accounts for your goals is an important part of managing your money effectively.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-blue-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🏦</div>
              <h2 className="text-3xl font-bold text-gray-900">Banking Accounts</h2>
            </div>
            
            <div className="grid gap-6">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">💳</span>
                  <h3 className="text-2xl font-bold text-blue-700">Checking Account</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-blue-200 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Everyday spending and bill payments
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Debit card, checks, easy access to money, low or no interest
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">💰</span>
                  <h3 className="text-2xl font-bold text-green-700">Savings Account</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-green-200 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Emergency funds and short-term savings goals
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Some interest, limited withdrawals, FDIC insured
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">📊</span>
                  <h3 className="text-2xl font-bold text-purple-700">Money Market Account</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-purple-200 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Higher interest savings with some checking features
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Better interest than regular savings, may include check-writing privileges
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">📜</span>
                  <h3 className="text-2xl font-bold text-orange-700">Certificate of Deposit (CD)</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-orange-200 text-orange-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Saving money you won't need for a specific time period
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Higher interest rates, fixed terms (6 months to 5+ years), penalties for early withdrawal
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-red-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">📈</div>
              <h2 className="text-3xl font-bold text-gray-900">Investment Accounts</h2>
            </div>
            
            <div className="grid gap-6">
              <div className="bg-gradient-to-r from-red-50 to-red-100 p-6 rounded-xl border border-red-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">👶</span>
                  <h3 className="text-2xl font-bold text-red-700">Custodial Investment Account</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-red-200 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Investments for minors, managed by parents/guardians
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Transfers to the minor when they reach adulthood (18-21 depending on state)
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-indigo-50 to-indigo-100 p-6 rounded-xl border border-indigo-200">
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">🎓</span>
                  <h3 className="text-2xl font-bold text-indigo-700">529 College Savings Plan</h3>
                </div>
                <div className="mb-3">
                  <span className="bg-indigo-200 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium">
                    Best for: Saving for education expenses
                  </span>
                </div>
                <p className="text-gray-700 text-lg">
                  <strong>Features:</strong> Tax advantages for education savings, can be used for college and K-12 expenses
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-yellow-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🤔</div>
              <h2 className="text-3xl font-bold text-gray-900">Choosing the Right Accounts</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed mb-6">When deciding which accounts to open, consider:</p>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-yellow-50 p-4 rounded-lg flex items-center">
                <span className="text-2xl mr-3">🎯</span>
                <span className="text-gray-700">Your goals and when you'll need the money</span>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg flex items-center">
                <span className="text-2xl mr-3">🔄</span>
                <span className="text-gray-700">How much access you need to the funds</span>
              </div>
              <div className="bg-green-50 p-4 rounded-lg flex items-center">
                <span className="text-2xl mr-3">📈</span>
                <span className="text-gray-700">The interest rate or potential return</span>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg flex items-center">
                <span className="text-2xl mr-3">💸</span>
                <span className="text-gray-700">Fees and minimum balance requirements</span>
              </div>
              <div className="bg-red-50 p-4 rounded-lg md:col-span-2 flex items-center justify-center">
                <span className="text-2xl mr-3">🛡️</span>
                <span className="text-gray-700">FDIC insurance for bank accounts</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white p-8 rounded-2xl shadow-xl">
            <div className="flex items-center mb-4">
              <div className="text-4xl mr-4">👨‍👩‍👧‍👦</div>
              <h2 className="text-3xl font-bold">Family Discussion Prompt</h2>
            </div>
            <div className="bg-white bg-opacity-20 p-6 rounded-xl">
              <p className="text-xl leading-relaxed">
                What types of accounts do your family members have? Ask your parents to explain why they chose these particular accounts and what they use them for.
              </p>
            </div>
          </div>

          {/* Quiz Section */}
          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <div className="text-xl mr-2">🧠</div>
                <h2 className="text-lg font-bold text-gray-900">Test Your Knowledge</h2>
              </div>
              <div className="text-xs text-gray-500">5 questions</div>
            </div>
            <p className="text-gray-700 text-xs mb-3">
              Ready to test what you've learned about different account types?
            </p>
            <button 
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded text-sm"
              onClick={() => setShowQuiz(true)}
            >
              Start Account Types Quiz
            </button>
          </div>
        </div>
      </div>
      <BackToTop />
    </div>
  );
}