import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, CheckCircle, Clipboard, Target, FileText, Users, HelpCircle, Shield, Lock, Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule6() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-600 flex items-center space-x-3">
              <CheckCircle className="w-8 h-8" />
              <span>Module 6: Getting Started</span>
            </CardTitle>
            <p className="text-gray-600">Your complete 8-step action plan to begin creating your own estate plan today</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-yellow-50 p-6 rounded border-l-4 border-yellow-500">
              <h3 className="text-lg font-bold text-yellow-700 mb-4">🎯 Ready to Begin?</h3>
              <p className="text-yellow-700">
                You've learned the concepts - now it's time to take action! This step-by-step guide will help you create your own estate plan. Take it one step at a time, and remember: starting is more important than perfection.
              </p>
            </div>

            <div className="bg-green-50 p-6 rounded border border-green-300">
              <h3 className="text-lg font-bold text-green-700 mb-3 flex items-center space-x-2">
                <Star className="w-6 h-6" />
                <span>Your 8-Step Estate Planning Action Plan</span>
              </h3>
              <p className="text-green-700 text-sm">
                Follow these steps in order to build your comprehensive estate plan. Each step builds on the previous ones, creating a solid foundation for your family's financial future.
              </p>
            </div>

            <div className="space-y-6">
              <Card className="border-l-4 border-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                      <Clipboard className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-blue-700 mb-3">Step 1: Take Inventory of What You Own</h4>
                      <p className="text-gray-700 mb-4">
                        List your assets including bank accounts, investment accounts, real estate, life insurance policies, retirement accounts, vehicles, and valuable personal items. Also note any debts you owe.
                      </p>
                      <div className="bg-blue-50 p-4 rounded">
                        <h5 className="font-semibold text-blue-700 mb-2">📝 Create Your Asset List:</h5>
                        <div className="grid md:grid-cols-2 gap-3 text-sm text-blue-700">
                          <div>
                            <strong>Assets to Include:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>• Bank and savings accounts</li>
                              <li>• Investment and retirement accounts</li>
                              <li>• Real estate and property</li>
                              <li>• Life insurance policies</li>
                              <li>• Vehicles and valuable items</li>
                            </ul>
                          </div>
                          <div>
                            <strong>Don't Forget:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>• Business interests</li>
                              <li>• Digital assets and accounts</li>
                              <li>• Collectibles and jewelry</li>
                              <li>• Outstanding debts and mortgages</li>
                              <li>• Money owed to you</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-green-100 p-3 rounded-lg flex-shrink-0">
                      <Target className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-green-700 mb-3">Step 2: Identify Your Goals</h4>
                      <p className="text-gray-700 mb-4">
                        Think about who should inherit your assets, who would care for your minor children, and what happens if you become incapacitated. Consider any charitable giving wishes or special family circumstances.
                      </p>
                      <div className="bg-green-50 p-4 rounded">
                        <h5 className="font-semibold text-green-700 mb-2">🎯 Key Questions to Consider:</h5>
                        <div className="space-y-2 text-sm text-green-700">
                          <div>• <strong>Who should inherit your assets?</strong> (spouse, children, other family, charities)</div>
                          <div>• <strong>Who would care for minor children?</strong> (guardians and backup guardians)</div>
                          <div>• <strong>Who would manage your finances if you couldn't?</strong> (financial power of attorney)</div>
                          <div>• <strong>Who would make medical decisions for you?</strong> (healthcare power of attorney)</div>
                          <div>• <strong>Any special circumstances?</strong> (blended families, special needs, business ownership)</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-purple-100 p-3 rounded-lg flex-shrink-0">
                      <FileText className="w-6 h-6 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-purple-700 mb-3">Step 3: Gather Important Documents</h4>
                      <p className="text-gray-700 mb-4">
                        Collect existing documents like previous wills, insurance policies, account statements, property deeds, and beneficiary forms. Review current beneficiary designations on retirement accounts and insurance.
                      </p>
                      <div className="bg-purple-50 p-4 rounded">
                        <h5 className="font-semibold text-purple-700 mb-2">📋 Document Checklist:</h5>
                        <div className="grid md:grid-cols-2 gap-3 text-sm text-purple-700">
                          <div>
                            <strong>Existing Legal Documents:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>□ Previous wills or trusts</li>
                              <li>□ Powers of attorney</li>
                              <li>□ Healthcare directives</li>
                              <li>□ Marriage/divorce certificates</li>
                            </ul>
                          </div>
                          <div>
                            <strong>Financial Records:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>□ Account statements</li>
                              <li>□ Insurance policies</li>
                              <li>□ Property deeds</li>
                              <li>□ Beneficiary forms</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-orange-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-orange-100 p-3 rounded-lg flex-shrink-0">
                      <Users className="w-6 h-6 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-orange-700 mb-3">Step 4: Choose Your Key People</h4>
                      <p className="text-gray-700 mb-4">
                        Select an executor for your will, guardians for minor children, and agents for your powers of attorney. Have backup choices for each role. Make sure these people are willing to serve.
                      </p>
                      <div className="bg-orange-50 p-4 rounded">
                        <h5 className="font-semibold text-orange-700 mb-2">👥 Key Roles to Fill:</h5>
                        <div className="space-y-3 text-sm text-orange-700">
                          <div>
                            <strong>Executor (Will):</strong> Manages your estate after death
                            <div className="text-xs mt-1">Choose someone trustworthy, organized, and willing to serve</div>
                          </div>
                          <div>
                            <strong>Guardians (Minor Children):</strong> Care for your children if both parents die
                            <div className="text-xs mt-1">Consider values, lifestyle, and ability to provide for children</div>
                          </div>
                          <div>
                            <strong>Financial Power of Attorney:</strong> Manages money if you can't
                            <div className="text-xs mt-1">Should be someone you trust completely with financial decisions</div>
                          </div>
                          <div>
                            <strong>Healthcare Power of Attorney:</strong> Makes medical decisions if you can't
                            <div className="text-xs mt-1">Choose someone who understands your healthcare values and wishes</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-red-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-red-100 p-3 rounded-lg flex-shrink-0">
                      <HelpCircle className="w-6 h-6 text-red-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-red-700 mb-3">Step 5: Decide if You Need Professional Help</h4>
                      <p className="text-gray-700 mb-4">
                        For simple situations, you might use online tools or basic forms. For complex estates, blended families, business ownership, or significant assets, consult an estate planning attorney.
                      </p>
                      <div className="bg-red-50 p-4 rounded">
                        <h5 className="font-semibold text-red-700 mb-2">🤔 When to Get Professional Help:</h5>
                        <div className="grid md:grid-cols-2 gap-3 text-sm text-red-700">
                          <div>
                            <strong>You Might Need an Attorney if:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>• Estate value over $1 million</li>
                              <li>• Own a business</li>
                              <li>• Blended family situation</li>
                              <li>• Special needs family member</li>
                              <li>• Complex assets or debts</li>
                            </ul>
                          </div>
                          <div>
                            <strong>DIY Might Work if:</strong>
                            <ul className="mt-1 space-y-1">
                              <li>• Simple family structure</li>
                              <li>• Modest estate value</li>
                              <li>• Straightforward wishes</li>
                              <li>• No business ownership</li>
                              <li>• Young with few assets</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-teal-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-teal-100 p-3 rounded-lg flex-shrink-0">
                      <Shield className="w-6 h-6 text-teal-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-teal-700 mb-3">Step 6: Create the Essential Documents</h4>
                      <p className="text-gray-700 mb-4">
                        Start with a will, financial power of attorney, and healthcare directives. Add trusts or other tools as needed based on your situation.
                      </p>
                      <div className="bg-teal-50 p-4 rounded">
                        <h5 className="font-semibold text-teal-700 mb-2">📋 Document Priority Order:</h5>
                        <div className="space-y-2 text-sm text-teal-700">
                          <div><strong>1. Will:</strong> Foundation document for asset distribution and guardianship</div>
                          <div><strong>2. Financial Power of Attorney:</strong> Someone to manage money if you can't</div>
                          <div><strong>3. Healthcare Power of Attorney:</strong> Someone to make medical decisions</div>
                          <div><strong>4. Advance Healthcare Directive:</strong> Your medical wishes in writing</div>
                          <div><strong>5. HIPAA Authorization:</strong> Medical information access</div>
                          <div><strong>6. Trust (if needed):</strong> For more complex planning or probate avoidance</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-indigo-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-indigo-100 p-3 rounded-lg flex-shrink-0">
                      <Users className="w-6 h-6 text-indigo-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-indigo-700 mb-3">Step 7: Update Beneficiary Forms</h4>
                      <p className="text-gray-700 mb-4">
                        Ensure all your accounts have current beneficiary designations that align with your overall plan.
                      </p>
                      <div className="bg-indigo-50 p-4 rounded">
                        <h5 className="font-semibold text-indigo-700 mb-2">⚠️ Critical Reminder:</h5>
                        <div className="space-y-2 text-sm text-indigo-700">
                          <div><strong>Beneficiary forms override your will!</strong> Make sure they're current.</div>
                          <div className="mt-3"><strong>Accounts to Update:</strong></div>
                          <div>• Retirement accounts (401k, IRA, etc.)</div>
                          <div>• Life insurance policies</div>
                          <div>• Bank and investment accounts</div>
                          <div>• Employee benefits</div>
                          <div className="mt-3 bg-indigo-100 p-2 rounded">
                            <strong>Pro Tip:</strong> Name primary AND contingent beneficiaries for each account
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-pink-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-pink-100 p-3 rounded-lg flex-shrink-0">
                      <Lock className="w-6 h-6 text-pink-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-bold text-pink-700 mb-3">Step 8: Store Documents Safely and Inform Others</h4>
                      <p className="text-gray-700 mb-4">
                        Keep originals in a secure location and let key people know where to find them.
                      </p>
                      <div className="bg-pink-50 p-4 rounded">
                        <h5 className="font-semibold text-pink-700 mb-2">🔒 Storage and Communication:</h5>
                        <div className="space-y-3 text-sm text-pink-700">
                          <div>
                            <strong>Store Originals:</strong>
                            <div>• Fireproof safe at home, bank safe deposit box, or attorney's office</div>
                          </div>
                          <div>
                            <strong>Keep Copies:</strong>
                            <div>• Give copies to your executor, family members, and attorney</div>
                          </div>
                          <div>
                            <strong>Create a Location List:</strong>
                            <div>• Document where everything is stored and who has copies</div>
                          </div>
                          <div>
                            <strong>Review Annually:</strong>
                            <div>• Update documents when life changes (marriage, divorce, new children, etc.)</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-green-50 p-6 rounded border border-green-300">
              <h3 className="text-lg font-bold text-green-700 mb-4">🎉 Congratulations on Taking Action!</h3>
              <p className="text-green-700 mb-4">
                By following these 8 steps, you're building a comprehensive estate plan that will protect your family and honor your wishes. Remember: estate planning is an ongoing process, not a one-time event. Review and update your plan as your life changes.
              </p>
              <div className="bg-green-100 p-4 rounded">
                <h4 className="font-semibold text-green-700 mb-2">💡 Final Reminders:</h4>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• Starting is more important than perfection</li>
                  <li>• You can always update and improve your plan</li>
                  <li>• Consider reviewing your plan annually</li>
                  <li>• Don't let procrastination prevent you from protecting your family</li>
                </ul>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Estate Planning Course Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                Excellent! You've completed all six modules of our Estate Planning course. You now have the knowledge and action plan to create comprehensive estate planning that builds wealth and protects your family.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-planning-course">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Back to Course Overview
                  </Button>
                </Link>
                <Button 
                  variant="outline"
                  className="border-teal-500 text-teal-600"
                  onClick={() => window.location.href = "/estate-planning-course#quiz"}
                >
                  Take Final Course Quiz
                </Button>
              </div>
            </div>

            {/* Quiz Section */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Final Knowledge Test!</h3>
                  <p className="mb-4">Ready to test your understanding of getting started with estate planning?</p>
                  <Link href="/estate-quiz-6">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 6 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-module-5">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Previous: When Someone Dies
                  </Button>
                </Link>
                <Link href="/estate-planning-course">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    🎓 Course Complete! Back to Overview →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}