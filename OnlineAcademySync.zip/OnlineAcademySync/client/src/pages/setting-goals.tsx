import { Link } from "wouter";
import { useState } from "react";
import BankingQuiz from "@/components/BankingQuiz";
import { ArrowLeft, Target, Calculator, Calendar, DollarSign, PiggyBank, Trophy, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function SettingGoals() {
  const [showQuiz, setShowQuiz] = useState(false);
  const [activeTab, setActiveTab] = useState("learn");
  
  // Goal planner states
  const [goalAmount, setGoalAmount] = useState("");
  const [goalTimeframe, setGoalTimeframe] = useState("");
  const [currentSavings, setCurrentSavings] = useState("");
  const [goalPriority, setGoalPriority] = useState("");
  const [goalCategory, setGoalCategory] = useState("");
  
  // Calculate savings needed
  const calculateSavingsNeeded = () => {
    const target = parseFloat(goalAmount) || 0;
    const current = parseFloat(currentSavings) || 0;
    const months = parseInt(goalTimeframe) || 1;
    const remaining = target - current;
    const monthlyNeeded = remaining / months;
    return { remaining, monthlyNeeded };
  };
  
  const { remaining, monthlyNeeded } = calculateSavingsNeeded();

  if (showQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
        <div className="bg-white shadow-sm border-b p-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Setting Goals
            </Button>
          </div>
        </div>
        <div className="p-4">
          <BankingQuiz moduleType="setting-goals" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Banking Modules
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white py-12">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-block bg-teal-500 text-teal-100 px-4 py-2 rounded-full text-sm font-medium mb-4">
            Learning Module
          </div>
          <h1 className="text-5xl font-bold mb-4">Setting Financial Goals</h1>
          <p className="text-xl text-teal-100 mb-6">Interactive Goal Planning Tools</p>
          <div className="inline-block bg-white text-teal-600 px-6 py-3 rounded-full font-semibold shadow-lg">
            🎯 Create a plan to reach your dreams
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="max-w-4xl mx-auto px-6 py-6">
        <div className="flex gap-4 mb-8">
          <Button
            onClick={() => setActiveTab("learn")}
            variant={activeTab === "learn" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <Target className="w-4 h-4" />
            Learn About Goals
          </Button>
          <Button
            onClick={() => setActiveTab("planner")}
            variant={activeTab === "planner" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <Calculator className="w-4 h-4" />
            Goal Planner
          </Button>
          <Button
            onClick={() => setActiveTab("tracker")}
            variant={activeTab === "tracker" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <TrendingUp className="w-4 h-4" />
            Progress Tracker
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-6 -mt-8 relative z-10">
        {activeTab === "learn" && (
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">The SMART Goals Framework</h2>
            
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-600">
                    <Target className="w-5 h-5" />
                    What Makes Goals SMART?
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Badge className="bg-blue-100 text-blue-600">S</Badge>
                    <div>
                      <strong>Specific:</strong> Clear and well-defined
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Badge className="bg-green-100 text-green-600">M</Badge>
                    <div>
                      <strong>Measurable:</strong> You can track progress
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Badge className="bg-yellow-100 text-yellow-600">A</Badge>
                    <div>
                      <strong>Achievable:</strong> Realistic and possible
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Badge className="bg-purple-100 text-purple-600">R</Badge>
                    <div>
                      <strong>Relevant:</strong> Important to you
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Badge className="bg-pink-100 text-pink-600">T</Badge>
                    <div>
                      <strong>Time-bound:</strong> Has a deadline
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-green-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-600">
                    <Calendar className="w-5 h-5" />
                    Goal Timeframes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-red-50 rounded-lg">
                    <strong className="text-red-600">Short-term (1-12 months):</strong>
                    <p className="text-sm text-gray-600">New phone, concert tickets, holiday gifts</p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <strong className="text-orange-600">Medium-term (1-5 years):</strong>
                    <p className="text-sm text-gray-600">Car, college fund, vacation</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <strong className="text-blue-600">Long-term (5+ years):</strong>
                    <p className="text-sm text-gray-600">House down payment, retirement</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-gradient-to-r from-teal-50 to-cyan-50 p-6 rounded-xl mb-6">
              <h3 className="text-xl font-semibold text-teal-700 mb-4">Goal Setting Examples</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg">
                  <div className="text-red-500 font-medium mb-2">❌ Vague Goal:</div>
                  <p className="text-gray-600">"I want to save money"</p>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="text-green-500 font-medium mb-2">✅ SMART Goal:</div>
                  <p className="text-gray-600">"Save $500 for a new laptop by December 31st by setting aside $50 each month"</p>
                </div>
              </div>
            </div>

            <div className="text-center">
              <Button 
                onClick={() => setShowQuiz(true)}
                className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-xl"
              >
                Take the Goals Quiz
              </Button>
            </div>
          </div>
        )}

        {activeTab === "planner" && (
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Interactive Goal Planner</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <Label htmlFor="goalCategory" className="text-base font-medium">Goal Category</Label>
                  <Select value={goalCategory} onValueChange={setGoalCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="electronics">📱 Electronics</SelectItem>
                      <SelectItem value="transportation">🚗 Transportation</SelectItem>
                      <SelectItem value="education">📚 Education</SelectItem>
                      <SelectItem value="entertainment">🎮 Entertainment</SelectItem>
                      <SelectItem value="clothing">👕 Clothing</SelectItem>
                      <SelectItem value="travel">✈️ Travel</SelectItem>
                      <SelectItem value="emergency">🚨 Emergency Fund</SelectItem>
                      <SelectItem value="other">💫 Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="goalAmount" className="text-base font-medium">Goal Amount ($)</Label>
                  <Input
                    id="goalAmount"
                    type="number"
                    placeholder="500"
                    value={goalAmount}
                    onChange={(e) => setGoalAmount(e.target.value)}
                    className="text-lg"
                  />
                </div>

                <div>
                  <Label htmlFor="currentSavings" className="text-base font-medium">Current Savings ($)</Label>
                  <Input
                    id="currentSavings"
                    type="number"
                    placeholder="0"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(e.target.value)}
                    className="text-lg"
                  />
                </div>

                <div>
                  <Label htmlFor="goalTimeframe" className="text-base font-medium">Time to Goal (months)</Label>
                  <Select value={goalTimeframe} onValueChange={setGoalTimeframe}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select timeframe" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 months</SelectItem>
                      <SelectItem value="6">6 months</SelectItem>
                      <SelectItem value="12">1 year</SelectItem>
                      <SelectItem value="18">1.5 years</SelectItem>
                      <SelectItem value="24">2 years</SelectItem>
                      <SelectItem value="36">3 years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="goalPriority" className="text-base font-medium">Priority Level</Label>
                  <Select value={goalPriority} onValueChange={setGoalPriority}>
                    <SelectTrigger>
                      <SelectValue placeholder="How important is this?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">🔥 High Priority</SelectItem>
                      <SelectItem value="medium">⚡ Medium Priority</SelectItem>
                      <SelectItem value="low">🌟 Low Priority</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-6">
                <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-blue-600">
                      <Calculator className="w-5 h-5" />
                      Your Savings Plan
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {goalAmount && goalTimeframe ? (
                      <>
                        <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                          <span className="font-medium">Goal Amount:</span>
                          <span className="text-xl font-bold text-green-600">${parseFloat(goalAmount).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                          <span className="font-medium">Current Savings:</span>
                          <span className="text-lg font-semibold">${parseFloat(currentSavings || "0").toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                          <span className="font-medium">Still Need:</span>
                          <span className="text-lg font-semibold text-orange-600">${remaining > 0 ? remaining.toLocaleString() : 0}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-lg">
                          <span className="font-medium">Save Monthly:</span>
                          <span className="text-xl font-bold">${monthlyNeeded > 0 ? Math.ceil(monthlyNeeded).toLocaleString() : 0}</span>
                        </div>
                      </>
                    ) : (
                      <p className="text-gray-500 text-center py-8">Fill in your goal details to see your savings plan!</p>
                    )}
                  </CardContent>
                </Card>

                {goalAmount && goalTimeframe && (
                  <Card className="border-green-200">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-green-600">
                        <Trophy className="w-5 h-5" />
                        Goal Breakdown
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span>Daily savings needed:</span>
                          <strong>${monthlyNeeded > 0 ? (monthlyNeeded / 30).toFixed(2) : "0.00"}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Weekly savings needed:</span>
                          <strong>${monthlyNeeded > 0 ? (monthlyNeeded / 4.33).toFixed(2) : "0.00"}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span>Progress so far:</span>
                          <strong>{goalAmount ? (((parseFloat(currentSavings || "0") / parseFloat(goalAmount)) * 100).toFixed(1)) : 0}%</strong>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === "tracker" && (
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Progress Tracker</h2>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="border-blue-200">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-blue-600 text-lg">
                    <PiggyBank className="w-5 h-5" />
                    Short-term Goals
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">2</div>
                    <div className="text-sm text-gray-500">Active goals</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-green-200">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-green-600 text-lg">
                    <Target className="w-5 h-5" />
                    Goals Achieved
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">5</div>
                    <div className="text-sm text-gray-500">Total completed</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-purple-600 text-lg">
                    <DollarSign className="w-5 h-5" />
                    Total Saved
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">$1,250</div>
                    <div className="text-sm text-gray-500">This year</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl">
              <h3 className="text-xl font-semibold text-green-700 mb-4">Sample Goal Progress</h3>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">New Laptop - $800</h4>
                    <Badge className="bg-blue-100 text-blue-600">75% Complete</Badge>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{width: "75%"}}></div>
                  </div>
                  <div className="mt-2 text-sm text-gray-600">$600 saved / $800 goal</div>
                </div>
                
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-medium">Emergency Fund - $1,000</h4>
                    <Badge className="bg-green-100 text-green-600">45% Complete</Badge>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{width: "45%"}}></div>
                  </div>
                  <div className="mt-2 text-sm text-gray-600">$450 saved / $1,000 goal</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}