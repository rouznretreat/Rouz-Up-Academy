import { Link } from "wouter";
import { ArrowLeft, GraduationCap, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function GraduationCalculator() {
  const [graduationExpenses, setGraduationExpenses] = useState(2500);
  const [currentSavings, setCurrentSavings] = useState(200);
  const [monthsUntilGraduation, setMonthsUntilGraduation] = useState(18);
  const [partTimeIncome, setPartTimeIncome] = useState(400);
  const [savePercentage, setSavePercentage] = useState(30);

  const calculateGraduationPlan = () => {
    const remainingAmount = graduationExpenses - currentSavings;
    const monthlySavingsCapacity = partTimeIncome * (savePercentage / 100);
    const totalCanSave = monthlySavingsCapacity * monthsUntilGraduation;
    const shortfall = remainingAmount - totalCanSave;
    
    return {
      remainingAmount,
      monthlySavingsCapacity,
      totalCanSave,
      shortfall: Math.max(0, shortfall),
      willReachGoal: shortfall <= 0,
      monthsToReach: shortfall <= 0 ? 
        Math.ceil(remainingAmount / monthlySavingsCapacity) : 
        monthsUntilGraduation
    };
  };

  const results = calculateGraduationPlan();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/tools">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2 text-white border-white/30 hover:bg-white/10 mr-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Calculators
                </Button>
              </Link>
              <div className="flex items-center">
                <GraduationCap className="w-8 h-8 mr-3" />
                <div>
                  <h1 className="text-2xl font-bold">Graduation Savings Calculator</h1>
                  <p className="text-purple-100">Plan and save for your graduation expenses</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Calculator Card */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center mb-6">
              <Calculator className="w-6 h-6 mr-3 text-purple-600" />
              <h2 className="text-2xl font-bold text-gray-900">Graduation Planning</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Total Graduation Expenses ($)
                  </label>
                  <input
                    type="number"
                    value={graduationExpenses}
                    onChange={(e) => setGraduationExpenses(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    min="100"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Include cap/gown, announcements, party, photos, etc.
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Savings ($)
                  </label>
                  <input
                    type="number"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Months Until Graduation
                  </label>
                  <input
                    type="number"
                    value={monthsUntilGraduation}
                    onChange={(e) => setMonthsUntilGraduation(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    min="1"
                    max="48"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Part-Time Income ($)
                  </label>
                  <input
                    type="number"
                    value={partTimeIncome}
                    onChange={(e) => setPartTimeIncome(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage to Save ({savePercentage}%)
                  </label>
                  <input
                    type="range"
                    value={savePercentage}
                    onChange={(e) => setSavePercentage(Number(e.target.value))}
                    className="w-full"
                    min="10"
                    max="80"
                    step="5"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>10%</span>
                    <span>80%</span>
                  </div>
                </div>
              </div>

              {/* Results Section */}
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Your Graduation Plan</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Still Need to Save:</span>
                      <span className="font-semibold">${results.remainingAmount.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Monthly Savings Goal:</span>
                      <span className="font-semibold">${results.monthlySavingsCapacity.toFixed(0)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Total You Can Save:</span>
                      <span className="font-semibold">${results.totalCanSave.toLocaleString()}</span>
                    </div>
                    
                    {results.willReachGoal ? (
                      <div className="bg-green-100 border border-green-200 rounded-lg p-3 mt-4">
                        <div className="flex items-center">
                          <div className="text-green-600 font-bold text-lg">🎉 You'll reach your goal!</div>
                        </div>
                        <p className="text-green-700 text-sm mt-1">
                          You'll have enough saved {results.monthsToReach} months before graduation!
                        </p>
                      </div>
                    ) : (
                      <div className="bg-orange-100 border border-orange-200 rounded-lg p-3 mt-4">
                        <div className="flex items-center">
                          <div className="text-orange-600 font-bold">⚠️ Need ${results.shortfall.toFixed(0)} more</div>
                        </div>
                        <p className="text-orange-700 text-sm mt-1">
                          Consider increasing work hours or saving percentage
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Tips Section */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-bold text-blue-900 mb-2">💡 Money-Saving Tips</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Start saving early - even $25/month helps!</li>
                    <li>• Ask family for graduation money instead of gifts</li>
                    <li>• Consider DIY decorations to cut party costs</li>
                    <li>• Look for discounted cap and gown rentals</li>
                    <li>• Plan a potluck-style graduation party</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Graduation Expense Breakdown */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Typical Graduation Expenses</h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-purple-600 mb-3">Essential Costs</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Cap & Gown</span>
                    <span>$50 - $150</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Graduation Photos</span>
                    <span>$100 - $300</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Announcements</span>
                    <span>$30 - $80</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Class Ring</span>
                    <span>$200 - $500</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-pink-600 mb-3">Celebration Costs</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Graduation Party</span>
                    <span>$200 - $800</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Family Dinner</span>
                    <span>$100 - $300</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Thank You Cards</span>
                    <span>$20 - $50</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Decorations</span>
                    <span>$50 - $200</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}