import { useState } from "react";
import { ArrowLeft, FileText, Scale, Users, AlertTriangle, CheckCircle, Gavel, Shield, BookOpen, Edit3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface WillsSectionProps {
  onBack: () => void;
}

export default function WillsSection({ onBack }: WillsSectionProps) {
  const [activeSubsection, setActiveSubsection] = useState<string | null>(null);

  const subsections = [
    { id: "capacity", title: "Testamentary Capacity", icon: Scale },
    { id: "provisions", title: "Primary Will Provisions", icon: FileText },
    { id: "antenuptial", title: "Antenuptial Agreements Impact", icon: Users },
    { id: "gifts", title: "Lapsed vs. Abated Gifts", icon: AlertTriangle },
    { id: "draft-page", title: "Will Drafting Exercise", icon: Edit3 },
    { id: "personal-rep", title: "Personal Representative Role", icon: Gavel },
    { id: "execution", title: "Will Execution Requirements", icon: Shield },
    { id: "amendments", title: "Changing & Amending Wills", icon: BookOpen },
  ];

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Estate Planning Course</span>
        </button>
        <h1 className="text-4xl font-bold text-blue-600 mb-2">Comprehensive Wills Education</h1>
        <p className="text-xl text-gray-600">Master the legal principles, drafting requirements, and professional standards for will creation and administration</p>
      </div>

      {!activeSubsection ? (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-3">🏛️ Professional Will Drafting & Administration</h2>
            <p className="mb-3">Comprehensive coverage of testamentary law, from capacity requirements to execution standards and ongoing administration.</p>
            <div className="text-sm opacity-90">
              <p>• Legal capacity and competency standards</p>
              <p>• Professional drafting principles and practices</p>
              <p>• Execution requirements and witness protocols</p>
              <p>• Personal representative duties and responsibilities</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subsections.map((section) => (
              <Card key={section.id} className="hover:shadow-lg transition-shadow border-l-4 border-blue-400 cursor-pointer" onClick={() => setActiveSubsection(section.id)}>
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                      <section.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-800">{section.title}</h3>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Explore Section
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded">
            <h3 className="text-lg font-bold text-yellow-800 mb-3">⚠️ Critical Professional Warning</h3>
            <p className="text-yellow-700 mb-3"><strong>Never Use Templates for Will Drafting:</strong> This course emphasizes the critical importance of custom will drafting by qualified legal professionals rather than relying on generic templates.</p>
            <div className="text-sm text-yellow-600">
              <p>• Each client's circumstances require unique legal solutions</p>
              <p>• State laws vary significantly in requirements and interpretations</p>
              <p>• Template errors can invalidate entire testamentary schemes</p>
              <p>• Professional legal training is essential for proper will drafting</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <Button 
            onClick={() => setActiveSubsection(null)}
            variant="outline"
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Sections
          </Button>

          {activeSubsection === "capacity" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-purple-700 text-2xl">⚖️ Testamentary Capacity Requirements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-purple-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-purple-700 mb-4">Legal Definition of Testamentary Capacity</h3>
                    <p className="text-purple-800 mb-4">Testamentary capacity refers to the mental ability required to make a valid will. The testator must possess sufficient mental capacity at the time the will is executed.</p>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-purple-600 mb-3">Four Essential Elements (Banks v. Goodfellow Standard):</h4>
                        <ul className="space-y-2 text-sm text-purple-700">
                          <li className="flex items-start space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                            <span><strong>Nature of the Act:</strong> Understand they are making a will</span>
                          </li>
                          <li className="flex items-start space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                            <span><strong>Extent of Property:</strong> Know the nature and extent of their assets</span>
                          </li>
                          <li className="flex items-start space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                            <span><strong>Natural Objects:</strong> Recognize persons who would naturally inherit</span>
                          </li>
                          <li className="flex items-start space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />
                            <span><strong>Disposition Plan:</strong> Understand how the will distributes property</span>
                          </li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-red-600 mb-3">Capacity Challenges:</h4>
                        <ul className="space-y-2 text-sm text-red-700">
                          <li>• <strong>Dementia/Alzheimer's:</strong> Progressive cognitive decline</li>
                          <li>• <strong>Mental Illness:</strong> Depression, bipolar disorder, schizophrenia</li>
                          <li>• <strong>Substance Abuse:</strong> Alcohol or drug impairment</li>
                          <li>• <strong>Medication Effects:</strong> Pain medications, sedatives</li>
                          <li>• <strong>Undue Influence:</strong> Coercion or manipulation by others</li>
                          <li>• <strong>Insane Delusions:</strong> False beliefs affecting testamentary decisions</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">📋 Professional Assessment Protocol</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Initial Client Interview:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Observe client's demeanor and responses</li>
                          <li>• Ask about current medications</li>
                          <li>• Inquire about recent major life events</li>
                          <li>• Assess understanding of proposed will terms</li>
                          <li>• Document any concerning behaviors</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Documentation Requirements:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Detailed file notes of all interactions</li>
                          <li>• Medical records if capacity questioned</li>
                          <li>• Witness statements from will execution</li>
                          <li>• Video recording of execution (where permitted)</li>
                          <li>• Physician capacity evaluation (if needed)</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                    <h3 className="text-lg font-bold text-orange-700 mb-3">⚖️ Legal Standards Variations</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold text-orange-600 mb-2">Lower Standard Than Contract Capacity:</h4>
                        <p className="text-sm text-orange-700">Testamentary capacity requires less mental ability than needed for contracts or business decisions. A person may lack capacity for complex transactions but still possess testamentary capacity.</p>
                      </div>
                      <div>
                        <h4 className="font-bold text-orange-600 mb-2">Lucid Intervals:</h4>
                        <p className="text-sm text-orange-700">Even persons with mental illness may have "lucid intervals" during which they possess sufficient capacity to execute a valid will. Timing of execution is crucial.</p>
                      </div>
                      <div>
                        <h4 className="font-bold text-orange-600 mb-2">Burden of Proof:</h4>
                        <p className="text-sm text-orange-700">Contestants challenging a will must prove lack of capacity. The law presumes capacity unless evidence demonstrates otherwise.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "provisions" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="text-green-700 text-2xl">📝 Primary Will Provisions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-green-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-green-700 mb-4">Essential Will Components</h3>
                    
                    <div className="space-y-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <FileText className="w-5 h-5 mr-2" />
                          1. Opening Provisions
                        </h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Title and Introduction:</strong> "Last Will and Testament of [Name]"</li>
                          <li>• <strong>Identification:</strong> Full legal name, address, citizenship</li>
                          <li>• <strong>Revocation Clause:</strong> Revokes all prior wills and codicils</li>
                          <li>• <strong>Declaration:</strong> Statement of sound mind and legal age</li>
                          <li>• <strong>Family Status:</strong> Marital status and children identification</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <Users className="w-5 h-5 mr-2" />
                          2. Fiduciary Appointments
                        </h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Personal Representative:</strong> Primary and alternate executors</li>
                          <li>• <strong>Guardian Nominations:</strong> Guardians for minor children</li>
                          <li>• <strong>Trustee Appointments:</strong> If testamentary trusts created</li>
                          <li>• <strong>Powers Granted:</strong> Specific authorities and limitations</li>
                          <li>• <strong>Bond Requirements:</strong> Whether bond is required or waived</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <Shield className="w-5 h-5 mr-2" />
                          3. Dispositive Provisions
                        </h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Specific Bequests:</strong> Particular items to named beneficiaries</li>
                          <li>• <strong>General Legacies:</strong> Cash amounts to specific persons</li>
                          <li>• <strong>Demonstrative Gifts:</strong> Amounts from specific sources</li>
                          <li>• <strong>Residuary Clause:</strong> Distribution of remaining estate</li>
                          <li>• <strong>Contingent Beneficiaries:</strong> Alternative beneficiaries</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <Gavel className="w-5 h-5 mr-2" />
                          4. Administrative Provisions
                        </h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Tax Directives:</strong> Who pays estate taxes</li>
                          <li>• <strong>Debt Payment:</strong> Instructions for paying debts</li>
                          <li>• <strong>Funeral Instructions:</strong> Burial or cremation preferences</li>
                          <li>• <strong>Survival Requirements:</strong> Time periods for beneficiary survival</li>
                          <li>• <strong>Interpretation Clauses:</strong> Governing law and severability</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <CheckCircle className="w-5 h-5 mr-2" />
                          5. Execution Requirements
                        </h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Signature Block:</strong> Testator's signature and date</li>
                          <li>• <strong>Witness Attestation:</strong> Required number of witnesses</li>
                          <li>• <strong>Self-Proving Affidavit:</strong> Notarized witness acknowledgment</li>
                          <li>• <strong>Page Numbering:</strong> Consecutive page identification</li>
                          <li>• <strong>Incorporation:</strong> Reference to attached schedules</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">🎯 Professional Drafting Considerations</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Clarity and Precision:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Use clear, unambiguous language</li>
                          <li>• Define all technical terms</li>
                          <li>• Avoid contradictory provisions</li>
                          <li>• Include specific dollar amounts where appropriate</li>
                          <li>• Provide for all possible contingencies</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Tax and Legal Optimization:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Maximize available tax exemptions</li>
                          <li>• Coordinate with other estate planning documents</li>
                          <li>• Consider state-specific requirements</li>
                          <li>• Plan for potential law changes</li>
                          <li>• Include savings clauses for invalid provisions</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "antenuptial" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-pink-500">
                <CardHeader>
                  <CardTitle className="text-pink-700 text-2xl">💑 Antenuptial Agreements Impact on Will Provisions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-pink-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-pink-700 mb-4">Understanding Prenuptial Agreement Interactions</h3>
                    <p className="text-pink-800 mb-4">Antenuptial (prenuptial) agreements can significantly impact will provisions by waiving spousal rights and creating binding obligations that override testamentary dispositions.</p>
                    
                    <div className="space-y-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-pink-600 mb-3">📋 Common Prenuptial Provisions Affecting Wills:</h4>
                        <ul className="text-sm text-pink-700 space-y-2">
                          <li>• <strong>Elective Share Waivers:</strong> Spouse waives right to claim against estate</li>
                          <li>• <strong>Specific Bequests:</strong> Agreement requires certain property to go to designated beneficiaries</li>
                          <li>• <strong>Inheritance Limitations:</strong> Caps on amounts spouse may receive</li>
                          <li>• <strong>Property Classifications:</strong> Separate vs. marital property designations</li>
                          <li>• <strong>Support Obligations:</strong> Ongoing financial commitments to former spouse</li>
                          <li>• <strong>Children's Rights:</strong> Protection of inheritance rights for children from prior relationships</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-pink-600 mb-3">⚖️ Legal Priority and Enforcement:</h4>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-semibold text-pink-600">Contract Law Supremacy:</h5>
                            <p className="text-sm text-pink-700">Prenuptial agreements are contracts that generally supersede will provisions. A will cannot unilaterally override valid prenuptial obligations.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-pink-600">Validity Requirements:</h5>
                            <p className="text-sm text-pink-700">Agreement must be properly executed with full financial disclosure, voluntary consent, and absence of unconscionability to be enforceable.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-pink-600">Modification Restrictions:</h5>
                            <p className="text-sm text-pink-700">Most prenuptial agreements require mutual written consent to modify, preventing unilateral changes through will provisions.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                    <h3 className="text-lg font-bold text-orange-700 mb-4">🎯 Practical Drafting Considerations</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-orange-600 mb-2">Will Drafting Best Practices:</h4>
                        <ul className="text-sm text-orange-700 space-y-1">
                          <li>• Review all prenuptial agreements before drafting</li>
                          <li>• Include acknowledgment of prenuptial obligations</li>
                          <li>• Draft will provisions consistent with agreements</li>
                          <li>• Consider trust structures to honor agreement terms</li>
                          <li>• Include specific reference to prenuptial waivers</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-orange-600 mb-2">Conflict Resolution Strategies:</h4>
                        <ul className="text-sm text-orange-700 space-y-1">
                          <li>• Obtain prenuptial agreement modifications in writing</li>
                          <li>• Use trust provisions to satisfy agreement requirements</li>
                          <li>• Create specific performance mechanisms</li>
                          <li>• Include dispute resolution procedures</li>
                          <li>• Plan for agreement invalidity scenarios</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-red-50 p-6 rounded border-l-4 border-red-500">
                    <h3 className="text-lg font-bold text-red-700 mb-4">⚠️ Common Problematic Scenarios</h3>
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-red-600 mb-2">Scenario 1: Will Contradicts Prenuptial Agreement</h4>
                        <p className="text-sm text-red-700 mb-2"><strong>Problem:</strong> Testator's will leaves entire estate to spouse, but prenuptial agreement limits spouse to $100,000.</p>
                        <p className="text-sm text-red-700"><strong>Result:</strong> Prenuptial agreement controls; excess estate passes through intestacy or to residuary beneficiaries.</p>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-red-600 mb-2">Scenario 2: Prenuptial Agreement Requires Specific Bequests</h4>
                        <p className="text-sm text-red-700 mb-2"><strong>Problem:</strong> Agreement requires $500,000 to spouse, but will only provides $200,000.</p>
                        <p className="text-sm text-red-700"><strong>Result:</strong> Estate may be liable for breach of contract; additional $300,000 must be found.</p>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-red-600 mb-2">Scenario 3: Children's Inheritance Protection</h4>
                        <p className="text-sm text-red-700 mb-2"><strong>Problem:</strong> Prenuptial protects children's inheritance, but will attempts to disinherit them.</p>
                        <p className="text-sm text-red-700"><strong>Result:</strong> Agreement may create enforceable rights for children despite will provisions.</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "gifts" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-orange-500">
                <CardHeader>
                  <CardTitle className="text-orange-700 text-2xl">⚖️ Lapsed vs. Abated Testamentary Gifts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-orange-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-orange-700 mb-4">Understanding Gift Failure in Wills</h3>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded border border-red-300">
                        <h4 className="font-bold text-red-600 mb-3 flex items-center">
                          <AlertTriangle className="w-5 h-5 mr-2" />
                          Lapsed Gifts
                        </h4>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-semibold text-red-600 mb-1">Definition:</h5>
                            <p className="text-sm text-red-700">A gift fails (lapses) when the intended beneficiary dies before the testator, and no alternative disposition is provided.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-red-600 mb-1">Common Causes:</h5>
                            <ul className="text-xs text-red-700 space-y-1">
                              <li>• Beneficiary predeceases testator</li>
                              <li>• Beneficiary disclaims the gift</li>
                              <li>• Beneficiary is found unworthy (slayer rule)</li>
                              <li>• Beneficiary entity ceases to exist</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-red-600 mb-1">Legal Consequences:</h5>
                            <ul className="text-xs text-red-700 space-y-1">
                              <li>• Gift falls into residuary estate</li>
                              <li>• Anti-lapse statutes may apply</li>
                              <li>• Descendants may take by representation</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white p-4 rounded border border-blue-300">
                        <h4 className="font-bold text-blue-600 mb-3 flex items-center">
                          <Scale className="w-5 h-5 mr-2" />
                          Abated Gifts
                        </h4>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-semibold text-blue-600 mb-1">Definition:</h5>
                            <p className="text-sm text-blue-700">Gifts are reduced (abated) proportionally when the estate has insufficient assets to pay all bequests in full.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-blue-600 mb-1">Common Causes:</h5>
                            <ul className="text-xs text-blue-700 space-y-1">
                              <li>• Estate assets insufficient for all gifts</li>
                              <li>• Large debts or taxes owed</li>
                              <li>• Asset values declined after will execution</li>
                              <li>• Administration expenses exceed projections</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-blue-600 mb-1">Abatement Order:</h5>
                            <ul className="text-xs text-blue-700 space-y-1">
                              <li>• Residuary gifts first</li>
                              <li>• General legacies second</li>
                              <li>• Specific bequests last</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-green-700 mb-4">📋 Detailed Legal Analysis</h3>
                    
                    <div className="space-y-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">Anti-Lapse Statutes</h4>
                        <p className="text-sm text-green-700 mb-3">Most states have anti-lapse statutes that prevent certain gifts from lapsing when the beneficiary predeceases the testator.</p>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-semibold text-green-600 mb-2">Typical Coverage:</h5>
                            <ul className="text-xs text-green-700 space-y-1">
                              <li>• Gifts to testator's descendants</li>
                              <li>• Gifts to testator's siblings</li>
                              <li>• Sometimes extends to other relatives</li>
                              <li>• Must have surviving descendants</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-green-600 mb-2">Requirements:</h5>
                            <ul className="text-xs text-green-700 space-y-1">
                              <li>• Deceased beneficiary must be covered relative</li>
                              <li>• Must have surviving descendants</li>
                              <li>• No contrary will provision</li>
                              <li>• Descendants take per stirpes</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">Abatement Hierarchy</h4>
                        <p className="text-sm text-green-700 mb-3">When estate assets are insufficient, gifts abate in the following order unless the will provides otherwise:</p>
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <div className="bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">1</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Residuary Gifts</h5>
                              <p className="text-xs text-green-700">The "rest and remainder" of the estate abates first</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-orange-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">2</div>
                            <div>
                              <h5 className="font-semibold text-green-600">General Legacies</h5>
                              <p className="text-xs text-green-700">Cash gifts from general estate assets</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-yellow-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">3</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Demonstrative Legacies</h5>
                              <p className="text-xs text-green-700">Gifts from specific sources (treated as general if source insufficient)</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">4</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Specific Bequests</h5>
                              <p className="text-xs text-green-700">Particular items or property (last to abate)</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded border-l-4 border-purple-500">
                    <h3 className="text-lg font-bold text-purple-700 mb-4">🎯 Professional Drafting Solutions</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Preventing Lapse:</h4>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Include alternative beneficiaries</li>
                          <li>• Use class gifts ("to my children")</li>
                          <li>• Specify survival requirements</li>
                          <li>• Consider per stirpes distributions</li>
                          <li>• Include express anti-lapse language</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Managing Abatement:</h4>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Specify abatement order in will</li>
                          <li>• Include specific abatement directives</li>
                          <li>• Consider insurance to fund bequests</li>
                          <li>• Regular estate value updates</li>
                          <li>• Proportional reduction clauses</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-6 rounded border-l-4 border-yellow-500">
                    <h3 className="text-lg font-bold text-yellow-700 mb-4">📚 Practical Examples</h3>
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Example 1: Lapsed Gift with Anti-Lapse</h4>
                        <p className="text-sm text-yellow-700 mb-2"><strong>Will provision:</strong> "I give $50,000 to my daughter Sarah"</p>
                        <p className="text-sm text-yellow-700 mb-2"><strong>Problem:</strong> Sarah predeceases testator, leaving two children</p>
                        <p className="text-sm text-yellow-700"><strong>Result:</strong> Anti-lapse statute applies; Sarah's children receive $25,000 each</p>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Example 2: Abated Gifts</h4>
                        <p className="text-sm text-yellow-700 mb-2"><strong>Will provisions:</strong> $100,000 to each of 5 children; residue to charity</p>
                        <p className="text-sm text-yellow-700 mb-2"><strong>Problem:</strong> Estate only worth $400,000 after debts and expenses</p>
                        <p className="text-sm text-yellow-700"><strong>Result:</strong> Charity gets nothing; children each receive $80,000 (proportional reduction)</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "draft-page" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-indigo-500">
                <CardHeader>
                  <CardTitle className="text-indigo-700 text-2xl">✍️ Will Drafting Exercise</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-indigo-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-indigo-700 mb-4">Professional Will Drafting Practice</h3>
                    <p className="text-indigo-800 mb-4">Practice professional will drafting using proper legal language, structure, and formatting. Remember: Never use templates in actual practice.</p>
                    
                    <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                      <h4 className="font-bold text-red-700 mb-2">⚠️ Critical Professional Warning</h4>
                      <p className="text-red-700 text-sm">This exercise is for educational purposes only. In professional practice, each will must be custom-drafted by qualified legal professionals. Never use templates or forms for actual will drafting as they cannot account for individual circumstances, state law variations, or complex family situations.</p>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded border">
                    <h3 className="text-lg font-bold text-indigo-700 mb-4">📝 Sample Will Format</h3>
                    <div className="bg-gray-50 p-6 rounded border text-sm font-mono">
                      <div className="text-center mb-6">
                        <h4 className="font-bold text-lg">LAST WILL AND TESTAMENT</h4>
                        <p className="font-bold">OF MARGARET ELIZABETH JOHNSON</p>
                      </div>
                      
                      <div className="space-y-4 text-xs">
                        <p><strong>I, MARGARET ELIZABETH JOHNSON,</strong> a resident of Phoenix, Maricopa County, Arizona, being of sound mind and legal age, do hereby make, publish, and declare this to be my Last Will and Testament, hereby revoking all prior wills and codicils made by me.</p>
                        
                        <div>
                          <p className="font-bold">ARTICLE I - FAMILY INFORMATION</p>
                          <p>I am married to ROBERT JOHNSON. I have two children whose names and dates of birth are:</p>
                          <ul className="ml-4 mt-2">
                            <li>JENNIFER JOHNSON SMITH, born March 15, 1985</li>
                            <li>MICHAEL ROBERT JOHNSON, born August 22, 1988</li>
                          </ul>
                        </div>

                        <div>
                          <p className="font-bold">ARTICLE II - APPOINTMENT OF PERSONAL REPRESENTATIVE</p>
                          <p>I hereby nominate and appoint my husband, ROBERT JOHNSON, as the Personal Representative of this Will. If he is unable or unwilling to serve, I nominate my daughter, JENNIFER JOHNSON SMITH, as alternate Personal Representative. I direct that no bond be required of any Personal Representative.</p>
                        </div>

                        <div>
                          <p className="font-bold">ARTICLE III - SPECIFIC BEQUESTS</p>
                          <p>I give and bequeath the following specific items:</p>
                          <ul className="ml-4 mt-2">
                            <li>My diamond engagement ring to my daughter JENNIFER JOHNSON SMITH</li>
                            <li>My 2020 Honda Accord to my son MICHAEL ROBERT JOHNSON</li>
                            <li>The sum of Ten Thousand Dollars ($10,000) to St. Mary's Hospital Foundation</li>
                          </ul>
                        </div>

                        <div>
                          <p className="font-bold">ARTICLE IV - RESIDUARY ESTATE</p>
                          <p>I give, devise, and bequeath all the rest, residue, and remainder of my estate, both real and personal, to my husband ROBERT JOHNSON, if he survives me by thirty (30) days. If he does not so survive me, then to my children JENNIFER JOHNSON SMITH and MICHAEL ROBERT JOHNSON in equal shares, per stirpes.</p>
                        </div>

                        <div>
                          <p className="font-bold">ARTICLE V - POWERS OF PERSONAL REPRESENTATIVE</p>
                          <p>In addition to all powers granted by law, I grant my Personal Representative the following powers to be exercised without court approval: to sell real or personal property at public or private sale; to invest and reinvest estate assets; to continue any business interests; and to distribute assets in kind or in cash.</p>
                        </div>

                        <div>
                          <p className="font-bold">ARTICLE VI - TAX PROVISIONS</p>
                          <p>All estate, inheritance, succession, and other death taxes payable by reason of my death shall be paid from my residuary estate and shall not be apportioned among the beneficiaries.</p>
                        </div>

                        <div className="pt-4 border-t">
                          <p>IN WITNESS WHEREOF, I have hereunto set my hand this 15th day of October, 2024.</p>
                          <div className="mt-6">
                            <p>_________________________________</p>
                            <p>MARGARET ELIZABETH JOHNSON, Testator</p>
                          </div>
                          
                          <div className="mt-8">
                            <p className="font-bold">WITNESSES:</p>
                            <p>We, the undersigned, declare that MARGARET ELIZABETH JOHNSON signed this will in our presence, and that we signed as witnesses in her presence and in the presence of each other, and that to the best of our knowledge the testator was of sound mind and under no constraint or undue influence.</p>
                            <div className="mt-4 space-y-4">
                              <div>
                                <p>_________________________________</p>
                                <p>SUSAN ANDERSON, Witness</p>
                                <p>Address: 123 Main Street, Phoenix, AZ 85001</p>
                              </div>
                              <div>
                                <p>_________________________________</p>
                                <p>DAVID THOMPSON, Witness</p>
                                <p>Address: 456 Oak Avenue, Phoenix, AZ 85002</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="pt-6 border-t">
                          <p className="font-bold">SELF-PROVING AFFIDAVIT</p>
                          <p className="text-xs">STATE OF ARIZONA</p>
                          <p className="text-xs">COUNTY OF MARICOPA</p>
                          <p className="text-xs mt-2">We, MARGARET ELIZABETH JOHNSON, SUSAN ANDERSON, and DAVID THOMPSON, the testator and the witnesses, respectively, whose names are signed to the attached or foregoing instrument, being sworn, do hereby declare to the undersigned authority that the testator signed and executed the instrument as the testator's last will and that the testator signed willingly, and that each of the witnesses, in the presence and hearing of the testator, signed the will as witnesses and that to the best of their knowledge the testator was at that time of sound mind and memory.</p>
                          
                          <div className="mt-4 space-y-3 text-xs">
                            <div>
                              <p>_________________________________</p>
                              <p>MARGARET ELIZABETH JOHNSON, Testator</p>
                            </div>
                            <div>
                              <p>_________________________________</p>
                              <p>SUSAN ANDERSON, Witness</p>
                            </div>
                            <div>
                              <p>_________________________________</p>
                              <p>DAVID THOMPSON, Witness</p>
                            </div>
                            <div className="mt-6">
                              <p>Subscribed, sworn to and acknowledged before me by MARGARET ELIZABETH JOHNSON, the testator, and subscribed and sworn to before me by SUSAN ANDERSON and DAVID THOMPSON, witnesses, this 15th day of October, 2024.</p>
                              <div className="mt-4">
                                <p>_________________________________</p>
                                <p>Notary Public</p>
                                <p>My commission expires: ___________</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-6 rounded border-l-4 border-yellow-500">
                    <h3 className="text-lg font-bold text-yellow-700 mb-4">🎯 Key Drafting Features Demonstrated</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Professional Structure:</h4>
                        <ul className="text-sm text-yellow-700 space-y-1">
                          <li>• Clear article organization</li>
                          <li>• Proper legal terminology</li>
                          <li>• Specific identification of parties</li>
                          <li>• Comprehensive witness requirements</li>
                          <li>• Self-proving affidavit included</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Essential Provisions:</h4>
                        <ul className="text-sm text-yellow-700 space-y-1">
                          <li>• Family status and identification</li>
                          <li>• Executor appointment with alternates</li>
                          <li>• Specific and residuary bequests</li>
                          <li>• Tax payment directives</li>
                          <li>• Administrative powers granted</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "personal-rep" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-blue-500">
                <CardHeader>
                  <CardTitle className="text-blue-700 text-2xl">⚖️ Personal Representative Role and Responsibilities</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-blue-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">Understanding the Personal Representative's Role</h3>
                    <p className="text-blue-800 mb-4">The Personal Representative (also called Executor or Administrator) is the fiduciary appointed to manage and settle the deceased person's estate according to the will's terms and applicable law.</p>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-blue-600 mb-3">📋 Primary Functions:</h4>
                        <ul className="text-sm text-blue-700 space-y-2">
                          <li>• <strong>Asset Collection:</strong> Locate and secure all estate property</li>
                          <li>• <strong>Debt Payment:</strong> Identify and pay valid estate debts</li>
                          <li>• <strong>Tax Compliance:</strong> File required tax returns and pay taxes</li>
                          <li>• <strong>Asset Distribution:</strong> Distribute property per will terms</li>
                          <li>• <strong>Court Reporting:</strong> File required court documents and accountings</li>
                          <li>• <strong>Record Keeping:</strong> Maintain detailed financial records</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-blue-600 mb-3">⚖️ Fiduciary Standards:</h4>
                        <ul className="text-sm text-blue-700 space-y-2">
                          <li>• <strong>Loyalty:</strong> Act solely in the estate's best interests</li>
                          <li>• <strong>Prudence:</strong> Exercise reasonable care and skill</li>
                          <li>• <strong>Impartiality:</strong> Treat all beneficiaries fairly</li>
                          <li>• <strong>Accountability:</strong> Keep detailed records and account to court</li>
                          <li>• <strong>Avoid Conflicts:</strong> No self-dealing or conflicts of interest</li>
                          <li>• <strong>Preserve Assets:</strong> Protect estate property from loss</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-green-700 mb-4">📊 Detailed Responsibilities Timeline</h3>
                    
                    <div className="space-y-6">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Initial Period (0-30 days)
                        </h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Locate and read the will</li>
                          <li>• File petition for probate with court</li>
                          <li>• Obtain death certificates (multiple copies)</li>
                          <li>• Secure estate assets and property</li>
                          <li>• Open estate bank account</li>
                          <li>• Notify life insurance companies</li>
                          <li>• Change locks on real estate if necessary</li>
                          <li>• Notify banks and financial institutions</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <Users className="w-5 h-5 mr-2" />
                          Notice Period (30-120 days)
                        </h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Notify all beneficiaries named in will</li>
                          <li>• Publish notice to creditors in newspaper</li>
                          <li>• Send notice to known creditors by mail</li>
                          <li>• Notify heirs at law (even if not beneficiaries)</li>
                          <li>• File inventory of estate assets with court</li>
                          <li>• Apply for tax identification number for estate</li>
                          <li>• Cancel credit cards and subscriptions</li>
                          <li>• Notify Social Security Administration</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <FileText className="w-5 h-5 mr-2" />
                          Administration Period (4-12 months)
                        </h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Collect and manage estate assets</li>
                          <li>• Pay valid creditor claims</li>
                          <li>• File final income tax return for decedent</li>
                          <li>• File estate tax return if required</li>
                          <li>• File estate income tax returns</li>
                          <li>• Sell assets if necessary for liquidity</li>
                          <li>• Invest estate funds prudently</li>
                          <li>• Defend against invalid claims</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3 flex items-center">
                          <Shield className="w-5 h-5 mr-2" />
                          Distribution Period (12-18 months)
                        </h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Prepare final accounting to court</li>
                          <li>• Distribute specific bequests to beneficiaries</li>
                          <li>• Distribute residuary estate</li>
                          <li>• Obtain receipts from all beneficiaries</li>
                          <li>• File petition for discharge</li>
                          <li>• Close estate bank accounts</li>
                          <li>• Transfer remaining assets</li>
                          <li>• File final court documents</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                    <h3 className="text-lg font-bold text-orange-700 mb-4">⚠️ Common Personal Representative Challenges</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-orange-600 mb-2">Family Conflicts:</h4>
                        <ul className="text-sm text-orange-700 space-y-1">
                          <li>• Disagreements over asset distributions</li>
                          <li>• Challenges to will validity</li>
                          <li>• Requests for advances on inheritances</li>
                          <li>• Disputes over asset valuations</li>
                          <li>• Pressure to favor certain beneficiaries</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-orange-600 mb-2">Legal and Financial Issues:</h4>
                        <ul className="text-sm text-orange-700 space-y-1">
                          <li>• Complex tax situations</li>
                          <li>• Creditor claim disputes</li>
                          <li>• Asset location and valuation</li>
                          <li>• Business interest management</li>
                          <li>• Real estate market timing</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded border-l-4 border-purple-500">
                    <h3 className="text-lg font-bold text-purple-700 mb-4">💼 Personal Representative Qualifications and Compensation</h3>
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Eligibility Requirements:</h4>
                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <h5 className="font-semibold text-purple-600 mb-1">Generally Eligible:</h5>
                            <ul className="text-purple-700 space-y-1">
                              <li>• Adults (18+) of sound mind</li>
                              <li>• Residents of the state (in most states)</li>
                              <li>• Beneficiaries named in the will</li>
                              <li>• Family members and close friends</li>
                              <li>• Professional fiduciaries</li>
                              <li>• Banks and trust companies</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-purple-600 mb-1">Generally Ineligible:</h5>
                            <ul className="text-purple-700 space-y-1">
                              <li>• Minors under 18</li>
                              <li>• Persons with felony convictions</li>
                              <li>• Those adjudicated incompetent</li>
                              <li>• Non-residents (in some states)</li>
                              <li>• Persons with conflicts of interest</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Compensation Standards:</h4>
                        <p className="text-sm text-purple-700 mb-2">Personal representatives are entitled to reasonable compensation for their services, typically based on:</p>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Statutory fee schedules (percentage of estate value)</li>
                          <li>• Reasonable hourly rates for time spent</li>
                          <li>• Complexity of the estate administration</li>
                          <li>• Special skills or expertise required</li>
                          <li>• Geographic location and local standards</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "execution" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-red-500">
                <CardHeader>
                  <CardTitle className="text-red-700 text-2xl">📝 Will Execution Requirements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-red-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-red-700 mb-4">The Formal Nature of Wills</h3>
                    <p className="text-red-800 mb-4">A will is one of the most formal legal documents that exists in the modern legal system. Because the will represents the wishes of a person no longer living, the law requires a great deal of formality to ensure that the document does, in fact, truly represent the desires of a person who can no longer speak for himself.</p>
                    <p className="text-red-800 mb-4">Not only are there certain formalities incident to drafting the will, there are strict standards required to execute, or finalize, the instrument. If these formalities are not adhered to, the will may not pass the scrutiny of the probate court.</p>
                  </div>

                  <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                    <h3 className="text-lg font-bold text-orange-700 mb-4">⚖️ Challenge Protection</h3>
                    <p className="text-orange-800 mb-4">Any person who is named in any will executed by the testator, as well as all intestate heirs of the deceased, has the right to challenge the validity of the instrument presented to the probate court as the last will of the decedent.</p>
                    <p className="text-orange-800">It is the function of the lawyer and the legal assistant who drafted the will to make sure that the legal formalities have been met so that the will can withstand these challenges, or, if the attorney represents one of the challenging heirs, to see that sufficient evidence and documentation validates the challenge.</p>
                  </div>

                  <div className="bg-blue-50 p-6 rounded border-l-4 border-blue-500">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">📋 Types of Valid Wills</h3>
                    <p className="text-blue-800 mb-4">In addition to formal, written wills, which represent the bulk of the documents presented for probate, many jurisdictions permit less formal instruments under special circumstances that also may represent the last wishes of a decedent.</p>
                    <p className="text-blue-800">Recently, many jurisdictions have also approved documents known as living wills, which indicate a person's wishes with respect to life termination in the event of the person becoming incapacitated with no reasonable expectation of recovery.</p>
                  </div>

                  <div className="bg-red-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-red-700 mb-4">Legal Requirements for Valid Will Execution</h3>
                    <p className="text-red-800 mb-4">Proper execution is critical for will validity. Failure to follow state requirements exactly can invalidate the entire will, regardless of the testator's intent.</p>
                    
                    <div className="bg-white p-4 rounded border border-red-300">
                      <h4 className="font-bold text-red-600 mb-3">⚖️ Universal Execution Requirements (Most States):</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        <ul className="text-sm text-red-700 space-y-2">
                          <li>• <strong>Writing:</strong> Will must be in writing (typed or handwritten)</li>
                          <li>• <strong>Signature:</strong> Testator must sign the will</li>
                          <li>• <strong>Witnesses:</strong> Minimum two competent witnesses required</li>
                          <li>• <strong>Capacity:</strong> Testator must have testamentary capacity</li>
                        </ul>
                        <ul className="text-sm text-red-700 space-y-2">
                          <li>• <strong>Intent:</strong> Clear intent to create a will</li>
                          <li>• <strong>Presence:</strong> Witnesses must sign in testator's presence</li>
                          <li>• <strong>Knowledge:</strong> Witnesses must know document is a will</li>
                          <li>• <strong>Contemporaneous:</strong> All signatures should be made at same time</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-green-700 mb-4">📋 Step-by-Step Execution Protocol</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">Before the Execution Ceremony:</h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Schedule execution with all parties present</li>
                          <li>• Prepare clean, final copy of will</li>
                          <li>• Arrange for competent, disinterested witnesses</li>
                          <li>• Obtain notary public if self-proving affidavit used</li>
                          <li>• Ensure testator is mentally competent</li>
                          <li>• Have blue ink pens ready (avoid black for copying clarity)</li>
                          <li>• Prepare self-proving affidavit if state allows</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">During the Execution Ceremony:</h4>
                        <div className="space-y-3">
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">1</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Testator Declaration</h5>
                              <p className="text-xs text-green-700">Testator states: "This is my will and I ask you to witness my signature"</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">2</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Testator Signature</h5>
                              <p className="text-xs text-green-700">Testator signs will in presence of all witnesses</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">3</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Witness Signatures</h5>
                              <p className="text-xs text-green-700">Each witness signs in presence of testator and other witnesses</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">4</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Witness Information</h5>
                              <p className="text-xs text-green-700">Witnesses print names and addresses clearly</p>
                            </div>
                          </div>
                          <div className="flex items-start space-x-3">
                            <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">5</div>
                            <div>
                              <h5 className="font-semibold text-green-600">Self-Proving Affidavit</h5>
                              <p className="text-xs text-green-700">If applicable, all parties sign notarized self-proving affidavit</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">After Execution:</h4>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Make copies for testator's records</li>
                          <li>• Store original in safe location</li>
                          <li>• Document witness contact information</li>
                          <li>• Provide execution memorandum to file</li>
                          <li>• Update estate planning documents as needed</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-6 rounded border-l-4 border-blue-500">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">👥 Witness Requirements and Qualifications</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Qualified Witnesses Must Be:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Adults (18 years or older)</li>
                          <li>• Mentally competent</li>
                          <li>• Able to testify in court if needed</li>
                          <li>• Present during entire execution ceremony</li>
                          <li>• Able to identify testator later</li>
                          <li>• Disinterested (not beneficiaries)</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-blue-600 mb-2">Poor Witness Choices:</h4>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Beneficiaries under the will</li>
                          <li>• Spouses of beneficiaries</li>
                          <li>• Minors or incompetent persons</li>
                          <li>• Persons unlikely to be available later</li>
                          <li>• Family members (if interested parties)</li>
                          <li>• Persons with poor memory or health</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-6 rounded border-l-4 border-yellow-500">
                    <h3 className="text-lg font-bold text-yellow-700 mb-4">⚠️ State Law Variations</h3>
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Number of Witnesses Required:</h4>
                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <h5 className="font-semibold text-yellow-600">Two Witnesses (Most States):</h5>
                            <p className="text-yellow-700">California, Florida, New York, Texas, and most others</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-yellow-600">Three Witnesses:</h5>
                            <p className="text-yellow-700">Vermont (for certain situations)</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-yellow-600">Special Rules:</h5>
                            <p className="text-yellow-700">Louisiana (notarial wills), holographic wills may not require witnesses</p>
                          </div>
                        </div>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-yellow-600 mb-2">Additional State Requirements:</h4>
                        <ul className="text-sm text-yellow-700 space-y-1">
                          <li>• <strong>Connecticut:</strong> Self-proving affidavit must be executed simultaneously</li>
                          <li>• <strong>Texas:</strong> Witnesses must be "credible" persons</li>
                          <li>• <strong>Florida:</strong> Witnesses must sign in each other's presence</li>
                          <li>• <strong>California:</strong> Clear signature requirements, witnesses must understand document is a will</li>
                          <li>• <strong>New York:</strong> Strict compliance with attestation clause requirements</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-6 rounded border-l-4 border-purple-500">
                    <h3 className="text-lg font-bold text-purple-700 mb-4">🎯 Self-Proving Affidavits</h3>
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Benefits of Self-Proving Affidavits:</h4>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Eliminates need to locate witnesses for probate</li>
                          <li>• Provides additional evidence of proper execution</li>
                          <li>• Speeds up probate process</li>
                          <li>• Protects against witness unavailability</li>
                          <li>• Creates presumption of valid execution</li>
                        </ul>
                      </div>
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-purple-600 mb-2">Execution Requirements:</h4>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Must be signed by testator and witnesses</li>
                          <li>• Requires notary public acknowledgment</li>
                          <li>• Should be executed at same time as will</li>
                          <li>• Must comply with state-specific language</li>
                          <li>• Cannot cure defective will execution</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeSubsection === "amendments" && (
            <div className="space-y-6">
              <Card className="border-l-4 border-teal-500">
                <CardHeader>
                  <CardTitle className="text-teal-700 text-2xl">📝 Changing and Amending Wills</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-teal-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-teal-700 mb-4">Methods for Modifying Wills</h3>
                    <p className="text-teal-800 mb-4">Wills can be changed during the testator's lifetime through several legally recognized methods. Each method has specific requirements and limitations.</p>
                    
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="bg-white p-4 rounded border border-teal-300">
                        <h4 className="font-bold text-teal-600 mb-2 text-center">🔄 Complete Revocation</h4>
                        <p className="text-sm text-teal-700 text-center">Creating an entirely new will that revokes all prior wills</p>
                      </div>
                      <div className="bg-white p-4 rounded border border-teal-300">
                        <h4 className="font-bold text-teal-600 mb-2 text-center">📋 Codicil</h4>
                        <p className="text-sm text-teal-700 text-center">A supplemental document that modifies specific provisions</p>
                      </div>
                      <div className="bg-white p-4 rounded border border-teal-300">
                        <h4 className="font-bold text-teal-600 mb-2 text-center">❌ Physical Destruction</h4>
                        <p className="text-sm text-teal-700 text-center">Intentionally destroying the will with intent to revoke</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-blue-700 mb-4">📋 Method 1: Codicils</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-blue-600 mb-3">Definition and Purpose:</h4>
                        <p className="text-sm text-blue-700 mb-3">A codicil is a supplemental document that modifies, explains, or adds to an existing will without completely replacing it. The original will remains in effect except for provisions specifically changed by the codicil.</p>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-semibold text-blue-600 mb-2">Appropriate Uses:</h5>
                            <ul className="text-sm text-blue-700 space-y-1">
                              <li>• Minor changes to existing provisions</li>
                              <li>• Adding or removing small bequests</li>
                              <li>• Changing executors or guardians</li>
                              <li>• Correcting errors in original will</li>
                              <li>• Adding new beneficiaries</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-blue-600 mb-2">Execution Requirements:</h5>
                            <ul className="text-sm text-blue-700 space-y-1">
                              <li>• Must comply with same formalities as wills</li>
                              <li>• Requires proper witnessing</li>
                              <li>• Must reference the original will clearly</li>
                              <li>• Should be dated and signed</li>
                              <li>• May include self-proving affidavit</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-blue-600 mb-3">Sample Codicil Format:</h4>
                        <div className="bg-gray-50 p-4 rounded text-sm font-mono">
                          <div className="text-center mb-4">
                            <h5 className="font-bold">FIRST CODICIL TO THE LAST WILL AND TESTAMENT</h5>
                            <p className="font-bold">OF [TESTATOR NAME]</p>
                          </div>
                          
                          <div className="space-y-3 text-xs">
                            <p><strong>I, [TESTATOR NAME],</strong> a resident of [City, State], being of sound mind, do hereby make this First Codicil to my Last Will and Testament dated [Original Will Date].</p>
                            
                            <p><strong>FIRST:</strong> I hereby revoke Article III, Section 2 of my said Will and substitute the following:</p>
                            <p className="ml-4">"I give and bequeath the sum of Twenty-Five Thousand Dollars ($25,000) to my nephew, JOHN SMITH, if he survives me."</p>
                            
                            <p><strong>SECOND:</strong> I hereby add the following new provision as Article VI of my said Will:</p>
                            <p className="ml-4">"I give and bequeath my collection of rare books to the City Public Library."</p>
                            
                            <p><strong>THIRD:</strong> In all other respects, I hereby confirm and republish my said Last Will and Testament.</p>
                            
                            <div className="pt-3 border-t">
                              <p>IN WITNESS WHEREOF, I have hereunto set my hand this _____ day of _______, 2024.</p>
                              <div className="mt-3">
                                <p>_________________________________</p>
                                <p>[TESTATOR NAME], Testator</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded">
                    <h3 className="text-lg font-bold text-green-700 mb-4">🔄 Method 2: Complete Will Revocation and Replacement</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">When to Use Complete Replacement:</h4>
                        <ul className="text-sm text-green-700 space-y-2">
                          <li>• <strong>Major Changes:</strong> Substantial modifications to distribution scheme</li>
                          <li>• <strong>Changed Circumstances:</strong> Marriage, divorce, birth of children</li>
                          <li>• <strong>Multiple Codicils:</strong> When several codicils create confusion</li>
                          <li>• <strong>Tax Law Changes:</strong> Significant changes in estate tax laws</li>
                          <li>• <strong>Clarity:</strong> When a new will would be clearer than amendments</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded border">
                        <h4 className="font-bold text-green-600 mb-3">Revocation Language in New Will:</h4>
                        <div className="bg-gray-50 p-4 rounded text-sm">
                          <p className="font-semibold mb-2">Standard Revocation Clause:</p>
                          <p className="italic">"I hereby revoke all prior wills and codicils made by me."</p>
                          
                          <p className="font-semibold mb-2 mt-4">Specific Revocation Clause:</p>
                          <p className="italic">"I hereby revoke my Last Will and Testament dated [Date] and all codicils thereto, and declare this to be my Last Will and Testament."</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-red-50 p-6 rounded border-l-4 border-red-500">
                    <h3 className="text-lg font-bold text-red-700 mb-4">❌ Method 3: Physical Destruction</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-red-600 mb-2">Legal Requirements for Revocation by Destruction:</h4>
                        <ul className="text-sm text-red-700 space-y-1">
                          <li>• <strong>Intent:</strong> Must intend to revoke the will</li>
                          <li>• <strong>Act:</strong> Must perform a destructive act (burning, tearing, canceling)</li>
                          <li>• <strong>Testator:</strong> Must be done by testator or at testator's direction</li>
                          <li>• <strong>Presence:</strong> If done by another, must be in testator's presence</li>
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-red-600 mb-2">⚠️ Risks of Physical Destruction:</h4>
                        <ul className="text-sm text-red-700 space-y-1">
                          <li>• Difficult to prove intent to revoke</li>
                          <li>• May result in intestacy if no prior will</li>
                          <li>• Accidental destruction may be disputed</li>
                          <li>• Copies may create confusion about revocation</li>
                          <li>• Family members may challenge the revocation</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                    <h3 className="text-lg font-bold text-orange-700 mb-4">⚠️ Essential Will Preparation Guidelines</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded">
                        <h4 className="font-bold text-orange-600 mb-3">Critical Drafting Requirements:</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-semibold text-orange-600 mb-2">Document Standards:</h5>
                            <ul className="text-sm text-orange-700 space-y-1">
                              <li>• <strong>Avoid printed forms and templates</strong></li>
                              <li>• Clearly describe all assets specifically given away</li>
                              <li>• Avoid all erasures on the document</li>
                              <li>• Make no changes to the will after execution</li>
                              <li>• Use simple, clear language throughout</li>
                              <li>• Number all pages and clauses properly</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-orange-600 mb-2">Execution Standards:</h5>
                            <ul className="text-sm text-orange-700 space-y-1">
                              <li>• Have each page signed by testator</li>
                              <li>• Always include a residuary clause</li>
                              <li>• Include marital deduction provision if married</li>
                              <li>• Never use angry or emotional words</li>
                              <li>• Never use a video will format</li>
                              <li>• Do not make duplicate originals</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-red-50 p-4 rounded border border-red-300">
                        <h4 className="font-bold text-red-600 mb-3">Important Prohibitions:</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="font-semibold text-red-600 mb-2">What to Avoid:</h5>
                            <ul className="text-sm text-red-700 space-y-1">
                              <li>• <strong>Never use printed forms or templates</strong></li>
                              <li>• Avoid joint and mutual wills</li>
                              <li>• No video wills under any circumstances</li>
                              <li>• Never include angry or vindictive language</li>
                              <li>• No erasures or corrections after drafting</li>
                            </ul>
                          </div>
                          <div>
                            <h5 className="font-semibold text-red-600 mb-2">Storage & Access:</h5>
                            <ul className="text-sm text-red-700 space-y-1">
                              <li>• Leave will in readily accessible place</li>
                              <li>• Do not create duplicate originals</li>
                              <li>• Inform executor of will location</li>
                              <li>• Keep will in secure but accessible location</li>
                              <li>• Consider fireproof safe or safety deposit box</li>
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="bg-green-50 p-4 rounded border border-green-300">
                        <h4 className="font-bold text-green-600 mb-3">Best Practices for Will Preparation:</h4>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-semibold text-green-600 mb-1">Asset Description:</h5>
                            <p className="text-sm text-green-700">Clearly describe all assets specifically given away in the will with sufficient detail to avoid confusion or disputes.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-green-600 mb-1">Language Standards:</h5>
                            <p className="text-sm text-green-700">Use simple, clear language that can be easily understood by all parties. Avoid legal jargon when plain English will suffice.</p>
                          </div>
                          <div>
                            <h5 className="font-semibold text-green-600 mb-1">Tax Considerations:</h5>
                            <p className="text-sm text-green-700">A marital deduction provision is strongly suggested if the testator is married to maximize tax benefits for the surviving spouse.</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-50 p-4 rounded border border-blue-300">
                        <h4 className="font-bold text-blue-600 mb-2">Why These Guidelines Matter:</h4>
                        <p className="text-sm text-blue-700 mb-2">These preparation standards help ensure:</p>
                        <ul className="text-sm text-blue-700 space-y-1">
                          <li>• Will validity and enforceability in probate court</li>
                          <li>• Clear understanding of testator's intent</li>
                          <li>• Reduced likelihood of successful will contests</li>
                          <li>• Efficient estate administration process</li>
                          <li>• Protection of beneficiaries' interests</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}
    </div>
  );
}