import { useState } from 'react';
import { ArrowLeft, BookOpen, Calculator, Brain, Trophy, DollarSign, Shield, TrendingUp, Users, ChevronRight, ChevronLeft, Check, X, Clock, Award, Star } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function InsuranceStandalone() {
  const [currentView, setCurrentView] = useState('home');
  const [currentModule, setCurrentModule] = useState('basics');
  const [currentLesson, setCurrentLesson] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [userProgress, setUserProgress] = useState({
    modulesCompleted: [] as string[],
    totalScore: 0,
    badges: [] as string[]
  });

  const modules = [
    {
      id: 'basics',
      title: '🛡️ Insurance Basics',
      icon: Shield,
      color: 'from-blue-500 to-blue-600',
      description: 'Understanding the fundamentals of life insurance',
      duration: '25 min',
      lessons: [
        {
          title: 'What is Life Insurance?',
          content: `Life insurance is a contract between you and an insurance company. You pay premiums, and in return, the company provides a death benefit to your beneficiaries when you pass away.

Think of it like a financial safety net for your family. Just like you wear a seatbelt to protect yourself in a car, life insurance protects your family financially.

**Key Terms:**
• **Premium**: The amount you pay (monthly or yearly)
• **Death Benefit**: The money your family receives
• **Beneficiary**: The person who gets the money
• **Policy**: The insurance contract

**Why It Matters:**
Life insurance becomes especially important when you have people depending on your income. Whether it's a spouse, children, or aging parents, life insurance ensures they can maintain their lifestyle even if something happens to you.`,
          scenario: {
            title: 'Real-Life Example',
            text: 'Sarah, 25, pays $30/month for a $250,000 life insurance policy. If something happens to her, her family receives $250,000 to help with expenses, mortgage, and her children\'s education. That\'s less than a dollar per day for incredible peace of mind!'
          }
        },
        {
          title: 'Types of Life Insurance',
          content: `There are two main types of life insurance, each serving different purposes:

**Term Life Insurance:**
• Temporary coverage (10, 20, or 30 years)
• Lower cost when young
• No cash value
• Like renting an apartment - pure protection

**Permanent Life Insurance:**
• Lifetime coverage
• Higher cost but builds cash value
• Can borrow against it
• Like owning a home - protection plus investment

**Which Should You Choose?**
Term is perfect for temporary needs like protecting a mortgage or providing for young children. Permanent insurance is ideal for long-term wealth building and estate planning.

**Pro Tip:** Many families start with term insurance for affordability and add permanent coverage later as their income grows.`,
          scenario: {
            title: 'The Johnson Family Decision',
            text: 'The Johnsons have young kids and a 30-year mortgage. They choose a 30-year term policy because it\'s affordable ($50/month) and covers their biggest risk period. Once the kids are grown and the mortgage is paid off, they plan to convert to permanent insurance.'
          }
        }
      ]
    },
    {
      id: 'living-benefits',
      title: '💰 Living Benefits',
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      description: 'How to benefit from insurance while you\'re alive',
      duration: '30 min',
      lessons: [
        {
          title: 'Cash Value Growth',
          content: `Permanent life insurance isn't just about death benefits. It builds cash value you can use while alive!

**How Cash Value Works:**
• Part of your premium pays for insurance cost
• Part goes into a savings/investment account
• This cash value grows over time (tax-free!)
• You can access it through loans or withdrawals

**Real Benefits While Living:**
• Emergency fund that grows tax-free
• Retirement income supplement
• College funding for children
• Business opportunity funding
• Major purchase financing

**The Magic of Tax-Free Growth:**
Unlike regular savings accounts or even 401(k)s, your cash value grows without yearly tax consequences. This can significantly boost your long-term wealth accumulation.`,
          scenario: {
            title: 'Marcus\'s Success Story',
            text: 'Marcus started a $500/month whole life policy at 25. By age 40, he had $180,000 in cash value. When a business opportunity arose, he borrowed $50,000 from his policy to invest - no credit check, no bank approval needed. His death benefit remained intact, and his cash value continued growing!'
          }
        },
        {
          title: 'Policy Loans & Withdrawals',
          content: `Your cash value is YOUR money. Here's how to access it strategically:

**Policy Loans:**
• Borrow against your cash value (not from it)
• No credit check or approval process needed
• Competitive interest rates
• Flexible repayment terms
• Death benefit reduced only by outstanding loan

**Withdrawals:**
• Take money directly from cash value
• May reduce death benefit permanently
• Usually tax-free up to total premiums paid
• Good for one-time needs

**Smart Access Strategies:**
• Use loans for temporary needs (real estate, business)
• Use withdrawals for permanent lifestyle changes
• Always consider the impact on your beneficiaries
• Work with your agent to optimize timing`,
          scenario: {
            title: 'The Emergency Fund Revolution',
            text: 'Instead of keeping $30,000 in a 0.5% savings account, the Williams family moved their emergency fund into life insurance cash value earning 4-6% annually. When their roof needed replacing ($15,000), they borrowed from their policy instead of using high-interest credit cards, saving thousands in interest payments!'
          }
        }
      ]
    },
    {
      id: 'wealth-building',
      title: '🏠 Generational Wealth',
      icon: Users,
      color: 'from-purple-500 to-purple-600',
      description: 'Building wealth that lasts for generations',
      duration: '35 min',
      lessons: [
        {
          title: 'The Wealth Transfer Strategy',
          content: `Life insurance is one of the most powerful wealth transfer tools available to everyday families:

**Why It's So Powerful:**
• Death benefits are typically tax-free to beneficiaries
• Can multiply your investment many times over
• Protects wealth from taxes and creditors
• Provides immediate liquidity when needed
• Creates wealth that didn't exist before

**The Multiplication Effect:**
A $500/month premium might provide a $1,000,000+ death benefit. That's potentially doubling or tripling your investment through the power of insurance leverage.

**Generational Impact:**
• Your children receive substantial inheritance
• They can use proceeds to buy their own policies
• Creates a family banking system
• Builds financial security for multiple generations
• Breaks cycles of financial struggle`,
          scenario: {
            title: 'The Martinez Family Legacy',
            text: 'Carlos, a teacher, pays $400/month for life insurance. When he passes, his three children each receive $300,000. Maria uses hers to pay off her home and start a business. Juan funds his children\'s college education. Sofia buys rental properties. All three purchase their own policies, continuing the wealth-building cycle their father started.'
          }
        },
        {
          title: 'Tax Advantages Explained',
          content: `Life insurance offers incredible tax benefits that can dramatically impact your family's wealth:

**Tax-Free Growth:**
• Cash value grows without yearly tax consequences
• Like a Roth IRA but with more flexibility
• No contribution limits like retirement accounts
• No required distributions at age 73

**Tax-Free Access:**
• Policy loans are generally not taxable events
• Withdrawals up to basis are usually tax-free
• No early withdrawal penalties like IRAs
• Access your money when YOU need it

**Tax-Free Death Benefit:**
• Beneficiaries receive proceeds income-tax-free
• Can help pay estate taxes if properly structured
• Protects other assets from forced liquidation
• Provides immediate cash when families need it most

**Estate Planning Advantages:**
• Can remove assets from taxable estate
• Provides liquidity to pay estate taxes
• Equalizes inheritances among children
• Funds business buy-sell agreements`,
          scenario: {
            title: 'Avoiding the Tax Trap',
            text: 'The Chen family owns a $2 million family business. Without planning, their children would face a $600,000+ estate tax bill, potentially forcing them to sell the business. With a $1 million life insurance policy, the taxes are covered, the business stays in the family, and the children can continue the legacy their parents built.'
          }
        }
      ]
    },
    {
      id: 'banking',
      title: '🏦 Be Your Own Bank',
      icon: DollarSign,
      color: 'from-orange-500 to-orange-600',
      description: 'Using insurance as your personal banking system',
      duration: '40 min',
      lessons: [
        {
          title: 'The Infinite Banking Concept',
          content: `Imagine owning a bank where YOU are both the customer and the owner. That's the power of the Infinite Banking Concept:

**How It Works:**
1. Build substantial cash value in whole life insurance
2. Borrow against your cash value for major purchases
3. Pay yourself back with interest (instead of a bank)
4. Your money continues earning dividends while borrowed

**Why It's Revolutionary:**
• You pay interest to yourself, not a bank
• Your cash value keeps earning even while borrowed
• No credit applications, approval processes, or qualifying
• You control the repayment terms completely
• You're building wealth instead of making banks rich

**What You Can Finance:**
• Automobiles and major purchases
• Real estate investments and down payments
• Business opportunities and equipment
• Education expenses for children
• Vacations and lifestyle purchases
• Emergency expenses without credit cards`,
          scenario: {
            title: 'The Car Purchase Revolution',
            text: 'Instead of financing a $40,000 car at 7% through a bank, Maria borrows from her life insurance cash value at 5%. She sets up a 5-year repayment plan to herself. Result: She saves $3,200 in interest AND that money goes back into her policy instead of the bank\'s profits!'
          }
        },
        {
          title: 'Building Your Banking System',
          content: `Creating your personal banking system is a journey that builds wealth over decades:

**Phase 1: Foundation (Years 1-5)**
• Start with an affordable premium you can sustain
• Focus on consistent payments to build cash value
• Learn how the system works
• Resist early borrowing temptations

**Phase 2: Growth (Years 6-15)**
• Increase premiums as income grows
• Make your first policy loans for major purchases
• Reinvest loan payments back into the system
• Consider additional policies for family members

**Phase 3: Mastery (Years 16+)**
• Achieve significant cash value accumulation
• Replace traditional banking for most financing needs
• Implement sophisticated wealth transfer strategies
• Teach the system to your children

**Keys to Success:**
• Start as early as possible (time is your greatest asset)
• Be consistent with premium payments
• Always pay yourself back with interest
• Work with knowledgeable professionals
• Think generationally, not just personally`,
          scenario: {
            title: 'The Thompson Family Bank',
            text: 'Over 20 years, the Thompsons built $500,000 in combined cash value across family policies. They\'ve financed 6 cars, funded two college educations, provided down payments for their children\'s homes, and started a family business - all while keeping the interest payments within the family system instead of enriching financial institutions!'
          }
        }
      ]
    }
  ];

  const quizQuestions = [
    {
      question: "What is the main purpose of life insurance?",
      options: [
        "To make you rich quickly",
        "To provide financial protection for your family",
        "To replace your job income completely",
        "To avoid paying any taxes"
      ],
      correct: 1,
      explanation: "Life insurance primarily provides financial protection for your beneficiaries when you pass away, ensuring they can maintain their lifestyle and meet financial obligations."
    },
    {
      question: "Which type of insurance builds cash value?",
      options: [
        "Term life insurance only",
        "Permanent life insurance only",
        "Both term and permanent",
        "Neither type builds cash value"
      ],
      correct: 1,
      explanation: "Only permanent life insurance (whole life, universal life) builds cash value that you can access while alive. Term insurance provides pure protection without any cash accumulation."
    },
    {
      question: "What is a policy loan?",
      options: [
        "A loan from the bank using your policy as collateral",
        "Borrowing money against your cash value",
        "A loan to help pay your monthly premiums",
        "Money the insurance company owes you"
      ],
      correct: 1,
      explanation: "A policy loan allows you to borrow against your own cash value, using your policy as collateral. You're essentially borrowing from yourself."
    },
    {
      question: "Life insurance death benefits are typically:",
      options: [
        "Fully taxable as ordinary income",
        "Partially taxable to beneficiaries",
        "Received tax-free by beneficiaries",
        "Subject to capital gains tax"
      ],
      correct: 2,
      explanation: "Life insurance death benefits are generally received tax-free by beneficiaries, making them an efficient wealth transfer tool."
    },
    {
      question: "The 'Infinite Banking Concept' involves:",
      options: [
        "Opening unlimited bank accounts",
        "Using life insurance cash value as your personal bank",
        "Getting unlimited credit from traditional banks",
        "Avoiding all banks and using only cash"
      ],
      correct: 1,
      explanation: "Infinite Banking uses whole life insurance cash value to create your own banking system, allowing you to be your own source of financing."
    }
  ];

  const handleQuizAnswer = (questionIndex: number, answerIndex: number) => {
    setQuizAnswers({...quizAnswers, [questionIndex]: answerIndex});
  };

  const calculateQuizScore = () => {
    let correct = 0;
    quizQuestions.forEach((q, index) => {
      if (quizAnswers[index] === q.correct) correct++;
    });
    return Math.round((correct / quizQuestions.length) * 100);
  };

  const submitQuiz = () => {
    const score = calculateQuizScore();
    setShowResults(true);
    setUserProgress(prev => ({
      ...prev,
      totalScore: Math.max(prev.totalScore, score),
      badges: score >= 80 ? [...prev.badges.filter(b => b !== 'Insurance Expert'), 'Insurance Expert'] : prev.badges
    }));
  };

  const resetQuiz = () => {
    setQuizAnswers({});
    setShowResults(false);
  };

  // Home View
  if (currentView === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Header */}
        <div className="bg-white shadow-sm border-b sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <button 
                onClick={() => window.history.back()}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </button>
              <h1 className="text-xl font-bold text-gray-900">🛡️ Insurance for Starters</h1>
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span className="font-semibold">{userProgress.totalScore}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-6">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-800 mb-4">🛡️ Insurance for Starters</h1>
            <p className="text-xl text-gray-600 mb-8">Master life insurance to protect your family and build generational wealth</p>
            
            <div className="flex justify-center space-x-8 mb-8">
              <div className="text-center">
                <Shield className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Family Protection</div>
              </div>
              <div className="text-center">
                <TrendingUp className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Wealth Building</div>
              </div>
              <div className="text-center">
                <DollarSign className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Personal Banking</div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge className="bg-blue-100 text-blue-800 px-4 py-2">Ages 18+ • Adult Learning</Badge>
              <Badge className="bg-green-100 text-green-800 px-4 py-2">💰 Real-World Application</Badge>
              <Badge className="bg-purple-100 text-purple-800 px-4 py-2">🎯 Financial Security</Badge>
            </div>
          </div>

          {/* Progress Overview */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card>
              <CardContent className="pt-6 text-center">
                <BookOpen className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">4</div>
                <div className="text-sm text-gray-600">Learning Modules</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <Brain className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">{userProgress.totalScore}%</div>
                <div className="text-sm text-gray-600">Quiz Score</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <Award className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">{userProgress.badges.length}</div>
                <div className="text-sm text-gray-600">Badges Earned</div>
              </CardContent>
            </Card>
          </div>

          {/* Course Modules */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {modules.map((module, index) => {
              const Icon = module.icon;
              return (
                <Card 
                  key={module.id}
                  className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
                  onClick={() => {
                    setCurrentView('module');
                    setCurrentModule(module.id);
                    setCurrentLesson(0);
                  }}
                >
                  <div className={`h-2 bg-gradient-to-r ${module.color} rounded-t-lg`}></div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Icon className="w-8 h-8 text-gray-700" />
                      <Badge variant="outline">Module {index + 1}</Badge>
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900">
                      {module.title}
                    </CardTitle>
                    <p className="text-gray-600 text-sm">{module.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <Clock className="w-4 h-4 mr-2" />
                      {module.duration}
                      <span className="mx-2">•</span>
                      <BookOpen className="w-4 h-4 mr-2" />
                      {module.lessons.length} lessons
                    </div>
                    <Button className="w-full">
                      Start Module
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Quick Actions */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-500" />
                  📝 Test Your Knowledge
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Take our comprehensive quiz to test your insurance knowledge and earn badges!</p>
                <Button onClick={() => setCurrentView('quiz')} className="w-full">
                  Take Quiz
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="w-5 h-5 mr-2 text-green-500" />
                  💰 Premium Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Calculate potential premiums and see how life insurance can fit your budget.</p>
                <Button variant="outline" className="w-full" disabled>
                  Coming Soon
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Quiz View
  if (currentView === 'quiz') {
    if (showResults) {
      const score = calculateQuizScore();
      return (
        <div className="min-h-screen bg-gray-50 p-6">
          <div className="max-w-2xl mx-auto">
            <Card className="text-center">
              <CardContent className="pt-8">
                <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-3xl font-bold mb-4">Quiz Complete! 🎉</h2>
                <div className="text-6xl font-bold text-blue-600 mb-4">{score}%</div>
                <p className="text-lg text-gray-600 mb-6">
                  You scored {Object.values(quizAnswers).filter((answer, index) => answer === quizQuestions[index].correct).length} out of {quizQuestions.length} questions correctly!
                </p>
                
                {score >= 80 && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-center text-yellow-800">
                      <Star className="w-5 h-5 mr-2" />
                      <span className="font-semibold">Congratulations! You earned the "Insurance Expert" badge!</span>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <Button onClick={resetQuiz} className="w-full">
                    Retake Quiz
                  </Button>
                  <Button onClick={() => setCurrentView('home')} variant="outline" className="w-full">
                    Back to Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <Button onClick={() => setCurrentView('home')} variant="ghost">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>📝 Insurance Knowledge Quiz</CardTitle>
              <Progress value={(Object.keys(quizAnswers).length / quizQuestions.length) * 100} />
              <p className="text-sm text-gray-600">
                {Object.keys(quizAnswers).length} of {quizQuestions.length} questions answered
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {quizQuestions.map((question, questionIndex) => (
                <div key={questionIndex} className="border-b pb-6 last:border-b-0">
                  <h3 className="font-semibold mb-4 text-lg">
                    {questionIndex + 1}. {question.question}
                  </h3>
                  <div className="space-y-2">
                    {question.options.map((option, optionIndex) => (
                      <button
                        key={optionIndex}
                        onClick={() => handleQuizAnswer(questionIndex, optionIndex)}
                        className={`w-full text-left p-3 rounded border transition-colors ${
                          quizAnswers[questionIndex] === optionIndex
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              
              {Object.keys(quizAnswers).length === quizQuestions.length && (
                <Button onClick={submitQuiz} className="w-full">
                  Submit Quiz
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Module View
  if (currentView === 'module') {
    const moduleData = modules.find(m => m.id === currentModule);
    if (!moduleData) return null;
    
    const lessonData = moduleData.lessons[currentLesson];
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button onClick={() => setCurrentView('home')} variant="ghost">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Modules
              </Button>
              <h1 className="text-lg font-semibold">{moduleData.title}</h1>
              <div className="text-sm text-gray-600">
                {currentLesson + 1} of {moduleData.lessons.length}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">{lessonData.title}</CardTitle>
                <Badge className={`bg-gradient-to-r ${moduleData.color} text-white`}>
                  Lesson {currentLesson + 1}
                </Badge>
              </div>
              <Progress value={((currentLesson + 1) / moduleData.lessons.length) * 100} />
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Main Content */}
              <div className="prose max-w-none">
                {lessonData.content.split('\n').map((paragraph, index) => {
                  if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                    return <h4 key={index} className="font-bold text-lg mt-4 mb-2 text-blue-900">{paragraph.slice(2, -2)}</h4>;
                  }
                  if (paragraph.startsWith('• ')) {
                    return <li key={index} className="ml-4 mb-1">{paragraph.slice(2)}</li>;
                  }
                  if (paragraph.trim()) {
                    return <p key={index} className="mb-4 text-gray-700 leading-relaxed">{paragraph}</p>;
                  }
                  return null;
                })}
              </div>

              {/* Scenario Box */}
              {lessonData.scenario && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                    <Star className="w-5 h-5 mr-2" />
                    {lessonData.scenario.title}
                  </h4>
                  <p className="text-blue-800 leading-relaxed">{lessonData.scenario.text}</p>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between pt-6">
                <Button
                  onClick={() => setCurrentLesson(Math.max(0, currentLesson - 1))}
                  disabled={currentLesson === 0}
                  variant="outline"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                
                {currentLesson < moduleData.lessons.length - 1 ? (
                  <Button
                    onClick={() => setCurrentLesson(currentLesson + 1)}
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={() => {
                      setCurrentView('home');
                      setCurrentLesson(0);
                    }}
                  >
                    Complete Module
                    <Check className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}