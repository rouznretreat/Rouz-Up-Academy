import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Target, TrendingUp, DollarSign, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Challenge {
  id: number;
  title: string;
  goal: number;
  timeLimit: number; // weeks
  difficulty: 'easy' | 'medium' | 'hard';
  description: string;
  weeklyTarget: number;
  rewards: string[];
}

const challenges: Challenge[] = [
  {
    id: 1,
    title: "Emergency Fund Starter",
    goal: 500,
    timeLimit: 10,
    difficulty: 'easy',
    description: "Build your first emergency fund of $500 in 10 weeks",
    weeklyTarget: 50,
    rewards: ["Financial Security Badge", "Emergency Fund Certificate", "Peace of Mind Achievement"]
  },
  {
    id: 2,
    title: "Car Fund Champion",
    goal: 2000,
    timeLimit: 16,
    difficulty: 'medium',
    description: "Save for a reliable used car down payment",
    weeklyTarget: 125,
    rewards: ["Car Fund Master", "Transportation Independence", "Big Goal Achiever"]
  },
  {
    id: 3,
    title: "College Fund Hero",
    goal: 5000,
    timeLimit: 20,
    difficulty: 'hard',
    description: "Build a substantial college fund in 20 weeks",
    weeklyTarget: 250,
    rewards: ["Education Investment Pro", "Future Planner Elite", "Big Dreams Achievement"]
  }
];

interface WeeklyEvent {
  week: number;
  event: string;
  impact: number;
  type: 'bonus' | 'expense' | 'choice';
  choices?: { option: string; impact: number }[];
}

const weeklyEvents: WeeklyEvent[] = [
  { week: 2, event: "Found $20 in old jacket!", impact: 20, type: 'bonus' },
  { week: 3, event: "Friend's birthday party", impact: -25, type: 'expense' },
  { week: 4, event: "Extra babysitting job", impact: 40, type: 'bonus' },
  { week: 5, event: "Car needs gas", impact: -30, type: 'expense' },
  { week: 7, event: "Sell old video games", impact: 35, type: 'bonus' },
  { week: 8, event: "Concert ticket opportunity", impact: -50, type: 'choice', 
    choices: [
      { option: "Buy ticket and have fun", impact: -50 },
      { option: "Skip concert, stay focused", impact: 0 }
    ]
  },
  { week: 10, event: "Tax refund arrives", impact: 75, type: 'bonus' },
  { week: 12, event: "Phone bill higher than expected", impact: -35, type: 'expense' },
  { week: 14, event: "Freelance work opportunity", impact: 60, type: 'choice',
    choices: [
      { option: "Take the job", impact: 60 },
      { option: "Too busy, skip it", impact: 0 }
    ]
  },
  { week: 16, event: "Black Friday shopping temptation", impact: -100, type: 'choice',
    choices: [
      { option: "Go shopping", impact: -100 },
      { option: "Stay strong, save money", impact: 0 }
    ]
  }
];

export default function SavingsChallengeGame() {
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [totalSaved, setTotalSaved] = useState(0);
  const [weeklyProgress, setWeeklyProgress] = useState<number[]>([]);
  const [gameActive, setGameActive] = useState(false);
  const [currentEvent, setCurrentEvent] = useState<WeeklyEvent | null>(null);
  const [gameComplete, setGameComplete] = useState(false);
  const [weeklyAmount, setWeeklyAmount] = useState("");

  const startChallenge = (challenge: Challenge) => {
    setSelectedChallenge(challenge);
    setCurrentWeek(1);
    setTotalSaved(0);
    setWeeklyProgress([]);
    setGameActive(true);
    setCurrentEvent(null);
    setGameComplete(false);
    setWeeklyAmount("");
  };

  const processWeek = () => {
    if (!selectedChallenge || !weeklyAmount) return;
    
    const amount = parseFloat(weeklyAmount);
    const newTotal = totalSaved + amount;
    setTotalSaved(newTotal);
    setWeeklyProgress([...weeklyProgress, amount]);
    
    // Check for events
    const event = weeklyEvents.find(e => e.week === currentWeek);
    if (event) {
      setCurrentEvent(event);
    } else {
      nextWeek();
    }
    
    setWeeklyAmount("");
  };

  const handleEvent = (impact: number) => {
    setTotalSaved(Math.max(0, totalSaved + impact));
    setCurrentEvent(null);
    nextWeek();
  };

  const nextWeek = () => {
    if (currentWeek >= selectedChallenge!.timeLimit) {
      setGameComplete(true);
      setGameActive(false);
    } else {
      setCurrentWeek(currentWeek + 1);
    }
  };

  const resetGame = () => {
    setSelectedChallenge(null);
    setCurrentWeek(1);
    setTotalSaved(0);
    setWeeklyProgress([]);
    setGameActive(false);
    setCurrentEvent(null);
    setGameComplete(false);
    setWeeklyAmount("");
  };

  const getProgressPercentage = () => {
    if (!selectedChallenge) return 0;
    return Math.min((totalSaved / selectedChallenge.goal) * 100, 100);
  };

  const getSuccessLevel = () => {
    if (!selectedChallenge) return '';
    const percentage = getProgressPercentage();
    
    if (percentage >= 100) return { level: "GOAL ACHIEVED! 🏆", color: "text-yellow-400" };
    if (percentage >= 80) return { level: "Almost There! 🔥", color: "text-green-400" };
    if (percentage >= 60) return { level: "Great Progress! 💪", color: "text-blue-400" };
    if (percentage >= 40) return { level: "Keep Going! 📈", color: "text-purple-400" };
    return { level: "Need to Push Harder! ⚡", color: "text-red-400" };
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-400 border-green-400';
      case 'medium': return 'text-yellow-400 border-yellow-400';
      case 'hard': return 'text-red-400 border-red-400';
      default: return 'text-white border-white';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900 text-white">
      <div className="bg-black/50 shadow-sm border-b border-green-600 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2 text-white border-green-400 hover:bg-green-800">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-green-100">🎯 Savings Challenge Game</h1>
          {selectedChallenge && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-400" />
                <span className="text-blue-400">Week {currentWeek}</span>
              </div>
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-400" />
                <span className="text-green-400 font-bold">${totalSaved}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {!selectedChallenge && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">💰</div>
            <h2 className="text-4xl font-bold text-green-100 mb-4">Choose Your Savings Challenge</h2>
            <p className="text-xl text-green-200 mb-8 max-w-3xl mx-auto">
              Test your saving skills with real-world challenges! Face unexpected expenses, bonus income, 
              and tough choices while working toward your goal.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {challenges.map((challenge) => (
                <div 
                  key={challenge.id}
                  className={`bg-green-800/50 rounded-xl p-6 border-2 ${getDifficultyColor(challenge.difficulty)} hover:scale-105 cursor-pointer transition-all`}
                  onClick={() => startChallenge(challenge)}
                >
                  <div className="text-center mb-6">
                    <div className="text-4xl mb-3">
                      {challenge.difficulty === 'easy' ? '🌱' : challenge.difficulty === 'medium' ? '🌳' : '🏔️'}
                    </div>
                    <h3 className="text-xl font-bold text-green-100 mb-2">{challenge.title}</h3>
                    <div className={`text-sm font-bold uppercase ${getDifficultyColor(challenge.difficulty).split(' ')[0]}`}>
                      {challenge.difficulty}
                    </div>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between">
                      <span className="text-green-200">Goal:</span>
                      <span className="font-bold text-yellow-400">${challenge.goal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-200">Time:</span>
                      <span className="font-bold text-blue-400">{challenge.timeLimit} weeks</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-200">Weekly:</span>
                      <span className="font-bold text-green-400">${challenge.weeklyTarget}</span>
                    </div>
                  </div>
                  
                  <p className="text-green-300 text-sm mb-4">{challenge.description}</p>
                  
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    Start Challenge
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {gameActive && !currentEvent && !gameComplete && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-green-800/50 rounded-xl p-8 mb-8">
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold text-green-100 mb-2">{selectedChallenge?.title}</h2>
                <div className="text-lg text-green-200">Week {currentWeek} of {selectedChallenge?.timeLimit}</div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-black/30 rounded-lg p-6 text-center">
                  <div className="text-2xl font-bold text-green-400 mb-2">${totalSaved}</div>
                  <div className="text-green-200">Total Saved</div>
                </div>
                <div className="bg-black/30 rounded-lg p-6 text-center">
                  <div className="text-2xl font-bold text-yellow-400 mb-2">${selectedChallenge?.goal}</div>
                  <div className="text-green-200">Goal</div>
                </div>
                <div className="bg-black/30 rounded-lg p-6 text-center">
                  <div className="text-2xl font-bold text-blue-400 mb-2">{getProgressPercentage().toFixed(0)}%</div>
                  <div className="text-green-200">Progress</div>
                </div>
              </div>

              <div className="mb-8">
                <div className="flex justify-between mb-2">
                  <span className="text-green-200">Progress to Goal</span>
                  <span className={getSuccessLevel().color}>{getSuccessLevel().level}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-4">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-yellow-400 h-4 rounded-full transition-all duration-500"
                    style={{ width: `${getProgressPercentage()}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="bg-black/30 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-green-100 mb-6 text-center">
                How much can you save this week?
              </h3>
              
              <div className="max-w-md mx-auto">
                <div className="mb-4">
                  <label className="block text-green-200 mb-2">Amount to Save ($)</label>
                  <input
                    type="number"
                    value={weeklyAmount}
                    onChange={(e) => setWeeklyAmount(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-800 border border-green-600 rounded-lg text-white focus:border-green-400 focus:outline-none"
                    placeholder="Enter amount..."
                    min="0"
                    step="0.01"
                  />
                </div>
                
                <div className="text-center mb-4">
                  <div className="text-sm text-green-300">
                    Suggested: ${selectedChallenge?.weeklyTarget} (to stay on track)
                  </div>
                </div>
                
                <Button 
                  onClick={processWeek}
                  disabled={!weeklyAmount || parseFloat(weeklyAmount) < 0}
                  className="w-full bg-green-600 hover:bg-green-700 py-3"
                >
                  Save This Week
                </Button>
              </div>
            </div>
          </div>
        )}

        {currentEvent && (
          <div className="max-w-2xl mx-auto text-center py-12">
            <div className="bg-yellow-800/50 rounded-xl p-8 border-2 border-yellow-400">
              <div className="text-6xl mb-4">
                {currentEvent.type === 'bonus' ? '💰' : currentEvent.type === 'expense' ? '💸' : '🤔'}
              </div>
              <h3 className="text-2xl font-bold text-yellow-100 mb-4">Week {currentEvent.week} Event</h3>
              <p className="text-xl text-yellow-200 mb-6">{currentEvent.event}</p>
              
              {currentEvent.type === 'choice' && currentEvent.choices ? (
                <div className="space-y-4">
                  {currentEvent.choices.map((choice, index) => (
                    <button
                      key={index}
                      onClick={() => handleEvent(choice.impact)}
                      className="w-full p-4 bg-black/30 rounded-lg border-2 border-yellow-600 hover:border-yellow-400 transition-all"
                    >
                      <div className="font-semibold">{choice.option}</div>
                      <div className={`text-sm ${choice.impact >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {choice.impact >= 0 ? '+' : ''}${choice.impact}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className={`text-3xl font-bold ${currentEvent.impact >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {currentEvent.impact >= 0 ? '+' : ''}${currentEvent.impact}
                  </div>
                  <Button 
                    onClick={() => handleEvent(currentEvent.impact)}
                    className="bg-yellow-600 hover:bg-yellow-700"
                  >
                    Continue
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {gameComplete && (
          <div className="text-center py-8">
            <div className="text-6xl mb-6">
              {getProgressPercentage() >= 100 ? '🏆' : '💪'}
            </div>
            <h2 className="text-3xl font-bold text-green-100 mb-4">Challenge Complete!</h2>
            
            <div className="bg-green-800/50 rounded-xl p-8 max-w-md mx-auto mb-8">
              <div className="text-4xl font-bold text-yellow-400 mb-2">${totalSaved}</div>
              <div className="text-green-200 mb-4">Total Saved</div>
              
              <div className={`text-2xl font-bold mb-4 ${getSuccessLevel().color}`}>
                {getSuccessLevel().level}
              </div>
              
              {getProgressPercentage() >= 100 && (
                <div className="bg-yellow-400/20 rounded-lg p-4 mb-4">
                  <h4 className="font-bold text-yellow-300 mb-2">Rewards Unlocked:</h4>
                  <div className="space-y-1">
                    {selectedChallenge?.rewards.map((reward, index) => (
                      <div key={index} className="text-yellow-200">🏅 {reward}</div>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="text-green-200">
                Goal: ${selectedChallenge?.goal} ({getProgressPercentage().toFixed(0)}% achieved)
              </div>
            </div>

            <Button 
              onClick={resetGame}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-3"
            >
              Try Another Challenge
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}