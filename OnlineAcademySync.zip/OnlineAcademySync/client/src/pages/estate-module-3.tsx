import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Scroll, CheckCircle, Shield, Users, FileText, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule3() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-purple-700 flex items-center space-x-3">
              <Shield className="w-8 h-8" />
              <span>Module 3: Essential Estate Planning Tools</span>
            </CardTitle>
            <p className="text-gray-600">Master the key documents and instruments needed for complete estate planning</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-purple-50 p-6 rounded border-l-4 border-purple-500">
              <h3 className="text-lg font-bold text-purple-700 mb-4">🎯 Learning Objectives</h3>
              <ul className="space-y-2 text-purple-700">
                <li>• Understand why wills have extensive formality requirements</li>
                <li>• Learn the essential elements that make a will legally valid</li>
                <li>• Discover how these requirements protect everyone involved</li>
                <li>• See real examples of what happens when requirements aren't met</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">Why Wills Are Special Legal Documents</h3>
              
              <p className="text-gray-700 leading-relaxed">
                <strong>A will is one of the most formal legal documents that exists in the modern legal system.</strong> Because the person who created the will (the testator) cannot speak for themselves after death, the law requires extensive formality to ensure the document truly represents their wishes and wasn't the result of fraud, coercion, or mistake.
              </p>

              <div className="bg-blue-50 p-4 rounded border border-blue-300">
                <h4 className="font-bold text-blue-700 mb-2">🛡️ Protection Through Formality</h4>
                <p className="text-blue-700 text-sm">
                  The strict requirements for wills aren't designed to make things difficult - they exist to protect you, your family, and your wishes. These formalities ensure that only legitimate wills are honored and prevent fraud or manipulation.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">Essential Elements of a Valid Will</h3>
              
              <div className="grid gap-4">
                <Card className="border-l-4 border-green-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-green-100 p-2 rounded">
                        <span className="text-xl">1️⃣</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-bold text-green-700 mb-2">Testamentary Capacity</h4>
                        <p className="text-gray-700 mb-3">
                          The person making the will must be of sound mind and understand what they're doing.
                        </p>
                        <div className="bg-green-50 p-3 rounded">
                          <h5 className="font-semibold text-green-700 mb-2">This means they understand:</h5>
                          <ul className="text-sm text-green-700 space-y-1">
                            <li>• What a will is and what it does</li>
                            <li>• The nature and extent of their property</li>
                            <li>• Who their family members and beneficiaries are</li>
                            <li>• How their decisions will affect their loved ones</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-blue-100 p-2 rounded">
                        <span className="text-xl">2️⃣</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-bold text-blue-700 mb-2">Testamentary Intent</h4>
                        <p className="text-gray-700 mb-3">
                          The person must actually intend for this document to be their will.
                        </p>
                        <div className="bg-blue-50 p-3 rounded">
                          <h5 className="font-semibold text-blue-700 mb-2">Clear Intent Includes:</h5>
                          <ul className="text-sm text-blue-700 space-y-1">
                            <li>• Understanding this document will control asset distribution</li>
                            <li>• Intending for it to take effect after death</li>
                            <li>• Not creating it as a joke, example, or practice document</li>
                            <li>• Making the decision voluntarily without pressure</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-orange-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-orange-100 p-2 rounded">
                        <span className="text-xl">3️⃣</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-bold text-orange-700 mb-2">Proper Execution (Signing & Witnessing)</h4>
                        <p className="text-gray-700 mb-3">
                          The will must be signed and witnessed according to state law requirements.
                        </p>
                        <div className="bg-orange-50 p-3 rounded">
                          <h5 className="font-semibold text-orange-700 mb-2">Typical Requirements:</h5>
                          <ul className="text-sm text-orange-700 space-y-1">
                            <li>• Testator must sign the will personally</li>
                            <li>• Two independent witnesses must observe the signing</li>
                            <li>• Witnesses must sign in the presence of the testator</li>
                            <li>• Some states require notarization or additional formalities</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-red-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-red-100 p-2 rounded">
                        <span className="text-xl">4️⃣</span>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-lg font-bold text-red-700 mb-2">Written Form</h4>
                        <p className="text-gray-700 mb-3">
                          In most states, wills must be in writing (oral wills are rarely valid).
                        </p>
                        <div className="bg-red-50 p-3 rounded">
                          <h5 className="font-semibold text-red-700 mb-2">Writing Requirements:</h5>
                          <ul className="text-sm text-red-700 space-y-1">
                            <li>• Can be typed or handwritten</li>
                            <li>• Must be on permanent material (paper, not easily erasable)</li>
                            <li>• Should be clear and legible</li>
                            <li>• Include the date of execution</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">Why These Requirements Matter</h3>
              
              <div className="space-y-4">
                <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                  <h4 className="font-bold text-yellow-700 mb-3">🔒 Real Protection Examples</h4>
                  <div className="space-y-3">
                    <div className="bg-white p-3 rounded">
                      <h5 className="font-semibold text-yellow-700">Capacity Requirements Prevent:</h5>
                      <p className="text-sm text-yellow-700">
                        Someone with dementia or under the influence of medications from making decisions they don't understand, protecting both them and their families.
                      </p>
                    </div>
                    
                    <div className="bg-white p-3 rounded">
                      <h5 className="font-semibold text-yellow-700">Witness Requirements Prevent:</h5>
                      <p className="text-sm text-yellow-700">
                        Family members from forging signatures or claiming fake documents are valid wills, as independent witnesses can testify about what really happened.
                      </p>
                    </div>
                    
                    <div className="bg-white p-3 rounded">
                      <h5 className="font-semibold text-yellow-700">Intent Requirements Prevent:</h5>
                      <p className="text-sm text-yellow-700">
                        Coercion or pressure from being used to force someone to change their will against their true wishes.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">What Happens When Requirements Aren't Met</h3>
              
              <div className="space-y-4">
                <div className="bg-red-50 p-4 rounded border border-red-300">
                  <h4 className="font-bold text-red-700 mb-3 flex items-center space-x-2">
                    <AlertTriangle className="w-5 h-5" />
                    <span>Case Study: The Invalid Will</span>
                  </h4>
                  <div className="space-y-3 text-sm text-red-700">
                    <div>
                      <strong>Situation:</strong> Mr. Johnson wrote a will on his computer but never printed or signed it. His family found it after his death and assumed it was valid.
                    </div>
                    <div>
                      <strong>Problem:</strong> The will was never properly executed - no signature, no witnesses, just a computer file.
                    </div>
                    <div>
                      <strong>Result:</strong> The court declared the will invalid. Mr. Johnson's assets were distributed according to state intestacy laws instead of his written wishes, causing family conflicts and unintended consequences.
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 p-4 rounded border border-green-300">
                  <h4 className="font-bold text-green-700 mb-3 flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5" />
                    <span>Case Study: The Properly Executed Will</span>
                  </h4>
                  <div className="space-y-3 text-sm text-green-700">
                    <div>
                      <strong>Situation:</strong> Mrs. Davis worked with an attorney to create her will, signed it in front of two independent witnesses, and stored it safely.
                    </div>
                    <div>
                      <strong>Execution:</strong> All formality requirements were met - proper capacity, clear intent, written form, and witnessed execution.
                    </div>
                    <div>
                      <strong>Result:</strong> When Mrs. Davis passed away, her will was quickly validated by the court. Her wishes were honored exactly as written, and her family received their inheritances without delay or conflict.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">Key Takeaways About Will Formalities</h3>
              
              <div className="bg-indigo-50 p-6 rounded border border-indigo-300">
                <h4 className="font-bold text-indigo-700 mb-4">💡 Important Reminders:</h4>
                <div className="space-y-3 text-sm text-indigo-700">
                  <div className="flex items-start space-x-2">
                    <Shield className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Formalities Protect Everyone:</strong> These requirements ensure only legitimate wills are honored</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Users className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Professional Help Matters:</strong> Attorneys ensure all requirements are properly met</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <FileText className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>State Laws Vary:</strong> Requirements can differ between states, so location matters</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>No Shortcuts:</strong> All requirements must be met - there are no "close enough" exceptions</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-purple-600">Test Your Understanding</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">1. Why do wills have such strict formality requirements?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Because the testator cannot speak for themselves after death, so extensive formalities ensure the document truly represents their wishes and prevents fraud or coercion.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">2. What are the four essential elements of a valid will?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Testamentary capacity, testamentary intent, proper execution (signing and witnessing), and written form.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">3. What happens if a will doesn't meet all the requirements?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> The court may declare it invalid, and assets will be distributed according to state intestacy laws instead of the person's written wishes.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Module 3 Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                Excellent! You now understand why wills have extensive formality requirements and how these requirements protect everyone involved. You've learned the four essential elements that make a will legally valid and seen what happens when these requirements aren't met.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-module-4">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Next: Essential Estate Planning Tools →
                  </Button>
                </Link>
                <Link href="/estate-planning-course">
                  <Button variant="outline" className="border-teal-500 text-teal-600">
                    Back to Course Overview
                  </Button>
                </Link>
              </div>
            </div>

            {/* Quiz Section */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Test Your Knowledge!</h3>
                  <p className="mb-4">Ready to test your understanding of essential estate planning tools?</p>
                  <Link href="/estate-quiz-3">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 3 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-module-2">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Previous: Planning vs Administration
                  </Button>
                </Link>
                <Link href="/estate-module-4">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Next Module: Understanding Wills →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}