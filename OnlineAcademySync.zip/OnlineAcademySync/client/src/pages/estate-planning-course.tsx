import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Shield, Users, FileText, Scale, Building, Heart, BookOpen, CheckCircle, History, Clock, Scroll, Brain, Calculator, Gavel } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import WillsSection from "@/pages/wills-section";

export default function EstatePlanningCourse() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("modules");


  const modules = [
    {
      id: "what-is-estate-planning",
      title: "What is Estate Planning?",
      description: "Discover estate planning as wealth-building discipline, not just death planning. Learn why it's about enhancing your life and building generational wealth.",
      icon: Heart,
      color: "from-blue-500 to-indigo-600",
      status: "complete"
    },
    {
      id: "important-documents", 
      title: "Estate Planning vs Estate Administration",
      description: "Understand the crucial difference between planning (building wealth during life) and administration (distributing assets after death).",
      icon: FileText,
      color: "from-green-500 to-teal-600",
      status: "complete"
    },
    {
      id: "protecting-family",
      title: "Essential Estate Planning Tools",
      description: "Discover the key documents and instruments needed to ensure your assets are distributed according to your wishes and your family's needs are met.",
      icon: Shield,
      color: "from-purple-500 to-pink-600",
      status: "complete"
    },
    {
      id: "understanding-wills",
      title: "Understanding Wills",
      description: "Learn why wills are the most formal legal documents in our system and why extensive formality requirements protect everyone involved.",
      icon: Scroll,
      color: "from-orange-500 to-red-600",
      status: "complete"
    },
    {
      id: "when-someone-dies",
      title: "When Someone Dies",
      description: "Essential guidance for families navigating estate administration with compassion and practical steps",
      icon: Users,
      color: "from-teal-500 to-cyan-600",
      status: "complete"
    },
    {
      id: "getting-started",
      title: "Getting Started",
      description: "Your complete 8-step action plan to begin creating your own estate plan today",
      icon: CheckCircle,
      color: "from-yellow-500 to-orange-600",
      status: "complete"
    }
  ];

  const menuTabs = [
    { id: "modules", label: "📚 Lessons", icon: BookOpen },
    { id: "documents", label: "📄 Documents", icon: FileText },
    { id: "glossary", label: "📖 Terms", icon: FileText },
    { id: "quiz", label: "🧠 Quiz", icon: Brain },
  ];

  const showMainMenu = () => {
    setActiveSection(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="pt-16 pb-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-6">
            <Link href="/" className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mr-4">
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Academy</span>
            </Link>
          </div>

          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-blue-600 mb-4">Estate Planning for Starters</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">Learn the basics of planning your estate and protecting your family's future</p>
            
            {/* Course Image */}
            <div className="flex justify-center my-8">
              <img 
                src="/attached_assets/estate planning.png" 
                alt="Estate Planning Documents and Concepts" 
                className="max-w-2xl w-full h-auto rounded-lg shadow-lg border border-gray-200"
              />
            </div>
            
            <div className="flex justify-center space-x-4 mt-4">
              <Badge variant="secondary" className="bg-blue-100 text-blue-800">Beginner Course</Badge>
              <Badge variant="secondary" className="bg-green-100 text-green-800">Easy to Follow</Badge>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800">Family Focused</Badge>
            </div>
          </div>

          {/* Navigation Menu */}
          <div className="bg-white rounded-lg shadow-lg border border-gray-200 mb-8">
            <div className="flex flex-wrap justify-center border-b border-gray-200">
              {menuTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-6 py-4 font-medium transition-colors ${
                    activeTab === tab.id
                      ? "text-blue-600 border-b-2 border-blue-600 bg-blue-50"
                      : "text-gray-600 hover:text-blue-600 hover:bg-gray-50"
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {activeTab === "modules" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Learning Modules</h2>
            
            <div className="mb-8 bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">💝 Planning for Your Family's Future</h3>
              <p className="mb-3">Learn the basics of estate planning in simple, easy-to-understand lessons designed for beginners.</p>
              <div className="text-sm opacity-90">
                <p>• Understand what estate planning really means</p>
                <p>• Learn about important documents every family needs</p>
                <p>• Discover simple ways to protect your loved ones</p>
                <p>• Get started with your own basic plan</p>
              </div>
            </div>

            <div className="grid gap-6">
              {modules.map((module, index) => (
                <Card key={module.id} className={`hover:shadow-lg transition-shadow border-l-4 border-blue-400 ${module.status === 'coming-soon' ? 'opacity-60' : ''}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 bg-gradient-to-r ${module.color} rounded-lg flex items-center justify-center`}>
                          <module.icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-gray-800 mb-2">{module.title}</h3>
                          <p className="text-gray-600 mb-3">{module.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <Badge variant="outline" className="text-blue-600 border-blue-200">
                              Module {index + 1}
                            </Badge>
                            {module.status === 'complete' && (
                              <div className="flex items-center space-x-1 text-green-600">
                                <CheckCircle className="w-4 h-4" />
                                <span className="text-xs font-medium">Content Complete</span>
                              </div>
                            )}
                            {module.status === 'coming-soon' && (
                              <div className="flex items-center space-x-1 text-orange-600">
                                <Clock className="w-4 h-4" />
                                <span className="text-xs font-medium">Coming Soon</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      {module.status === 'complete' ? (
                        <Link href={`/estate-module-${index + 1}`}>
                          <Button className="bg-blue-600 hover:bg-blue-700">
                            Start Module
                          </Button>
                        </Link>
                      ) : (
                        <Button 
                          className="bg-gray-400 cursor-not-allowed"
                          disabled={true}
                        >
                          Coming Soon
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === "planning" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Estate Planning Tools</h2>
            
            <div className="mb-8 bg-gradient-to-r from-green-500 to-teal-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📋 Interactive Planning Resources</h3>
              <p className="mb-3">Use our comprehensive tools to create your personalized estate plan and understand your needs.</p>
              <div className="text-sm opacity-90">
                <p>• Estate planning checklist and worksheets</p>
                <p>• Asset inventory and valuation tools</p>
                <p>• Tax estimation calculators</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-green-700">
                    <Calculator className="w-6 h-6" />
                    <span>Estate Tax Calculator</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Calculate potential estate tax liability and plan tax-efficient strategies.</p>
                  <Button className="bg-green-600 hover:bg-green-700">Launch Calculator</Button>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-blue-700">
                    <FileText className="w-6 h-6" />
                    <span>Asset Inventory Worksheet</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Organize and value all your assets for comprehensive estate planning.</p>
                  <Button className="bg-blue-600 hover:bg-blue-700">Start Inventory</Button>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-purple-700">
                    <Users className="w-6 h-6" />
                    <span>Beneficiary Planner</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Plan distributions and designate beneficiaries for all your accounts and assets.</p>
                  <Button className="bg-purple-600 hover:bg-purple-700">Plan Beneficiaries</Button>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-orange-500">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-orange-700">
                    <Shield className="w-6 h-6" />
                    <span>Protection Strategy Advisor</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Get recommendations for protecting your assets from various risks.</p>
                  <Button className="bg-orange-600 hover:bg-orange-700">Get Advice</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {activeTab === "documents" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Important Documents You Need</h2>
            
            <div className="mb-8 bg-gradient-to-r from-purple-500 to-pink-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📄 Your Document Guide</h3>
              <p className="mb-3">Learn about the important documents that help protect your family and your wishes.</p>
              <div className="text-sm opacity-90">
                <p>• Easy explanations of each document</p>
                <p>• Examples to help you understand</p>
                <p>• Simple language, no legal jargon</p>
              </div>
            </div>

            <div className="space-y-6">
              <Card className="border-l-4 border-blue-500">
                <CardHeader>
                  <CardTitle className="text-blue-700">Last Will and Testament</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">The foundation document that directs how your assets will be distributed after death and names guardians for minor children.</p>
                  <div className="bg-blue-50 p-4 rounded mb-4">
                    <h4 className="font-bold text-blue-700 mb-2">Key Components:</h4>
                    <ul className="text-sm text-blue-600 space-y-1">
                      <li>• Executor appointment and powers</li>
                      <li>• Asset distribution instructions</li>
                      <li>• Guardian nominations for minors</li>
                      <li>• Specific bequests and gifts</li>
                      <li>• Residuary clause for remaining assets</li>
                    </ul>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="border-blue-500 text-blue-600">Learn More</Button>
                    <Button 
                      onClick={() => window.location.href = "/sample-will"}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      View Sample
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="text-green-700">Revocable Living Trust</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">A flexible trust that allows you to maintain control during life while avoiding probate and providing incapacity planning.</p>
                  <div className="bg-green-50 p-4 rounded mb-4">
                    <h4 className="font-bold text-green-700 mb-2">Benefits:</h4>
                    <ul className="text-sm text-green-600 space-y-1">
                      <li>• Avoids probate process</li>
                      <li>• Provides incapacity planning</li>
                      <li>• Maintains privacy</li>
                      <li>• Allows continued control during life</li>
                      <li>• Facilitates asset management</li>
                    </ul>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="border-green-500 text-green-600">Learn More</Button>
                    <Button 
                      onClick={() => window.location.href = "/sample-trust"}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      View Sample
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-purple-700">Financial Power of Attorney</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Authorizes someone to manage your financial affairs if you become incapacitated or unable to handle them yourself.</p>
                  <div className="bg-purple-50 p-4 rounded mb-4">
                    <h4 className="font-bold text-purple-700 mb-2">Types of Powers:</h4>
                    <ul className="text-sm text-purple-600 space-y-1">
                      <li>• Banking and investment management</li>
                      <li>• Real estate transactions</li>
                      <li>• Tax matters and filing</li>
                      <li>• Insurance decisions</li>
                      <li>• Legal and business affairs</li>
                    </ul>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="border-purple-500 text-purple-600">Learn More</Button>
                    <Button 
                      onClick={() => window.location.href = "/sample-power-of-attorney"}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      View Sample
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-orange-500">
                <CardHeader>
                  <CardTitle className="text-orange-700">Advance Healthcare Directive</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Combines a living will with healthcare power of attorney to direct your medical care if you cannot speak for yourself.</p>
                  <div className="bg-orange-50 p-4 rounded mb-4">
                    <h4 className="font-bold text-orange-700 mb-2">Includes:</h4>
                    <ul className="text-sm text-orange-600 space-y-1">
                      <li>• End-of-life care preferences</li>
                      <li>• Healthcare agent appointment</li>
                      <li>• Medical treatment instructions</li>
                      <li>• Organ donation decisions</li>
                      <li>• HIPAA authorization</li>
                    </ul>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="border-orange-500 text-orange-600">Learn More</Button>
                    <Button 
                      onClick={() => window.location.href = "/sample-healthcare-directive"}
                      className="bg-orange-600 hover:bg-orange-700"
                    >
                      View Sample
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Sample Document Library */}
              <div className="mt-8 bg-gradient-to-r from-gray-100 to-gray-200 p-6 rounded-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-4 text-center">📋 Document Examples & Templates</h3>
                <p className="text-gray-600 text-center mb-6">Click "View Sample" above to see examples of estate planning documents with clear language and formatting.</p>
                
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="bg-white p-4 rounded shadow">
                    <h4 className="font-bold text-blue-700 mb-2">✅ What Our Examples Show:</h4>
                    <ul className="text-gray-600 space-y-1">
                      <li>• Clear legal language and terms</li>
                      <li>• Standard document structure</li>
                      <li>• Required witness sections</li>
                      <li>• Real-world examples</li>
                      <li>• Easy-to-understand formatting</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-4 rounded shadow">
                    <h4 className="font-bold text-orange-700 mb-2">⚠️ Important Note:</h4>
                    <ul className="text-gray-600 space-y-1">
                      <li>• Examples are for learning purposes only</li>
                      <li>• Always work with qualified attorneys</li>
                      <li>• State laws are different everywhere</li>
                      <li>• Every family situation is unique</li>
                      <li>• Legal guidance is always recommended</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "drafting" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Professional Will Drafting Examples</h2>
            
            <div className="mb-8 bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">✍️ Authentic Will Drafting Templates</h3>
              <p className="mb-3">Study professionally drafted wills that demonstrate proper legal language, structure, and formatting for various family situations.</p>
              <div className="text-sm opacity-90">
                <p>• Real-world will examples with proper legal terminology</p>
                <p>• Various family structures and asset distributions</p>
                <p>• Professional execution requirements and witness clauses</p>
                <p>• State-compliant language and formatting standards</p>
              </div>
            </div>

            <div className="bg-red-50 border-l-4 border-red-500 p-6 mb-8 rounded">
              <h4 className="font-bold text-red-700 mb-3">⚠️ Critical Professional Disclaimer</h4>
              <p className="text-red-700 mb-2">These examples are provided for educational purposes only to demonstrate professional will drafting standards. Each will must be custom-drafted by qualified legal professionals based on individual circumstances.</p>
              <ul className="text-sm text-red-600 space-y-1">
                <li>• Never use these as templates for actual will drafting</li>
                <li>• State laws vary significantly in requirements</li>
                <li>• Individual family situations require custom solutions</li>
                <li>• Professional legal advice is essential for all estate planning</li>
              </ul>
            </div>

            <div className="space-y-8">
              <Card className="border-l-4 border-blue-500">
                <CardHeader>
                  <CardTitle className="text-blue-700">📋 Example 1: Simple Will with Minor Children</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-blue-50 p-6 rounded border text-sm font-mono">
                    <div className="text-center mb-4">
                      <h4 className="font-bold text-lg">LAST WILL AND TESTAMENT</h4>
                      <p className="font-bold">OF SARAH ELIZABETH MARTINEZ</p>
                    </div>
                    
                    <div className="space-y-4 text-xs">
                      <p><strong>I, SARAH ELIZABETH MARTINEZ,</strong> a resident of Denver, Colorado, being of sound mind and legal age, do hereby make, publish, and declare this to be my Last Will and Testament, hereby revoking all prior wills and codicils made by me.</p>
                      
                      <div>
                        <p className="font-bold">ARTICLE I - FAMILY INFORMATION</p>
                        <p>I am married to CARLOS MARTINEZ. I have three children whose names and dates of birth are:</p>
                        <ul className="ml-4 mt-2">
                          <li>SOFIA MARTINEZ, born June 12, 2018</li>
                          <li>DIEGO MARTINEZ, born March 8, 2020</li>
                          <li>LUCIA MARTINEZ, born November 3, 2022</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE II - APPOINTMENT OF PERSONAL REPRESENTATIVE</p>
                        <p>I hereby nominate and appoint my husband, CARLOS MARTINEZ, as the Personal Representative of this Will. If he is unable or unwilling to serve, I nominate my sister, MARIA GONZALEZ, as alternate Personal Representative. I direct that no bond be required of any Personal Representative.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE III - GUARDIAN FOR MINOR CHILDREN</p>
                        <p>If I die leaving minor children, I nominate my sister MARIA GONZALEZ and her husband RICARDO GONZALEZ as guardians of the person and property of my minor children. If they cannot serve, I nominate my brother ALEJANDRO MARTINEZ as alternate guardian.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE IV - SPECIFIC BEQUESTS</p>
                        <p>I give and bequeath the following specific items:</p>
                        <ul className="ml-4 mt-2">
                          <li>My grandmother's wedding ring to my daughter SOFIA MARTINEZ when she reaches age 18</li>
                          <li>My piano to my son DIEGO MARTINEZ</li>
                          <li>The sum of Five Thousand Dollars ($5,000) to Children's Hospital Colorado Foundation</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE V - RESIDUARY ESTATE</p>
                        <p>I give, devise, and bequeath all the rest, residue, and remainder of my estate to my husband CARLOS MARTINEZ, if he survives me by thirty (30) days. If he does not so survive me, then to my children SOFIA MARTINEZ, DIEGO MARTINEZ, and LUCIA MARTINEZ in equal shares, with each child's share to be held in trust until that child reaches age 25.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VI - TRUST PROVISIONS FOR MINOR CHILDREN</p>
                        <p>If any of my children are under age 25 at the time of distribution, their shares shall be held in separate trusts. The trustee may distribute income and principal for the child's health, education, maintenance, and support until the child reaches age 25, at which time the remaining trust assets shall be distributed outright.</p>
                      </div>

                      <div className="pt-4 border-t">
                        <p>IN WITNESS WHEREOF, I have hereunto set my hand this 20th day of November, 2024.</p>
                        <div className="mt-4">
                          <p>_________________________________</p>
                          <p>SARAH ELIZABETH MARTINEZ, Testator</p>
                        </div>
                        
                        <div className="mt-6">
                          <p className="font-bold">WITNESSES:</p>
                          <p>We, the undersigned, declare that SARAH ELIZABETH MARTINEZ signed this will in our presence, and that we signed as witnesses in her presence and in the presence of each other.</p>
                          <div className="mt-4 space-y-3">
                            <div>
                              <p>_________________________________</p>
                              <p>JENNIFER ADAMS, Witness</p>
                              <p>Address: 789 Cherry Lane, Denver, CO 80203</p>
                            </div>
                            <div>
                              <p>_________________________________</p>
                              <p>MICHAEL CHEN, Witness</p>
                              <p>Address: 456 Maple Street, Denver, CO 80204</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="text-green-700">📋 Example 2: Will with Charitable Bequests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-green-50 p-6 rounded border text-sm font-mono">
                    <div className="text-center mb-4">
                      <h4 className="font-bold text-lg">LAST WILL AND TESTAMENT</h4>
                      <p className="font-bold">OF RICHARD JAMES THOMPSON</p>
                    </div>
                    
                    <div className="space-y-4 text-xs">
                      <p><strong>I, RICHARD JAMES THOMPSON,</strong> a resident of Seattle, Washington, being of sound mind and legal age, do hereby make, publish, and declare this to be my Last Will and Testament, hereby revoking all prior wills and codicils made by me.</p>
                      
                      <div>
                        <p className="font-bold">ARTICLE I - FAMILY INFORMATION</p>
                        <p>I am unmarried. I have two adult children whose names are:</p>
                        <ul className="ml-4 mt-2">
                          <li>EMILY THOMPSON PARKER</li>
                          <li>JAMES RICHARD THOMPSON</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE II - APPOINTMENT OF PERSONAL REPRESENTATIVE</p>
                        <p>I hereby nominate and appoint my daughter, EMILY THOMPSON PARKER, as the Personal Representative of this Will. If she is unable or unwilling to serve, I nominate FIRST NATIONAL BANK OF SEATTLE as alternate Personal Representative. I direct that no bond be required of any Personal Representative.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE III - CHARITABLE BEQUESTS</p>
                        <p>I give and bequeath the following amounts to the following charitable organizations:</p>
                        <ul className="ml-4 mt-2">
                          <li>Twenty-Five Thousand Dollars ($25,000) to the American Cancer Society</li>
                          <li>Twenty-Five Thousand Dollars ($25,000) to the University of Washington School of Medicine</li>
                          <li>Fifteen Thousand Dollars ($15,000) to the Seattle Symphony Orchestra</li>
                          <li>Ten Thousand Dollars ($10,000) to the local animal shelter, Best Friends Pet Sanctuary</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE IV - SPECIFIC BEQUESTS TO FAMILY</p>
                        <p>I give and bequeath the following specific items:</p>
                        <ul className="ml-4 mt-2">
                          <li>My collection of first-edition books to my son JAMES RICHARD THOMPSON</li>
                          <li>My 2022 BMW sedan to my daughter EMILY THOMPSON PARKER</li>
                          <li>My Rolex watch and cufflinks to my grandson MATTHEW PARKER</li>
                          <li>My grandmother's china set to my granddaughter SARAH PARKER</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE V - GENERAL LEGACIES</p>
                        <p>I give and bequeath the following cash amounts:</p>
                        <ul className="ml-4 mt-2">
                          <li>Fifty Thousand Dollars ($50,000) to my longtime friend PATRICIA WILLIAMS</li>
                          <li>Twenty Thousand Dollars ($20,000) to my housekeeper MARIA SANTOS</li>
                          <li>Fifteen Thousand Dollars ($15,000) to each of my grandchildren living at my death</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VI - RESIDUARY ESTATE</p>
                        <p>I give, devise, and bequeath all the rest, residue, and remainder of my estate to my children EMILY THOMPSON PARKER and JAMES RICHARD THOMPSON in equal shares, per stirpes.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VII - POWERS OF PERSONAL REPRESENTATIVE</p>
                        <p>In addition to all powers granted by law, I grant my Personal Representative full power to manage my business interests, including the authority to continue, sell, or liquidate Thompson Manufacturing Company as deemed appropriate for the estate.</p>
                      </div>

                      <div className="pt-4 border-t">
                        <p>IN WITNESS WHEREOF, I have hereunto set my hand this 5th day of December, 2024.</p>
                        <div className="mt-4">
                          <p>_________________________________</p>
                          <p>RICHARD JAMES THOMPSON, Testator</p>
                        </div>
                        
                        <div className="mt-6">
                          <p className="font-bold">WITNESSES:</p>
                          <div className="mt-4 space-y-3">
                            <div>
                              <p>_________________________________</p>
                              <p>KATHLEEN MURPHY, Attorney at Law</p>
                              <p>Address: 1200 Fifth Avenue, Seattle, WA 98101</p>
                            </div>
                            <div>
                              <p>_________________________________</p>
                              <p>DAVID LEE, CPA</p>
                              <p>Address: 800 Pine Street, Seattle, WA 98101</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-purple-700">📋 Example 3: Will with Business Interests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-purple-50 p-6 rounded border text-sm font-mono">
                    <div className="text-center mb-4">
                      <h4 className="font-bold text-lg">LAST WILL AND TESTAMENT</h4>
                      <p className="font-bold">OF ALEXANDRA VICTORIA CHEN</p>
                    </div>
                    
                    <div className="space-y-4 text-xs">
                      <p><strong>I, ALEXANDRA VICTORIA CHEN,</strong> a resident of Austin, Texas, being of sound mind and legal age, do hereby make, publish, and declare this to be my Last Will and Testament, hereby revoking all prior wills and codicils made by me.</p>
                      
                      <div>
                        <p className="font-bold">ARTICLE I - FAMILY INFORMATION</p>
                        <p>I am divorced. I have one child, KEVIN CHEN, born August 15, 1995.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE II - APPOINTMENT OF PERSONAL REPRESENTATIVE</p>
                        <p>I hereby nominate and appoint my son, KEVIN CHEN, as the Personal Representative of this Will. If he is unable or unwilling to serve, I nominate my business partner, SAMUEL RODRIGUEZ, as alternate Personal Representative.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE III - BUSINESS INTERESTS</p>
                        <p>I own a 60% interest in Chen & Associates Marketing LLC. I direct my Personal Representative to:</p>
                        <ul className="ml-4 mt-2">
                          <li>Offer my business interest first to my business partner SAMUEL RODRIGUEZ at fair market value as determined by professional appraisal</li>
                          <li>If he declines to purchase, then offer the interest to my son KEVIN CHEN</li>
                          <li>If both decline, then sell the interest to any third party at fair market value</li>
                          <li>The proceeds from any such sale shall become part of my residuary estate</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE IV - REAL ESTATE PROVISIONS</p>
                        <p>I own real property located at 1847 Oak Hill Drive, Austin, Texas. I give and devise this property to my son KEVIN CHEN, subject to any mortgage or liens thereon, which he shall assume and pay.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE V - SPECIFIC BEQUESTS</p>
                        <p>I give and bequeath the following specific items:</p>
                        <ul className="ml-4 mt-2">
                          <li>My art collection to the Austin Museum of Art</li>
                          <li>My jewelry to my dear friend LINDA WATSON</li>
                          <li>My BMW vehicle to my son KEVIN CHEN</li>
                          <li>The sum of Ten Thousand Dollars ($10,000) to my former colleague MELISSA TORRES</li>
                        </ul>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VI - RETIREMENT ACCOUNTS</p>
                        <p>I have designated beneficiaries for my 401(k) and IRA accounts. These accounts shall pass according to the beneficiary designations on file with the respective institutions and are not governed by this Will.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VII - RESIDUARY ESTATE</p>
                        <p>I give, devise, and bequeath all the rest, residue, and remainder of my estate to my son KEVIN CHEN. If he does not survive me, then to the University of Texas at Austin School of Business for scholarships for first-generation college students.</p>
                      </div>

                      <div>
                        <p className="font-bold">ARTICLE VIII - TAX PROVISIONS</p>
                        <p>All estate, inheritance, and death taxes shall be paid from my residuary estate and shall not be apportioned among the beneficiaries of specific bequests.</p>
                      </div>

                      <div className="pt-4 border-t">
                        <p>IN WITNESS WHEREOF, I have hereunto set my hand this 12th day of January, 2025.</p>
                        <div className="mt-4">
                          <p>_________________________________</p>
                          <p>ALEXANDRA VICTORIA CHEN, Testator</p>
                        </div>
                        
                        <div className="mt-6">
                          <p className="font-bold">WITNESSES:</p>
                          <div className="mt-4 space-y-3">
                            <div>
                              <p>_________________________________</p>
                              <p>ROBERT MARTINEZ, Attorney</p>
                              <p>Address: 500 West 6th Street, Austin, TX 78701</p>
                            </div>
                            <div>
                              <p>_________________________________</p>
                              <p>STEPHANIE WRIGHT, Paralegal</p>
                              <p>Address: 500 West 6th Street, Austin, TX 78701</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-yellow-50 p-6 rounded border-l-4 border-yellow-500">
                <h3 className="text-lg font-bold text-yellow-700 mb-4">🎯 Key Drafting Features Demonstrated</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded">
                    <h4 className="font-bold text-yellow-600 mb-2">Example 1 Features:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Guardian nominations for minors</li>
                      <li>• Trust provisions for young beneficiaries</li>
                      <li>• Family-oriented specific bequests</li>
                      <li>• Charitable giving component</li>
                      <li>• Age-based distribution requirements</li>
                    </ul>
                  </div>
                  <div className="bg-white p-4 rounded">
                    <h4 className="font-bold text-yellow-600 mb-2">Example 2 Features:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Substantial charitable bequests</li>
                      <li>• Corporate alternate executor</li>
                      <li>• Multiple specific bequests</li>
                      <li>• Grandchildren provisions</li>
                      <li>• Per stirpes distribution</li>
                    </ul>
                  </div>
                  <div className="bg-white p-4 rounded">
                    <h4 className="font-bold text-yellow-600 mb-2">Example 3 Features:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Business succession planning</li>
                      <li>• Real estate specific devise</li>
                      <li>• Buy-sell agreement coordination</li>
                      <li>• Retirement account acknowledgment</li>
                      <li>• Tax payment directives</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "administration" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Estate Administration</h2>
            
            <div className="mb-8 bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">⚖️ Managing Estates After Death</h3>
              <p className="mb-3">Understanding the process of settling an estate and fulfilling fiduciary duties.</p>
              <div className="text-sm opacity-90">
                <p>• Step-by-step administration process</p>
                <p>• Executor and trustee responsibilities</p>
                <p>• Timeline and deadlines to meet</p>
              </div>
            </div>

            <div className="space-y-6">
              <Card className="border-l-4 border-indigo-500">
                <CardHeader>
                  <CardTitle className="text-indigo-700">The Probate Process</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-indigo-50 p-4 rounded">
                      <h4 className="font-bold text-indigo-700 mb-3">Typical Probate Timeline:</h4>
                      <div className="space-y-3 text-sm">
                        <div className="flex items-start space-x-3">
                          <div className="bg-indigo-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">1</div>
                          <div>
                            <span className="font-semibold">File Petition (30 days)</span>
                            <p className="text-indigo-600">Submit will and petition to probate court</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="bg-indigo-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">2</div>
                          <div>
                            <span className="font-semibold">Notice to Creditors (4 months)</span>
                            <p className="text-indigo-600">Publish notice and notify known creditors</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="bg-indigo-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">3</div>
                          <div>
                            <span className="font-semibold">Asset Inventory (4-6 months)</span>
                            <p className="text-indigo-600">Identify, value, and secure all estate assets</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="bg-indigo-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">4</div>
                          <div>
                            <span className="font-semibold">Pay Debts and Taxes (9-12 months)</span>
                            <p className="text-indigo-600">Settle all valid claims and file tax returns</p>
                          </div>
                        </div>
                        <div className="flex items-start space-x-3">
                          <div className="bg-indigo-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">5</div>
                          <div>
                            <span className="font-semibold">Distribute Assets (12-18 months)</span>
                            <p className="text-indigo-600">Transfer remaining assets to beneficiaries</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="text-green-700">Executor Responsibilities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-green-50 p-4 rounded">
                      <h4 className="font-bold text-green-700 mb-2">Initial Duties:</h4>
                      <ul className="text-sm text-green-600 space-y-1">
                        <li>• Locate and read the will</li>
                        <li>• File death certificates</li>
                        <li>• Secure estate assets</li>
                        <li>• Open estate bank account</li>
                        <li>• Notify beneficiaries</li>
                      </ul>
                    </div>
                    <div className="bg-green-50 p-4 rounded">
                      <h4 className="font-bold text-green-700 mb-2">Ongoing Duties:</h4>
                      <ul className="text-sm text-green-600 space-y-1">
                        <li>• Manage estate assets</li>
                        <li>• Pay valid debts and taxes</li>
                        <li>• Keep detailed records</li>
                        <li>• Communicate with beneficiaries</li>
                        <li>• Distribute assets per will</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-purple-700">Trust Administration</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">Managing trusts requires ongoing attention to fiduciary duties and beneficiary needs.</p>
                  <div className="bg-purple-50 p-4 rounded">
                    <h4 className="font-bold text-purple-700 mb-2">Key Responsibilities:</h4>
                    <ul className="text-sm text-purple-600 space-y-1">
                      <li>• Follow trust terms exactly</li>
                      <li>• Invest assets prudently</li>
                      <li>• Make required distributions</li>
                      <li>• Keep beneficiaries informed</li>
                      <li>• Maintain detailed records</li>
                      <li>• File annual tax returns</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {activeTab === "glossary" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Important Terms to Know</h2>
            
            <div className="mb-8 bg-gradient-to-r from-teal-500 to-cyan-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📖 Simple Definitions</h3>
              <p className="mb-3">Learn important estate planning words and what they mean in everyday language.</p>
              <div className="text-sm opacity-90">
                <p>• Easy-to-understand explanations</p>
                <p>• No confusing legal jargon</p>
                <p>• Real examples you can relate to</p>
              </div>
            </div>

            <div className="grid gap-4">
              {[
                { term: "Abatement", definition: "Process of selling estate property to pay debts." },
                { term: "Ademption", definition: "Loss of a testamentary gift because the testator no longer owns the property at his or her death." },
                { term: "Advancement", definition: "Inter vivos gift to children in anticipation of their share of the parent's estate." },
                { term: "Anti-lapse statute", definition: "State law providing that gifts to deceased heirs go to those person's heirs." },
                { term: "Attestation", definition: "Clause signed by witnesses to a will." },
                { term: "Beneficiary", definition: "Recipient of personal property under a will." },
                { term: "Bequest", definition: "Testamentary gift of personal property." },
                { term: "Codicil", definition: "Formal document used to amend a will." },
                { term: "Demonstrative legacy", definition: "Testamentary gift of money from a particular source." },
                { term: "Dependent relative revocation", definition: "Court doctrine holding that if a later will is found invalid, an earlier valid will shall be probated." },
                { term: "Devise", definition: "Testamentary gift of real property." },
                { term: "Devisee", definition: "Recipient of testamentary gift of real property." },
                { term: "Durable power of attorney", definition: "Power of attorney that takes effect upon execution and lasts despite the incapacity of the principal." },
                { term: "Execution of a will", definition: "Formal signing and witnessing of a will." },
                { term: "Exordium", definition: "Introductory paragraph of a will." },
                { term: "Fraud", definition: "Misrepresentation to induce a person to sign a will." },
                { term: "General revocatory clause", definition: "Will provision revoking earlier wills and codicils." },
                { term: "Health care proxy", definition: "Document appointing another to make health care decisions for the principal." },
                { term: "Holographic will", definition: "Will written in the testator's own hand." },
                { term: "In terrorem clause", definition: "Anti-contest clause." },
                { term: "Incorporation by reference", definition: "Including terms of an independent document by making specific allusion to in another document." },
                { term: "Joint will", definition: "One will used for two persons." },
                { term: "Legacy", definition: "Testamentary gift of money." },
                { term: "Legatee", definition: "Recipient of money under a will." },
                { term: "Lapse", definition: "Provision in a will indicating that if a recipient of a gift under the will predeceases the testator, the gift forms a part of the testator's residuum." },
                { term: "Living will", definition: "Instrument indicating a person's wishes with respect to life termination should he be unable to speak for himself." },
                { term: "Marital deduction", definition: "Tax provision permitting property that goes to a surviving spouse to go tax free." },
                { term: "Menace", definition: "Threats used to induce a person to sign a will." },
                { term: "Mortmain Statute", definition: "Law limiting charitable gifts under a will." },
                { term: "Mutual will", definition: "Identical wills executed by two persons." },
                { term: "Nuncupative will", definition: "Oral will permitted in limited situations." },
                { term: "Power of attorney", definition: "Authorization for one person to act on another's behalf." },
                { term: "Pretermission", definition: "Omitting mention of a child or issue in a will; the omitted child or issue is entitled to an intestate share of the estate." },
                { term: "QTIP trust", definition: "Special trust that qualifies for a marital deduction." },
                { term: "Residuum", definition: "The residuary estate." },
                { term: "Self-proving will", definition: "Will with affidavit of attesting witnesses attached." },
                { term: "Simultaneous death clause", definition: "Provision indicating how property is to be distributed if the testator and the heir die in a common disaster." },
                { term: "Slayer Statute", definition: "Law prohibiting a murderer from inheriting from his or her victim." },
                { term: "Springing power of attorney", definition: "Power of attorney that takes effect at some point in the future." },
                { term: "Statutory will", definition: "Form will appearing in the state statutes." },
                { term: "Stored Communications Act", definition: "Federal statute authorizing service providers to release covered information to appointees." },
                { term: "Testamentary capacity", definition: "Knowing the nature and extent of one's property and the natural bounty of one's affections." },
                { term: "Testimonium", definition: "Last clause in a will." },
                { term: "Undue influence", definition: "Ability of a person in a close relationship to the testator to use that position to cause the testator to make a particular testamentary disposition." },
                { term: "Will contest", definition: "Legal challenge to the validity of an instrument filed for probate." }
              ].map((item, index) => (
                <Card key={index} className="border-l-4 border-teal-500">
                  <CardContent className="p-4">
                    <h4 className="font-bold text-teal-700 mb-2">{item.term}</h4>
                    <p className="text-gray-600 text-sm">{item.definition}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeSection === "sample-will" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveSection("documents")}
              className="mb-4"
            >
              ← Back to Documents
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-700">Sample Last Will and Testament</CardTitle>
                <p className="text-gray-600">Educational example showing proper will structure and language</p>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
                  <div className="text-center font-bold text-lg mb-6">
                    LAST WILL AND TESTAMENT<br/>
                    OF<br/>
                    SARAH ELIZABETH MARTINEZ
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold mb-2">ARTICLE I - EXORDIUM</h4>
                      <p>I, SARAH ELIZABETH MARTINEZ, a resident of Harris County, Texas, being of sound mind and disposing memory, do hereby make, publish and declare this to be my Last Will and Testament, hereby revoking all former wills and codicils by me at any time heretofore made.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE II - FAMILY INFORMATION</h4>
                      <p>I am married to MICHAEL ROBERT MARTINEZ. I have two children now living, namely: ISABELLA MARIE MARTINEZ, born March 15, 2010, and DIEGO ANTONIO MARTINEZ, born September 22, 2012. All references in this Will to "my children" refer to the above-named children and to any children hereafter born to or adopted by me.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE III - PAYMENT OF DEBTS</h4>
                      <p>I direct that all my just debts, funeral expenses, and costs of administration of my estate be paid as soon as practicable after my death.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE IV - SPECIFIC BEQUESTS</h4>
                      <p>I give and bequeath the following specific gifts:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>A. To my daughter, ISABELLA MARIE MARTINEZ, my grandmother's diamond ring and jewelry box.</li>
                        <li>B. To my son, DIEGO ANTONIO MARTINEZ, my father's watch collection and tools.</li>
                        <li>C. To the Houston Food Bank, the sum of Five Thousand Dollars ($5,000).</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE V - RESIDUARY ESTATE</h4>
                      <p>All the rest, residue and remainder of my estate, both real and personal, of whatsoever kind and wheresoever situated, I give, devise and bequeath to my husband, MICHAEL ROBERT MARTINEZ, if he survives me by thirty (30) days. If my husband does not survive me by thirty (30) days, then I give, devise and bequeath my residuary estate in equal shares to my children, ISABELLA MARIE MARTINEZ and DIEGO ANTONIO MARTINEZ.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE VI - EXECUTOR</h4>
                      <p>I hereby nominate and appoint my husband, MICHAEL ROBERT MARTINEZ, as Executor of this Will. If he is unable or unwilling to serve, I nominate my sister, MARIA ELENA RODRIGUEZ, as alternate Executor. I direct that no bond shall be required of any Executor.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE VII - GUARDIAN</h4>
                      <p>If at my death any of my children are minors, I nominate my sister, MARIA ELENA RODRIGUEZ, as Guardian of the person and property of such minor children.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">TESTIMONIUM</h4>
                      <p>IN WITNESS WHEREOF, I have hereunto set my hand this _____ day of __________, 2024.</p>
                      <div className="mt-4 text-right">
                        <p>_________________________________</p>
                        <p>SARAH ELIZABETH MARTINEZ, Testator</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ATTESTATION CLAUSE</h4>
                      <p>The foregoing instrument was signed and published by SARAH ELIZABETH MARTINEZ as her Last Will and Testament in our presence, and we, at her request and in her presence and in the presence of each other, have subscribed our names as witnesses thereto.</p>
                      
                      <div className="mt-4 space-y-3">
                        <div>
                          <p>_________________________________   Date: __________</p>
                          <p>Witness Name: _____________________</p>
                          <p>Address: __________________________</p>
                        </div>
                        <div>
                          <p>_________________________________   Date: __________</p>
                          <p>Witness Name: _____________________</p>
                          <p>Address: __________________________</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-blue-50 p-4 rounded border border-blue-300">
                  <h4 className="font-bold text-blue-700 mb-2">Key Elements Demonstrated:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• <strong>Exordium</strong> - Establishes testator's identity and mental capacity</li>
                    <li>• <strong>Revocation Clause</strong> - Cancels all previous wills</li>
                    <li>• <strong>Family Information</strong> - Identifies spouse and children</li>
                    <li>• <strong>Specific Bequests</strong> - Individual gifts to named beneficiaries</li>
                    <li>• <strong>Residuary Clause</strong> - Disposes of remaining estate</li>
                    <li>• <strong>Executor Appointment</strong> - Names estate administrator</li>
                    <li>• <strong>Guardian Nomination</strong> - Provides for minor children</li>
                    <li>• <strong>Proper Attestation</strong> - Witness requirements</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "sample-trust" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveSection("documents")}
              className="mb-4"
            >
              ← Back to Documents
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-green-700">Sample Revocable Living Trust</CardTitle>
                <p className="text-gray-600">Educational example of trust structure and provisions</p>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
                  <div className="text-center font-bold text-lg mb-6">
                    THE JENNIFER ANNE THOMPSON<br/>
                    REVOCABLE LIVING TRUST<br/>
                    DATED OCTOBER 15, 2024
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold mb-2">ARTICLE I - CREATION OF TRUST</h4>
                      <p>JENNIFER ANNE THOMPSON, as Settlor, hereby transfers and delivers to herself, as Trustee, the property described in Schedule A attached hereto, to be held, administered and distributed according to the terms of this Trust Agreement.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE II - TRUST NAME</h4>
                      <p>This trust shall be known as "THE JENNIFER ANNE THOMPSON REVOCABLE LIVING TRUST DATED OCTOBER 15, 2024."</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE III - DISTRIBUTIONS DURING SETTLOR'S LIFETIME</h4>
                      <p>During the Settlor's lifetime, the Trustee shall distribute to or for the benefit of the Settlor such amounts of the net income and principal as the Settlor may request from time to time. Any net income not distributed shall be added to principal.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE IV - DISTRIBUTIONS DURING INCAPACITY</h4>
                      <p>If the Settlor becomes incapacitated, the Trustee shall distribute such amounts of income and principal as may be necessary for the Settlor's health, education, maintenance and support, taking into account other resources available to the Settlor.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE V - DISTRIBUTIONS AFTER DEATH</h4>
                      <p>Upon the Settlor's death, the Trustee shall:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>A. Pay all debts, funeral expenses, and costs of administration.</li>
                        <li>B. Distribute $25,000 to the American Red Cross.</li>
                        <li>C. Distribute the remainder equally to the Settlor's children: RYAN MICHAEL THOMPSON and EMILY SARAH THOMPSON.</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE VI - SUCCESSOR TRUSTEE</h4>
                      <p>If the Settlor is unable to serve as Trustee, DAVID WILLIAM THOMPSON shall serve as Successor Trustee. If he is unable to serve, FIRST NATIONAL BANK OF TEXAS shall serve as Successor Trustee.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE VII - POWERS OF TRUSTEE</h4>
                      <p>The Trustee shall have all powers necessary to administer this trust, including but not limited to:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>• Buy, sell, and manage real estate</li>
                        <li>• Invest in stocks, bonds, and mutual funds</li>
                        <li>• Collect income and pay expenses</li>
                        <li>• Hire professional advisors</li>
                        <li>• Make tax elections</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ARTICLE VIII - REVOCATION</h4>
                      <p>The Settlor reserves the right to amend or revoke this trust in whole or in part at any time during her lifetime by written instrument delivered to the Trustee.</p>
                    </div>

                    <div className="mt-6">
                      <p>IN WITNESS WHEREOF, the Settlor has executed this Trust Agreement on the date first written above.</p>
                      <div className="mt-4 grid grid-cols-2 gap-8">
                        <div>
                          <p>_________________________________</p>
                          <p>JENNIFER ANNE THOMPSON, Settlor</p>
                        </div>
                        <div>
                          <p>_________________________________</p>
                          <p>JENNIFER ANNE THOMPSON, Trustee</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-green-50 p-4 rounded border border-green-300">
                  <h4 className="font-bold text-green-700 mb-2">Trust Features Demonstrated:</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• <strong>Revocable</strong> - Can be changed or cancelled during lifetime</li>
                    <li>• <strong>Self-Trusteed</strong> - Settlor maintains control as trustee</li>
                    <li>• <strong>Incapacity Planning</strong> - Provides for management if unable to act</li>
                    <li>• <strong>Successor Trustees</strong> - Named alternatives to continue management</li>
                    <li>• <strong>Distribution Instructions</strong> - Clear directions for asset distribution</li>
                    <li>• <strong>Comprehensive Powers</strong> - Trustee authority for all necessary actions</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "sample-poa" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveSection("documents")}
              className="mb-4"
            >
              ← Back to Documents
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-purple-700">Sample Durable Power of Attorney</CardTitle>
                <p className="text-gray-600">Educational example of financial power of attorney</p>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
                  <div className="text-center font-bold text-lg mb-6">
                    DURABLE POWER OF ATTORNEY<br/>
                    FOR FINANCIAL AFFAIRS
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold mb-2">DESIGNATION OF AGENT</h4>
                      <p>I, ROBERT JAMES ANDERSON, of Dallas County, Texas, hereby designate and appoint STEPHANIE LYNN ANDERSON, my wife, as my attorney-in-fact (agent) to act for me and in my name in any way which I myself could act with respect to financial and property matters.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">SUCCESSOR AGENT</h4>
                      <p>If STEPHANIE LYNN ANDERSON is unable or unwilling to serve as my agent, I hereby designate JONATHAN PAUL ANDERSON, my son, as my successor agent.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">EFFECTIVENESS</h4>
                      <p>This Power of Attorney shall become effective immediately upon execution and shall remain in effect during any period of incapacity.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">POWERS GRANTED</h4>
                      <p>My agent is hereby authorized to:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>A. Buy, sell, lease, mortgage, or otherwise deal in real estate</li>
                        <li>B. Manage bank accounts, investments, and securities</li>
                        <li>C. File tax returns and handle tax matters</li>
                        <li>D. Manage business interests and employment benefits</li>
                        <li>E. Handle insurance claims and policies</li>
                        <li>F. Make gifts consistent with my gift-giving history</li>
                        <li>G. Hire professional advisors and pay reasonable fees</li>
                        <li>H. Take any action necessary to preserve and protect my assets</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">LIMITATIONS</h4>
                      <p>My agent may NOT:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>• Make or change my will</li>
                        <li>• Make gifts exceeding $15,000 per recipient per year</li>
                        <li>• Change beneficiaries on my retirement accounts or insurance</li>
                        <li>• Make healthcare decisions (separate document required)</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">DURABILITY CLAUSE</h4>
                      <p>This Power of Attorney shall not be affected by my subsequent incapacity or disability, and shall remain in full force and effect unless revoked by me in writing.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">THIRD PARTY RELIANCE</h4>
                      <p>Any third party may rely upon this Power of Attorney without inquiry into whether it has been revoked or into the authority of my agent to take the action in question.</p>
                    </div>

                    <div className="mt-6">
                      <p>IN WITNESS WHEREOF, I have executed this Power of Attorney on __________, 2024.</p>
                      <div className="mt-4">
                        <p>_________________________________</p>
                        <p>ROBERT JAMES ANDERSON, Principal</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">NOTARIZATION</h4>
                      <div className="border p-3 bg-white">
                        <p>State of Texas</p>
                        <p>County of Dallas</p>
                        <p className="mt-2">On this _____ day of __________, 2024, before me personally appeared ROBERT JAMES ANDERSON, who proved to me on the basis of satisfactory evidence to be the person whose name is subscribed to the within instrument.</p>
                        <div className="mt-4">
                          <p>_________________________________</p>
                          <p>Notary Public</p>
                          <p>My commission expires: __________</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-purple-50 p-4 rounded border border-purple-300">
                  <h4 className="font-bold text-purple-700 mb-2">Power of Attorney Essentials:</h4>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• <strong>Durable</strong> - Remains effective during incapacity</li>
                    <li>• <strong>Comprehensive Powers</strong> - Covers all financial matters</li>
                    <li>• <strong>Clear Limitations</strong> - Specifies what agent cannot do</li>
                    <li>• <strong>Successor Named</strong> - Backup agent designated</li>
                    <li>• <strong>Third Party Protection</strong> - Encourages acceptance by institutions</li>
                    <li>• <strong>Proper Execution</strong> - Notarized for legal validity</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "sample-healthcare" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveSection("documents")}
              className="mb-4"
            >
              ← Back to Documents
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-orange-700">Sample Healthcare Directive</CardTitle>
                <p className="text-gray-600">Educational example of advance healthcare directive</p>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
                  <div className="text-center font-bold text-lg mb-6">
                    ADVANCE HEALTHCARE DIRECTIVE<br/>
                    (Living Will and Healthcare Power of Attorney)
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-bold mb-2">PART I - LIVING WILL</h4>
                      <p>I, MARIA ELENA RODRIGUEZ, being of sound mind, willfully and voluntarily make this Living Will to declare my wishes regarding medical treatment.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">END-OF-LIFE DECISIONS</h4>
                      <p>If I am in a terminal condition or persistent vegetative state and cannot communicate my wishes:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>• I DO NOT want life-sustaining treatments that would only prolong dying</li>
                        <li>• I DO want comfort care to relieve pain and suffering</li>
                        <li>• I DO want adequate pain medication even if it hastens death</li>
                        <li>• I DO want nutrition and hydration unless it causes suffering</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">SPECIFIC TREATMENTS</h4>
                      <div className="grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <p><strong>Cardiopulmonary Resuscitation (CPR):</strong></p>
                          <p>☐ I want CPR  ☑ I do not want CPR</p>
                          
                          <p className="mt-2"><strong>Mechanical Ventilation:</strong></p>
                          <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                          
                          <p className="mt-2"><strong>Dialysis:</strong></p>
                          <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                        </div>
                        <div>
                          <p><strong>Tube Feeding:</strong></p>
                          <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                          
                          <p className="mt-2"><strong>Antibiotics:</strong></p>
                          <p>☑ I want  ☐ I do not want</p>
                          
                          <p className="mt-2"><strong>Comfort Care:</strong></p>
                          <p>☑ I want comfort care always</p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">PART II - HEALTHCARE POWER OF ATTORNEY</h4>
                      <p>I hereby designate CARLOS MIGUEL RODRIGUEZ, my husband, as my healthcare agent to make healthcare decisions for me when I cannot make them myself.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">SUCCESSOR HEALTHCARE AGENT</h4>
                      <p>If CARLOS MIGUEL RODRIGUEZ is unable to serve, I designate ANA SOFIA RODRIGUEZ, my daughter, as my successor healthcare agent.</p>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">AGENT'S AUTHORITY</h4>
                      <p>My healthcare agent is authorized to:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>• Consent to or refuse medical treatment and procedures</li>
                        <li>• Choose healthcare providers and facilities</li>
                        <li>• Access my medical records and information</li>
                        <li>• Make decisions about organ donation</li>
                        <li>• Arrange for hospice or palliative care</li>
                        <li>• Take any action necessary to carry out my wishes</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">GUIDANCE FOR AGENT</h4>
                      <p>I want my agent to make decisions based on:</p>
                      <ul className="ml-4 mt-2 space-y-1">
                        <li>1. My specific instructions in this document</li>
                        <li>2. My known wishes and values</li>
                        <li>3. My best interests if my wishes are unknown</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">ORGAN DONATION</h4>
                      <p>☑ I consent to donate my organs, tissues, and eyes for transplantation, research, or education</p>
                      <p>☐ I do not consent to organ donation</p>
                      <p>☐ I consent only to: ________________________</p>
                    </div>

                    <div className="mt-6">
                      <p>I have carefully read this document and understand its contents. I am emotionally and mentally competent to make this directive.</p>
                      <div className="mt-4">
                        <p>Signed: _________________________________ Date: __________</p>
                        <p>MARIA ELENA RODRIGUEZ</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold mb-2">WITNESS ATTESTATION</h4>
                      <p>We witness that the principal signed this document in our presence, appears to be of sound mind and under no duress.</p>
                      <div className="mt-4 space-y-3">
                        <div>
                          <p>Witness 1: ______________________________ Date: ______</p>
                          <p>Print Name: _____________________________</p>
                        </div>
                        <div>
                          <p>Witness 2: ______________________________ Date: ______</p>
                          <p>Print Name: _____________________________</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-orange-50 p-4 rounded border border-orange-300">
                  <h4 className="font-bold text-orange-700 mb-2">Healthcare Directive Components:</h4>
                  <ul className="text-sm text-orange-700 space-y-1">
                    <li>• <strong>Living Will</strong> - Specific treatment preferences when terminal</li>
                    <li>• <strong>Healthcare Agent</strong> - Trusted person to make decisions</li>
                    <li>• <strong>Treatment Choices</strong> - Clear preferences for specific interventions</li>
                    <li>• <strong>Comfort Care</strong> - Emphasis on pain relief and dignity</li>
                    <li>• <strong>Organ Donation</strong> - Personal choice clearly documented</li>
                    <li>• <strong>Proper Witnessing</strong> - Legal validity through witnesses</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Module Pages */}
        {activeSection === "module-what-is-estate-planning" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveTab("overview")}
              className="mb-4"
            >
              ← Back to Course Overview
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-700">Module 1: What is Estate Planning?</CardTitle>
                <p className="text-gray-600">Understanding the basics of estate planning and why it matters</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-blue-50 p-6 rounded border-l-4 border-blue-500">
                  <h3 className="text-lg font-bold text-blue-700 mb-4">🎯 Learning Objectives</h3>
                  <ul className="space-y-2 text-blue-700">
                    <li>• Understand what estate planning means and why it's important</li>
                    <li>• Learn who needs estate planning (spoiler: everyone!)</li>
                    <li>• Discover the main goals of a good estate plan</li>
                    <li>• Recognize common misconceptions about estate planning</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">What is Estate Planning?</h3>
                  
                  <div className="bg-red-50 p-4 rounded border border-red-300">
                    <h4 className="font-bold text-red-700 mb-2">❌ Common Misconceptions</h4>
                    <p className="text-red-700 text-sm">
                      When most people hear "estate," they picture mourners dressed in black, somber cemeteries, and sometimes even wicked stepparents controlling family wealth. These dramatic images are neither true nor accurate.
                    </p>
                  </div>

                  <p className="text-gray-700 leading-relaxed">
                    <strong>Estate planning is fundamentally a specialized area of financial planning.</strong> Its core mission is to guide individuals in acquiring and building assets that fulfill their financial needs and aspirations throughout their lifetime. Distributing these assets after death represents just one component of comprehensive estate planning.
                  </p>

                  <div className="bg-green-50 p-4 rounded border border-green-300">
                    <h4 className="font-bold text-green-700 mb-2">✅ The Real Truth</h4>
                    <p className="text-green-700 text-sm">
                      Rather than focusing on death, estate planners are deeply invested in enhancing your life. Without substantial assets, there's nothing meaningful to distribute upon death. The estate planner's goal is helping clients build wealth significant enough to warrant careful distribution planning.
                    </p>
                  </div>

                  <p className="text-gray-700 leading-relaxed">
                    Estate planning is essentially a branch of financial planning that helps you accumulate, manage, and distribute your assets throughout your lifetime and after death. It's much more about building wealth and living well than it is about preparing for death.
                  </p>
                  
                  <div className="bg-blue-50 p-4 rounded border border-blue-300">
                    <h4 className="font-bold text-blue-700 mb-2">Professional Definition:</h4>
                    <p className="text-blue-700 text-sm">
                      Estate planning is the method whereby a person accumulates, manages, and disposes of real and personal property during life and after death. The primary function is to meet your short- and long-term financial needs while ensuring your particular concerns are addressed after death.
                    </p>
                  </div>

                  <div className="bg-green-50 p-4 rounded border border-green-300">
                    <h4 className="font-bold text-green-700 mb-2">Think of it like this:</h4>
                    <p className="text-green-700 text-sm">
                      Estate planning is about your LIFE, not just your death. It's like being the CEO of your own financial empire - you're building wealth, managing resources, and creating a legacy that supports you now and your family later.
                    </p>
                  </div>

                  <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-2">Key Insight:</h4>
                    <p className="text-yellow-700 text-sm">
                      If you have no assets, there's nothing to distribute after death. Estate planning helps you acquire assets substantial enough that you'll actually need to plan their distribution. It's about building wealth first, then protecting it.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Estate Planning is Life Planning</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">🌱 Asset Accumulation</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Building disposable income</li>
                          <li>• Smart investment strategies</li>
                          <li>• Tax-efficient wealth building</li>
                          <li>• Capital growth and income generation</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-blue-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-blue-700 mb-2">💼 Asset Management</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Ongoing financial planning</li>
                          <li>• Risk management and insurance</li>
                          <li>• Regular portfolio review</li>
                          <li>• Adapting to life changes</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-purple-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-purple-700 mb-2">🎯 Meeting Life Goals</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Short-term financial needs</li>
                          <li>• Long-term financial security</li>
                          <li>• Retirement planning</li>
                          <li>• Education funding</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-orange-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-orange-700 mb-2">🏛️ Asset Distribution</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Efficient wealth transfer</li>
                          <li>• Minimizing tax consequences</li>
                          <li>• Protecting beneficiaries</li>
                          <li>• Legacy preservation</li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Starting Your Estate Planning Journey</h3>
                  
                  <div className="bg-teal-50 p-4 rounded border border-teal-300">
                    <h4 className="font-bold text-teal-700 mb-3">Essential First Questions:</h4>
                    <div className="space-y-2 text-teal-700">
                      <p><strong>1. What are your current assets?</strong> - List everything you own</p>
                      <p><strong>2. What's your family situation?</strong> - Who depends on you financially?</p>
                      <p><strong>3. What are your financial goals?</strong> - What do you want to achieve?</p>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-4 rounded border border-orange-300">
                    <h4 className="font-bold text-orange-700 mb-3">If You Have Few Assets - Start Here:</h4>
                    <div className="space-y-2 text-orange-700 text-sm">
                      <p><strong>Step 1:</strong> Analyze your income and expenses completely</p>
                      <p><strong>Step 2:</strong> Determine your disposable income (money left after taxes and expenses)</p>
                      <p><strong>Step 3:</strong> Create a budget to maximize asset accumulation potential</p>
                      <p><strong>Step 4:</strong> Only disposable income can be used to acquire assets</p>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-4 rounded border border-purple-300">
                    <h4 className="font-bold text-purple-700 mb-3">Professional Team Approach:</h4>
                    <div className="grid md:grid-cols-2 gap-3 text-sm">
                      <div>
                        <p><strong className="text-purple-700">Financial Planner:</strong></p>
                        <ul className="text-purple-700 space-y-1">
                          <li>• Investment strategy development</li>
                          <li>• Capital growth planning</li>
                          <li>• Income generation strategies</li>
                          <li>• Risk assessment and management</li>
                        </ul>
                      </div>
                      <div>
                        <p><strong className="text-purple-700">Estate Attorney:</strong></p>
                        <ul className="text-purple-700 space-y-1">
                          <li>• Legal document preparation</li>
                          <li>• Tax law compliance</li>
                          <li>• Asset protection strategies</li>
                          <li>• Estate administration guidance</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Why Does Everyone Need Estate Planning?</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="border-l-4 border-purple-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-purple-700 mb-2">If You Have Kids</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Who will take care of them?</li>
                          <li>• Who will manage their money?</li>
                          <li>• How will they pay for college?</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-orange-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-orange-700 mb-2">If You Have Stuff</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Who gets your house?</li>
                          <li>• What about your car and savings?</li>
                          <li>• Who gets family heirlooms?</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">If You Get Sick</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Who makes medical decisions?</li>
                          <li>• Who pays your bills?</li>
                          <li>• What about end-of-life care?</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-red-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-red-700 mb-2">If You Don't Plan</h4>
                        <ul className="text-sm text-gray-700 space-y-1">
                          <li>• Courts decide everything</li>
                          <li>• Family fights over money</li>
                          <li>• Expensive legal processes</li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Main Goals of Estate Planning</h3>
                  
                  <div className="space-y-3">
                    <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                      <h4 className="font-bold text-yellow-700 mb-2">1. 👨‍👩‍👧‍👦 Protect Your Family</h4>
                      <p className="text-yellow-700 text-sm">Make sure your loved ones are taken care of financially and emotionally when you can't be there.</p>
                    </div>

                    <div className="bg-blue-50 p-4 rounded border border-blue-300">
                      <h4 className="font-bold text-blue-700 mb-2">2. 💰 Save Money and Time</h4>
                      <p className="text-blue-700 text-sm">Avoid expensive court processes and reduce taxes so more of your wealth goes to your family.</p>
                    </div>

                    <div className="bg-green-50 p-4 rounded border border-green-300">
                      <h4 className="font-bold text-green-700 mb-2">3. ✌️ Keep Peace in the Family</h4>
                      <p className="text-green-700 text-sm">Clear instructions prevent arguments and confusion between family members.</p>
                    </div>

                    <div className="bg-purple-50 p-4 rounded border border-purple-300">
                      <h4 className="font-bold text-purple-700 mb-2">4. 🛡️ Maintain Your Privacy</h4>
                      <p className="text-purple-700 text-sm">Keep your personal and financial information private instead of public court records.</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Common Myths About Estate Planning</h3>
                  
                  <div className="space-y-3">
                    <div className="bg-red-50 p-4 rounded border border-red-300">
                      <h4 className="font-bold text-red-700 mb-2">❌ "I'm too young to worry about this"</h4>
                      <p className="text-red-700 text-sm">Life is unpredictable. Young adults need basic planning, especially if they have children or own property.</p>
                    </div>

                    <div className="bg-red-50 p-4 rounded border border-red-300">
                      <h4 className="font-bold text-red-700 mb-2">❌ "I don't have enough money"</h4>
                      <p className="text-red-700 text-sm">Estate planning isn't just for the wealthy. Even basic assets like cars, savings accounts, and personal items need planning.</p>
                    </div>

                    <div className="bg-red-50 p-4 rounded border border-red-300">
                      <h4 className="font-bold text-red-700 mb-2">❌ "It's too complicated and expensive"</h4>
                      <p className="text-red-700 text-sm">Basic estate planning can be straightforward and affordable. The cost of NOT planning is usually much higher.</p>
                    </div>

                    <div className="bg-red-50 p-4 rounded border border-red-300">
                      <h4 className="font-bold text-red-700 mb-2">❌ "My family will figure it out"</h4>
                      <p className="text-red-700 text-sm">Without clear instructions, even the closest families can end up in legal battles that tear relationships apart.</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Real-Life Examples</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="border-l-4 border-blue-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-blue-700 mb-2">🏠 Example: Young Professional</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Sarah, 28:</strong> Just started her career, has student loans, rents an apartment.
                        </p>
                        <div className="bg-blue-50 p-3 rounded">
                          <p className="text-xs text-blue-700">
                            <strong>Estate Planning Focus:</strong> Build emergency fund, start retirement savings, get basic life insurance. Create simple will naming guardians for future children.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">👨‍👩‍👧‍👦 Example: Growing Family</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mike & Lisa, 35:</strong> Two kids, own home, moderate savings, both working.
                        </p>
                        <div className="bg-green-50 p-3 rounded">
                          <p className="text-xs text-green-700">
                            <strong>Estate Planning Focus:</strong> Increase life insurance, create comprehensive wills, establish education funds, consider trust for asset protection.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-purple-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-purple-700 mb-2">🏆 Example: Successful Business Owner</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>David, 50:</strong> Owns successful business, substantial assets, nearing retirement.
                        </p>
                        <div className="bg-purple-50 p-3 rounded">
                          <p className="text-xs text-purple-700">
                            <strong>Estate Planning Focus:</strong> Business succession planning, tax optimization strategies, charitable giving, complex trust structures.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-orange-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-orange-700 mb-2">🌅 Example: Retiree</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Helen, 72:</strong> Retired teacher, modest pension, owns home, wants to help grandchildren.
                        </p>
                        <div className="bg-orange-50 p-3 rounded">
                          <p className="text-xs text-orange-700">
                            <strong>Estate Planning Focus:</strong> Healthcare directives, long-term care planning, simple will updates, education gifts for grandchildren.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-blue-600">Test Your Knowledge</h3>
                  
                  <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                    <div className="space-y-3">
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">1. True or False: Estate planning is only for wealthy people.</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> False. Estate planning helps people at all wealth levels build assets and protect their families.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">2. What is the primary focus of estate planning?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Helping individuals acquire and accumulate assets to meet their financial needs during life, with distribution planning being just one aspect.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">3. Why do estate planners focus on building wealth first?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Without substantial assets, there's nothing meaningful to distribute after death. The goal is building wealth significant enough to warrant distribution planning.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-teal-50 p-6 rounded border border-teal-300">
                  <h3 className="text-lg font-bold text-teal-700 mb-4">🎉 Module Complete!</h3>
                  <p className="text-teal-700 mb-4">
                    Excellent! You now understand that estate planning is really about life and wealth building, not just death and distribution. You've learned the real purpose and seen examples of how it applies to people at different life stages.
                  </p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => setActiveSection("module-important-documents")}
                      className="bg-teal-600 hover:bg-teal-700"
                    >
                      Next: Important Documents →
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setActiveTab("quiz")}
                      className="border-teal-500 text-teal-600"
                    >
                      Take Full Quiz
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "module-important-documents" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveTab("overview")}
              className="mb-4"
            >
              ← Back to Course Overview
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-green-700">Module 2: Estate Planning vs Estate Administration</CardTitle>
                <p className="text-gray-600">Understanding the difference between planning and administration</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-green-50 p-6 rounded border-l-4 border-green-500">
                  <h3 className="text-lg font-bold text-green-700 mb-4">🎯 Learning Objectives</h3>
                  <ul className="space-y-2 text-green-700">
                    <li>• Distinguish between estate planning and estate administration</li>
                    <li>• Understand the role of estate administrators</li>
                    <li>• Learn the key responsibilities in estate administration</li>
                    <li>• See how planning and administration work together</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-green-600">What is Estate Administration?</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4 mb-6">
                    <Card className="border-l-4 border-blue-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-blue-700 mb-2">🏗️ Estate Planning</h4>
                        <p className="text-sm text-gray-700">
                          <strong>Focus:</strong> Building wealth during life<br/>
                          <strong>Goal:</strong> Acquire and accumulate assets<br/>
                          <strong>When:</strong> Throughout your lifetime<br/>
                          <strong>Purpose:</strong> Meet financial needs and prepare for the future
                        </p>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">⚖️ Estate Administration</h4>
                        <p className="text-sm text-gray-700">
                          <strong>Focus:</strong> Distributing assets after death<br/>
                          <strong>Goal:</strong> Transfer property to heirs<br/>
                          <strong>When:</strong> After someone passes away<br/>
                          <strong>Purpose:</strong> Complete the person's legal affairs
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  <p className="text-gray-700 leading-relaxed">
                    <strong>Estate administration focuses specifically on distributing a person's assets after their death.</strong> Those who handle estate administration become involved in transferring property ownership from the deceased to their heirs, following either the person's expressed wishes or state legal requirements.
                  </p>

                  <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-2">🔑 Key Responsibilities of Estate Administration:</h4>
                    <ul className="text-yellow-700 text-sm space-y-1">
                      <li>• <strong>Transfer Property Titles:</strong> Legally move ownership from deceased to heirs</li>
                      <li>• <strong>Follow Instructions:</strong> Honor the decedent's wishes or state statutes</li>
                      <li>• <strong>Handle Tax Obligations:</strong> Ensure all required taxes are properly paid</li>
                      <li>• <strong>Conclude Legal Affairs:</strong> Provide orderly completion of the person's legal life</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded border border-green-300">
                    <h4 className="font-bold text-green-700 mb-2">💡 The Connection</h4>
                    <p className="text-green-700 text-sm">
                      <strong>Simple Summary:</strong> Estate planning helps a person build assets during their lifetime, while estate administration helps distribute those assets when the person dies. They work together as a complete system for wealth building and transfer.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-green-600">Real-Life Estate Administration Examples</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="border-l-4 border-blue-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-blue-700 mb-2">📋 Example: Simple Estate</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mrs. Johnson passes away:</strong> Owns house, car, savings account, few personal items.
                        </p>
                        <div className="bg-blue-50 p-3 rounded">
                          <p className="text-xs text-blue-700">
                            <strong>Administration Tasks:</strong> Executor files will with court, transfers house deed to daughter, moves car title to son, distributes savings per will instructions, pays final bills and taxes.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">🏢 Example: Business Owner Estate</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mr. Davis passes away:</strong> Owned successful business, multiple properties, investments.
                        </p>
                        <div className="bg-green-50 p-3 rounded">
                          <p className="text-xs text-green-700">
                            <strong>Administration Tasks:</strong> Transfer business ownership per succession plan, sell or transfer properties, liquidate investments, file complex tax returns, distribute proceeds to heirs.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-purple-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-purple-700 mb-2">⚖️ Example: No Will Situation</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Young father dies unexpectedly:</strong> No will, wife and two young children survive.
                        </p>
                        <div className="bg-purple-50 p-3 rounded">
                          <p className="text-xs text-purple-700">
                            <strong>Administration Tasks:</strong> Court appoints administrator, assets distributed according to state law, longer probate process, higher costs, family stress during difficult time.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-orange-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-orange-700 mb-2">🏛️ Example: Trust Administration</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Grandmother with living trust:</strong> Assets already in trust, successor trustee named.
                        </p>
                        <div className="bg-orange-50 p-3 rounded">
                          <p className="text-xs text-orange-700">
                            <strong>Administration Tasks:</strong> Trustee distributes assets per trust terms, no probate court needed, faster distribution to grandchildren, privacy maintained, lower costs.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-green-600">Test Your Knowledge</h3>
                  
                  <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                    <div className="space-y-3">
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">1. When does estate administration begin?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Estate administration begins after a person's death and focuses on distributing their assets to heirs.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">2. What are the main responsibilities of estate administration?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Transfer property titles, follow the decedent's wishes or state statutes, pay taxes, and conclude legal affairs.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">3. How do estate planning and estate administration work together?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Estate planning builds assets during life, while estate administration distributes those assets after death - they form a complete wealth-building and transfer system.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-teal-50 p-6 rounded border border-teal-300">
                  <h3 className="text-lg font-bold text-teal-700 mb-4">🎉 Module Complete!</h3>
                  <p className="text-teal-700 mb-4">
                    Great work! You now understand the important difference between estate planning and estate administration. You can see how they work together to create a complete system for building and transferring wealth.
                  </p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => setActiveSection("module-understanding-wills")}
                      className="bg-teal-600 hover:bg-teal-700"
                    >
                      Next: Understanding Wills →
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setActiveTab("quiz")}
                      className="border-teal-500 text-teal-600"
                    >
                      Take Full Quiz
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "module-understanding-wills" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveTab("overview")}
              className="mb-4"
            >
              ← Back to Course Overview
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-purple-700">Module 3: Understanding Wills</CardTitle>
                <p className="text-gray-600">Learn about the most formal and important legal document in estate planning</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-purple-50 p-6 rounded border-l-4 border-purple-500">
                  <h3 className="text-lg font-bold text-purple-700 mb-4">🎯 Learning Objectives</h3>
                  <ul className="space-y-2 text-purple-700">
                    <li>• Understand why wills are the most formal legal documents</li>
                    <li>• Learn the importance of legal formality requirements</li>
                    <li>• Recognize why specific procedures must be followed</li>
                    <li>• Appreciate the protection these formalities provide</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-purple-600">What is a Will?</h3>
                  
                  <div className="bg-red-50 p-4 rounded border border-red-300">
                    <h4 className="font-bold text-red-700 mb-2">⚖️ Legal Formality Explained</h4>
                    <p className="text-red-700 text-sm">
                      A will stands among the most formal legal documents in our entire modern legal system. This extraordinary level of formality exists for a critical reason: the will speaks for someone who can no longer speak for themselves.
                    </p>
                  </div>

                  <p className="text-gray-700 leading-relaxed">
                    <strong>A will represents the final wishes of a person who is no longer living.</strong> Because the person who made the will cannot clarify their intentions or confirm the document's authenticity, the law demands extensive formality. These requirements ensure the document genuinely reflects the true desires of someone who can no longer advocate for themselves.
                  </p>

                  <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-2">🔍 Why Such Strict Requirements?</h4>
                    <p className="text-yellow-700 text-sm">
                      Think about it: When someone is alive, they can explain what they meant, clarify confusing language, or confirm they really signed a document. After death, the document must speak entirely for itself. That's why wills need the highest level of legal protection.
                    </p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded border border-blue-300">
                    <h4 className="font-bold text-blue-700 mb-2">🛡️ Protection Through Formality</h4>
                    <p className="text-blue-700 text-sm">
                      The extensive formality requirements protect everyone involved - the person who made the will, their family members, and society as a whole. These rules prevent fraud, ensure authenticity, and give everyone confidence that the will truly represents the deceased person's wishes.
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-purple-600">Real-Life Examples of Will Formality</h3>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="border-l-4 border-green-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-green-700 mb-2">✅ Properly Executed Will</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mr. Smith's Will:</strong> Typed document, signed by Mr. Smith in presence of two witnesses who also signed, dated clearly.
                        </p>
                        <div className="bg-green-50 p-3 rounded">
                          <p className="text-xs text-green-700">
                            <strong>Result:</strong> Will accepted by court, family receives clear direction, assets distributed according to wishes, no legal challenges.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-red-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-red-700 mb-2">❌ Informal "Will"</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mrs. Jones's Note:</strong> Handwritten note on napkin, no witnesses, unclear date, found in kitchen drawer.
                        </p>
                        <div className="bg-red-50 p-3 rounded">
                          <p className="text-xs text-red-700">
                            <strong>Result:</strong> Court rejects document, family disputes over authenticity, assets distributed by state law instead of personal wishes.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-orange-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-orange-700 mb-2">⚠️ Missing Formalities</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Mr. Brown's Will:</strong> Typed and signed by Mr. Brown, but only one witness instead of required two.
                        </p>
                        <div className="bg-orange-50 p-3 rounded">
                          <p className="text-xs text-orange-700">
                            <strong>Result:</strong> Will challenged in court, expensive legal battle, family stress during grief, delayed asset distribution.
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="border-l-4 border-blue-500">
                      <CardContent className="p-4">
                        <h4 className="font-bold text-blue-700 mb-2">💡 Modern Protection</h4>
                        <p className="text-sm text-gray-700 mb-2">
                          <strong>Ms. Davis's Will:</strong> Prepared by attorney, videotaped signing, witnesses interviewed, stored safely.
                        </p>
                        <div className="bg-blue-50 p-3 rounded">
                          <p className="text-xs text-blue-700">
                            <strong>Result:</strong> Maximum protection against challenges, clear evidence of authenticity, family confidence in document validity.
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-purple-600">Test Your Knowledge</h3>
                  
                  <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                    <div className="space-y-3">
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">1. Why are wills among the most formal legal documents?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Because wills represent the wishes of someone who can no longer speak for themselves, requiring extensive formality to ensure authenticity.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">2. What happens when a will doesn't meet formal requirements?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> The court may reject the document, leading to family disputes and assets being distributed according to state law instead of personal wishes.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">3. Who benefits from strict will formality requirements?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Everyone involved - the person who made the will, their family members, and society as a whole, as these rules prevent fraud and ensure authenticity.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-teal-50 p-6 rounded border border-teal-300">
                  <h3 className="text-lg font-bold text-teal-700 mb-4">🎉 Module Complete!</h3>
                  <p className="text-teal-700 mb-4">
                    Excellent! You now understand why wills require such formal procedures and how these protections benefit everyone. You've learned that the formality isn't bureaucratic red tape - it's essential protection for people who can no longer speak for themselves.
                  </p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => setActiveSection("module-protecting-family")}
                      className="bg-teal-600 hover:bg-teal-700"
                    >
                      Next: Protecting Your Family →
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setActiveTab("quiz")}
                      className="border-teal-500 text-teal-600"
                    >
                      Take Full Quiz
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeSection === "module-protecting-family" && (
          <div className="space-y-6">
            <Button 
              variant="outline" 
              onClick={() => setActiveTab("overview")}
              className="mb-4"
            >
              ← Back to Course Overview
            </Button>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-orange-700">Module 4: Essential Estate Planning Tools</CardTitle>
                <p className="text-gray-600">Master the key documents and instruments needed for complete estate planning</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
                  <h3 className="text-lg font-bold text-orange-700 mb-4">🎯 Learning Objectives</h3>
                  <ul className="space-y-2 text-orange-700">
                    <li>• Identify the seven essential estate planning tools</li>
                    <li>• Understand the purpose and function of each document</li>
                    <li>• Learn how these tools work together for complete protection</li>
                    <li>• Recognize the importance of keeping documents current</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-orange-600">Your Estate Planning Toolkit</h3>
                  
                  <p className="text-gray-700 leading-relaxed">
                    <strong>Estate planning requires several key tools to ensure your assets are distributed according to your wishes and your family's needs are met.</strong> Think of these as your complete protection toolkit - each tool serves a specific purpose and together they create comprehensive coverage for you and your loved ones.
                  </p>

                  <div className="bg-blue-50 p-4 rounded border border-blue-300">
                    <h4 className="font-bold text-blue-700 mb-2">🔧 Complete Toolkit Overview</h4>
                    <p className="text-blue-700 text-sm">
                      Your estate planning toolkit includes seven essential documents and instruments. Each one protects different aspects of your life and legacy - from financial decisions to healthcare choices to asset distribution.
                    </p>
                  </div>
                </div>

                <div className="grid gap-6">
                  <Card className="border-l-4 border-blue-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-blue-100 p-2 rounded">
                          <span className="text-2xl">📜</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-blue-700 mb-2">1. Last Will and Testament</h4>
                          <p className="text-gray-700 mb-3">
                            The foundation document that specifies how your assets should be distributed, names guardians for minor children, and designates an executor to manage your estate.
                          </p>
                          <div className="bg-blue-50 p-3 rounded">
                            <h5 className="font-semibold text-blue-700 mb-2">Critical Protection:</h5>
                            <p className="text-sm text-blue-700">
                              Without a will, state intestacy laws determine asset distribution - which may not match your wishes at all.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-green-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-green-100 p-2 rounded">
                          <span className="text-2xl">🏛️</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-green-700 mb-2">2. Trust Documents</h4>
                          <p className="text-gray-700 mb-3">
                            Revocable living trusts can help avoid probate, provide privacy, and offer more control over asset distribution. Irrevocable trusts serve specialized purposes like tax reduction or asset protection.
                          </p>
                          <div className="bg-green-50 p-3 rounded">
                            <h5 className="font-semibold text-green-700 mb-2">Key Benefits:</h5>
                            <ul className="text-sm text-green-700 space-y-1">
                              <li>• Avoid probate court processes</li>
                              <li>• Maintain privacy for your family</li>
                              <li>• Provide specialized tax advantages</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-purple-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-purple-100 p-2 rounded">
                          <span className="text-2xl">💰</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-purple-700 mb-2">3. Financial Power of Attorney</h4>
                          <p className="text-gray-700 mb-3">
                            Allows a trusted person to make financial decisions on your behalf if you become incapacitated. This covers banking, investment, and property management decisions.
                          </p>
                          <div className="bg-purple-50 p-3 rounded">
                            <h5 className="font-semibold text-purple-700 mb-2">Essential Coverage:</h5>
                            <ul className="text-sm text-purple-700 space-y-1">
                              <li>• Banking and investment management</li>
                              <li>• Property and real estate decisions</li>
                              <li>• Business and financial obligations</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-red-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-red-100 p-2 rounded">
                          <span className="text-2xl">🏥</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-red-700 mb-2">4. Healthcare Power of Attorney</h4>
                          <p className="text-gray-700 mb-3">
                            Designates someone to make medical decisions for you when you cannot. This person should understand your values and healthcare preferences.
                          </p>
                          <div className="bg-red-50 p-3 rounded">
                            <h5 className="font-semibold text-red-700 mb-2">Critical Decisions:</h5>
                            <ul className="text-sm text-red-700 space-y-1">
                              <li>• Treatment options and procedures</li>
                              <li>• Hospital and care facility choices</li>
                              <li>• End-of-life medical decisions</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-teal-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-teal-100 p-2 rounded">
                          <span className="text-2xl">📋</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-teal-700 mb-2">5. Advance Healthcare Directive (Living Will)</h4>
                          <p className="text-gray-700 mb-3">
                            Documents your wishes regarding life-sustaining treatment, end-of-life care, and other medical preferences when you cannot communicate them yourself.
                          </p>
                          <div className="bg-teal-50 p-3 rounded">
                            <h5 className="font-semibold text-teal-700 mb-2">Your Voice When You Can't Speak:</h5>
                            <ul className="text-sm text-teal-700 space-y-1">
                              <li>• Life-sustaining treatment preferences</li>
                              <li>• Pain management and comfort care</li>
                              <li>• Organ donation decisions</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-indigo-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-indigo-100 p-2 rounded">
                          <span className="text-2xl">👥</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-indigo-700 mb-2">6. Beneficiary Designations</h4>
                          <p className="text-gray-700 mb-3">
                            These forms for retirement accounts, life insurance policies, and other financial accounts often supersede your will, so keeping them current is crucial.
                          </p>
                          <div className="bg-indigo-50 p-3 rounded">
                            <h5 className="font-semibold text-indigo-700 mb-2">⚠️ Critical Note:</h5>
                            <p className="text-sm text-indigo-700">
                              Beneficiary designations override your will! An outdated beneficiary form can send assets to the wrong person regardless of your will's instructions.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-l-4 border-pink-500">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-3">
                        <div className="bg-pink-100 p-2 rounded">
                          <span className="text-2xl">🔒</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-lg font-bold text-pink-700 mb-2">7. HIPAA Authorization</h4>
                          <p className="text-gray-700 mb-3">
                            Allows designated individuals to access your medical information, which can be vital for healthcare decision-making.
                          </p>
                          <div className="bg-pink-50 p-3 rounded">
                            <h5 className="font-semibold text-pink-700 mb-2">Essential Access:</h5>
                            <p className="text-sm text-pink-700">
                              Without HIPAA authorization, even your spouse may be denied access to your medical information when making critical healthcare decisions.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-orange-600">How These Tools Work Together</h3>
                  
                  <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-4">🔗 Integrated Protection System:</h4>
                    <div className="space-y-3 text-sm text-yellow-700">
                      <div>
                        <strong>During Your Lifetime:</strong> Powers of attorney and HIPAA authorization protect you if you become incapacitated.
                      </div>
                      <div>
                        <strong>Healthcare Crisis:</strong> Healthcare power of attorney and advance directive guide medical decisions while you recover.
                      </div>
                      <div>
                        <strong>After Your Death:</strong> Will, trusts, and beneficiary designations ensure your assets go to the right people quickly and efficiently.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-orange-600">Test Your Knowledge</h3>
                  
                  <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                    <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                    <div className="space-y-3">
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">1. Which document can override your will's instructions?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> Beneficiary designations on retirement accounts and life insurance policies often supersede your will's instructions.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">2. What happens if you don't have a will?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> State intestacy laws determine how your assets are distributed, which may not match your personal wishes.
                        </div>
                      </div>
                      
                      <div className="bg-white p-3 rounded">
                        <p className="font-semibold text-gray-800 mb-2">3. Why do you need both financial and healthcare powers of attorney?</p>
                        <div className="text-sm text-gray-600">
                          <strong>Answer:</strong> They cover different aspects of your life - financial power of attorney handles money and property decisions, while healthcare power of attorney handles medical decisions.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-teal-50 p-6 rounded border border-teal-300">
                  <h3 className="text-lg font-bold text-teal-700 mb-4">🎉 Module Complete!</h3>
                  <p className="text-teal-700 mb-4">
                    Excellent! You now understand the seven essential tools for complete estate planning protection. You've learned how each document serves a specific purpose and how they work together to protect you and your family in all situations.
                  </p>
                  <div className="flex space-x-3">
                    <Button 
                      onClick={() => setActiveSection("module-when-someone-dies")}
                      className="bg-teal-600 hover:bg-teal-700"
                    >
                      Next: When Someone Dies →
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => setActiveTab("quiz")}
                      className="border-teal-500 text-teal-600"
                    >
                      Take Full Quiz
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "quiz" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-blue-600 mb-6">Estate Planning Quizzes</h2>
            
            <div className="mb-8 bg-gradient-to-r from-red-500 to-pink-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🧠 Test Your Knowledge Module by Module</h3>
              <p className="mb-3">Take focused quizzes for each module to master estate planning concepts step by step.</p>
              <div className="text-sm opacity-90">
                <p>• 3 questions per module covering key concepts</p>
                <p>• Immediate feedback with detailed explanations</p>
                <p>• Track your progress through each topic</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-l-4 border-blue-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-blue-700">Module 1 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">What is Estate Planning?</h4>
                  <p className="text-gray-600 mb-4">Test your understanding of estate planning as a wealth-building discipline and generational wealth creation.</p>
                  <Link href="/estate-quiz-1">
                    <Button className="bg-blue-600 hover:bg-blue-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-green-700">Module 2 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">Planning vs Administration</h4>
                  <p className="text-gray-600 mb-4">Understand the key differences between estate planning and estate administration processes.</p>
                  <Link href="/estate-quiz-2">
                    <Button className="bg-green-600 hover:bg-green-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-purple-700">Module 3 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">Essential Planning Tools</h4>
                  <p className="text-gray-600 mb-4">Master the seven essential estate planning tools and their specific functions.</p>
                  <Link href="/estate-quiz-3">
                    <Button className="bg-purple-600 hover:bg-purple-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-orange-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-orange-700">Module 4 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">Understanding Wills</h4>
                  <p className="text-gray-600 mb-4">Learn about will formalities, requirements, and what happens when they're not met.</p>
                  <Link href="/estate-quiz-4">
                    <Button className="bg-orange-600 hover:bg-orange-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-teal-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-teal-700">Module 5 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">When Someone Dies</h4>
                  <p className="text-gray-600 mb-4">Understand the immediate steps families should take and the administration process.</p>
                  <Link href="/estate-quiz-5">
                    <Button className="bg-teal-600 hover:bg-teal-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-yellow-500 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-yellow-600">Module 6 Quiz</CardTitle>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold text-gray-800 mb-2">Getting Started</h4>
                  <p className="text-gray-600 mb-4">Learn the practical steps to begin your estate planning journey and when to seek help.</p>
                  <Link href="/estate-quiz-6">
                    <Button className="bg-yellow-600 hover:bg-yellow-700 w-full">
                      Take Quiz (3 Questions)
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>

            {/* Quiz Progress Overview */}
            <Card className="mt-8 bg-gray-50">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-4">🎯 Your Quiz Progress</h3>
                <p className="text-gray-600 mb-4">
                  Complete all module quizzes to demonstrate mastery of estate planning concepts. Each quiz focuses on specific topics to reinforce your learning.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-white rounded border">
                    <div className="text-2xl font-bold text-blue-600">6</div>
                    <div className="text-sm text-gray-600">Total Quizzes</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded border">
                    <div className="text-2xl font-bold text-green-600">18</div>
                    <div className="text-sm text-gray-600">Total Questions</div>
                  </div>
                  <div className="text-center p-3 bg-white rounded border md:col-span-1 col-span-2">
                    <div className="text-2xl font-bold text-purple-600">100%</div>
                    <div className="text-sm text-gray-600">Master Level</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Wills Section */}
      {activeSection === "module-3" && (
        <WillsSection onBack={() => setActiveSection(null)} />
      )}

      {/* Footer */}
      <div className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-blue-600 font-semibold text-lg">🌟 Generational Wealth Starts Now! 🌟</p>
          <p className="text-gray-600 mt-2">Master estate planning to protect and transfer your wealth effectively</p>
          <p className="text-sm text-gray-500 mt-4">💡 <strong>Remember:</strong> This app provides educational information only. Always consult with qualified legal and financial professionals before making estate planning decisions.</p>
          <p className="text-sm text-gray-500">Proper estate planning ensures your legacy lives on and your loved ones are protected!</p>
        </div>
      </div>
    </div>
  );
}