import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import AllowanceCalculator from "@/components/AllowanceCalculator";

export default function AllowanceCalculatorPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Back Button */}
      <div className="bg-white shadow-sm border-b p-4">
        <div className="max-w-4xl mx-auto">
          <Link to="/tools">
            <Button variant="outline" className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50">
              <ArrowLeft className="w-4 h-4" />
              Return to Calculators
            </Button>
          </Link>
        </div>
      </div>

      {/* Calculator Component */}
      <div className="py-6">
        <AllowanceCalculator />
      </div>
    </div>
  );
}