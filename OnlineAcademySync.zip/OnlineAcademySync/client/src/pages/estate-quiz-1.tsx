import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz1() {
  return <EstateQuiz moduleType="module-1" />;
}