import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz2() {
  return <EstateQuiz moduleType="module-2" />;
}