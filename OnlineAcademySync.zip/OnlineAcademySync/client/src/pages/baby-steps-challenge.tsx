import { useState, useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft, TrendingUp, DollarSign, Target, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface BabyStep {
  id: number;
  title: string;
  description: string;
  target: number;
  completed: boolean;
  progress: number;
}

interface GameEvent {
  type: "income" | "expense" | "windfall" | "emergency";
  description: string;
  amount: number;
}

export default function BabyStepsChallenge() {
  const [month, setMonth] = useState(1);
  const [income, setIncome] = useState(2000);
  const [expenses, setExpenses] = useState(1500);
  const [debt, setDebt] = useState(15000);
  const [mortgage, setMortgage] = useState(0);
  const [emergencyFund, setEmergencyFund] = useState(0);
  const [retirement, setRetirement] = useState(0);
  const [collegeFund, setCollegeFund] = useState(0);
  const [extraWealth, setExtraWealth] = useState(0);
  const [currentEvent, setCurrentEvent] = useState<GameEvent | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [allocation, setAllocation] = useState({
    step1: 0,
    step2: 0,
    step3: 0,
    step4: 0,
    step5: 0,
    step6: 0,
    step7: 0
  });

  const babySteps: BabyStep[] = [
    {
      id: 0,
      title: "Baby Step 0: Create a Budget",
      description: "Find extra money to save",
      target: 1,
      completed: true,
      progress: 100
    },
    {
      id: 1,
      title: "Baby Step 1: Starter Emergency Fund",
      description: "Save $1,000 for emergencies",
      target: 1000,
      completed: emergencyFund >= 1000,
      progress: Math.min((emergencyFund / 1000) * 100, 100)
    },
    {
      id: 2,
      title: "Baby Step 2: Pay Off Debt",
      description: "Pay off all debt using debt snowball",
      target: 15000,
      completed: debt <= 0,
      progress: Math.max(((15000 - debt) / 15000) * 100, 0)
    },
    {
      id: 3,
      title: "Baby Step 3: Full Emergency Fund",
      description: "Save 3-6 months of expenses",
      target: expenses * 6,
      completed: emergencyFund >= expenses * 6 && debt <= 0,
      progress: debt <= 0 ? Math.min((emergencyFund / (expenses * 6)) * 100, 100) : 0
    },
    {
      id: 4,
      title: "Baby Step 4: Retirement Investing",
      description: "Invest 15% of income into retirement",
      target: income * 0.15 * 12,
      completed: retirement >= income * 0.15 * 12 && emergencyFund >= expenses * 6 && debt <= 0,
      progress: (debt <= 0 && emergencyFund >= expenses * 6) ? Math.min((retirement / (income * 0.15 * 12)) * 100, 100) : 0
    },
    {
      id: 5,
      title: "Baby Step 5: College Fund",
      description: "Save for children's college",
      target: 50000,
      completed: collegeFund >= 50000 && retirement >= income * 0.15 * 12,
      progress: (retirement >= income * 0.15 * 12) ? Math.min((collegeFund / 50000) * 100, 100) : 0
    },
    {
      id: 6,
      title: "Baby Step 6: Pay Off Home",
      description: "Pay off mortgage early",
      target: 200000,
      completed: mortgage <= 0,
      progress: Math.max(((200000 - mortgage) / 200000) * 100, 0)
    },
    {
      id: 7,
      title: "Baby Step 7: Build Wealth & Give",
      description: "Build wealth and give generously",
      target: 100000,
      completed: extraWealth >= 100000 && mortgage <= 0,
      progress: mortgage <= 0 ? Math.min((extraWealth / 100000) * 100, 100) : 0
    }
  ];

  const availableMoney = income - expenses + (currentEvent?.type === "income" || currentEvent?.type === "windfall" ? currentEvent.amount : 0) - (currentEvent?.type === "expense" || currentEvent?.type === "emergency" ? currentEvent.amount : 0);

  const generateRandomEvent = (): GameEvent | null => {
    const events: GameEvent[] = [
      { type: "windfall", description: "Tax refund received!", amount: 800 },
      { type: "windfall", description: "Work bonus earned!", amount: 500 },
      { type: "emergency", description: "Car repair needed", amount: -600 },
      { type: "emergency", description: "Medical bill", amount: -400 },
      { type: "income", description: "Side hustle income", amount: 300 },
      { type: "expense", description: "Unexpected home repair", amount: -350 }
    ];

    if (Math.random() < 0.3) { // 30% chance of event
      return events[Math.floor(Math.random() * events.length)];
    }
    return null;
  };

  const processMonth = () => {
    // Apply allocations
    const totalAllocated = Object.values(allocation).reduce((sum, val) => sum + val, 0);
    
    if (totalAllocated > availableMoney) {
      alert("You've allocated more money than you have available!");
      return;
    }

    // Apply allocations to appropriate funds
    if (allocation.step1 > 0 && emergencyFund < 1000) {
      setEmergencyFund(prev => Math.min(prev + allocation.step1, 1000));
    }
    
    if (allocation.step2 > 0 && debt > 0) {
      setDebt(prev => Math.max(prev - allocation.step2, 0));
    }
    
    if (allocation.step3 > 0 && debt <= 0) {
      setEmergencyFund(prev => prev + allocation.step3);
    }
    
    if (allocation.step4 > 0 && debt <= 0 && emergencyFund >= expenses * 6) {
      setRetirement(prev => prev + allocation.step4);
    }
    
    if (allocation.step5 > 0 && retirement >= income * 0.15 * 12) {
      setCollegeFund(prev => prev + allocation.step5);
    }
    
    if (allocation.step6 > 0 && mortgage > 0) {
      setMortgage(prev => Math.max(prev - allocation.step6, 0));
    }
    
    if (allocation.step7 > 0 && mortgage <= 0) {
      setExtraWealth(prev => prev + allocation.step7);
    }

    // Generate random event for next month
    setCurrentEvent(generateRandomEvent());
    
    // Reset allocations
    setAllocation({
      step1: 0,
      step2: 0,
      step3: 0,
      step4: 0,
      step5: 0,
      step6: 0,
      step7: 0
    });
    
    setMonth(prev => prev + 1);
  };

  const startGame = () => {
    setGameStarted(true);
    setMortgage(200000); // Add mortgage when game starts
    setCurrentEvent(generateRandomEvent());
  };

  const resetGame = () => {
    setMonth(1);
    setIncome(2000);
    setExpenses(1500);
    setDebt(15000);
    setMortgage(0);
    setEmergencyFund(0);
    setRetirement(0);
    setCollegeFund(0);
    setExtraWealth(0);
    setCurrentEvent(null);
    setGameStarted(false);
    setAllocation({
      step1: 0,
      step2: 0,
      step3: 0,
      step4: 0,
      step5: 0,
      step6: 0,
      step7: 0
    });
  };

  const completedSteps = babySteps.filter(step => step.completed).length;
  const allStepsComplete = completedSteps === babySteps.length;

  if (!gameStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 shadow-lg">
          <div className="max-w-4xl mx-auto">
            <Link href="/games">
              <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-50 bg-white transition-colors mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Games
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Dave Ramsey's Baby Steps Challenge</h1>
            <p className="text-lg text-green-100">Follow the 7 Baby Steps to achieve financial peace</p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-4 space-y-6">
          {/* What Are Baby Steps */}
          <Card>
            <CardHeader>
              <CardTitle className="text-green-600">What Are the Baby Steps?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">
                Dave Ramsey's Baby Steps are a proven plan to help you get out of debt, save money, and build wealth. 
                In this game, you'll follow these steps to achieve financial freedom!
              </p>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">0</div>
                  <span><strong>Baby Step 0:</strong> Create a budget and find extra money to save</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">1</div>
                  <span><strong>Baby Step 1:</strong> Save $1,000 for your starter emergency fund</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">2</div>
                  <span><strong>Baby Step 2:</strong> Pay off all debt using the debt snowball method</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">3</div>
                  <span><strong>Baby Step 3:</strong> Save 3-6 months of expenses for emergencies</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">4</div>
                  <span><strong>Baby Step 4:</strong> Invest 15% of household income into retirement</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">5</div>
                  <span><strong>Baby Step 5:</strong> Save for your children's college fund</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">6</div>
                  <span><strong>Baby Step 6:</strong> Pay off your home early</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold">7</div>
                  <span><strong>Baby Step 7:</strong> Build wealth and give generously</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* How Game Works */}
          <Card>
            <CardHeader>
              <CardTitle className="text-blue-600">How This Game Works:</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">
                Each month, you'll receive income and pay expenses. You decide how to allocate your extra money 
                between the Baby Steps. Random financial events will occur along the way. Your goal is to complete 
                all seven steps as quickly as possible!
              </p>
            </CardContent>
          </Card>

          {/* Starting Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Your Starting Financial Situation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <div className="text-sm text-gray-600">Monthly Income:</div>
                  <div className="text-2xl font-bold text-green-600">${income.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Monthly Expenses:</div>
                  <div className="text-2xl font-bold text-red-600">${expenses.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Current Debt:</div>
                  <div className="text-2xl font-bold text-red-600">${debt.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600">Mortgage Balance:</div>
                  <div className="text-2xl font-bold text-gray-600">${mortgage.toLocaleString()}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button onClick={startGame} className="w-full bg-green-600 hover:bg-green-700 text-lg py-4">
            Start Baby Steps Challenge
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <Link href="/games">
            <Button variant="outline" className="text-green-600 border-green-600 hover:bg-green-50 bg-white transition-colors mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Games
            </Button>
          </Link>
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">Baby Steps Challenge</h1>
              <p className="text-lg text-green-100">Month {month} | Steps Completed: {completedSteps}/8</p>
            </div>
            {allStepsComplete && (
              <div className="text-center">
                <Award className="w-12 h-12 mx-auto mb-2 text-yellow-300" />
                <div className="text-lg font-bold">Financial Peace!</div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Current Event */}
        {currentEvent && (
          <Card className={`border-2 ${currentEvent.type === "windfall" || currentEvent.type === "income" ? "border-green-300 bg-green-50" : "border-red-300 bg-red-50"}`}>
            <CardHeader>
              <CardTitle className={currentEvent.type === "windfall" || currentEvent.type === "income" ? "text-green-600" : "text-red-600"}>
                Monthly Event
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <span className="text-lg">{currentEvent.description}</span>
                <span className={`text-xl font-bold ${currentEvent.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                  {currentEvent.amount > 0 ? "+" : ""}${Math.abs(currentEvent.amount).toLocaleString()}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Financial Dashboard */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <DollarSign className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-sm text-gray-600">Available</div>
              <div className="text-xl font-bold text-green-600">${availableMoney.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <div className="text-sm text-gray-600">Emergency Fund</div>
              <div className="text-xl font-bold text-blue-600">${emergencyFund.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-red-600" />
              <div className="text-sm text-gray-600">Remaining Debt</div>
              <div className="text-xl font-bold text-red-600">${debt.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Award className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <div className="text-sm text-gray-600">Net Worth</div>
              <div className="text-xl font-bold text-purple-600">
                ${(emergencyFund + retirement + collegeFund + extraWealth - debt - mortgage).toLocaleString()}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Baby Steps Progress */}
        <Card>
          <CardHeader>
            <CardTitle>Baby Steps Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {babySteps.map((step) => (
                <div key={step.id} className={`p-4 rounded-lg border-2 ${step.completed ? "border-green-300 bg-green-50" : "border-gray-200"}`}>
                  <div className="flex justify-between items-center mb-2">
                    <h4 className={`font-bold ${step.completed ? "text-green-600" : "text-gray-700"}`}>
                      {step.title}
                    </h4>
                    <span className={`text-sm font-medium ${step.completed ? "text-green-600" : "text-gray-500"}`}>
                      {step.completed ? "✓ Complete" : `${step.progress.toFixed(1)}%`}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{step.description}</p>
                  <Progress value={step.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {!allStepsComplete && (
          <>
            {/* Money Allocation */}
            <Card>
              <CardHeader>
                <CardTitle>Allocate Your Extra Money (${availableMoney.toLocaleString()} available)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Only show relevant allocations based on current step */}
                  {emergencyFund < 1000 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 1 - Emergency Fund ($1,000)</label>
                      <input
                        type="number"
                        min="0"
                        max={Math.min(availableMoney, 1000 - emergencyFund)}
                        value={allocation.step1}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step1: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {debt > 0 && emergencyFund >= 1000 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 2 - Pay Off Debt (${debt.toLocaleString()} remaining)</label>
                      <input
                        type="number"
                        min="0"
                        max={Math.min(availableMoney, debt)}
                        value={allocation.step2}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step2: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {debt <= 0 && emergencyFund < expenses * 6 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 3 - Full Emergency Fund (${(expenses * 6).toLocaleString()} target)</label>
                      <input
                        type="number"
                        min="0"
                        max={availableMoney}
                        value={allocation.step3}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step3: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {debt <= 0 && emergencyFund >= expenses * 6 && retirement < income * 0.15 * 12 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 4 - Retirement (15% of income)</label>
                      <input
                        type="number"
                        min="0"
                        max={availableMoney}
                        value={allocation.step4}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step4: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {retirement >= income * 0.15 * 12 && collegeFund < 50000 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 5 - College Fund</label>
                      <input
                        type="number"
                        min="0"
                        max={availableMoney}
                        value={allocation.step5}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step5: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {mortgage > 0 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 6 - Pay Off Home (${mortgage.toLocaleString()} remaining)</label>
                      <input
                        type="number"
                        min="0"
                        max={Math.min(availableMoney, mortgage)}
                        value={allocation.step6}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step6: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                  
                  {mortgage <= 0 && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Step 7 - Build Wealth & Give</label>
                      <input
                        type="number"
                        min="0"
                        max={availableMoney}
                        value={allocation.step7}
                        onChange={(e) => setAllocation(prev => ({ ...prev, step7: parseInt(e.target.value) || 0 }))}
                        className="w-full p-2 border rounded"
                      />
                    </div>
                  )}
                </div>
                
                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center mb-4">
                    <span>Total Allocated:</span>
                    <span className="font-bold">${Object.values(allocation).reduce((sum, val) => sum + val, 0).toLocaleString()}</span>
                  </div>
                  <Button onClick={processMonth} className="w-full bg-blue-600 hover:bg-blue-700">
                    Continue to Next Month
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}

        {allStepsComplete && (
          <Card className="border-green-300 bg-green-50">
            <CardHeader>
              <CardTitle className="text-green-600 text-center">Congratulations! 🎉</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-lg mb-4">
                You've completed all Baby Steps in {month} months! You've achieved financial peace and can now 
                build wealth and give generously.
              </p>
              <Button onClick={resetGame} className="bg-green-600 hover:bg-green-700">
                Play Again
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}