import { useState } from "react";
import { ArrowLeft, PlayCircle, CheckCircle, Clock, Users, Star, BookOpen, DollarSign, TrendingUp, FileText, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";

export default function BusinessCourse() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeModule, setActiveModule] = useState(0);

  const courseModules = [
    {
      title: "💰 Cash Flow Quadrant - Pick Your Money-Making Superpower!",
      lessons: [
        "🌟 Understanding the Cash Flow Quadrant - Your Financial GPS!",
        "👷 E - Employee: The Safe but Limited Path",
        "🧑‍💼 S - Self-Employed: You ARE the Business!", 
        "🏢 B - Business Owner: Building Money Machines!",
        "📈 I - Investor: Making Money While You Sleep!",
        "🗺️ Your Path to Financial Freedom",
        "🚀 Moving from Left Side to Right Side",
        "🎯 Find Your Quadrant Quiz"
      ],
      duration: "45 min",
      description: "Think of this like choosing your character class in an RPG! Robert Kiyosaki created this amazing system that shows you the 4 different ways people make money. Which path will lead YOU to financial freedom? Let's find out! 🎮✨",
      emoji: "💰",
      funFact: "Did you know? Most millionaires make money from the B and I quadrants - not from having a job!"
    }
  ];

  const businessTools = [
    {
      name: "Business Plan Template",
      description: "Comprehensive template to create your business plan",
      icon: FileText
    },
    {
      name: "Startup Cost Calculator",
      description: "Calculate how much you need to start your business",
      icon: Calculator
    },
    {
      name: "Revenue Projector",
      description: "Project your potential business revenue",
      icon: TrendingUp
    },
    {
      name: "Break-Even Analysis",
      description: "Determine when your business will become profitable",
      icon: DollarSign
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Welcome Section - Authentic Layout */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-green-500 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-4xl mx-auto px-4 text-center">
          <Button 
            onClick={() => window.history.back()}
            variant="outline"
            className="mb-8 text-white border-white hover:bg-white hover:text-blue-600"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Academy
          </Button>
          
          <h1 className="text-5xl lg:text-6xl font-bold mb-6">Welcome to Rouz Up!</h1>
          <p className="text-2xl text-white/90 mb-8">
            Your adventure to becoming a future business superstar starts here!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg"
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
            >
              Start Your Journey <TrendingUp className="w-5 h-5 ml-2" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-xl font-bold text-lg"
            >
              My Badges <Star className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Business Modules Section - Authentic Layout */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Business Modules</h1>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courseModules.map((module, index) => (
              <div 
                key={index} 
                className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer border border-gray-200 overflow-hidden group"
                onClick={() => setActiveModule(index)}
              >
                <div className="p-8 text-center relative">
                  <div className="mb-6">
                    <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform duration-300">
                      {index === 0 && <DollarSign className="w-8 h-8" />}
                      {index === 1 && <TrendingUp className="w-8 h-8" />}
                      {index === 2 && <BookOpen className="w-8 h-8" />}
                      {index === 3 && <Calculator className="w-8 h-8" />}
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <h2 className="text-xl font-bold text-gray-900 mb-2">{module.title}</h2>
                    <p className="text-gray-600 text-sm">{module.description}</p>
                  </div>
                  
                  {activeModule === index && (
                    <div className="absolute top-4 right-4">
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Active Module Content */}
          <div className="mt-12">
            {courseModules.map((module, index) => 
              activeModule === index && (
                <Card key={index} className="bg-white shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-2xl">{module.title}</CardTitle>
                    <p className="text-gray-600">{module.lessons.length} lessons • {module.duration}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {module.lessons.map((lesson, lessonIndex) => (
                        <div key={lessonIndex} className="flex items-center p-3 rounded-lg hover:bg-gray-50 cursor-pointer border border-gray-100">
                          <PlayCircle className="w-5 h-5 text-blue-500 mr-3" />
                          <span className="font-medium">{lesson}</span>
                        </div>
                      ))}
                    </div>
                    
                    {index === 0 && (
                          <div className="mt-6 p-6 bg-green-50 rounded-lg">
                            <h3 className="text-xl font-bold mb-4">Understanding the Cash Flow Quadrant</h3>
                            <p className="text-gray-700 mb-6">
                              The Cash Flow Quadrant is a concept developed by Robert Kiyosaki that helps you understand the four different ways people make money:
                            </p>
                            
                            <div className="grid md:grid-cols-2 gap-6 mb-6">
                              <div className="bg-white p-4 rounded-lg border-l-4 border-red-500">
                                <h4 className="font-bold text-lg text-red-600 mb-2">E - Employee</h4>
                                <p className="text-gray-700 text-sm">
                                  Employees work for someone else. They have job security and a regular paycheck, but limited income potential and control.
                                </p>
                                <div className="mt-2 text-xs text-gray-500">You have a job</div>
                              </div>
                              
                              <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                                <h4 className="font-bold text-lg text-orange-600 mb-2">S - Self-Employed</h4>
                                <p className="text-gray-700 text-sm">
                                  Self-employed people own their own job. They have more control but still trade time for money - when they stop working, the income stops.
                                </p>
                                <div className="mt-2 text-xs text-gray-500">You own a job</div>
                              </div>
                              
                              <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                                <h4 className="font-bold text-lg text-blue-600 mb-2">B - Business Owner</h4>
                                <p className="text-gray-700 text-sm">
                                  Business owners create systems that generate money even when they're not personally working. They leverage other people's time and skills.
                                </p>
                                <div className="mt-2 text-xs text-gray-500">You own a system</div>
                              </div>
                              
                              <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                                <h4 className="font-bold text-lg text-green-600 mb-2">I - Investor</h4>
                                <p className="text-gray-700 text-sm">
                                  Investors make money from their investments - their money works for them. This can include stocks, real estate, or businesses they invest in.
                                </p>
                                <div className="mt-2 text-xs text-gray-500">Money works for you</div>
                              </div>
                            </div>
                            
                            <div className="bg-white p-6 rounded-lg">
                              <h4 className="font-bold text-lg mb-3">Your Path to Financial Freedom</h4>
                              <p className="text-gray-700 mb-4">
                                Moving from the left side (E and S) to the right side (B and I) of the quadrant is how many people achieve financial freedom. The right side offers more leverage, potential for passive income, and tax advantages.
                              </p>
                              <p className="text-gray-700 mb-4">
                                Take the quiz to discover which quadrant best matches your current mindset and where you might want to focus your future efforts!
                              </p>
                              
                              <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold">
                                🎯 Find Your Quadrant - Start Quiz
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  </CardContent>
                </Card>
              )
            )}

              {/* Business Tools Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Business Tools & Resources</CardTitle>
                  <p className="text-gray-600">Interactive tools to help you start your business</p>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {businessTools.map((tool, index) => (
                      <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer">
                        <div className="flex items-start">
                          <tool.icon className="w-8 h-8 text-green-600 mr-3 mt-1" />
                          <div>
                            <h4 className="font-medium text-gray-900">{tool.name}</h4>
                            <p className="text-sm text-gray-600 mt-1">{tool.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div>
              <Card className="sticky top-8">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-gray-900 mb-2">$59</div>
                    <div className="text-sm text-gray-600">One-time payment • Lifetime access</div>
                  </div>

                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700 mb-4" 
                    size="lg"
                  >
                    Enroll Now
                  </Button>

                  <div className="space-y-3 text-sm">
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Lifetime access</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Downloadable resources</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Business plan templates</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Financial calculators</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Certificate of completion</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>30-day money-back guarantee</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}