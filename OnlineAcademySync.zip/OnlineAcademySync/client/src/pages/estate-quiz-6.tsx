import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz6() {
  return <EstateQuiz moduleType="module-6" />;
}