import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";

export default function About() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* About Us Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-8 text-center">About Rouz Up Academy</h1>
          
          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Mission</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                At Rouz Up Academy, we're revolutionizing financial education by making it accessible, engaging, and practical for learners of all ages. Our mission is to empower individuals with the knowledge and tools they need to build generational wealth and achieve financial freedom.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We believe that financial literacy should start early and be taught in a way that's both comprehensive and easy to understand. Through our interactive courses and practical tools, we're building a community of financially empowered individuals.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">What We Offer</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="font-bold text-lg text-blue-800 mb-3">Comprehensive Courses</h3>
                  <ul className="text-gray-700 space-y-2">
                    <li>• Credit Building & Management</li>
                    <li>• Business Fundamentals</li>
                    <li>• Trust & Estate Planning</li>
                    <li>• Banking & Financial Services</li>
                    <li>• Investment Strategies</li>
                  </ul>
                </div>
                
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="font-bold text-lg text-green-800 mb-3">Interactive Tools</h3>
                  <ul className="text-gray-700 space-y-2">
                    <li>• Credit Score Simulators</li>
                    <li>• Financial Calculators</li>
                    <li>• Budget Planning Tools</li>
                    <li>• Investment Trackers</li>
                    <li>• Educational Games</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Approach</h2>
              <div className="bg-yellow-50 p-6 rounded-lg">
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl mb-2">🎯</div>
                    <h4 className="font-bold text-yellow-800 mb-2">Practical Learning</h4>
                    <p className="text-gray-700 text-sm">Real-world applications and actionable strategies you can implement immediately.</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl mb-2">🎮</div>
                    <h4 className="font-bold text-yellow-800 mb-2">Gamified Experience</h4>
                    <p className="text-gray-700 text-sm">Interactive quizzes, challenges, and games make learning engaging and memorable.</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl mb-2">👥</div>
                    <h4 className="font-bold text-yellow-800 mb-2">Community Support</h4>
                    <p className="text-gray-700 text-sm">Join a community of learners and access expert guidance on your financial journey.</p>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why Choose Rouz Up Academy?</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <span className="text-white text-xs font-bold">✓</span>
                  </div>
                  <p className="text-gray-700"><strong>Expert-Designed Curriculum:</strong> Our courses are developed by financial professionals with decades of experience.</p>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <span className="text-white text-xs font-bold">✓</span>
                  </div>
                  <p className="text-gray-700"><strong>Age-Appropriate Content:</strong> From teenagers to adults, our content is tailored for different life stages and learning levels.</p>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <span className="text-white text-xs font-bold">✓</span>
                  </div>
                  <p className="text-gray-700"><strong>Measurable Results:</strong> Track your progress with assessments, certificates, and practical milestones.</p>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center mt-1">
                    <span className="text-white text-xs font-bold">✓</span>
                  </div>
                  <p className="text-gray-700"><strong>Continuous Updates:</strong> Our content evolves with changing financial landscapes and regulations.</p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Start Your Journey Today</h2>
              <p className="text-gray-700 leading-relaxed mb-6">
                Whether you're just starting your financial journey or looking to expand your knowledge, Rouz Up Academy has the resources you need. Join thousands of learners who are already building their path to financial success.
              </p>
              
              <div className="text-center">
                <Link href="/courses">
                  <Button className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3 rounded-lg font-semibold mr-4">
                    Explore Courses
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button variant="outline" className="px-8 py-3 rounded-lg font-semibold">
                    Contact Us
                  </Button>
                </Link>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}