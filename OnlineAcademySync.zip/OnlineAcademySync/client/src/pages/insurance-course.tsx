import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, CheckCircle, Play, BookOpen, Brain, Trophy, Star, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function InsuranceCourse() {
  const [completedModules, setCompletedModules] = useState<number[]>([]);
  const [currentModule, setCurrentModule] = useState<number | null>(null);
  const [quizResults, setQuizResults] = useState<{[key: number]: number}>({});

  const modules = [
    {
      id: 1,
      title: "💰 Death Benefits Explained",
      description: "Understanding the foundation of life insurance",
      duration: "15 min",
      difficulty: "Beginner",
      topics: ["Death benefit basics", "Coverage calculations", "Tax advantages", "Beneficiary designation"]
    },
    {
      id: 2,
      title: "🛡️ Insurance Basics",
      description: "Essential insurance terminology and concepts",
      duration: "20 min", 
      difficulty: "Beginner",
      topics: ["Premiums", "Underwriting", "Policy basics", "Coverage types"]
    },
    {
      id: 3,
      title: "📈 Compound Interest in Insurance",
      description: "How compound growth builds wealth",
      duration: "18 min",
      difficulty: "Intermediate", 
      topics: ["Cash value growth", "Time value of money", "Long-term benefits", "Growth strategies"]
    },
    {
      id: 4,
      title: "🏷️ Insurance Types",
      description: "Term, Whole, Universal & Variable Life Insurance",
      duration: "25 min",
      difficulty: "Intermediate",
      topics: ["Term life insurance", "Whole life insurance", "Universal life", "Variable life"]
    },
    {
      id: 5,
      title: "🏦 Be Your Own Bank",
      description: "Using insurance as a personal banking system",
      duration: "22 min",
      difficulty: "Advanced",
      topics: ["Infinite banking concept", "Policy loans", "Cash flow management", "Wealth strategies"]
    }
  ];

  const moduleQuizzes = {
    1: {
      title: "💰 Death Benefits Quiz",
      questions: [
        {
          question: "What is the primary purpose of a death benefit in life insurance?",
          options: [
            "To provide retirement income",
            "To pay beneficiaries when the insured dies",
            "To build cash value",
            "To reduce taxes"
          ],
          correct: 1,
          explanation: "Death benefits are the tax-free money paid to beneficiaries when the insured person passes away, which is the core purpose of life insurance."
        },
        {
          question: "What is the recommended death benefit amount based on annual income?",
          options: [
            "5-7 times annual income",
            "10-12 times annual income", 
            "2-3 times annual income",
            "15-20 times annual income"
          ],
          correct: 1,
          explanation: "The rule of thumb is 10-12 times your annual income. So if you earn $50,000, consider $500,000-600,000 in coverage."
        },
        {
          question: "Are death benefits typically taxable to beneficiaries?",
          options: [
            "Yes, they are fully taxable",
            "No, they are generally tax-free",
            "Only if over $100,000",
            "Depends on the state"
          ],
          correct: 1,
          explanation: "Death benefits are generally received tax-free by beneficiaries, making life insurance an effective wealth transfer tool."
        }
      ]
    },
    2: {
      title: "🛡️ Insurance Basics Quiz", 
      questions: [
        {
          question: "What is a beneficiary in life insurance?",
          options: [
            "The insurance company",
            "The person who pays premiums", 
            "The person who receives the death benefit",
            "The insurance agent"
          ],
          correct: 2,
          explanation: "A beneficiary is the person or entity designated to receive the death benefit when the insured person passes away."
        },
        {
          question: "What does 'underwriting' mean in insurance?",
          options: [
            "Writing the insurance policy",
            "Evaluating risk to determine rates and eligibility",
            "Paying premiums",
            "Filing a claim"
          ],
          correct: 1,
          explanation: "Underwriting is the process where insurance companies evaluate your risk through health questions, medical exams, and lifestyle factors."
        },
        {
          question: "What is a premium in life insurance?",
          options: [
            "The death benefit amount",
            "The cash value",
            "The regular payment to keep coverage active",
            "The insurance company's profit"
          ],
          correct: 2,
          explanation: "A premium is the amount you pay for your life insurance coverage, typically monthly or annually."
        }
      ]
    },
    3: {
      title: "📈 Compound Interest Quiz",
      questions: [
        {
          question: "How does compound interest work in permanent life insurance?",
          options: [
            "Interest is only paid on premiums",
            "Interest earns interest, creating exponential growth",
            "Interest is taxed annually",
            "Interest only applies to death benefits"
          ],
          correct: 1,
          explanation: "Compound interest means your cash value earns returns, and those returns also earn returns, creating exponential growth over time."
        },
        {
          question: "What is the typical guaranteed growth rate in whole life insurance?",
          options: [
            "8-10%",
            "2-4%",
            "0-1%", 
            "15-20%"
          ],
          correct: 1,
          explanation: "Whole life insurance typically guarantees 2-4% growth, with potential for higher returns through dividends."
        },
        {
          question: "When does compound interest have the greatest impact?",
          options: [
            "In the first year",
            "Over long periods of time",
            "Only at retirement",
            "It has the same impact every year"
          ],
          correct: 1,
          explanation: "Compound interest becomes more powerful over longer time periods, which is why starting early is crucial for wealth building."
        }
      ]
    },
    4: {
      title: "🏷️ Insurance Types Quiz",
      questions: [
        {
          question: "What is the main difference between term and whole life insurance?",
          options: [
            "Term is more expensive",
            "Whole life builds cash value",
            "Term covers more people",
            "Whole life is temporary"
          ],
          correct: 1,
          explanation: "The main difference is that whole life insurance builds cash value that you can access while alive, while term life only provides death benefit protection."
        },
        {
          question: "Which type of life insurance typically has the lowest premiums for young people?",
          options: [
            "Whole life",
            "Universal life", 
            "Variable life",
            "Term life"
          ],
          correct: 3,
          explanation: "Term life insurance typically has the lowest premiums, especially for young, healthy individuals, because it only provides death benefit without cash value."
        },
        {
          question: "Variable life insurance allows you to:",
          options: [
            "Change your age",
            "Control investment choices",
            "Avoid all premiums",
            "Cancel anytime without penalty"
          ],
          correct: 1,
          explanation: "Variable life insurance allows policyholders to direct their cash value into various investment options, giving them control over how their money is invested."
        }
      ]
    },
    5: {
      title: "🏦 Be Your Own Bank Quiz",
      questions: [
        {
          question: "What is the Infinite Banking Concept?",
          options: [
            "Using credit cards for everything",
            "Using whole life insurance as a personal banking system",
            "Opening multiple bank accounts",
            "Avoiding all debt"
          ],
          correct: 1,
          explanation: "The Infinite Banking Concept uses whole life insurance as a personal banking system, allowing you to borrow against your policy's cash value instead of from banks."
        },
        {
          question: "What happens to your policy when you take a policy loan?",
          options: [
            "The policy is cancelled",
            "Growth stops completely",
            "The policy continues earning returns on the full cash value",
            "You lose your death benefit"
          ],
          correct: 2,
          explanation: "Your policy continues earning returns on the full cash value even when loans are outstanding, which is a key advantage of the infinite banking strategy."
        },
        {
          question: "What is a major advantage of policy loans compared to bank loans?",
          options: [
            "Higher interest rates",
            "No credit checks or approval needed",
            "Shorter repayment terms",
            "They're always free"
          ],
          correct: 1,
          explanation: "Policy loans don't require credit checks, income verification, or approval processes since you're borrowing against your own cash value."
        }
      ]
    }
  };

  const [currentQuiz, setCurrentQuiz] = useState<number | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const startQuiz = (moduleId: number) => {
    setCurrentQuiz(moduleId);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setUserAnswers([]);
  };

  const selectAnswer = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setUserAnswers(newAnswers);
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    const quiz = moduleQuizzes[currentQuiz as keyof typeof moduleQuizzes];
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const quiz = moduleQuizzes[currentQuiz as keyof typeof moduleQuizzes];
    const correctAnswers = userAnswers.filter((answer, index) => 
      answer === quiz.questions[index].correct
    ).length;
    const percentage = Math.round((correctAnswers / quiz.questions.length) * 100);
    
    setQuizResults({
      ...quizResults,
      [currentQuiz!]: percentage
    });

    if (percentage >= 70 && !completedModules.includes(currentQuiz!)) {
      setCompletedModules([...completedModules, currentQuiz!]);
    }

    setCurrentQuiz(null);
  };

  const completeModule = (moduleId: number) => {
    if (!completedModules.includes(moduleId)) {
      setCompletedModules([...completedModules, moduleId]);
    }
    setCurrentModule(null);
  };

  const openModule = (moduleId: number) => {
    setCurrentModule(moduleId);
  };

  const overallProgress = (completedModules.length / modules.length) * 100;

  if (currentModule) {
    const module = modules.find(m => m.id === currentModule);
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              onClick={() => setCurrentModule(null)}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Course
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">{module?.title}</h1>
          </div>

          <Card className="mb-6">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <div className="text-6xl mb-4">🛡️</div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">{module?.title}</h2>
                <p className="text-lg text-gray-600 mb-8">{module?.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold text-blue-900 mb-2">Duration</h3>
                  <p className="text-blue-800">{module?.duration}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <h3 className="font-semibold text-green-900 mb-2">Difficulty</h3>
                  <p className="text-green-800">{module?.difficulty}</p>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Topics Covered</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {module?.topics.map((topic, index) => (
                    <div key={index} className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span className="text-gray-700">{topic}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-center space-x-4">
                <Button 
                  onClick={() => startQuiz(currentModule)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Take Quiz
                </Button>
                <Button 
                  onClick={() => completeModule(currentModule)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Mark Complete
                </Button>
                <Link href="/insurance-preview.html" target="_blank">
                  <Button variant="outline">
                    <BookOpen className="w-4 h-4 mr-2" />
                    View Full Content
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentQuiz) {
    const quiz = moduleQuizzes[currentQuiz as keyof typeof moduleQuizzes];
    const question = quiz.questions[currentQuestion];
    const isCorrect = selectedAnswer === question.correct;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              onClick={() => setCurrentQuiz(null)}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Exit Quiz
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">{quiz.title}</h1>
          </div>

          <Card>
            <CardContent className="p-8">
              <div className="mb-6">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm text-gray-600">
                    Question {currentQuestion + 1} of {quiz.questions.length}
                  </span>
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">{question.question}</h3>
                
                {!showExplanation ? (
                  <div className="space-y-3">
                    {question.options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => selectAnswer(index)}
                        className="w-full p-4 text-left border-2 border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-colors"
                        disabled={selectedAnswer !== null}
                      >
                        <div className="font-medium">{option}</div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div>
                    <div className="space-y-3 mb-6">
                      {question.options.map((option, index) => (
                        <div
                          key={index}
                          className={`p-4 border-2 rounded-lg ${
                            index === question.correct
                              ? 'border-green-500 bg-green-50'
                              : index === selectedAnswer && index !== question.correct
                              ? 'border-red-500 bg-red-50'
                              : 'border-gray-200 bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{option}</span>
                            {index === question.correct && <CheckCircle className="w-5 h-5 text-green-600" />}
                            {index === selectedAnswer && index !== question.correct && <span className="text-red-600">✗</span>}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="p-4 bg-blue-50 rounded-lg mb-6">
                      <h4 className="font-semibold text-blue-900 mb-2">Explanation:</h4>
                      <p className="text-blue-800">{question.explanation}</p>
                    </div>

                    <div className="text-center">
                      <div className={`inline-flex items-center px-4 py-2 rounded-lg mb-4 ${
                        isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {isCorrect ? (
                          <>
                            <CheckCircle className="w-5 h-5 mr-2" />
                            Correct!
                          </>
                        ) : (
                          <>
                            <span className="text-xl mr-2">✗</span>
                            Not quite right
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-center">
                      <Button onClick={nextQuestion} className="bg-purple-600 hover:bg-purple-700">
                        {currentQuestion < quiz.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/courses">
            <Button variant="ghost" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Courses
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">🛡️ Insurance for Starters</h1>
            <p className="text-gray-600">Master the fundamentals of life insurance and wealth protection</p>
          </div>
        </div>

        {/* Course Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <BookOpen className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{modules.length}</div>
              <div className="text-sm text-gray-600">Modules</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Clock className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">1.5</div>
              <div className="text-sm text-gray-600">Hours</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">2.5K+</div>
              <div className="text-sm text-gray-600">Students</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Star className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">4.9</div>
              <div className="text-sm text-gray-600">Rating</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your Progress</CardTitle>
            <CardDescription>
              {completedModules.length} of {modules.length} modules completed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={overallProgress} className="mb-4" />
            <div className="text-sm text-gray-600">
              {Math.round(overallProgress)}% Complete
            </div>
          </CardContent>
        </Card>

        {/* Modules */}
        <div className="grid grid-cols-1 gap-6">
          {modules.map((module) => {
            const isCompleted = completedModules.includes(module.id);
            const quizScore = quizResults[module.id];
            
            return (
              <Card key={module.id} className={`transition-all duration-300 ${isCompleted ? 'border-green-200 bg-green-50' : 'hover:shadow-lg'}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h3 className="text-xl font-semibold text-gray-900 mr-3">{module.title}</h3>
                        {isCompleted && <CheckCircle className="w-5 h-5 text-green-600" />}
                        <Badge variant="outline" className="ml-2">{module.difficulty}</Badge>
                      </div>
                      <p className="text-gray-600 mb-4">{module.description}</p>
                      
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="w-4 h-4 mr-1" />
                          {module.duration}
                        </div>
                        {quizScore && (
                          <div className="flex items-center text-sm text-gray-500">
                            <Trophy className="w-4 h-4 mr-1" />
                            Quiz Score: {quizScore}%
                          </div>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {module.topics.map((topic, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2 ml-4">
                      <Button 
                        onClick={() => openModule(module.id)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Start Module
                      </Button>
                      <Button 
                        onClick={() => startQuiz(module.id)}
                        variant="outline"
                        className="border-purple-300 text-purple-700 hover:bg-purple-50"
                      >
                        <Brain className="w-4 h-4 mr-2" />
                        Take Quiz
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Certificate Section */}
        {completedModules.length === modules.length && (
          <Card className="mt-8 border-yellow-200 bg-yellow-50">
            <CardContent className="p-8 text-center">
              <Trophy className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-yellow-900 mb-2">Congratulations!</h3>
              <p className="text-yellow-800 mb-6">
                You've completed the Insurance for Starters course. You're now ready to make informed decisions about life insurance!
              </p>
              <Button className="bg-yellow-600 hover:bg-yellow-700">
                <Trophy className="w-4 h-4 mr-2" />
                Download Certificate
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}