import { Link } from "wouter";
import { ArrowLeft, Target, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function SavingsGoalCalculator() {
  const [goalAmount, setGoalAmount] = useState(5000);
  const [currentSavings, setCurrentSavings] = useState(500);
  const [monthlyDeposit, setMonthlyDeposit] = useState(200);
  const [interestRate, setInterestRate] = useState(4);

  const calculateTimeToGoal = () => {
    if (monthlyDeposit <= 0) return { months: 0, years: 0 };
    
    const monthlyRate = interestRate / 100 / 12;
    const remainingAmount = goalAmount - currentSavings;
    
    if (remainingAmount <= 0) {
      return { months: 0, years: 0, alreadyReached: true };
    }
    
    if (monthlyRate === 0) {
      const months = Math.ceil(remainingAmount / monthlyDeposit);
      return { months, years: Math.floor(months / 12) };
    }
    
    // Using the formula for future value of annuity to solve for time
    const futureValueCurrent = currentSavings * Math.pow(1 + monthlyRate, 12);
    let months = 0;
    let runningTotal = currentSavings;
    
    while (runningTotal < goalAmount && months < 600) { // max 50 years
      runningTotal = runningTotal * (1 + monthlyRate) + monthlyDeposit;
      months++;
    }
    
    return { months, years: Math.floor(months / 12) };
  };

  const calculateRequiredMonthly = () => {
    const remainingAmount = goalAmount - currentSavings;
    const timeInYears = 5; // Calculate for 5 years
    const monthlyRate = interestRate / 100 / 12;
    const months = timeInYears * 12;
    
    if (remainingAmount <= 0) return 0;
    if (monthlyRate === 0) return remainingAmount / months;
    
    // Future value of current savings after 5 years
    const futureValueCurrent = currentSavings * Math.pow(1 + monthlyRate, months);
    const remainingAfterGrowth = goalAmount - futureValueCurrent;
    
    if (remainingAfterGrowth <= 0) return 0;
    
    // Required monthly payment using annuity formula
    const requiredMonthly = remainingAfterGrowth * monthlyRate / 
      (Math.pow(1 + monthlyRate, months) - 1);
    
    return Math.max(0, requiredMonthly);
  };

  const timeResults = calculateTimeToGoal();
  const requiredMonthly = calculateRequiredMonthly();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/tools">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2 text-white border-white/30 hover:bg-white/10 mr-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Calculators
                </Button>
              </Link>
              <div className="flex items-center">
                <Target className="w-8 h-8 mr-3" />
                <div>
                  <h1 className="text-2xl font-bold">Savings Goal Calculator</h1>
                  <p className="text-blue-100">Plan your path to financial goals</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Calculator Card */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center mb-6">
              <Calculator className="w-6 h-6 mr-3 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Goal Calculator</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Goal Amount ($)
                  </label>
                  <input
                    type="number"
                    value={goalAmount}
                    onChange={(e) => setGoalAmount(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Savings ($)
                  </label>
                  <input
                    type="number"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Savings ($)
                  </label>
                  <input
                    type="number"
                    value={monthlyDeposit}
                    onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Annual Interest Rate (%)
                  </label>
                  <input
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    step="0.1"
                  />
                </div>
              </div>
              
              {/* Results Section */}
              <div className="space-y-4">
                {timeResults.alreadyReached ? (
                  <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                    <h3 className="font-bold text-green-700 mb-2">Congratulations!</h3>
                    <p className="text-green-600">You've already reached your goal!</p>
                  </div>
                ) : (
                  <>
                    <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                      <h3 className="font-bold text-blue-700 mb-2">Time to Reach Goal</h3>
                      {timeResults.years > 0 ? (
                        <p className="text-xl font-bold text-blue-600">
                          {timeResults.years} years, {timeResults.months % 12} months
                        </p>
                      ) : (
                        <p className="text-xl font-bold text-blue-600">
                          {timeResults.months} months
                        </p>
                      )}
                    </div>
                    
                    <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-400">
                      <h3 className="font-bold text-purple-700 mb-2">Progress</h3>
                      <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                        <div 
                          className="bg-purple-600 h-3 rounded-full transition-all duration-300"
                          style={{ width: `${Math.min((currentSavings / goalAmount) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <p className="text-purple-600 font-bold">
                        {((currentSavings / goalAmount) * 100).toFixed(1)}% complete
                      </p>
                    </div>
                  </>
                )}
                
                <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                  <h3 className="font-bold text-yellow-700 mb-2">To Reach Goal in 5 Years</h3>
                  <p className="text-lg font-bold text-yellow-600">
                    Save ${requiredMonthly.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} per month
                  </p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h3 className="font-bold text-green-700 mb-2">Amount Still Needed</h3>
                  <p className="text-lg font-bold text-green-600">
                    ${Math.max(0, goalAmount - currentSavings).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Goal Ideas */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Popular Savings Goals</h2>
            <div className="grid md:grid-cols-4 gap-4">
              <div 
                className="bg-blue-50 p-4 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors"
                onClick={() => setGoalAmount(1000)}
              >
                <div className="text-2xl mb-2">🎮</div>
                <h3 className="font-bold text-blue-700 mb-1">Gaming Setup</h3>
                <p className="text-blue-600 font-bold">$1,000</p>
              </div>
              <div 
                className="bg-green-50 p-4 rounded-lg cursor-pointer hover:bg-green-100 transition-colors"
                onClick={() => setGoalAmount(5000)}
              >
                <div className="text-2xl mb-2">🚗</div>
                <h3 className="font-bold text-green-700 mb-1">First Car</h3>
                <p className="text-green-600 font-bold">$5,000</p>
              </div>
              <div 
                className="bg-purple-50 p-4 rounded-lg cursor-pointer hover:bg-purple-100 transition-colors"
                onClick={() => setGoalAmount(10000)}
              >
                <div className="text-2xl mb-2">🎓</div>
                <h3 className="font-bold text-purple-700 mb-1">College Fund</h3>
                <p className="text-purple-600 font-bold">$10,000</p>
              </div>
              <div 
                className="bg-orange-50 p-4 rounded-lg cursor-pointer hover:bg-orange-100 transition-colors"
                onClick={() => setGoalAmount(2500)}
              >
                <div className="text-2xl mb-2">✈️</div>
                <h3 className="font-bold text-orange-700 mb-1">Dream Trip</h3>
                <p className="text-orange-600 font-bold">$2,500</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}