import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Filter } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import businessImage from "@assets/business pic.jpg";
import trustImage from "@assets/Trust for Starters.jpg";
import bankingImage from "@assets/financial education.jpg";

export default function Courses() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const { user } = useAuth();

  const { data: courses = [], isLoading } = useQuery({
    queryKey: ["/api/courses", { search: searchQuery, category: categoryFilter !== "all" ? categoryFilter : undefined }],
    queryFn: () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (categoryFilter !== "all") params.append("category", categoryFilter);
      if (typeFilter === "free") params.append("isFree", "true");
      else if (typeFilter === "paid") params.append("isFree", "false");
      
      return fetch(`/api/courses?${params}`).then(res => res.json());
    },
  });

  const allCourses = courses;

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/enrollments"],
  });

  const enrolledCourseIds = new Set(enrollments.map(e => e.courseId));

  const handleSearch = () => {
    // The query will automatically refetch due to the dependency on searchQuery
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white lg:hidden flex flex-col justify-center items-center space-y-8 text-xl font-semibold text-gray-800">
          <a href="/" className="hover:text-blue-600 transition-colors">Home</a>
          <a href="/dashboard" className="hover:text-blue-600 transition-colors">Dashboard</a>
          <a href="/subscribe" className="hover:text-blue-600 transition-colors">Membership</a>
          <Button 
            onClick={() => window.location.href = '/api/logout'}
            variant="outline"
            className="px-8 py-3 rounded-full font-semibold"
          >
            Sign Out
          </Button>
        </div>
      )}

      {/* Page Header */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Course <span className="relative">Library
                <div className="absolute bottom-0 left-0 w-full h-2 bg-yellow-400 rounded -z-10"></div>
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Explore our comprehensive collection of financial education courses designed to build your wealth knowledge.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="bg-white py-8 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="w-full pl-4 pr-12 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Button 
                onClick={handleSearch}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>

            {/* Filters */}
            <div className="flex gap-4 items-center">
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="credit">Credit Building</SelectItem>
                  <SelectItem value="estate">Estate Planning</SelectItem>
                  <SelectItem value="business">Business Formation</SelectItem>
                  <SelectItem value="banking">Banking Strategies</SelectItem>
                  <SelectItem value="investment">Investment</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Courses</SelectItem>
                  <SelectItem value="free">Free Only</SelectItem>
                  <SelectItem value="paid">Premium</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quick Filter Tags */}
          <div className="flex flex-wrap gap-2 mt-4">
            <Badge 
              variant={categoryFilter === "all" ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setCategoryFilter("all")}
            >
              All
            </Badge>
            <Badge 
              variant={categoryFilter === "credit" ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setCategoryFilter("credit")}
            >
              Credit Building
            </Badge>
            <Badge 
              variant={categoryFilter === "estate" ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setCategoryFilter("estate")}
            >
              Estate Planning
            </Badge>
            <Badge 
              variant={categoryFilter === "business" ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setCategoryFilter("business")}
            >
              Business Formation
            </Badge>
            <Badge 
              variant={categoryFilter === "banking" ? "default" : "secondary"}
              className="cursor-pointer"
              onClick={() => setCategoryFilter("banking")}
            >
              Banking
            </Badge>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {allCourses.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="w-16 h-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No courses found</h3>
              <p className="text-gray-600 mb-4">Try adjusting your search criteria or filters</p>
              <Button 
                onClick={() => {
                  setSearchQuery("");
                  setCategoryFilter("all");
                  setTypeFilter("all");
                }}
                variant="outline"
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900">
                  {allCourses.length} Course{allCourses.length !== 1 ? 's' : ''} Found
                </h2>
                
                <div className="text-sm text-gray-600">
                  {user?.membershipTier === 'free' && (
                    <span className="mr-4">
                      Free Member - {allCourses.filter(c => c.isFree).length} free courses available
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {allCourses.map((course) => (
                  <CourseCard 
                    key={course.id} 
                    course={course} 
                    showEnrollButton={true}
                    isEnrolled={enrolledCourseIds.has(course.id)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
