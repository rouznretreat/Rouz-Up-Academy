import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Home, DollarSign, TrendingUp, Users, MapPin, Wrench, Key } from "lucide-react";
import { Link } from "wouter";

interface Property {
  id: number;
  address: string;
  type: 'single-family' | 'condo' | 'duplex' | 'apartment';
  purchasePrice: number;
  monthlyRent: number;
  renovationCost: number;
  marketValue: number;
  cashFlow: number;
  roi: number;
  owned: boolean;
}

export default function RealEstateGame() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [money, setMoney] = useState(50000);
  const [monthlyIncome, setMonthlyIncome] = useState(0);
  const [ownedProperties, setOwnedProperties] = useState<Property[]>([]);
  const [gameMonth, setGameMonth] = useState(1);
  const [totalROI, setTotalROI] = useState(0);

  const availableProperties: Property[] = [
    {
      id: 1,
      address: "123 Starter St",
      type: 'single-family',
      purchasePrice: 45000,
      monthlyRent: 800,
      renovationCost: 5000,
      marketValue: 55000,
      cashFlow: 400,
      roi: 10.7,
      owned: false
    },
    {
      id: 2,
      address: "456 Downtown Ave",
      type: 'condo',
      purchasePrice: 75000,
      monthlyRent: 1200,
      renovationCost: 8000,
      marketValue: 85000,
      cashFlow: 600,
      roi: 9.6,
      owned: false
    },
    {
      id: 3,
      address: "789 Investment Blvd",
      type: 'duplex',
      purchasePrice: 120000,
      monthlyRent: 2000,
      renovationCost: 15000,
      marketValue: 140000,
      cashFlow: 1200,
      roi: 12.0,
      owned: false
    },
    {
      id: 4,
      address: "321 Luxury Lane",
      type: 'apartment',
      purchasePrice: 200000,
      monthlyRent: 3000,
      renovationCost: 25000,
      marketValue: 230000,
      cashFlow: 1800,
      roi: 10.8,
      owned: false
    }
  ];

  const buyProperty = (property: Property) => {
    const totalCost = property.purchasePrice + property.renovationCost;
    if (money >= totalCost) {
      setMoney(money - totalCost);
      setMonthlyIncome(monthlyIncome + property.cashFlow);
      setOwnedProperties([...ownedProperties, { ...property, owned: true }]);
      setTotalROI(totalROI + property.roi);
    }
  };

  const sellProperty = (propertyId: number) => {
    const property = ownedProperties.find(p => p.id === propertyId);
    if (property) {
      setMoney(money + property.marketValue);
      setMonthlyIncome(monthlyIncome - property.cashFlow);
      setOwnedProperties(ownedProperties.filter(p => p.id !== propertyId));
      setTotalROI(totalROI - property.roi);
    }
  };

  const nextMonth = () => {
    setGameMonth(gameMonth + 1);
    setMoney(money + monthlyIncome);
  };

  const getPropertyIcon = (type: string) => {
    switch (type) {
      case 'single-family': return '🏠';
      case 'condo': return '🏢';
      case 'duplex': return '🏘️';
      case 'apartment': return '🏙️';
      default: return '🏠';
    }
  };

  const getPropertyColor = (type: string) => {
    switch (type) {
      case 'single-family': return 'from-blue-500 to-blue-600';
      case 'condo': return 'from-green-500 to-green-600';
      case 'duplex': return 'from-purple-500 to-purple-600';
      case 'apartment': return 'from-red-500 to-red-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/games">
            <Button variant="outline" className="bg-white text-blue-600 border-blue-200 hover:bg-blue-50">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Games
            </Button>
          </Link>
        </div>

        {/* Game Header */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🏘️</div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Real Estate Investment Game</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Build your real estate empire! Buy properties, collect rent, and grow your wealth through smart investments.
          </p>
        </div>

        {/* Game Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-bold text-gray-900">Cash Available</h3>
              <p className="text-2xl font-bold text-green-600">${money.toLocaleString()}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-bold text-gray-900">Monthly Income</h3>
              <p className="text-2xl font-bold text-blue-600">${monthlyIncome.toLocaleString()}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Home className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <h3 className="font-bold text-gray-900">Properties Owned</h3>
              <p className="text-2xl font-bold text-purple-600">{ownedProperties.length}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <h3 className="font-bold text-gray-900">Month</h3>
              <p className="text-2xl font-bold text-orange-600">{gameMonth}</p>
            </CardContent>
          </Card>
        </div>

        {/* Game Actions */}
        <div className="mb-8 text-center">
          <Button 
            onClick={nextMonth}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg"
          >
            Next Month (+${monthlyIncome.toLocaleString()} income)
          </Button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Available Properties */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">🏠 Properties for Sale</h2>
            <div className="space-y-4">
              {availableProperties.filter(p => !ownedProperties.some(owned => owned.id === p.id)).map((property) => (
                <Card key={property.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-2xl">{getPropertyIcon(property.type)}</span>
                          <h3 className="text-lg font-bold text-gray-900">{property.address}</h3>
                        </div>
                        <p className="text-sm text-gray-600 capitalize mb-2">{property.type.replace('-', ' ')}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">ROI</p>
                        <p className="text-lg font-bold text-green-600">{property.roi}%</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                      <div>
                        <p className="text-gray-600">Purchase Price</p>
                        <p className="font-bold">${property.purchasePrice.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Renovation Cost</p>
                        <p className="font-bold">${property.renovationCost.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Monthly Rent</p>
                        <p className="font-bold text-green-600">${property.monthlyRent.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Monthly Cash Flow</p>
                        <p className="font-bold text-blue-600">${property.cashFlow.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-600">Total Investment</p>
                          <p className="text-lg font-bold">${(property.purchasePrice + property.renovationCost).toLocaleString()}</p>
                        </div>
                        <Button 
                          onClick={() => buyProperty(property)}
                          disabled={money < (property.purchasePrice + property.renovationCost)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          <Key className="w-4 h-4 mr-2" />
                          Buy Property
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Owned Properties */}
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">🏡 Your Portfolio</h2>
            {ownedProperties.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <Home className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">You don't own any properties yet. Start building your real estate empire!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {ownedProperties.map((property) => (
                  <Card key={property.id} className="border-green-200 bg-green-50">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-2xl">{getPropertyIcon(property.type)}</span>
                            <h3 className="text-lg font-bold text-gray-900">{property.address}</h3>
                          </div>
                          <p className="text-sm text-gray-600 capitalize">{property.type.replace('-', ' ')}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Monthly Income</p>
                          <p className="text-lg font-bold text-green-600">${property.cashFlow.toLocaleString()}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                        <div>
                          <p className="text-gray-600">Market Value</p>
                          <p className="font-bold">${property.marketValue.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">ROI</p>
                          <p className="font-bold text-green-600">{property.roi}%</p>
                        </div>
                      </div>

                      <Button 
                        onClick={() => sellProperty(property.id)}
                        variant="outline"
                        className="w-full border-red-200 text-red-600 hover:bg-red-50"
                      >
                        Sell Property (${property.marketValue.toLocaleString()})
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Learning Section */}
        <Card className="mt-8 bg-gradient-to-r from-purple-500 to-pink-600 text-white">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-4">💡 Real Estate Investment Tips</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold mb-2">🔍 Key Metrics to Watch:</h4>
                <ul className="text-sm space-y-1">
                  <li>• <strong>ROI (Return on Investment):</strong> Annual return percentage</li>
                  <li>• <strong>Cash Flow:</strong> Monthly income after expenses</li>
                  <li>• <strong>Cap Rate:</strong> Net income ÷ property value</li>
                  <li>• <strong>Market Value:</strong> Current worth of the property</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-2">💰 Investment Strategies:</h4>
                <ul className="text-sm space-y-1">
                  <li>• Start with properties that generate positive cash flow</li>
                  <li>• Diversify across different property types</li>
                  <li>• Factor in renovation costs before buying</li>
                  <li>• Consider selling when market values peak</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}