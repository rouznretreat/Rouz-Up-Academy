import { Link } from "wouter";
import { useState } from "react";
import BankingQuiz from "@/components/BankingQuiz";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CompoundInterest() {
  const [showQuiz, setShowQuiz] = useState(false);

  if (showQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-100">
        <div className="bg-white shadow-sm border-b p-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Compound Interest
            </Button>
          </div>
        </div>
        <div className="p-4">
          <BankingQuiz moduleType="compound-interest" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Banking Modules
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-12">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-block bg-orange-500 text-orange-100 px-4 py-2 rounded-full text-sm font-medium mb-4">
            Learning Module
          </div>
          <h1 className="text-5xl font-bold mb-4">Compound Interest</h1>
          <p className="text-xl text-orange-100 mb-6">12 minute read</p>
          <div className="inline-block bg-white text-orange-600 px-6 py-3 rounded-full font-semibold shadow-lg">
            ⚡ The "eighth wonder of the world"
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-6 -mt-8 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">⚡</div>
            <h2 className="text-3xl font-bold text-gray-900">The Magic of Compound Interest!</h2>
            <p className="text-gray-600 mt-2">Einstein's favorite financial concept</p>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-yellow-500">
            <div className="flex items-center mb-4">
              <div className="text-3xl mr-4">✨</div>
              <h2 className="text-3xl font-bold text-gray-900">The Power of Compound Interest</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">
              Compound interest has been called the "eighth wonder of the world" by Albert Einstein because of its incredible ability to grow money over time. It's one of the most important concepts to understand in personal finance!
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-blue-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🤔</div>
              <h2 className="text-3xl font-bold text-gray-900">What is Compound Interest?</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              Compound interest is when you earn interest not just on your original investment (the principal), but also on the interest you've already earned. It's like a snowball that gets bigger as it rolls downhill.
            </p>
            
            <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
              <div className="flex items-center mb-4">
                <span className="text-2xl mr-3">⚙️</span>
                <h3 className="text-xl font-bold text-blue-900">How Compound Interest Works:</h3>
              </div>
              <div className="grid gap-4">
                <div className="flex items-start">
                  <span className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 font-bold">1</span>
                  <p className="text-blue-800">You deposit money into an account that earns interest</p>
                </div>
                <div className="flex items-start">
                  <span className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 font-bold">2</span>
                  <p className="text-blue-800">After a period (usually a month, quarter, or year), interest is calculated and added to your balance</p>
                </div>
                <div className="flex items-start">
                  <span className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 font-bold">3</span>
                  <p className="text-blue-800">In the next period, interest is calculated on your new balance (original deposit + previous interest)</p>
                </div>
                <div className="flex items-start">
                  <span className="bg-blue-500 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 font-bold">4</span>
                  <p className="text-blue-800">This cycle continues, with your money growing faster over time</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-green-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">⚖️</div>
              <h2 className="text-3xl font-bold text-gray-900">Simple vs. Compound Interest</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="p-6 bg-gradient-to-br from-red-50 to-red-100 rounded-xl border border-red-200">
                <div className="text-center">
                  <div className="text-3xl mb-3">📉</div>
                  <h3 className="text-xl font-bold text-red-700 mb-3">Simple Interest:</h3>
                  <p className="text-red-600 font-medium">You only earn interest on your principal (original amount)</p>
                </div>
              </div>
              <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200">
                <div className="text-center">
                  <div className="text-3xl mb-3">📈</div>
                  <h3 className="text-xl font-bold text-green-700 mb-3">Compound Interest:</h3>
                  <p className="text-green-600 font-medium">You earn interest on your principal AND on previously earned interest</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-purple-500">
            <div className="flex items-center mb-4">
              <div className="text-3xl mr-4">⏰</div>
              <h2 className="text-3xl font-bold text-gray-900">The Power of Time</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">
              The true power of compound interest comes from time. The longer your money compounds, the more dramatic the growth. This is why starting to save and invest early is so important.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-indigo-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">📊</div>
              <h2 className="text-3xl font-bold text-gray-900">Example: $1,000 at 10% Annual Interest</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-indigo-50">
                    <th className="border border-indigo-200 p-3 text-left font-bold text-indigo-900">Year</th>
                    <th className="border border-indigo-200 p-3 text-left font-bold text-indigo-900">Starting Amount</th>
                    <th className="border border-indigo-200 p-3 text-left font-bold text-indigo-900">Interest Earned</th>
                    <th className="border border-indigo-200 p-3 text-left font-bold text-indigo-900">Ending Balance</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-3">1</td>
                    <td className="border border-gray-200 p-3">$1,000.00</td>
                    <td className="border border-gray-200 p-3">$100.00</td>
                    <td className="border border-gray-200 p-3 font-bold text-green-600">$1,100.00</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-3">2</td>
                    <td className="border border-gray-200 p-3">$1,100.00</td>
                    <td className="border border-gray-200 p-3">$110.00</td>
                    <td className="border border-gray-200 p-3 font-bold text-green-600">$1,210.00</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-3">5</td>
                    <td className="border border-gray-200 p-3">$1,464.10</td>
                    <td className="border border-gray-200 p-3">$146.41</td>
                    <td className="border border-gray-200 p-3 font-bold text-green-600">$1,610.51</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-3">10</td>
                    <td className="border border-gray-200 p-3">$2,593.74</td>
                    <td className="border border-gray-200 p-3">$259.37</td>
                    <td className="border border-gray-200 p-3 font-bold text-green-600">$2,853.12</td>
                  </tr>
                  <tr className="hover:bg-gray-50 bg-yellow-50">
                    <td className="border border-gray-200 p-3 font-bold">30</td>
                    <td className="border border-gray-200 p-3 font-bold">$17,449.40</td>
                    <td className="border border-gray-200 p-3 font-bold">$1,744.94</td>
                    <td className="border border-gray-200 p-3 font-bold text-green-600 text-lg">$19,194.34</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-yellow-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🧮</div>
              <h2 className="text-3xl font-bold text-gray-900">The Rule of 72</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              The Rule of 72 is a simple way to estimate how long it will take for your money to double. Just divide 72 by the interest rate:
            </p>
            <div className="bg-yellow-50 p-6 rounded-xl border border-yellow-200 mb-6">
              <p className="text-center text-2xl font-bold text-yellow-700">
                Years to double your money = 72 ÷ Interest Rate (%)
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                <div className="text-2xl mb-2">🐌</div>
                <p className="font-bold text-blue-700">At 4% interest:</p>
                <p className="text-blue-600 text-lg">72 ÷ 4 = 18 years</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg border border-green-200">
                <div className="text-2xl mb-2">🚶</div>
                <p className="font-bold text-green-700">At 6% interest:</p>
                <p className="text-green-600 text-lg">72 ÷ 6 = 12 years</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg border border-purple-200">
                <div className="text-2xl mb-2">🏃</div>
                <p className="font-bold text-purple-700">At 12% interest:</p>
                <p className="text-purple-600 text-lg">72 ÷ 12 = 6 years</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-500 to-red-600 text-white p-8 rounded-2xl shadow-xl">
            <div className="flex items-center mb-4">
              <div className="text-4xl mr-4">👨‍👩‍👧‍👦</div>
              <h2 className="text-3xl font-bold">Family Discussion Prompt</h2>
            </div>
            <div className="bg-white bg-opacity-20 p-6 rounded-xl">
              <p className="text-xl leading-relaxed">
                If you save $50 per month starting at age 15, and it earns 8% interest compounded annually, how much would you have by age 65? Calculate this together and discuss the impact of starting to save early.
              </p>
            </div>
          </div>

          {/* Quiz Section */}
          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <div className="text-xl mr-2">🧠</div>
                <h2 className="text-lg font-bold text-gray-900">Test Your Knowledge</h2>
              </div>
              <div className="text-xs text-gray-500">5 questions</div>
            </div>
            <p className="text-gray-700 text-xs mb-3">
              Ready to test what you've learned about compound interest?
            </p>
            <button 
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded text-sm"
              onClick={() => setShowQuiz(true)}
            >
              Start Compound Interest Quiz
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}