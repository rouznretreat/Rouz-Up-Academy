import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Heart, CheckCircle, TrendingUp, Users, DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule1() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-blue-700 flex items-center space-x-3">
              <Heart className="w-8 h-8" />
              <span>Module 1: What is Estate Planning?</span>
            </CardTitle>
            <p className="text-gray-600">Understanding the basics of estate planning and why it matters</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-blue-50 p-6 rounded border-l-4 border-blue-500">
              <h3 className="text-lg font-bold text-blue-700 mb-4">🎯 Learning Objectives</h3>
              <ul className="space-y-2 text-blue-700">
                <li>• Understand estate planning as a wealth-building discipline</li>
                <li>• Discover why it's about enhancing your life, not just planning for death</li>
                <li>• Learn how estate planning creates generational wealth</li>
                <li>• See real examples of estate planning in action</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-blue-600">Estate Planning: Your Wealth-Building Superpower</h3>
              
              <p className="text-gray-700 leading-relaxed">
                <strong>Most people think estate planning is about death, but that's completely wrong!</strong> Estate planning is actually a powerful wealth-building discipline that enhances your life and creates opportunities for generational wealth. It's about making smart decisions today that benefit you and your family for decades to come.
              </p>

              <div className="bg-green-50 p-4 rounded border border-green-300">
                <h4 className="font-bold text-green-700 mb-2">🌟 The Real Purpose of Estate Planning</h4>
                <p className="text-green-700 text-sm">
                  Estate planning isn't about preparing to die - it's about preparing to live! It's the strategic organization of your life and wealth to maximize opportunities, minimize taxes, and create lasting security for your family.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-blue-600">Why Estate Planning is Actually About LIFE</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="border-l-4 border-green-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <TrendingUp className="w-6 h-6 text-green-600 mt-1" />
                      <div>
                        <h4 className="font-bold text-green-700 mb-2">Wealth Building</h4>
                        <p className="text-sm text-gray-700">
                          Smart estate planning structures help you build wealth faster through tax advantages and strategic organization.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <Users className="w-6 h-6 text-blue-600 mt-1" />
                      <div>
                        <h4 className="font-bold text-blue-700 mb-2">Family Security</h4>
                        <p className="text-sm text-gray-700">
                          Protect your family's financial future and ensure they have the resources they need to thrive.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-purple-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <DollarSign className="w-6 h-6 text-purple-600 mt-1" />
                      <div>
                        <h4 className="font-bold text-purple-700 mb-2">Tax Advantages</h4>
                        <p className="text-sm text-gray-700">
                          Reduce taxes during your lifetime and minimize the tax burden on your heirs.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-orange-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <Heart className="w-6 h-6 text-orange-600 mt-1" />
                      <div>
                        <h4 className="font-bold text-orange-700 mb-2">Peace of Mind</h4>
                        <p className="text-sm text-gray-700">
                          Know that your family is protected and your wishes will be honored, no matter what happens.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-blue-600">Real-Life Examples of Estate Planning Success</h3>
              
              <div className="space-y-4">
                <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                  <h4 className="font-bold text-yellow-700 mb-2">🏠 Example 1: The Johnson Family</h4>
                  <p className="text-yellow-700 text-sm mb-2">
                    <strong>Situation:</strong> Parents with young children worried about what would happen if something happened to them.
                  </p>
                  <p className="text-yellow-700 text-sm">
                    <strong>Estate Planning Solution:</strong> Created a revocable trust that ensures their children's education is funded, named trusted guardians, and set up life insurance to replace lost income. Now they sleep peacefully knowing their kids are protected.
                  </p>
                </div>

                <div className="bg-purple-50 p-4 rounded border border-purple-300">
                  <h4 className="font-bold text-purple-700 mb-2">💼 Example 2: The Martinez Business Owners</h4>
                  <p className="text-purple-700 text-sm mb-2">
                    <strong>Situation:</strong> Successful business owners wanting to pass their company to their children while minimizing taxes.
                  </p>
                  <p className="text-purple-700 text-sm">
                    <strong>Estate Planning Solution:</strong> Used advanced trust strategies to transfer business ownership gradually, reducing taxes by millions and ensuring smooth business continuation for the next generation.
                  </p>
                </div>

                <div className="bg-teal-50 p-4 rounded border border-teal-300">
                  <h4 className="font-bold text-teal-700 mb-2">🏥 Example 3: The Chen Grandparents</h4>
                  <p className="text-teal-700 text-sm mb-2">
                    <strong>Situation:</strong> Grandparents wanting to help pay for grandchildren's college while getting tax benefits.
                  </p>
                  <p className="text-teal-700 text-sm">
                    <strong>Estate Planning Solution:</strong> Established 529 education trusts that grow tax-free and created a gifting strategy that reduces their estate taxes while funding their grandchildren's education.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-blue-600">Building Generational Wealth</h3>
              
              <p className="text-gray-700 leading-relaxed">
                The most exciting part of estate planning is its power to create <strong>generational wealth</strong> - money and assets that benefit not just you, but your children, grandchildren, and beyond. This is how wealthy families stay wealthy for generations.
              </p>

              <div className="bg-indigo-50 p-6 rounded border border-indigo-300">
                <h4 className="font-bold text-indigo-700 mb-4">🏆 The Generational Wealth Formula:</h4>
                <div className="space-y-3 text-sm text-indigo-700">
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">1.</span>
                    <span><strong>Smart Structures:</strong> Use trusts and business entities to protect and grow wealth</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">2.</span>
                    <span><strong>Tax Efficiency:</strong> Minimize taxes so more money stays in your family</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">3.</span>
                    <span><strong>Education:</strong> Teach your children how to manage and grow inherited wealth</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">4.</span>
                    <span><strong>Values:</strong> Pass along the values and work ethic that created the wealth</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-blue-600">Test Your Understanding</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">1. What is the main purpose of estate planning?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Estate planning is a wealth-building discipline that enhances your life and creates generational wealth, not just planning for death.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">2. How does estate planning help build wealth?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Through tax advantages, strategic organization, and creating structures that protect and grow assets over time.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">3. What is generational wealth?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Money and assets that benefit not just you, but your children, grandchildren, and future generations through smart planning and structures.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Module 1 Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                Excellent! You now understand that estate planning is really about building wealth and enhancing your life. You've learned how it creates generational wealth and seen real examples of families using estate planning to secure their futures.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-module-2">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Next: Estate Planning vs Administration →
                  </Button>
                </Link>
                <Link href="/estate-planning-course">
                  <Button variant="outline" className="border-teal-500 text-teal-600">
                    Back to Course Overview
                  </Button>
                </Link>
              </div>
            </div>

            {/* Next Module Button at Bottom */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Test Your Knowledge!</h3>
                  <p className="mb-4">Ready to see how well you understand estate planning as a wealth-building discipline?</p>
                  <Link href="/estate-quiz-1">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 1 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-planning-course">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Back to Course
                  </Button>
                </Link>
                <Link href="/estate-module-2">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Next Module: Estate Planning vs Administration →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}