import { Link } from "wouter";
import { ArrowLeft, Car, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function CarSavingsCalculator() {
  const [carPrice, setCarPrice] = useState(8000);
  const [downPayment, setDownPayment] = useState(2000);
  const [currentSavings, setCurrentSavings] = useState(500);
  const [monthlyIncome, setMonthlyIncome] = useState(600);
  const [savePercentage, setSavePercentage] = useState(40);
  const [interestRate, setInterestRate] = useState(3);

  const calculateCarSavings = () => {
    const totalNeeded = carPrice;
    const remainingForDownPayment = downPayment - currentSavings;
    const monthlySavings = monthlyIncome * (savePercentage / 100);
    const monthlyRate = interestRate / 100 / 12;
    
    // Time to save for down payment
    let monthsToDownPayment = 0;
    if (remainingForDownPayment > 0) {
      if (monthlyRate > 0) {
        // With interest earning
        let runningTotal = currentSavings;
        while (runningTotal < downPayment && monthsToDownPayment < 120) {
          runningTotal = runningTotal * (1 + monthlyRate) + monthlySavings;
          monthsToDownPayment++;
        }
      } else {
        monthsToDownPayment = Math.ceil(remainingForDownPayment / monthlySavings);
      }
    }
    
    // Calculate loan details if financing
    const loanAmount = carPrice - downPayment;
    const loanTermMonths = 48; // 4 years typical
    const loanRate = 0.06 / 12; // 6% annual rate
    
    let monthlyPayment = 0;
    if (loanAmount > 0) {
      monthlyPayment = loanAmount * (loanRate * Math.pow(1 + loanRate, loanTermMonths)) / 
        (Math.pow(1 + loanRate, loanTermMonths) - 1);
    }
    
    // Calculate if buying cash
    let monthsToFullAmount = 0;
    if (monthlyRate > 0) {
      let runningTotal = currentSavings;
      while (runningTotal < totalNeeded && monthsToFullAmount < 120) {
        runningTotal = runningTotal * (1 + monthlyRate) + monthlySavings;
        monthsToFullAmount++;
      }
    } else {
      monthsToFullAmount = Math.ceil((totalNeeded - currentSavings) / monthlySavings);
    }
    
    return {
      remainingForDownPayment: Math.max(0, remainingForDownPayment),
      monthsToDownPayment,
      monthlySavings,
      loanAmount,
      monthlyPayment,
      monthsToFullAmount,
      totalInterestPaid: (monthlyPayment * loanTermMonths) - loanAmount
    };
  };

  const results = calculateCarSavings();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/tools">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2 text-white border-white/30 hover:bg-white/10 mr-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Calculators
                </Button>
              </Link>
              <div className="flex items-center">
                <Car className="w-8 h-8 mr-3" />
                <div>
                  <h1 className="text-2xl font-bold">Car Savings Calculator</h1>
                  <p className="text-blue-100">Plan your path to car ownership</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Calculator Card */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center mb-6">
              <Calculator className="w-6 h-6 mr-3 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">Car Purchase Planning</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Car Price ($)
                  </label>
                  <input
                    type="number"
                    value={carPrice}
                    onChange={(e) => setCarPrice(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1000"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Down Payment Goal ($)
                  </label>
                  <input
                    type="number"
                    value={downPayment}
                    onChange={(e) => setDownPayment(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    max={carPrice}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Typically 10-20% of car price
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Savings ($)
                  </label>
                  <input
                    type="number"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Income ($)
                  </label>
                  <input
                    type="number"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage to Save ({savePercentage}%)
                  </label>
                  <input
                    type="range"
                    value={savePercentage}
                    onChange={(e) => setSavePercentage(Number(e.target.value))}
                    className="w-full"
                    min="10"
                    max="70"
                    step="5"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>10%</span>
                    <span>70%</span>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Savings Account Interest Rate (%)
                  </label>
                  <input
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    max="10"
                    step="0.1"
                  />
                </div>
              </div>

              {/* Results Section */}
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-4 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Your Car Savings Plan</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Monthly Savings:</span>
                      <span className="font-semibold">${results.monthlySavings.toFixed(0)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Still Need for Down Payment:</span>
                      <span className="font-semibold">${results.remainingForDownPayment.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Time to Down Payment:</span>
                      <span className="font-semibold">{results.monthsToDownPayment} months</span>
                    </div>
                  </div>
                </div>

                {/* Financing vs Cash Comparison */}
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-bold text-green-900 mb-3">💰 Financing vs Cash</h4>
                  
                  <div className="space-y-2 text-sm">
                    <div className="bg-white p-3 rounded border">
                      <div className="font-semibold text-blue-600">Option 1: Financing</div>
                      <div>Down Payment: ${downPayment.toLocaleString()}</div>
                      <div>Loan Amount: ${results.loanAmount.toLocaleString()}</div>
                      <div>Monthly Payment: ${results.monthlyPayment.toFixed(0)}</div>
                      <div>Total Interest: ${results.totalInterestPaid.toFixed(0)}</div>
                      <div className="font-semibold">Ready in: {results.monthsToDownPayment} months</div>
                    </div>
                    
                    <div className="bg-white p-3 rounded border">
                      <div className="font-semibold text-green-600">Option 2: Buy Cash</div>
                      <div>Total Needed: ${carPrice.toLocaleString()}</div>
                      <div>No Interest Paid: $0</div>
                      <div>No Monthly Payments</div>
                      <div className="font-semibold">Ready in: {results.monthsToFullAmount} months</div>
                    </div>
                  </div>
                </div>

                {/* Car Buying Tips */}
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-bold text-yellow-900 mb-2">🚗 Smart Car Buying Tips</h4>
                  <ul className="text-sm text-yellow-800 space-y-1">
                    <li>• Consider certified pre-owned for better value</li>
                    <li>• Factor in insurance, gas, and maintenance costs</li>
                    <li>• Get pre-approved for financing to know your budget</li>
                    <li>• Don't forget registration and tax fees</li>
                    <li>• Emergency fund should cover 3-6 months of car payments</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Car Cost Breakdown */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Monthly Car Ownership Costs</h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold text-blue-600 mb-3">Fixed Costs</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Car Payment</span>
                    <span>${results.monthlyPayment.toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Insurance</span>
                    <span>$100 - $200</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Registration</span>
                    <span>$10 - $30</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-green-600 mb-3">Variable Costs</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Gas</span>
                    <span>$80 - $150</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Maintenance</span>
                    <span>$50 - $100</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Repairs</span>
                    <span>$25 - $75</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-purple-600 mb-3">Total Monthly</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between font-bold">
                    <span>Estimated Total:</span>
                    <span>${(results.monthlyPayment + 300).toFixed(0)}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Budget for 20-25% of income on transportation
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}