import { Link } from "wouter";
import { Calculator, TrendingUp, Target, DollarSign, ArrowRight } from "lucide-react";

export default function Tools() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-4">
            <Calculator className="w-10 h-10 mr-4" />
            <div>
              <h1 className="text-4xl font-bold">Financial Tools</h1>
              <p className="text-purple-100 text-lg">Powerful calculators to plan your financial future</p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* Tools Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Allowance Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-green-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-green-100 p-3 rounded-full mr-4">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Allowance Calculator</h3>
                  <p className="text-green-600 font-medium">Budget planning made easy</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Plan your allowance with three powerful tabs: Basic Budget planning, Savings Growth tracking, and Savings Goal setting. Perfect for learning how to manage money responsibly.
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Budget planning with income vs expenses
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Savings growth visualization
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                  Goal-based savings planning
                </div>
              </div>
              
              <Link href="/allowance-calculator">
                <button className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Start Planning <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>

            {/* Savings Growth Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-blue-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Money Growth Calculator</h3>
                  <p className="text-blue-600 font-medium">See compound interest in action</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Watch your money grow over time with different account types. Compare how starting amount, monthly deposits, and interest rates affect your future wealth.
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Compare different account types
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  See compound interest effects
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  Plan monthly deposits
                </div>
              </div>
              
              <Link href="/savings-growth-calculator">
                <button className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Calculate Growth <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>

            {/* Savings Goal Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-purple-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-purple-100 p-3 rounded-full mr-4">
                  <Target className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Savings Goal Calculator</h3>
                  <p className="text-purple-600 font-medium">Plan your path to dreams</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Set a financial goal and discover exactly how much to save each month to reach it. Includes popular goal presets like gaming setup, first car, or college fund.
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Set and track financial goals
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Calculate required monthly savings
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-purple-500 rounded-full mr-2"></span>
                  Popular goal presets included
                </div>
              </div>
              
              <Link href="/savings-goal-calculator">
                <button className="w-full bg-purple-500 hover:bg-purple-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Set Goals <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>

            {/* Graduation Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-pink-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-pink-100 p-3 rounded-full mr-4">
                  <span className="text-2xl">🎓</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Graduation Savings Calculator</h3>
                  <p className="text-pink-600 font-medium">Plan for your graduation expenses</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Calculate how much to save monthly for graduation costs including cap & gown, photos, announcements, and celebration party. Perfect for planning ahead!
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                  Plan graduation expenses breakdown
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                  Calculate monthly savings needed
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-pink-500 rounded-full mr-2"></span>
                  Money-saving tips included
                </div>
              </div>
              
              <Link href="/graduation-calculator">
                <button className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Plan Graduation <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>

            {/* Car Savings Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-cyan-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-cyan-100 p-3 rounded-full mr-4">
                  <span className="text-2xl">🚗</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Car Savings Calculator</h3>
                  <p className="text-cyan-600 font-medium">Save for your first car</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Compare financing vs buying cash, calculate down payments, and discover total car ownership costs including insurance, gas, and maintenance.
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-cyan-500 rounded-full mr-2"></span>
                  Financing vs cash comparison
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-cyan-500 rounded-full mr-2"></span>
                  Total ownership cost breakdown
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-cyan-500 rounded-full mr-2"></span>
                  Smart car buying tips
                </div>
              </div>
              
              <Link href="/car-savings-calculator">
                <button className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Plan Car Purchase <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>

            {/* Emergency Fund Calculator */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-emerald-500 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <div className="bg-emerald-100 p-3 rounded-full mr-4">
                  <span className="text-2xl">🛡️</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Emergency Fund Calculator</h3>
                  <p className="text-emerald-600 font-medium">Build your financial safety net</p>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4">
                Calculate how much to save for emergencies, explore different emergency scenarios, and learn why having 3-6 months of expenses saved is crucial.
              </p>
              
              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                  Emergency fund goal setting
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                  Progress tracking with visual bar
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                  Real emergency scenarios
                </div>
              </div>
              
              <Link href="/emergency-fund-calculator">
                <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center">
                  Build Safety Net <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              </Link>
            </div>
          </div>

          {/* How to Use Section */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">How to Use the Calculators</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold text-green-600 mb-3">Starting Amount</h3>
                <p className="text-gray-700 mb-4">
                  This is how much money you already have saved that you want to start growing. Even a small amount can grow significantly over time!
                </p>
                
                <h3 className="text-xl font-bold text-blue-600 mb-3">Monthly Deposit</h3>
                <p className="text-gray-700 mb-4">
                  This is how much you plan to save each month. Regular deposits, even small ones, can dramatically increase your savings over time due to compound interest.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-purple-600 mb-3">Time Period</h3>
                <p className="text-gray-700 mb-4">
                  The number of years you plan to save. The longer the time period, the more your money can grow through compound interest - especially with higher interest accounts.
                </p>
                
                <h3 className="text-xl font-bold text-orange-600 mb-3">Account Type</h3>
                <p className="text-gray-700 mb-4">
                  Different types of accounts offer different interest rates. Higher interest rates usually come with either limitations or higher risk.
                </p>
              </div>
            </div>
          </div>

          {/* Account Comparison Table */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Account Type Comparison</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-200 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="border border-gray-200 p-4 text-left font-bold">Account Type</th>
                    <th className="border border-gray-200 p-4 text-left font-bold">Interest Rate</th>
                    <th className="border border-gray-200 p-4 text-left font-bold">Best For</th>
                    <th className="border border-gray-200 p-4 text-left font-bold">Risk Level</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-4 font-medium">Piggy Bank</td>
                    <td className="border border-gray-200 p-4">0%</td>
                    <td className="border border-gray-200 p-4">Short-term cash needs</td>
                    <td className="border border-gray-200 p-4 text-green-600">None</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-4 font-medium">Basic Savings</td>
                    <td className="border border-gray-200 p-4">0.05%</td>
                    <td className="border border-gray-200 p-4">Emergency fund</td>
                    <td className="border border-gray-200 p-4 text-green-600">Very Low</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-4 font-medium">High-Yield Savings</td>
                    <td className="border border-gray-200 p-4">0.70%</td>
                    <td className="border border-gray-200 p-4">Short-term goals (1-2 years)</td>
                    <td className="border border-gray-200 p-4 text-blue-600">Low</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-4 font-medium">Certificate of Deposit</td>
                    <td className="border border-gray-200 p-4">1.50%</td>
                    <td className="border border-gray-200 p-4">Medium-term goals (2-5 years)</td>
                    <td className="border border-gray-200 p-4 text-yellow-600">Low-Medium</td>
                  </tr>
                  <tr className="hover:bg-gray-50">
                    <td className="border border-gray-200 p-4 font-medium">Index Fund</td>
                    <td className="border border-gray-200 p-4">~7% (average)</td>
                    <td className="border border-gray-200 p-4">Long-term growth (5+ years)</td>
                    <td className="border border-gray-200 p-4 text-orange-600">Medium-High</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Pro Tip */}
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-2xl shadow-lg p-8">
            <div className="flex items-center mb-4">
              <div className="text-3xl mr-4">💡</div>
              <h2 className="text-2xl font-bold">Pro Tip</h2>
            </div>
            <p className="text-lg leading-relaxed">
              Try running the calculators multiple times with different values to see how changes to your starting amount, monthly deposit, time period, or account type can affect your final balance. You might be surprised by how much difference a small change can make!
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}