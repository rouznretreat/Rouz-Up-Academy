import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz4() {
  return <EstateQuiz moduleType="module-4" />;
}