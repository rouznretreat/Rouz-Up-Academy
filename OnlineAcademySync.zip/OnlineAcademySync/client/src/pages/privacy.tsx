import { useState } from "react";
import { Link } from "wouter";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";

export default function Privacy() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white lg:hidden flex flex-col justify-center items-center space-y-8 text-xl font-semibold text-gray-800">
          <Link href="/" className="hover:text-blue-600 transition-colors">
            <a>Home</a>
          </Link>
          <Link href="/courses" className="hover:text-blue-600 transition-colors">
            <a>Courses</a>
          </Link>
          <Link href="/dashboard" className="hover:text-blue-600 transition-colors">
            <a>Dashboard</a>
          </Link>
          <Link href="/subscribe" className="hover:text-blue-600 transition-colors">
            <a>Membership</a>
          </Link>
          <Button 
            onClick={() => window.location.href = '/api/logout'}
            variant="outline"
            className="px-8 py-3 rounded-full font-semibold"
          >
            Sign Out
          </Button>
        </div>
      )}

      {/* Privacy Policy Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Privacy Policy</h1>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-gray-600 mb-6">
              <strong>Effective Date:</strong> {new Date().toLocaleDateString()}<br/>
              <strong>Last Updated:</strong> {new Date().toLocaleDateString()}
            </p>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Introduction</h2>
              <div className="text-gray-700 space-y-4">
                <p>Welcome to Rouz Up Academy ("we," "our," or "us"). We are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and educational services.</p>
                <p>Rouz Up Academy provides educational courses designed to enhance generational wealth through our "Starter" series, including Credit for Starters, Business for Starters, Banking for Starters, Trust for Starters, and Estate Planning for Starters. All content is provided for educational purposes only.</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Information We Collect</h2>
              <div className="text-gray-700 space-y-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Personal Information You Provide</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Account Information:</strong> Name, email address, phone number, and password when you create an account</li>
                  <li><strong>Profile Information:</strong> Optional demographic information, educational background, and learning preferences</li>
                  <li><strong>Course Data:</strong> Your progress, completion status, quiz results, and learning analytics</li>
                  <li><strong>Communication Data:</strong> Messages, feedback, and support requests you send to us</li>
                  <li><strong>Payment Information:</strong> Billing details and transaction history (processed securely through third-party payment processors)</li>
                </ul>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-2 mt-6">Information Collected Automatically</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Device Information:</strong> Device type, operating system, app version, and unique device identifiers</li>
                  <li><strong>Usage Data:</strong> Time spent in the app, features accessed, course interactions, and navigation patterns</li>
                  <li><strong>Technical Data:</strong> IP address, browser type, and connection information</li>
                  <li><strong>Analytics Data:</strong> App performance metrics and crash reports</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">How We Use Your Information</h2>
              <div className="text-gray-700 space-y-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Educational Services</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Provide access to our educational courses and content</li>
                  <li>Track your learning progress and course completion</li>
                  <li>Personalize your learning experience and recommend relevant courses</li>
                  <li>Generate certificates of completion when applicable</li>
                </ul>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-2 mt-6">Account Management</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Create and maintain your user account</li>
                  <li>Authenticate your identity and ensure account security</li>
                  <li>Process payments and manage subscriptions</li>
                  <li>Send important account notifications and updates</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Information Sharing and Disclosure</h2>
              <div className="text-gray-700 space-y-4">
                <p>We do not sell, trade, or rent your personal information. We may share your information only in the following circumstances:</p>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Service Providers</h3>
                <p>We work with trusted third-party service providers who help us operate our app and provide services, including:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Cloud hosting and data storage providers</li>
                  <li>Payment processing companies</li>
                  <li>Analytics and performance monitoring services</li>
                  <li>Customer support platforms</li>
                  <li>Email and communication services</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Data Security</h2>
              <div className="text-gray-700 space-y-4">
                <p>We implement appropriate technical and organizational measures to protect your personal information, including:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Encryption:</strong> Data is encrypted in transit and at rest using industry-standard protocols</li>
                  <li><strong>Access Controls:</strong> Limited access to personal information on a need-to-know basis</li>
                  <li><strong>Security Monitoring:</strong> Regular monitoring for unauthorized access or security breaches</li>
                  <li><strong>Secure Infrastructure:</strong> Use of reputable cloud service providers with robust security measures</li>
                  <li><strong>Regular Updates:</strong> Ongoing security assessments and system updates</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your Rights and Choices</h2>
              <div className="text-gray-700 space-y-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Account Control</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Access:</strong> View and download your personal information</li>
                  <li><strong>Update:</strong> Modify your account information and preferences</li>
                  <li><strong>Delete:</strong> Request deletion of your account and personal data</li>
                  <li><strong>Data Portability:</strong> Request a copy of your data in a portable format</li>
                </ul>
                
                <h3 className="text-lg font-semibold text-gray-800 mb-2 mt-6">Communication Preferences</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Marketing Emails:</strong> Unsubscribe from promotional communications</li>
                  <li><strong>Push Notifications:</strong> Manage notification settings in your device or app settings</li>
                  <li><strong>Course Recommendations:</strong> Opt out of personalized course suggestions</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Children's Privacy</h2>
              <div className="text-gray-700 space-y-4">
                <p>Rouz Up Academy is intended for users who are 13 years of age or older. We do not knowingly collect personal information from children under 13. If we become aware that we have collected information from a child under 13, we will take steps to delete such information promptly.</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Data Retention</h2>
              <div className="text-gray-700 space-y-4">
                <p>We retain your personal information for as long as necessary to provide our educational services and comply with legal requirements.</p>
                <p><strong>Specific Retention Periods:</strong></p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Account information: Retained while your account is active</li>
                  <li>Course progress data: Retained for 3 years after account closure</li>
                  <li>Payment information: Retained as required by financial regulations</li>
                  <li>Support communications: Retained for 2 years</li>
                  <li>Analytics data: Anonymized and retained for service improvement</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Educational Disclaimer</h2>
              <div className="text-gray-700 space-y-4">
                <p>All courses and content provided by Rouz Up Academy are for educational purposes only. Our courses on credit, business, banking, trusts, and estate planning do not constitute professional financial, legal, or tax advice. Always consult with qualified professionals for specific financial decisions.</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Changes to This Privacy Policy</h2>
              <div className="text-gray-700 space-y-4">
                <p>We may update this Privacy Policy periodically to reflect changes in our practices or applicable laws. We will notify you of significant changes by posting the updated policy in our app and sending email notifications to registered users.</p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Information</h2>
              <div className="text-gray-700 space-y-4">
                <p>If you have questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us:</p>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <p><strong>Rouz Up Academy</strong></p>
                  <p><strong>Email:</strong> privacy@rouzupacademy.com</p>
                  <p><strong>Address:</strong> Rouz Up Academy Privacy Department</p>
                  <p><strong>Phone:</strong> 1-800-ROUZ-UP</p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Regulatory Information</h2>
              <div className="text-gray-700 space-y-4">
                <p><strong>For California Residents (CCPA):</strong> You have additional rights under the California Consumer Privacy Act. Please contact us for information about exercising these rights.</p>
                <p><strong>For EU Residents (GDPR):</strong> You have rights under the General Data Protection Regulation. You may also file complaints with your local data protection authority.</p>
              </div>
            </section>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-200">
            <Link href="/">
              <Button className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3 rounded-lg font-semibold">
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}