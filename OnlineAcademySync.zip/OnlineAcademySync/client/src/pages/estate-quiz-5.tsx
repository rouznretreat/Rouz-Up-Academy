import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz5() {
  return <EstateQuiz moduleType="module-5" />;
}