import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
// Removed CashFlowQuiz import
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, DollarSign, Store, TrendingUp, Play, Clock, Coins, GraduationCap, Briefcase, Home } from "lucide-react";
import { Link } from "wouter";

export default function Games() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeGame, setActiveGame] = useState<string | null>(null);

  const games = [
    {
      id: "stock-simulator",
      title: "📈 Stock Market Simulator",
      description: "Trade virtual stocks for 10 days and test your investing skills! Learn how the stock market works with real market scenarios.",
      icon: TrendingUp,
      available: true,
      color: "from-blue-500 to-blue-600",
      badge: "🔥 POPULAR",
      link: "/stock-simulator"
    },

    {
      id: "coin-flip",
      title: "🪙 Coin Flip Challenge",
      description: "Test your luck and learn about probability and risk! Make smart bets and see if you can beat the odds.",
      icon: Coins,
      available: true,
      color: "from-yellow-500 to-orange-600",
      badge: "🎲 CHANCE",
      link: "/coin-flip-game"
    },
    {
      id: "baby-steps",
      title: "👶 Baby Steps Challenge",
      description: "Follow Dave Ramsey's 7 Baby Steps to financial freedom! Manage money through monthly challenges and life events.",
      icon: GraduationCap,
      available: true,
      color: "from-green-500 to-blue-600",
      badge: "💎 WISDOM",
      link: "/baby-steps-challenge"
    },
    {
      id: "real-estate",
      title: "🏘️ Real Estate Investment Game",
      description: "Buy, renovate, and sell properties to build wealth! Learn about real estate investing, property values, and rental income.",
      icon: Home,
      available: true,
      color: "from-emerald-500 to-teal-600",
      badge: "💰 WEALTH",
      link: "/real-estate-game"
    },
    {
      id: "budget-blaster",
      title: "💥 Budget Blaster",
      description: "Survive 4 weeks of unexpected financial events! Test your budgeting skills against life's surprises.",
      icon: Store,
      available: true,
      color: "from-red-500 to-orange-600",
      badge: "⚡ ACTION",
      link: "/budget-blaster"
    },

  ];

  // Cash Flow game removed and replaced with Real Estate game

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Back to Academy Button */}
      <div className="bg-white border-b border-gray-200 py-4">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/">
            <Button 
              variant="outline" 
              className="bg-white text-purple-600 border-purple-200 hover:bg-purple-50 font-medium"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Academy
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Games Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">🎮 Epic Banking Game Zone! 🚀</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Level up your money skills with these addictive games! Discover your financial superpower, build business empires, and become the next teen entrepreneur legend! 💯✨
          </p>
          <div className="flex justify-center items-center space-x-4 text-lg">
            <span className="bg-yellow-400 text-black px-4 py-2 rounded-full font-bold">🏆 Play & Learn</span>
            <span className="bg-green-400 text-black px-4 py-2 rounded-full font-bold">💡 Get Smart</span>
            <span className="bg-pink-400 text-black px-4 py-2 rounded-full font-bold">🎯 Have Fun!</span>
          </div>
        </div>
      </section>

      {/* Games Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {games.map((game, index) => {
              const IconComponent = game.icon;
              
              return (
                <Card 
                  key={game.id}
                  className={`bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer border border-gray-200 overflow-hidden relative ${
                    !game.available ? 'opacity-75' : ''
                  }`}
                >
                  {/* Fun Badge */}
                  <div className="absolute top-3 right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold px-3 py-1 rounded-full shadow-lg z-10">
                    {game.badge}
                  </div>
                  
                  <CardHeader className="text-center pb-4">
                    <div className={`w-20 h-20 mx-auto rounded-full bg-gradient-to-br ${game.color} flex items-center justify-center text-white mb-4 shadow-lg animate-pulse`}>
                      <IconComponent className="w-10 h-10" />
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900 mb-2">
                      {game.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="text-center">
                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {game.description}
                    </p>
                    
                    {game.available ? (
                      game.id === "cashflow" ? (
                        <Button 
                          onClick={() => setActiveGame(game.id)}
                          className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
                        >
                          <Play className="w-5 h-5" />
                          Play Now
                        </Button>
                      ) : (
                        <Link href={game.link}>
                          <Button 
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
                          >
                            <Play className="w-5 h-5" />
                            Play Now
                          </Button>
                        </Link>
                      )
                    ) : (
                      <Button 
                        variant="outline" 
                        disabled
                        className="w-full py-3 px-6 rounded-lg flex items-center justify-center gap-2"
                      >
                        <Clock className="w-5 h-5" />
                        Coming Soon
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {/* Games Info Section */}
          <div className="mt-16 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">🚀 Why These Games Will Change Your Life!</h2>
            
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="bg-white p-6 rounded-xl shadow-md transform hover:scale-105 transition-all duration-200">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                  <span className="text-2xl">🎯</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">Addictive Learning</h3>
                <p className="text-gray-600">These games are so fun, you'll forget you're becoming a business genius! 🧠✨</p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-md transform hover:scale-105 transition-all duration-200">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-blue-400 to-indigo-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                  <span className="text-2xl">🏆</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">Future CEO Skills</h3>
                <p className="text-gray-600">Learn what they don't teach in school - real money-making skills! 💰🚀</p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-md transform hover:scale-105 transition-all duration-200">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-green-400 to-teal-500 rounded-full flex items-center justify-center mb-4 animate-pulse">
                  <span className="text-2xl">📈</span>
                </div>
                <h3 className="text-xl font-semibold mb-3">Level Up Your Life</h3>
                <p className="text-gray-600">Watch your confidence and knowledge skyrocket with every game! 🌟💪</p>
              </div>
            </div>
            
            {/* Motivational Boost Section */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-8 rounded-2xl shadow-xl">
              <h3 className="text-3xl font-bold mb-4">🔥 Ready to Become a Teen Business Legend? 🔥</h3>
              <p className="text-xl mb-6">
                Every successful entrepreneur started with curiosity and courage. Today is YOUR day to start building tomorrow's empire! 💪✨
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-lg font-semibold">
                <span className="bg-yellow-400 text-black px-4 py-2 rounded-full">🎯 Play Smart</span>
                <span className="bg-green-400 text-black px-4 py-2 rounded-full">💡 Think Big</span>
                <span className="bg-blue-400 text-black px-4 py-2 rounded-full">🚀 Dream Bigger</span>
                <span className="bg-pink-400 text-black px-4 py-2 rounded-full">👑 Become Legendary</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}