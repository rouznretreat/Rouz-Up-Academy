import { Link } from "wouter";
import { useState } from "react";
import BankingQuiz from "@/components/BankingQuiz";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BankingBasics() {
  const [showQuiz, setShowQuiz] = useState(false);

  if (showQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="bg-white shadow-sm border-b p-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Banking Basics
            </Button>
          </div>
        </div>
        <div className="p-4">
          <BankingQuiz moduleType="banking-basics" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Banking Modules
            </Button>
          </Link>
        </div>
      </div>

      {/* Banking Module Navigation */}
      <div className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex overflow-x-auto space-x-1 py-2">
            <Link href="/banking-basics">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg">
                Banking Basics
              </button>
            </Link>
            <Link href="/saving-vs-growing">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Saving vs Growing
              </button>
            </Link>
            <Link href="/account-types">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Account Types
              </button>
            </Link>
            <Link href="/compound-interest">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Compound Interest
              </button>
            </Link>
            <Link href="/investing-basics">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Investing Basics
              </button>
            </Link>
            <Link href="/setting-goals">
              <button className="flex-shrink-0 px-3 py-2 text-sm font-medium text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                Setting Goals
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-6">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="inline-block bg-blue-500 text-blue-100 px-3 py-1 rounded-full text-xs font-medium mb-2">
            Learning Module
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Banking Basics</h1>
          <p className="text-lg text-blue-100 mb-4">15 minute read</p>
          <div className="inline-block bg-white text-blue-600 px-4 py-2 rounded-full font-semibold shadow-lg text-sm">
            🏦 Master banking fundamentals
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-4 -mt-6 relative z-10">
        <div className="space-y-3">
          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-blue-500">
            <div className="flex items-center mb-2">
              <div className="text-xl mr-2">🤔</div>
              <h2 className="text-lg font-bold text-gray-900">What is a Bank?</h2>
            </div>
            <p className="text-gray-700 text-xs">
              Banks store your money safely and help with payments, loans, and financial services.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-green-500">
            <div className="flex items-center mb-2">
              <div className="text-xl mr-2">⚙️</div>
              <h2 className="text-lg font-bold text-gray-900">How Banks Work</h2>
            </div>
            <p className="text-gray-700 text-xs">
              Banks take deposits and lend to others, making money from interest rate differences.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-purple-500">
            <div className="flex items-center mb-2">
              <div className="text-xl mr-2">🏦</div>
              <h2 className="text-lg font-bold text-gray-900">Account Types</h2>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center p-2 bg-blue-50 rounded">
                <div className="text-lg">💳</div>
                <p className="text-xs font-bold text-blue-700">Checking</p>
              </div>
              <div className="text-center p-2 bg-green-50 rounded">
                <div className="text-lg">💰</div>
                <p className="text-xs font-bold text-green-700">Savings</p>
              </div>
              <div className="text-center p-2 bg-purple-50 rounded">
                <div className="text-lg">📜</div>
                <p className="text-xs font-bold text-purple-700">CDs</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-3 rounded-lg">
            <div className="flex items-center mb-2">
              <div className="text-lg mr-2">👨‍👩‍👧‍👦</div>
              <h2 className="text-sm font-bold">Family Discussion</h2>
            </div>
            <p className="text-xs">Ask your parents about their first bank account.</p>
          </div>

          {/* Quiz Section */}
          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <div className="text-xl mr-2">🧠</div>
                <h2 className="text-lg font-bold text-gray-900">Test Your Knowledge</h2>
              </div>
              <div className="text-xs text-gray-500">5 questions</div>
            </div>
            <p className="text-gray-700 text-xs mb-3">
              Ready to test what you've learned about banking basics?
            </p>
            <button 
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded text-sm"
              onClick={() => setShowQuiz(true)}
            >
              Start Banking Basics Quiz
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}