import React, { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Menu, X, Search, BookOpen, TrendingUp, Users, Star } from "lucide-react";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import MembershipTiers from "@/components/MembershipTiers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import heroImage from "@assets/generational wealth starts now white background.png";
import creditImage from "@assets/Untitled design (3).jpg";
import businessImage from "@assets/business pic.jpg";
import trustImage from "@assets/Trust for Starters.jpg";
import bankingImage from "@assets/financial education.jpg";
import academyLogo from "@assets/Rouz up academy logo-tm.jpg";

export default function Landing() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const allCourses = courses;

  return (
    <div className="min-h-screen bg-white">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white lg:hidden flex flex-col justify-center items-center space-y-8 text-xl font-semibold text-gray-800">
          <Link href="#courses">
            <div className="hover:text-blue-600 transition-colors">All Courses</div>
          </Link>
          <Link href="#membership">
            <div className="hover:text-blue-600 transition-colors">Membership</div>
          </Link>
          <Link href="#about">
            <div className="hover:text-blue-600 transition-colors">About</div>
          </Link>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors"
          >
            Get Started
          </Button>
        </div>
      )}

      {/* Hero Section */}
      <section className="relative pt-8 pb-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-orange-50 via-yellow-50 to-blue-50 overflow-hidden">
        {/* Background decorations */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-gradient-to-r from-blue-400 to-green-400 rounded-full opacity-20 animate-pulse delay-1000"></div>
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-left">

              
              <h1 className="text-4xl lg:text-7xl font-black text-gray-900 mb-6 leading-tight text-center">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-green-600 to-blue-700 block">
                  Generational
                </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-blue-700 block">
                  Wealth
                </span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 to-indigo-600 block">
                  Starts Now
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-700 mb-8 max-w-xl leading-relaxed font-semibold text-center mx-auto">
                <span className="text-blue-600 font-bold">Today's Learning Tomorrow's Earning</span>
                <br />
                <span className="text-green-600 font-bold">Empowering Teens and Adults to empower the future!</span>
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8 justify-center">
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="bg-gradient-to-r from-orange-400 to-yellow-400 text-black px-6 py-3 rounded-xl font-bold text-md hover:from-orange-500 hover:to-yellow-500 transform hover:scale-105 transition-all duration-200 shadow-xl"
                >
                  🎯 Begin Your Journey
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => window.location.href = '/courses'}
                  className="border-3 border-blue-600 text-blue-600 px-6 py-3 rounded-xl font-bold text-md hover:bg-blue-600 hover:text-white transition-all duration-200 shadow-lg"
                >
                  📚 View All Courses
                </Button>
              </div>


            </div>

            {/* Right Image */}
            <div className="relative">
              <div className="relative z-10 transform hover:scale-105 transition-transform duration-300">
                <img 
                  src={heroImage} 
                  alt="Generational Wealth Starts Now - Happy Family Celebrating Success" 
                  className="w-3/5 h-auto rounded-3xl shadow-2xl border-4 border-white mx-auto"
                />
                

              </div>
            </div>
          </div>
        </div>
      </section>

      {/* All Courses Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Transform Your Financial Future
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose from our comprehensive course library designed to build generational wealth
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 sm:gap-6">
            {allCourses.map((course: any) => (
              <CourseCard 
                key={course.id} 
                course={course} 
                showEnrollButton={true}
              />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button 
              onClick={() => window.location.href = '/subscribe'}
              className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              📦 See Bundles and Memberships
            </Button>
          </div>
        </div>
      </section>





      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
            Ready to Transform Your Financial Future?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join thousands of students who are building generational wealth through financial education. Start your journey today with our comprehensive course library.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-200 shadow-lg"
            >
              Get Started
            </Button>
            <Button 
              variant="outline"
              className="border-2 border-blue-500 text-blue-500 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-blue-500 hover:text-white transition-all duration-200"
            >
              View Pricing
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center font-bold text-white text-lg">
                  R
                </div>
                <span className="font-bold text-2xl">Rouz Up Academy</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Empowering individuals and families to build generational wealth through comprehensive financial education.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg mb-4">Courses</h3>
              <ul className="space-y-2 text-gray-400">
                {allCourses.map((course: any) => (
                  <li key={course.id}>
                    <Link href="/courses">
                      <div className="hover:text-white transition-colors">{course.title}</div>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><div className="hover:text-white transition-colors cursor-pointer">Help Center</div></li>
                <li><div className="hover:text-white transition-colors cursor-pointer">Contact Us</div></li>
                <li><div className="hover:text-white transition-colors cursor-pointer">Community</div></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
            <p>&copy; 2024 Rouz Up Academy. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}