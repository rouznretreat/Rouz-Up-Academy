import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";

export default function Banking() {
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Banking Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">🏦 Banking Simulator</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Practice real banking skills with our virtual bank account! Learn deposits, withdrawals, transfers, and automatic payments in a safe environment.
          </p>
          <div className="flex justify-center items-center space-x-4 text-lg">
            <span className="bg-green-400 text-black px-4 py-2 rounded-full font-bold">💰 Practice Banking</span>
            <span className="bg-blue-400 text-black px-4 py-2 rounded-full font-bold">🔒 Risk-Free</span>
            <span className="bg-purple-400 text-black px-4 py-2 rounded-full font-bold">📈 Build Skills</span>
          </div>
        </div>
      </section>

      {/* Simple Banking Content */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-3xl font-bold text-center mb-6">🏦 Virtual Bank Account</h2>
            <p className="text-center text-lg text-gray-600 mb-8">
              Coming soon - practice banking operations in a safe environment!
            </p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-6 rounded-lg border-l-4 border-green-500">
                <h3 className="text-xl font-bold text-green-800 mb-3">Checking Account</h3>
                <p className="text-2xl font-bold text-green-700">$585.00</p>
                <p className="text-green-600 mt-2">Practice deposits and withdrawals</p>
              </div>
              
              <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-500">
                <h3 className="text-xl font-bold text-blue-800 mb-3">Savings Account</h3>
                <p className="text-2xl font-bold text-blue-700">$150.00</p>
                <p className="text-blue-600 mt-2">Learn about interest and saving</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}