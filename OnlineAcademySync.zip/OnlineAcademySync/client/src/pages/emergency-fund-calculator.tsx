import { Link } from "wouter";
import { ArrowLeft, Shield, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function EmergencyFundCalculator() {
  const [monthlyExpenses, setMonthlyExpenses] = useState(800);
  const [emergencyMonths, setEmergencyMonths] = useState(3);
  const [currentEmergencyFund, setCurrentEmergencyFund] = useState(200);
  const [monthlyIncome, setMonthlyIncome] = useState(600);
  const [savePercentage, setSavePercentage] = useState(20);
  const [interestRate, setInterestRate] = useState(4);

  const calculateEmergencyFund = () => {
    const targetAmount = monthlyExpenses * emergencyMonths;
    const remainingNeeded = Math.max(0, targetAmount - currentEmergencyFund);
    const monthlySavings = monthlyIncome * (savePercentage / 100);
    const monthlyRate = interestRate / 100 / 12;
    
    // Calculate months to reach goal with compound interest
    let monthsToGoal = 0;
    if (remainingNeeded > 0 && monthlySavings > 0) {
      if (monthlyRate > 0) {
        let runningTotal = currentEmergencyFund;
        while (runningTotal < targetAmount && monthsToGoal < 120) {
          runningTotal = runningTotal * (1 + monthlyRate) + monthlySavings;
          monthsToGoal++;
        }
      } else {
        monthsToGoal = Math.ceil(remainingNeeded / monthlySavings);
      }
    }
    
    // Calculate emergency scenarios
    const scenarios = [
      { name: "Job Loss", months: 6, description: "6 months of expenses" },
      { name: "Medical Emergency", amount: 2000, description: "Unexpected medical bills" },
      { name: "Car Repair", amount: 1500, description: "Major car breakdown" },
      { name: "Home Repair", amount: 3000, description: "Appliance replacement, etc." }
    ];
    
    return {
      targetAmount,
      remainingNeeded,
      monthlySavings,
      monthsToGoal,
      scenarios,
      isOnTrack: monthsToGoal <= 24, // Within 2 years
      progressPercentage: Math.min(100, (currentEmergencyFund / targetAmount) * 100)
    };
  };

  const results = calculateEmergencyFund();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-teal-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/tools">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2 text-white border-white/30 hover:bg-white/10 mr-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Calculators
                </Button>
              </Link>
              <div className="flex items-center">
                <Shield className="w-8 h-8 mr-3" />
                <div>
                  <h1 className="text-2xl font-bold">Emergency Fund Calculator</h1>
                  <p className="text-green-100">Build your financial safety net</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Calculator Card */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center mb-6">
              <Calculator className="w-6 h-6 mr-3 text-green-600" />
              <h2 className="text-2xl font-bold text-gray-900">Emergency Fund Planning</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Essential Expenses ($)
                  </label>
                  <input
                    type="number"
                    value={monthlyExpenses}
                    onChange={(e) => setMonthlyExpenses(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="100"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Include rent, groceries, utilities, phone, minimum debt payments
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Months of Expenses to Save
                  </label>
                  <select
                    value={emergencyMonths}
                    onChange={(e) => setEmergencyMonths(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value={1}>1 month (Minimum)</option>
                    <option value={3}>3 months (Recommended for students)</option>
                    <option value={6}>6 months (Full-time workers)</option>
                    <option value={9}>9 months (Contractors/Freelancers)</option>
                    <option value={12}>12 months (Maximum security)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Emergency Savings ($)
                  </label>
                  <input
                    type="number"
                    value={currentEmergencyFund}
                    onChange={(e) => setCurrentEmergencyFund(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Income ($)
                  </label>
                  <input
                    type="number"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage to Save for Emergencies ({savePercentage}%)
                  </label>
                  <input
                    type="range"
                    value={savePercentage}
                    onChange={(e) => setSavePercentage(Number(e.target.value))}
                    className="w-full"
                    min="5"
                    max="50"
                    step="5"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>5%</span>
                    <span>50%</span>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    High-Yield Savings Rate (%)
                  </label>
                  <input
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                    max="10"
                    step="0.1"
                  />
                </div>
              </div>

              {/* Results Section */}
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-green-50 to-teal-50 p-4 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">Your Emergency Fund Goal</h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Target Amount:</span>
                      <span className="font-semibold text-lg">${results.targetAmount.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Still Need:</span>
                      <span className="font-semibold">${results.remainingNeeded.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Monthly Savings:</span>
                      <span className="font-semibold">${results.monthlySavings.toFixed(0)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Time to Goal:</span>
                      <span className="font-semibold">{results.monthsToGoal} months</span>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Progress</span>
                      <span>{results.progressPercentage.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div 
                        className="bg-green-500 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, results.progressPercentage)}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  {results.isOnTrack ? (
                    <div className="bg-green-100 border border-green-200 rounded-lg p-3 mt-4">
                      <div className="text-green-600 font-bold">✅ You're on track!</div>
                      <p className="text-green-700 text-sm">
                        Great job building your safety net responsibly
                      </p>
                    </div>
                  ) : (
                    <div className="bg-orange-100 border border-orange-200 rounded-lg p-3 mt-4">
                      <div className="text-orange-600 font-bold">⚠️ Consider saving more</div>
                      <p className="text-orange-700 text-sm">
                        Try to reach your goal within 2 years
                      </p>
                    </div>
                  )}
                </div>

                {/* Emergency Scenarios */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-bold text-blue-900 mb-3">🚨 Emergency Scenarios</h4>
                  <div className="space-y-2">
                    {results.scenarios.map((scenario, index) => (
                      <div key={index} className="bg-white p-3 rounded border text-sm">
                        <div className="font-semibold text-blue-600">{scenario.name}</div>
                        <div className="text-gray-700">{scenario.description}</div>
                        <div className="text-gray-600">
                          Cost: ${scenario.amount ? scenario.amount.toLocaleString() : 
                            (monthlyExpenses * (scenario.months || 1)).toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tips */}
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h4 className="font-bold text-yellow-900 mb-2">💡 Emergency Fund Tips</h4>
                  <ul className="text-sm text-yellow-800 space-y-1">
                    <li>• Keep emergency funds in a separate high-yield savings account</li>
                    <li>• Start small - even $500 can help with minor emergencies</li>
                    <li>• Automate transfers to build the habit</li>
                    <li>• Only use for true emergencies, not wants</li>
                    <li>• Replenish immediately after using</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Fund Tiers */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Emergency Fund Levels</h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🥉</span>
                </div>
                <h4 className="font-semibold text-orange-600 mb-2">Starter Emergency Fund</h4>
                <div className="text-2xl font-bold text-gray-900">${monthlyExpenses.toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-1">1 month of expenses</p>
                <p className="text-xs text-gray-500 mt-2">Good for minor car repairs, small medical bills</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🥈</span>
                </div>
                <h4 className="font-semibold text-blue-600 mb-2">Student Emergency Fund</h4>
                <div className="text-2xl font-bold text-gray-900">${(monthlyExpenses * 3).toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-1">3 months of expenses</p>
                <p className="text-xs text-gray-500 mt-2">Perfect for students and part-time workers</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🥇</span>
                </div>
                <h4 className="font-semibold text-green-600 mb-2">Full Emergency Fund</h4>
                <div className="text-2xl font-bold text-gray-900">${(monthlyExpenses * 6).toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-1">6 months of expenses</p>
                <p className="text-xs text-gray-500 mt-2">Complete protection for job loss or major emergencies</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}