import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, CreditCard } from "lucide-react";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ course }: { course: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/dashboard`,
      },
    });

    setIsProcessing(false);

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      // Record the purchase
      try {
        await apiRequest("POST", "/api/purchases", {
          courseId: course.id,
          amount: parseFloat(course.price),
          status: 'completed'
        });
        
        toast({
          title: "Payment Successful",
          description: `You now have access to ${course.title}!`,
        });
        
        setLocation('/dashboard');
      } catch (error) {
        console.error('Error recording purchase:', error);
      }
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/courses')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Courses
        </Button>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Purchase</h1>
        <p className="text-gray-600">Secure payment powered by Stripe</p>
      </div>

      {/* Course Summary */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Order Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-semibold text-lg">{course.title}</h3>
              <p className="text-gray-600 text-sm">{course.description}</p>
              <p className="text-sm text-gray-500 mt-1">Level: {course.level}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">${course.price}</div>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total</span>
              <span className="text-xl font-bold">${course.price}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="w-5 h-5 mr-2" />
            Payment Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <PaymentElement />
            
            <Button 
              type="submit" 
              disabled={!stripe || isProcessing}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold"
            >
              {isProcessing ? 'Processing...' : `Pay $${course.price}`}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <div className="mt-6 text-center text-sm text-gray-500">
        <p>🔒 Your payment information is secure and encrypted</p>
      </div>
    </div>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [course, setCourse] = useState(null);
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Get course info from URL params or localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('courseId');
    
    if (!courseId) {
      setLocation('/courses');
      return;
    }

    // Fetch course details and create payment intent
    Promise.all([
      fetch(`/api/courses/${courseId}`).then(res => res.json()),
      apiRequest("POST", "/api/create-payment-intent", { 
        courseId: parseInt(courseId),
        amount: 0 // Will be updated with actual price
      }).then(res => res.json())
    ]).then(([courseData, paymentData]) => {
      setCourse(courseData);
      
      // Create payment intent with correct amount
      return apiRequest("POST", "/api/create-payment-intent", { 
        courseId: parseInt(courseId),
        amount: parseFloat(courseData.price)
      }).then(res => res.json());
    }).then((data) => {
      setClientSecret(data.clientSecret);
    }).catch((error) => {
      console.error('Error setting up checkout:', error);
      setLocation('/courses');
    });
  }, []);

  if (!clientSecret || !course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <Elements stripe={stripePromise} options={{ clientSecret }}>
        <CheckoutForm course={course} />
      </Elements>
    </div>
  );
}
