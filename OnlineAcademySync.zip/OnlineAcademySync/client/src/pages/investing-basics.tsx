import { Link } from "wouter";
import { useState } from "react";
import BankingQuiz from "@/components/BankingQuiz";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function InvestingBasics() {
  const [showQuiz, setShowQuiz] = useState(false);

  if (showQuiz) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100">
        <div className="bg-white shadow-sm border-b p-4">
          <div className="max-w-4xl mx-auto">
            <Button 
              variant="outline" 
              className="flex items-center gap-2 text-blue-600 border-blue-200 hover:bg-blue-50"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Investing Basics
            </Button>
          </div>
        </div>
        <div className="p-4">
          <BankingQuiz moduleType="investing-basics" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/banking-course">
            <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-white transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Banking Modules
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-12">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="inline-block bg-indigo-500 text-indigo-100 px-4 py-2 rounded-full text-sm font-medium mb-4">
            Learning Module
          </div>
          <h1 className="text-5xl font-bold mb-4">Investing Basics</h1>
          <p className="text-xl text-indigo-100 mb-6">25 minute read</p>
          <div className="inline-block bg-white text-indigo-600 px-6 py-3 rounded-full font-semibold shadow-lg">
            📈 Start building wealth for your future
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto p-6 -mt-8 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">📈</div>
            <h2 className="text-3xl font-bold text-gray-900">Start Your Investment Journey!</h2>
            <p className="text-gray-600 mt-2">Learn the fundamentals of growing wealth through investing</p>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-indigo-500">
            <div className="flex items-center mb-4">
              <div className="text-3xl mr-4">💡</div>
              <h2 className="text-3xl font-bold text-gray-900">What is Investing?</h2>
            </div>
            <p className="text-gray-700 text-lg leading-relaxed">
              Investing means putting your money into assets that have the potential to grow in value over time. Unlike saving, where your money stays relatively safe but grows slowly, investing involves some risk but offers the possibility of much higher returns.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-green-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🎯</div>
              <h2 className="text-3xl font-bold text-gray-900">Why Should Teens Invest?</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-6 rounded-xl border border-green-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">⏰</span>
                  <h3 className="text-xl font-bold text-green-700">Time Advantage</h3>
                </div>
                <p className="text-gray-700">You have decades for your investments to grow through compound returns</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">📚</span>
                  <h3 className="text-xl font-bold text-blue-700">Learning Time</h3>
                </div>
                <p className="text-gray-700">You can learn from mistakes while the amounts are smaller</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">🎓</span>
                  <h3 className="text-xl font-bold text-purple-700">Future Goals</h3>
                </div>
                <p className="text-gray-700">Start saving for college, first home, or retirement early</p>
              </div>
              <div className="bg-orange-50 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">💪</span>
                  <h3 className="text-xl font-bold text-orange-700">Good Habits</h3>
                </div>
                <p className="text-gray-700">Develop disciplined saving and investing habits early</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-blue-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">📊</div>
              <h2 className="text-3xl font-bold text-gray-900">Types of Investments</h2>
            </div>
            <div className="grid gap-6">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">📈</span>
                  <h3 className="text-2xl font-bold text-blue-700">Stocks</h3>
                </div>
                <p className="text-gray-700 text-lg mb-2">Ownership shares in companies</p>
                <div className="text-sm text-blue-600">Higher risk, higher potential return</div>
              </div>
              
              <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">🏛️</span>
                  <h3 className="text-2xl font-bold text-green-700">Bonds</h3>
                </div>
                <p className="text-gray-700 text-lg mb-2">Loans you give to companies or governments</p>
                <div className="text-sm text-green-600">Lower risk, steady returns</div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">📦</span>
                  <h3 className="text-2xl font-bold text-purple-700">Index Funds</h3>
                </div>
                <p className="text-gray-700 text-lg mb-2">Baskets of many stocks or bonds</p>
                <div className="text-sm text-purple-600">Diversified, good for beginners</div>
              </div>
              
              <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center mb-3">
                  <span className="text-3xl mr-3">🏠</span>
                  <h3 className="text-2xl font-bold text-orange-700">Real Estate</h3>
                </div>
                <p className="text-gray-700 text-lg mb-2">Property investments</p>
                <div className="text-sm text-orange-600">Tangible assets, long-term growth</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-red-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">⚠️</div>
              <h2 className="text-3xl font-bold text-gray-900">Investment Risks to Understand</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-red-50 p-4 rounded-lg flex items-start">
                <span className="text-2xl mr-3">📉</span>
                <div>
                  <h4 className="font-bold text-red-700 mb-1">Market Risk</h4>
                  <p className="text-gray-700 text-sm">Investments can lose value when markets decline</p>
                </div>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg flex items-start">
                <span className="text-2xl mr-3">💸</span>
                <div>
                  <h4 className="font-bold text-yellow-700 mb-1">Inflation Risk</h4>
                  <p className="text-gray-700 text-sm">Your returns might not keep up with rising prices</p>
                </div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg flex items-start">
                <span className="text-2xl mr-3">🏢</span>
                <div>
                  <h4 className="font-bold text-blue-700 mb-1">Company Risk</h4>
                  <p className="text-gray-700 text-sm">Individual companies can fail or perform poorly</p>
                </div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg flex items-start">
                <span className="text-2xl mr-3">⏱️</span>
                <div>
                  <h4 className="font-bold text-purple-700 mb-1">Timing Risk</h4>
                  <p className="text-gray-700 text-sm">When you buy and sell can affect your returns</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border-l-4 border-yellow-500">
            <div className="flex items-center mb-6">
              <div className="text-3xl mr-4">🎯</div>
              <h2 className="text-3xl font-bold text-gray-900">Getting Started Tips</h2>
            </div>
            <div className="space-y-4">
              <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                <h4 className="font-bold text-yellow-700 mb-2">1. Start with education</h4>
                <p className="text-gray-700">Learn the basics before investing real money</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                <h4 className="font-bold text-green-700 mb-2">2. Begin small</h4>
                <p className="text-gray-700">Start with amounts you can afford to lose while learning</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                <h4 className="font-bold text-blue-700 mb-2">3. Diversify</h4>
                <p className="text-gray-700">Don't put all your money in one investment</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-400">
                <h4 className="font-bold text-purple-700 mb-2">4. Think long-term</h4>
                <p className="text-gray-700">Invest for goals that are years away, not next month</p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-indigo-500 to-blue-600 text-white p-8 rounded-2xl shadow-xl">
            <div className="flex items-center mb-4">
              <div className="text-4xl mr-4">👨‍👩‍👧‍👦</div>
              <h2 className="text-3xl font-bold">Family Discussion Prompt</h2>
            </div>
            <div className="bg-white bg-opacity-20 p-6 rounded-xl">
              <p className="text-xl leading-relaxed">
                Ask your family about their investment experiences. What investments do they have? What advice would they give to someone just starting to invest? Discuss the difference between saving and investing.
              </p>
            </div>
          </div>

          {/* Quiz Section */}
          <div className="bg-white rounded-lg shadow-md p-3 border-l-4 border-yellow-500">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <div className="text-xl mr-2">🧠</div>
                <h2 className="text-lg font-bold text-gray-900">Test Your Knowledge</h2>
              </div>
              <div className="text-xs text-gray-500">5 questions</div>
            </div>
            <p className="text-gray-700 text-xs mb-3">
              Ready to test what you've learned about investing basics?
            </p>
            <button 
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded text-sm"
              onClick={() => setShowQuiz(true)}
            >
              Start Investing Basics Quiz
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}