import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function SampleHealthcareDirective() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => setLocation("/estate-planning-course")}
          className="mb-4"
        >
          ← Back to Documents
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-orange-700">Sample Healthcare Directive</CardTitle>
            <p className="text-gray-600">Educational example of advance healthcare directive</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
              <div className="text-center font-bold text-lg mb-6">
                ADVANCE HEALTHCARE DIRECTIVE<br/>
                (Living Will and Healthcare Power of Attorney)
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold mb-2">PART I - LIVING WILL</h4>
                  <p>I, MARIA ELENA RODRIGUEZ, being of sound mind, willfully and voluntarily make this Living Will to declare my wishes regarding medical treatment.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">END-OF-LIFE DECISIONS</h4>
                  <p>If I am in a terminal condition or persistent vegetative state and cannot communicate my wishes:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>• I DO NOT want life-sustaining treatments that would only prolong dying</li>
                    <li>• I DO want comfort care to relieve pain and suffering</li>
                    <li>• I DO want adequate pain medication even if it hastens death</li>
                    <li>• I DO want nutrition and hydration unless it causes suffering</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">SPECIFIC TREATMENTS</h4>
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <p><strong>Cardiopulmonary Resuscitation (CPR):</strong></p>
                      <p>☐ I want CPR  ☑ I do not want CPR</p>
                      
                      <p className="mt-2"><strong>Mechanical Ventilation:</strong></p>
                      <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                      
                      <p className="mt-2"><strong>Dialysis:</strong></p>
                      <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                    </div>
                    <div>
                      <p><strong>Tube Feeding:</strong></p>
                      <p>☐ I want  ☑ I do not want  ☐ Trial period only</p>
                      
                      <p className="mt-2"><strong>Antibiotics:</strong></p>
                      <p>☑ I want  ☐ I do not want</p>
                      
                      <p className="mt-2"><strong>Comfort Care:</strong></p>
                      <p>☑ I want comfort care always</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold mb-2">PART II - HEALTHCARE POWER OF ATTORNEY</h4>
                  <p>I hereby designate CARLOS MIGUEL RODRIGUEZ, my husband, as my healthcare agent to make healthcare decisions for me when I cannot make them myself.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">SUCCESSOR HEALTHCARE AGENT</h4>
                  <p>If CARLOS MIGUEL RODRIGUEZ is unable to serve, I designate ANA SOFIA RODRIGUEZ, my daughter, as my successor healthcare agent.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">AGENT'S AUTHORITY</h4>
                  <p>My healthcare agent is authorized to:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>• Consent to or refuse medical treatment and procedures</li>
                    <li>• Choose healthcare providers and facilities</li>
                    <li>• Access my medical records and information</li>
                    <li>• Make decisions about organ donation</li>
                    <li>• Arrange for hospice or palliative care</li>
                    <li>• Take any action necessary to carry out my wishes</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">GUIDANCE FOR AGENT</h4>
                  <p>I want my agent to make decisions based on:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>1. My specific instructions in this document</li>
                    <li>2. My known wishes and values</li>
                    <li>3. My best interests if my wishes are unknown</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">ORGAN DONATION</h4>
                  <p>☑ I consent to donate my organs, tissues, and eyes for transplantation, research, or education</p>
                  <p>☐ I do not consent to organ donation</p>
                  <p>☐ I consent only to: ________________________</p>
                </div>

                <div className="mt-6">
                  <p>I have carefully read this document and understand its contents. I am emotionally and mentally competent to make this directive.</p>
                  <div className="mt-4">
                    <p>Signed: _________________________________ Date: __________</p>
                    <p>MARIA ELENA RODRIGUEZ</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold mb-2">WITNESS ATTESTATION</h4>
                  <p>We witness that the principal signed this document in our presence, appears to be of sound mind and under no duress.</p>
                  <div className="mt-4 space-y-3">
                    <div>
                      <p>Witness 1: ______________________________ Date: ______</p>
                      <p>Print Name: _____________________________</p>
                    </div>
                    <div>
                      <p>Witness 2: ______________________________ Date: ______</p>
                      <p>Print Name: _____________________________</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-orange-50 p-4 rounded border border-orange-300">
              <h4 className="font-bold text-orange-700 mb-2">Healthcare Directive Components:</h4>
              <ul className="text-sm text-orange-700 space-y-1">
                <li>• <strong>Living Will</strong> - Specific treatment preferences when terminal</li>
                <li>• <strong>Healthcare Agent</strong> - Trusted person to make decisions</li>
                <li>• <strong>Treatment Choices</strong> - Clear preferences for specific interventions</li>
                <li>• <strong>Comfort Care</strong> - Emphasis on pain relief and dignity</li>
                <li>• <strong>Organ Donation</strong> - Personal choice clearly documented</li>
                <li>• <strong>Proper Witnessing</strong> - Legal validity through witnesses</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}