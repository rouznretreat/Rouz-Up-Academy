import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, DollarSign, ShoppingCart, Car, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BudgetEvent {
  week: number;
  event: string;
  cost: number;
  type: 'expense' | 'income';
  category: string;
}

const budgetEvents: BudgetEvent[] = [
  { week: 1, event: "Friend's birthday party gift", cost: 25, type: 'expense', category: 'social' },
  { week: 1, event: "Part-time job paycheck", cost: 150, type: 'income', category: 'work' },
  { week: 2, event: "Car needs gas", cost: 40, type: 'expense', category: 'transport' },
  { week: 2, event: "Unexpected movie date", cost: 30, type: 'expense', category: 'entertainment' },
  { week: 3, event: "Phone bill due", cost: 50, type: 'expense', category: 'bills' },
  { week: 3, event: "Side hustle earnings", cost: 75, type: 'income', category: 'work' },
  { week: 4, event: "Emergency: broken laptop charger", cost: 60, type: 'expense', category: 'emergency' },
  { week: 4, event: "Found money in old jacket", cost: 20, type: 'income', category: 'surprise' }
];

export default function BudgetBlaster() {
  const [currentWeek, setCurrentWeek] = useState(1);
  const [balance, setBalance] = useState(200);
  const [gameOver, setGameOver] = useState(false);
  const [decisions, setDecisions] = useState<string[]>([]);
  const [currentEvent, setCurrentEvent] = useState<BudgetEvent | null>(null);

  const startWeek = () => {
    const weekEvents = budgetEvents.filter(event => event.week === currentWeek);
    if (weekEvents.length > 0) {
      setCurrentEvent(weekEvents[0]);
    } else {
      nextWeek();
    }
  };

  const handleDecision = (choice: 'accept' | 'decline', eventCost: number, eventType: string) => {
    let newBalance = balance;
    let decision = '';

    if (choice === 'accept') {
      if (currentEvent?.type === 'expense') {
        newBalance -= eventCost;
        decision = `Week ${currentWeek}: Spent $${eventCost} on ${currentEvent.event}`;
      } else {
        newBalance += eventCost;
        decision = `Week ${currentWeek}: Earned $${eventCost} from ${currentEvent.event}`;
      }
    } else {
      decision = `Week ${currentWeek}: Declined ${currentEvent?.event}`;
    }

    setBalance(newBalance);
    setDecisions([...decisions, decision]);

    if (newBalance < 0) {
      setGameOver(true);
    } else {
      nextWeek();
    }
  };

  const nextWeek = () => {
    if (currentWeek >= 4) {
      setGameOver(true);
    } else {
      setCurrentWeek(currentWeek + 1);
      setCurrentEvent(null);
    }
  };

  const restartGame = () => {
    setCurrentWeek(1);
    setBalance(200);
    setGameOver(false);
    setDecisions([]);
    setCurrentEvent(null);
  };

  const getBalanceColor = () => {
    if (balance >= 150) return "text-green-600";
    if (balance >= 50) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100">
      <div className="bg-white shadow-sm border-b p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">💥 Budget Blaster</h1>
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            <span className={`text-xl font-bold ${getBalanceColor()}`}>
              ${balance}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {!gameOver && !currentEvent && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">💥</div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Week {currentWeek} of 4
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              You start with $200. Can you survive 4 weeks of unexpected events?
            </p>
            <Button onClick={startWeek} className="bg-red-600 hover:bg-red-700 text-white px-8 py-3">
              Start Week {currentWeek}
            </Button>
          </div>
        )}

        {currentEvent && !gameOver && (
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="text-5xl mb-4">
              {currentEvent.type === 'expense' ? '💸' : '💰'}
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Week {currentWeek}: {currentEvent.event}
            </h3>
            <div className="text-4xl font-bold mb-6">
              {currentEvent.type === 'expense' ? '-' : '+'}${currentEvent.cost}
            </div>
            
            {currentEvent.type === 'expense' ? (
              <div className="space-y-4">
                <p className="text-lg text-gray-600">Do you want to spend this money?</p>
                <div className="flex gap-4 justify-center">
                  <Button 
                    onClick={() => handleDecision('accept', currentEvent.cost, currentEvent.type)}
                    className="bg-red-600 hover:bg-red-700 text-white px-6 py-3"
                  >
                    Spend ${currentEvent.cost}
                  </Button>
                  <Button 
                    onClick={() => handleDecision('decline', currentEvent.cost, currentEvent.type)}
                    variant="outline"
                    className="px-6 py-3"
                  >
                    Skip This Expense
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-lg text-gray-600">Great! You earned some money!</p>
                <Button 
                  onClick={() => handleDecision('accept', currentEvent.cost, currentEvent.type)}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3"
                >
                  Collect ${currentEvent.cost}
                </Button>
              </div>
            )}
          </div>
        )}

        {gameOver && (
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="text-6xl mb-4">
              {balance >= 0 ? '🎉' : '💔'}
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              {balance >= 0 ? 'Congratulations!' : 'Game Over!'}
            </h3>
            <div className="text-2xl font-bold mb-6">
              Final Balance: <span className={getBalanceColor()}>${balance}</span>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h4 className="text-lg font-bold text-gray-900 mb-4">Your Decisions:</h4>
              <div className="space-y-2 text-left">
                {decisions.map((decision, index) => (
                  <div key={index} className="text-gray-700">{decision}</div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              {balance >= 100 && (
                <div className="bg-green-100 border border-green-300 rounded-lg p-4">
                  <p className="text-green-800 font-semibold">
                    🏆 Excellent! You managed your money wisely and ended with a healthy balance!
                  </p>
                </div>
              )}
              {balance >= 0 && balance < 100 && (
                <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-4">
                  <p className="text-yellow-800 font-semibold">
                    🤔 Good job surviving, but consider building an emergency fund for unexpected costs!
                  </p>
                </div>
              )}
              {balance < 0 && (
                <div className="bg-red-100 border border-red-300 rounded-lg p-4">
                  <p className="text-red-800 font-semibold">
                    😬 You went into debt! This shows why emergency funds and budgeting are so important.
                  </p>
                </div>
              )}
              
              <Button 
                onClick={restartGame}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
              >
                Play Again
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}