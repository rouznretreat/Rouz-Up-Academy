import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Trophy, Clock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TriviaQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

const triviaQuestions: TriviaQuestion[] = [
  {
    id: 1,
    question: "What's the FDIC insurance limit per depositor, per bank?",
    options: ["$100,000", "$250,000", "$500,000", "$1,000,000"],
    correctAnswer: 1,
    explanation: "FDIC protects up to $250,000 per depositor, per bank, keeping your money safe!",
    difficulty: 'easy',
    points: 100
  },
  {
    id: 2,
    question: "If you invest $100 monthly at 7% annual return, how much will you have in 10 years?",
    options: ["$12,000", "$13,800", "$16,800", "$17,400"],
    correctAnswer: 3,
    explanation: "Compound interest magic! Your $12,000 investment grows to $17,400.",
    difficulty: 'medium',
    points: 200
  },
  {
    id: 3,
    question: "What's the best strategy to pay off multiple credit cards?",
    options: ["Pay minimums on all", "Debt avalanche (highest interest first)", "Debt snowball (smallest balance first)", "Ignore them"],
    correctAnswer: 1,
    explanation: "Debt avalanche saves the most money by targeting highest interest rates first!",
    difficulty: 'medium',
    points: 200
  },
  {
    id: 4,
    question: "Which account typically offers the highest interest rates?",
    options: ["Checking Account", "Regular Savings", "High-Yield Savings", "Certificate of Deposit"],
    correctAnswer: 3,
    explanation: "CDs offer higher rates because you commit to leaving money untouched for a set time.",
    difficulty: 'easy',
    points: 100
  },
  {
    id: 5,
    question: "What's compound interest?",
    options: ["Interest on your principal only", "Interest on interest", "A type of bank account", "A credit card fee"],
    correctAnswer: 1,
    explanation: "Compound interest is earning interest on both your original money AND previous interest earned!",
    difficulty: 'easy',
    points: 100
  },
  {
    id: 6,
    question: "If you start investing $50/month at age 16 vs age 26, how much more will you have at 65?",
    options: ["$50,000 more", "$100,000 more", "$200,000 more", "$300,000+ more"],
    correctAnswer: 3,
    explanation: "Starting 10 years earlier gives you $300,000+ more due to compound interest!",
    difficulty: 'hard',
    points: 300
  },
  {
    id: 7,
    question: "What's the main risk of keeping all your money in a regular savings account?",
    options: ["Bank fees", "Inflation", "FDIC limits", "Account closure"],
    correctAnswer: 1,
    explanation: "Inflation can make your money lose purchasing power over time if it's not growing.",
    difficulty: 'medium',
    points: 200
  },
  {
    id: 8,
    question: "Which is typically the worst financial decision for teens?",
    options: ["Opening a savings account", "Getting a part-time job", "Using payday loans", "Learning about investing"],
    correctAnswer: 2,
    explanation: "Payday loans have extremely high interest rates and trap people in debt cycles.",
    difficulty: 'easy',
    points: 100
  }
];

export default function BankingTriviaShowdown() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [gameActive, setGameActive] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);

  const startGame = () => {
    setGameActive(true);
    setCurrentQuestion(0);
    setScore(0);
    setTimeLeft(15);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setGameComplete(false);
    setStreak(0);
    startTimer();
  };

  const startTimer = () => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleTimeout = () => {
    setSelectedAnswer(-1); // Indicates timeout
    setShowExplanation(true);
    setStreak(0);
    setTimeout(nextQuestion, 3000);
  };

  const selectAnswer = (answerIndex: number) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answerIndex);
    setShowExplanation(true);
    
    const question = triviaQuestions[currentQuestion];
    const isCorrect = answerIndex === question.correctAnswer;
    
    if (isCorrect) {
      const timeBonus = Math.floor(timeLeft * 10);
      const totalPoints = question.points + timeBonus;
      setScore(score + totalPoints);
      setStreak(streak + 1);
      setBestStreak(Math.max(bestStreak, streak + 1));
    } else {
      setStreak(0);
    }
    
    setTimeout(nextQuestion, 3000);
  };

  const nextQuestion = () => {
    if (currentQuestion >= triviaQuestions.length - 1) {
      setGameComplete(true);
      setGameActive(false);
    } else {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setTimeLeft(15);
      startTimer();
    }
  };

  const getScoreRating = () => {
    const maxScore = triviaQuestions.reduce((sum, q) => sum + q.points + 150, 0); // Max points + time bonus
    const percentage = (score / maxScore) * 100;
    
    if (percentage >= 90) return { rating: "Banking Genius! 🧠", color: "text-yellow-400" };
    if (percentage >= 75) return { rating: "Money Master! 💰", color: "text-green-400" };
    if (percentage >= 60) return { rating: "Finance Learner! 📚", color: "text-blue-400" };
    return { rating: "Keep Learning! 💪", color: "text-purple-400" };
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'hard': return 'text-red-400';
      default: return 'text-white';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 text-white">
      <div className="bg-black/50 shadow-sm border-b border-blue-600 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2 text-white border-blue-400 hover:bg-blue-800">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-blue-100">🏆 Banking Trivia Showdown</h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-bold">{score}</span>
            </div>
            {gameActive && (
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-red-400" />
                <span className="text-red-400 font-bold">{timeLeft}s</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {!gameActive && !gameComplete && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">🎯</div>
            <h2 className="text-4xl font-bold text-blue-100 mb-4">Ready for the Ultimate Banking Challenge?</h2>
            <p className="text-xl text-blue-200 mb-8 max-w-2xl mx-auto">
              Test your financial knowledge with rapid-fire questions! You have 15 seconds per question. 
              Speed matters - faster answers earn bonus points!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 max-w-2xl mx-auto">
              <div className="bg-blue-800/50 rounded-lg p-4">
                <div className="text-2xl font-bold text-green-400">Easy</div>
                <div className="text-blue-200">100 points</div>
              </div>
              <div className="bg-blue-800/50 rounded-lg p-4">
                <div className="text-2xl font-bold text-yellow-400">Medium</div>
                <div className="text-blue-200">200 points</div>
              </div>
              <div className="bg-blue-800/50 rounded-lg p-4">
                <div className="text-2xl font-bold text-red-400">Hard</div>
                <div className="text-blue-200">300 points</div>
              </div>
            </div>

            <Button 
              onClick={startGame}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-xl"
            >
              🚀 Start Showdown!
            </Button>
          </div>
        )}

        {gameActive && !gameComplete && (
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <span className="text-blue-300">Question {currentQuestion + 1} of {triviaQuestions.length}</span>
                <div className="flex items-center gap-4">
                  <span className={`font-bold ${getDifficultyColor(triviaQuestions[currentQuestion].difficulty)}`}>
                    {triviaQuestions[currentQuestion].difficulty.toUpperCase()}
                  </span>
                  <span className="text-yellow-400">+{triviaQuestions[currentQuestion].points} pts</span>
                </div>
              </div>
              
              <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
                <div 
                  className="bg-red-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${(timeLeft / 15) * 100}%` }}
                ></div>
              </div>
            </div>

            <div className="bg-blue-800/50 rounded-xl p-8 mb-6">
              <h3 className="text-2xl font-bold text-blue-100 mb-6 text-center">
                {triviaQuestions[currentQuestion].question}
              </h3>
              
              <div className="grid gap-4">
                {triviaQuestions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => selectAnswer(index)}
                    disabled={selectedAnswer !== null}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedAnswer === null 
                        ? 'border-blue-600 hover:border-blue-400 hover:bg-blue-700/30' 
                        : selectedAnswer === index
                          ? index === triviaQuestions[currentQuestion].correctAnswer
                            ? 'border-green-500 bg-green-600/30'
                            : 'border-red-500 bg-red-600/30'
                          : index === triviaQuestions[currentQuestion].correctAnswer && showExplanation
                            ? 'border-green-500 bg-green-600/30'
                            : 'border-gray-600 bg-gray-700/30'
                    }`}
                  >
                    <span className="font-bold mr-3">{String.fromCharCode(65 + index)}.</span>
                    {option}
                  </button>
                ))}
              </div>
            </div>

            {showExplanation && (
              <div className="bg-black/30 rounded-lg p-6 text-center">
                <div className="text-4xl mb-3">
                  {selectedAnswer === triviaQuestions[currentQuestion].correctAnswer ? '✅' : '❌'}
                </div>
                <p className="text-blue-200">{triviaQuestions[currentQuestion].explanation}</p>
                {streak > 1 && (
                  <div className="mt-4 flex items-center justify-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    <span className="text-yellow-400 font-bold">{streak} Streak!</span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {gameComplete && (
          <div className="text-center py-8">
            <div className="text-6xl mb-6">🎉</div>
            <h2 className="text-3xl font-bold text-blue-100 mb-4">Showdown Complete!</h2>
            
            <div className="bg-blue-800/50 rounded-xl p-8 max-w-md mx-auto mb-8">
              <div className="text-4xl font-bold text-yellow-400 mb-2">{score}</div>
              <div className="text-blue-200 mb-4">Total Points</div>
              
              <div className={`text-2xl font-bold mb-4 ${getScoreRating().color}`}>
                {getScoreRating().rating}
              </div>
              
              <div className="space-y-2 text-blue-200">
                <div>Best Streak: {bestStreak}</div>
                <div>Questions: {currentQuestion + 1}/{triviaQuestions.length}</div>
              </div>
            </div>

            <Button 
              onClick={startGame}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 mr-4"
            >
              Play Again
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}