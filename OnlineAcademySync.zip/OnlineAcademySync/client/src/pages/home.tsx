import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Search, BookOpen, TrendingUp, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import MobileTabBar from "@/components/MobileTabBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/enrollments"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const featuredCourses = courses.slice(0, 8);
  const inProgressCourses = enrollments.filter(e => e.progress > 0 && e.progress < 100).slice(0, 2);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white lg:hidden flex flex-col justify-center items-center space-y-8 text-xl font-semibold text-gray-800">
          <Link href="/courses" className="hover:text-blue-600 transition-colors">
            <a>All Courses</a>
          </Link>
          <Link href="/dashboard" className="hover:text-blue-600 transition-colors">
            <a>Dashboard</a>
          </Link>
          <Link href="/subscribe" className="hover:text-blue-600 transition-colors">
            <a>Membership</a>
          </Link>
          <Button 
            onClick={() => window.location.href = '/api/logout'}
            variant="outline"
            className="px-8 py-3 rounded-full font-semibold"
          >
            Sign Out
          </Button>
        </div>
      )}

      {/* EPIC Welcome Hero Section for Future Legends! */}
      <section className="bg-gradient-to-br from-purple-600 via-pink-500 to-blue-600 py-16 relative overflow-hidden">
        {/* Cool animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-bounce"></div>
          <div className="absolute top-32 right-20 w-16 h-16 bg-green-400 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute bottom-20 left-1/4 w-12 h-12 bg-pink-400 rounded-full opacity-20 animate-bounce delay-300"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-8">
            <div className="mb-4">
              <span className="inline-block bg-yellow-400 text-purple-900 px-6 py-2 rounded-full text-sm font-bold animate-pulse">
                🎮 Level Up Your Life! Ages 12+
              </span>
            </div>
            <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
              🚀 Welcome back, 
              <span className="bg-gradient-to-r from-yellow-400 to-pink-400 bg-clip-text text-transparent">
                {user?.firstName || 'Future Legend'}
              </span>!
            </h1>
            <p className="text-xl text-purple-100 max-w-3xl mx-auto leading-relaxed">
              Ready to continue your epic money adventure? Keep building those wealth superpowers and become the financial legend you were born to be! 💰✨
            </p>
          </div>

          {/* Epic Achievement Stats */}
          {stats && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 shadow-lg text-center border border-white/30 hover:scale-105 transition-transform duration-300">
                <div className="text-4xl mb-2">🎓</div>
                <div className="text-3xl font-bold text-yellow-300">{stats.coursesCompleted}</div>
                <div className="text-sm text-purple-100 font-semibold">Courses Conquered!</div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 shadow-lg text-center border border-white/30 hover:scale-105 transition-transform duration-300">
                <div className="text-4xl mb-2">⚡</div>
                <div className="text-3xl font-bold text-green-300">{stats.totalHours}</div>
                <div className="text-sm text-purple-100 font-semibold">Power Hours Gained!</div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 shadow-lg text-center border border-white/30 hover:scale-105 transition-transform duration-300">
                <div className="text-4xl mb-2">🏆</div>
                <div className="text-3xl font-bold text-pink-300">{stats.certificates}</div>
                <div className="text-sm text-purple-100 font-semibold">Epic Badges Earned!</div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-6 shadow-lg text-center border border-white/30 hover:scale-105 transition-transform duration-300">
                <div className="text-4xl mb-2">🚀</div>
                <div className="text-3xl font-bold text-blue-300">{stats.overallProgress}%</div>
                <div className="text-sm text-purple-100 font-semibold">Legend Status!</div>
              </div>
            </div>
          )}
        </div>
      </section>







      {/* Epic Money Superpowers Section */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="mb-4">
              <span className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-2 rounded-full text-sm font-bold">
                🎮 Choose Your Superpower!
              </span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              💰 Unlock Epic 
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Money Skills
              </span>!
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Ready to become a financial legend? Pick your adventure and start building the money superpowers that'll make you unstoppable! 🚀✨
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:gap-6">
            {featuredCourses.map((course) => (
              <CourseCard 
                key={course.id} 
                course={course} 
                showEnrollButton={true}
                isEnrolled={false}
              />
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/courses">
              <Button className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-3 rounded-lg font-semibold">
                View All Courses
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
            Accelerate Your Learning
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Upgrade to Premium or VIP membership for unlimited access to all courses and exclusive content.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/subscribe">
              <Button className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-xl font-bold text-lg hover:bg-yellow-300 transform hover:scale-105 transition-all duration-200 shadow-lg">
                Upgrade Membership
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button 
                variant="outline"
                className="border-2 border-yellow-400 text-yellow-400 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-yellow-400 hover:text-gray-900 transition-all duration-200"
              >
                View Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* iOS-Style Mobile Tab Bar */}
      <MobileTabBar />
    </div>
  );
}
