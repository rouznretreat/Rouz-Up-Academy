import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Shield, Users, FileText, Scale, Building, Heart, BookOpen, CheckCircle, History, Clock, Scroll, Brain, Settings } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import TrustQuiz from "@/components/TrustQuiz";
import SalvageDoctrineContent from "@/components/SalvageDoctrineContent";
import TrustBuilder from "@/components/TrustBuilder";
import BackToTop from "@/components/BackToTop";

export default function TrustCourse() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("modules");

  const courseModules = [
    {
      id: "basics",
      title: "🏛️ Trust Basics",
      description: "Learn the fundamental definitions of Trust, Grantor, Trustee, and Beneficiary with real-world examples",
      icon: Building,
      color: "from-blue-500 to-purple-600"
    },
    {
      id: "elements", 
      title: "🔧 Five Elements of a Trust",
      description: "Understand the five essential components that make a trust legally valid and enforceable",
      icon: Shield,
      color: "from-purple-500 to-pink-600"
    },
    {
      id: "duties",
      title: "⚖️ Duties & Responsibilities", 
      description: "Explore the legal obligations and responsibilities of each party in a trust relationship",
      icon: Scale,
      color: "from-green-500 to-blue-600"
    },
    {
      id: "documents",
      title: "📋 Required Documents",
      description: "Complete checklist of documents needed to create an enforceable trust",
      icon: FileText,
      color: "from-orange-500 to-red-600"
    },
    {
      id: "types",
      title: "🏗️ Trust vs Title Types", 
      description: "Learn about Revocable vs Irrevocable trusts and Legal vs Equitable title",
      icon: Users,
      color: "from-teal-500 to-green-600"
    },
    {
      id: "trustTypes",
      title: "📊 Types of Trusts",
      description: "Comprehensive guide to different trust structures and their specific purposes", 
      icon: BookOpen,
      color: "from-indigo-500 to-purple-600"
    },
    {
      id: "restrictions", 
      title: "🚫 Trust Restrictions",
      description: "Understanding limitations and legal boundaries when creating trusts",
      icon: Shield,
      color: "from-red-500 to-pink-600"
    },
    {
      id: "wealth",
      title: "💰 Building Generational Wealth",
      description: "Practical strategies for using trusts to create lasting family wealth",
      icon: Heart,
      color: "from-yellow-500 to-orange-600"
    }
  ];

  const menuTabs = [
    { id: "modules", label: "📚\nModules", icon: BookOpen },
    { id: "history", label: "📜\nHistory", icon: History },
    { id: "glossary", label: "📖\nGlossary", icon: FileText },
    { id: "property", label: "🏠\nProperty", icon: Building },
    { id: "drafting", label: "✍️\nDrafting", icon: Scroll },
    { id: "quiz", label: "🧠\nQuiz", icon: Brain },
    { id: "builder", label: "🔧 Trust\nBuilder", icon: Settings },
  ];

  const showMainMenu = () => {
    setActiveSection(null);
  };

  const showSection = (sectionId: string) => {
    setActiveSection(sectionId);
  };

  // Trust Basics Content Component
  const TrustBasicsContent = () => (
    <div className="space-y-6">
      <Button onClick={showMainMenu} variant="outline" className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Menu
      </Button>
      
      <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">What is a Trust? 🤔</h3>
        <p>A trust is a legal arrangement where one person (the grantor) gives another person (the trustee) the right to hold and manage property or assets for the benefit of a third party (the beneficiary). Think of it like a financial safety box with specific rules about who can access it and when.</p>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">Key Players in a Trust</h2>

      <div className="space-y-4">
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">🏦 Grantor (also called Settlor or Trustor)</h3>
          <p className="mb-3"><strong>Definition:</strong> The person who creates the trust and transfers their assets into it.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Real-Life Example:</strong> Sarah is a successful business owner who wants to ensure her children's college education is funded. She creates a trust and transfers $500,000 into it. Sarah is the grantor because she created the trust and provided the money.
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">👨‍💼 Trustee</h3>
          <p className="mb-3"><strong>Definition:</strong> The person or institution responsible for managing the trust assets according to the trust's terms.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Real-Life Example:</strong> Sarah appoints her trusted financial advisor, Mike, as the trustee. Mike's job is to invest the $500,000 wisely, pay for the children's educational expenses when the time comes, and follow all the rules Sarah set up in the trust document.
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">👶 Beneficiary</h3>
          <p className="mb-3"><strong>Definition:</strong> The person(s) who will receive benefits from the trust assets.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Real-Life Example:</strong> Sarah's two children, Emma (age 8) and James (age 10), are the beneficiaries. They will receive money from the trust to pay for college tuition, books, and living expenses when they reach age 18.
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">📚 Complete Trust Scenario</h3>
        <p className="font-semibold">The Johnson Family Trust:</p>
        <p className="mt-2">Mr. Johnson (Grantor) owns a rental property worth $800,000. He creates the "Johnson Family Education Trust" and transfers ownership of the property to his sister, Mrs. Smith (Trustee). The trust document states that rental income should be saved and used to pay for his three grandchildren's (Beneficiaries) college education. Mrs. Smith collects rent, maintains the property, and saves money in a special trust account. When each grandchild turns 18, they receive funds for their education expenses.</p>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">🎯 Why Use Trusts?</h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
          <h3 className="text-lg font-bold text-green-700 mb-2">💰 Wealth Building Benefits</h3>
          <ul className="space-y-2 text-green-700">
            <li>• Professional asset management</li>
            <li>• Tax-efficient wealth transfer</li>
            <li>• Compound growth over generations</li>
            <li>• Protection from poor financial decisions</li>
          </ul>
        </div>
        
        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded">
          <h3 className="text-lg font-bold text-orange-700 mb-2">🛡️ Protection Benefits</h3>
          <ul className="space-y-2 text-orange-700">
            <li>• Asset protection from creditors</li>
            <li>• Privacy in wealth transfer</li>
            <li>• Avoiding probate court</li>
            <li>• Controlled distribution timing</li>
          </ul>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">📋 Trust Creation Checklist</h2>
      
      <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-lg">
        <h3 className="text-lg font-bold text-yellow-800 mb-4">Essential Steps to Create Your Trust:</h3>
        <div className="space-y-3">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
            <div>
              <strong>Define Your Purpose:</strong> Clearly state why you're creating the trust (education, family support, asset protection)
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
            <div>
              <strong>Choose Your Trustee:</strong> Select someone trustworthy and capable of managing finances
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
            <div>
              <strong>Identify Beneficiaries:</strong> Decide who will benefit from the trust and when
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
            <div>
              <strong>Transfer Assets:</strong> Move your chosen property into the trust legally
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold">5</div>
            <div>
              <strong>Document Everything:</strong> Create proper legal documentation with professional help
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 flex justify-between items-center">
        <Button onClick={showMainMenu} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Menu
        </Button>
        <Button 
          onClick={() => showSection("elements")}
          className="bg-purple-600 text-white hover:bg-purple-700"
        >
          Next: Five Elements of a Trust
          <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
        </Button>
      </div>
    </div>
  );

  // History of Trusts Content Component
  const HistoryContent = () => (
    <div className="space-y-6">
      <Button onClick={showMainMenu} variant="outline" className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Menu
      </Button>
      
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">📜 The Ancient Origins of Trusts</h3>
        <p>Trusts have a rich history spanning over 2,000 years, evolving from ancient Roman civil law to become one of the most powerful wealth-building tools in modern finance.</p>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">🏛️ Roman Foundations</h2>

      <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
        <h3 className="text-lg font-bold text-blue-700 mb-2">Ancient Roman Civil Law</h3>
        <p className="mb-3">Although trusts existed thousands of years ago under Roman civil law, these early trust concepts laid the groundwork for modern wealth protection and transfer strategies.</p>
        <div className="bg-white p-3 rounded border">
          <strong>Roman Innovation:</strong> Romans created legal structures where property could be held by one person for the benefit of another, establishing the fundamental principle that still governs trust law today.
        </div>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">🏰 Medieval England: The Birth of Modern Trusts</h2>

      <div className="space-y-4">
        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded">
          <h3 className="text-lg font-bold text-amber-700 mb-2">⚔️ The Feudal System and "Uses"</h3>
          <p className="mb-3">The modern interpretation of trusts dates from the feudal period in England. The feudal form of a trust was called a "use."</p>
          
          <p><strong>How Feudal Uses Worked:</strong><br/>
          • The lord could place title in the land in the use for the benefit of himself, his son, his grandson, and so on<br/>
          • This allowed wealth transfer across generations while maintaining family control<br/>
          • Uses provided flexibility in an otherwise rigid feudal land system<br/>
          • Lords could bypass restrictive inheritance laws through creative use structures</p>

          <div className="bg-white p-3 rounded border mt-3">
            <strong>Medieval Example:</strong> Lord William owns vast estates but wants to ensure his lands benefit his family for generations. He creates a "use" where Sir Thomas holds legal title to the lands, but the income and benefits flow to Lord William's descendants according to his wishes.
          </div>
        </div>

        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded">
          <h3 className="text-lg font-bold text-amber-700 mb-2">📜 The Statute of Uses: Revolutionary Legal Requirements</h3>
          <p className="mb-3">Uses were regulated by a groundbreaking law called the Statute of Uses, which established principles still followed today.</p>
          
          <p><strong>Key Requirements of the Statute:</strong><br/>
          • <strong>Active Duties Required:</strong> No use was valid unless it imposed active duties on the trustee<br/>
          • <strong>No Passive Trustees:</strong> The trustee could not merely be a caretaker, but must have fiduciary obligations to fulfill<br/>
          • <strong>Passive Uses Void:</strong> Title could be held up only as long as the trustee had active functions to perform<br/>
          • <strong>Meaningful Responsibilities:</strong> Trustees had to actively manage and protect the beneficiaries' interests</p>

          <div className="bg-white p-3 rounded border mt-3">
            <strong>Legal Innovation:</strong> This requirement for "active duties" prevented wealthy families from creating empty shell arrangements and ensured trustees had real responsibilities to beneficiaries.
          </div>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">⚖️ Modern Legal Requirements</h2>

      <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
        <h3 className="text-lg font-bold text-green-700 mb-2">🎯 Active Duties in Today's Trusts</h3>
        <p className="mb-3">Modern law still requires that a valid and enforceable trust impose active duties on the trustee. When the trust is created, in specifying the trust purposes, the trustor must also indicate the duties of the trustee.</p>
        
        <p><strong>Examples of Active Duties Today:</strong><br/>
        • Investment management and portfolio oversight<br/>
        • Regular distribution of income or principal<br/>
        • Tax planning and compliance<br/>
        • Property maintenance and improvement<br/>
        • Educational planning for beneficiaries<br/>
        • Regular communication and accounting</p>

        <div className="bg-white p-3 rounded border mt-3">
          <strong>Modern Example:</strong> In the trust created by Kingston and Donna for their grandchildren, they impose the duty on Dr. Montague, as trustee, to make the trust property productive, and to use the income to pay for the education of their grandchildren. This is an active trust with clear fiduciary responsibilities.
        </div>
      </div>

      <h2 className="text-2xl font-bold text-purple-600 mt-8 mb-4">🌟 Evolution Through the Ages</h2>

      <div className="space-y-4">
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">🕰️ Timeline of Trust Development</h3>
          
          <div className="space-y-3">
            <div className="bg-white p-3 rounded border">
              <strong>Ancient Rome (100-400 AD):</strong> Early trust concepts in civil law for property transfer
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>Medieval England (1000-1500):</strong> Feudal "uses" develop to transfer land across generations
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>1535 - Statute of Uses:</strong> Establishes requirement for active trustee duties
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>1601 - Statute of Charitable Uses:</strong> Creates framework for charitable trusts
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>1700s-1800s:</strong> American colonies adopt English trust law principles
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>1900s:</strong> Modern estate planning and tax-efficient trust strategies emerge
            </div>
            <div className="bg-white p-3 rounded border">
              <strong>2000s-Present:</strong> Digital assets, international trusts, and advanced wealth protection
            </div>
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">🔄 Continuous Innovation</h3>
          <p><strong>Why Trusts Keep Evolving:</strong><br/>
          • Changing tax laws require new strategies<br/>
          • Global wealth creates international planning needs<br/>
          • Technology enables new types of assets and management<br/>
          • Family structures become more complex<br/>
          • Asset protection needs grow with litigation risks</p>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">🏆 Trusts Today: A Proven Legacy</h3>
        <p><strong>Over 2,000 Years of Success:</strong> From Roman civil law to medieval English uses to modern family offices, trusts have consistently helped families build and preserve wealth across generations.</p>
        
        <p className="mt-3"><strong>Key Historical Lessons:</strong><br/>
        • Active management beats passive wealth holding<br/>
        • Legal structure must match family goals<br/>
        • Professional trustees add value over time<br/>
        • Flexibility allows adaptation to changing circumstances<br/>
        • Early planning creates the greatest long-term benefits</p>
      </div>

      <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
        <h3 className="text-xl font-bold mb-3">💡 Historical Wisdom for Modern Families</h3>
        <p>The same principles that made trusts successful for medieval lords and Roman patricians still work today: professional management, clear active duties, legal structure, and long-term thinking. Your family can benefit from this 2,000-year-old proven wealth-building strategy!</p>
      </div>
    </div>
  );

  // Glossary Content Component
  const GlossaryContent = () => (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">📖 Comprehensive Trust Terminology</h3>
        <p>Master the complete vocabulary of trust law with these essential definitions from legal practice and estate planning.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">A-B Trusts</h4>
          <p className="text-gray-700 text-sm">Credit shelter and marital deduction trusts.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Administrative Control Rule</h4>
          <p className="text-gray-700 text-sm">Tax rule for short-term trust making the trustor tax liable if he retains administrative control over the trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Asset Protection Trust</h4>
          <p className="text-gray-700 text-sm">Trust established offshore to protect the grantor's assets.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Beneficiary</h4>
          <p className="text-gray-700 text-sm">Person who has equitable title to a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Cestui Que Trust</h4>
          <p className="text-gray-700 text-sm">Beneficiary.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Charitable Lead Trusts</h4>
          <p className="text-gray-700 text-sm">Charitable remainder unitrusts and charitable remainder annuity trusts.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Charitable Remainder Annuity Trust</h4>
          <p className="text-gray-700 text-sm">Trust in which the income goes to a private person and the remainder goes to charity.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Charitable Remainder Unitrust</h4>
          <p className="text-gray-700 text-sm">Trust in which a private person receives a percentage of the income, the rest and the remainder going to charity.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Charitable Trust</h4>
          <p className="text-gray-700 text-sm">Trust created for a public, charitable purpose.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Clifford Trust</h4>
          <p className="text-gray-700 text-sm">Short-term trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Constructive Trust</h4>
          <p className="text-gray-700 text-sm">Implied trust used to right a wrong.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Conveyance of Trust</h4>
          <p className="text-gray-700 text-sm">Method of transferring realty to a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Corpus</h4>
          <p className="text-gray-700 text-sm">Trust property.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Creator</h4>
          <p className="text-gray-700 text-sm">Trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Cy Pres</h4>
          <p className="text-gray-700 text-sm">Doctrine permitting changes in the operation of a public trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Declaration of Trust</h4>
          <p className="text-gray-700 text-sm">Instrument creating an inter vivos trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Deed of Trust</h4>
          <p className="text-gray-700 text-sm">Method of transferring realty to a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Disclaimer Trust</h4>
          <p className="text-gray-700 text-sm">Trust formed if a surviving spouse declines to accept the estate's assets outright.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Discretionary Trust</h4>
          <p className="text-gray-700 text-sm">Trust in which trustee is given broad powers of discretion with respect to investments and distribution of income.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Divested</h4>
          <p className="text-gray-700 text-sm">Losing a legal right.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Duration Rule</h4>
          <p className="text-gray-700 text-sm">Tax rule stating trusts that exist for less than ten years and a day, or the life of the beneficiary, make the grantor tax liable.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Dynasty Trust</h4>
          <p className="text-gray-700 text-sm">Trust used to avoid violating the Rule against Perpetuities.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Enjoyment Control Rule</h4>
          <p className="text-gray-700 text-sm">Tax rule for short-term trusts making the trustor tax liable if he may enjoy the income from the trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Equitable Title</h4>
          <p className="text-gray-700 text-sm">Title giving the beneficiary the right to enjoy the trust property subject to limitations imposed by the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Express Trust</h4>
          <p className="text-gray-700 text-sm">Trust created by the voluntary and deliberate act of the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Failed Trust</h4>
          <p className="text-gray-700 text-sm">Trust that terminates because its objective cannot be accomplished.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Fertile Octogenarian</h4>
          <p className="text-gray-700 text-sm">Doctrine stating a person is capable of bearing children until death.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Fiduciary</h4>
          <p className="text-gray-700 text-sm">Trustee, a person held to a standard of care higher than ordinary care.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Fiduciary Returns</h4>
          <p className="text-gray-700 text-sm">Tax returns filed by trustees and executors.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Generation Skipping Transfer</h4>
          <p className="text-gray-700 text-sm">Trusts that benefit persons two or more generations removed from the trustor are subject to special tax rules.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Grantor</h4>
          <p className="text-gray-700 text-sm">Person who creates a trust with real estate.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Implied Trust</h4>
          <p className="text-gray-700 text-sm">Trust created by operation of law.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Indefinite Class</h4>
          <p className="text-gray-700 text-sm">Group identified by general characteristics, a charitable group.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Injunction</h4>
          <p className="text-gray-700 text-sm">Court order to stop performing a specified act.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Inter Vivos Trust</h4>
          <p className="text-gray-700 text-sm">Trust taking effect during the life of the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Irrevocable Trust</h4>
          <p className="text-gray-700 text-sm">Trust that cannot be revoked by the creator.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Legal List</h4>
          <p className="text-gray-700 text-sm">Statutorily approved investments for fiduciaries.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Legal Title</h4>
          <p className="text-gray-700 text-sm">Title held by the trustee giving the holder the right to preserve, protect, and defend the trust property, subject to duties imposed by the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Operation of Law</h4>
          <p className="text-gray-700 text-sm">Actions having certain legal consequences regardless of the wishes of the parties involved.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Overendowed Trust</h4>
          <p className="text-gray-700 text-sm">Resulting trust with income greater than is needed to accomplish the trust purpose.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Premium Payment Rule</h4>
          <p className="text-gray-700 text-sm">Tax rule for short-term trust making the trustor tax liable if the trust can be used to pay the trustor's insurance premiums.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Pour-Over Trust</h4>
          <p className="text-gray-700 text-sm">Property being added to the corpus of a separate trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Power of Appointment</h4>
          <p className="text-gray-700 text-sm">Legal right to select successor beneficiary.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Principal</h4>
          <p className="text-gray-700 text-sm">Trust property of cash.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Private Trust</h4>
          <p className="text-gray-700 text-sm">Trust designed to fulfill a private purpose of the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Public Trust</h4>
          <p className="text-gray-700 text-sm">Charitable trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Purchase Money Resulting Trust</h4>
          <p className="text-gray-700 text-sm">Resulting trust in which person holds property for the benefit of the person who paid for the property.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Qualified Personal Residence Trust</h4>
          <p className="text-gray-700 text-sm">Trust established only with the personal residence of the grantor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">QTIP (Qualified Terminable Interest Property)</h4>
          <p className="text-gray-700 text-sm">Property left to a surviving spouse under a trust that qualifies for a marital deduction.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Recapture Rule</h4>
          <p className="text-gray-700 text-sm">Tax rule taxing the trustor of a short-term trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Remainderman</h4>
          <p className="text-gray-700 text-sm">Person in whom legal and equitable titles merge.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Res</h4>
          <p className="text-gray-700 text-sm">Trust property consisting of personalty.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Resulting Trust</h4>
          <p className="text-gray-700 text-sm">Implied trust in which the trust property reverts to the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Reversion</h4>
          <p className="text-gray-700 text-sm">Legal and equitable title merging in the trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Reversionary Interest</h4>
          <p className="text-gray-700 text-sm">Remainder interests of a trustor.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Revocable Trust</h4>
          <p className="text-gray-700 text-sm">Trust in which the trustor retains the power to revoke.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Rule Against Perpetuities</h4>
          <p className="text-gray-700 text-sm">All interests must vest, if at all, within 21 years after the death of a life in being plus the period of gestation.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Salvage Doctrines</h4>
          <p className="text-gray-700 text-sm">State statutory rules used to save trusts from violating the rule against perpetuities.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Self-Dealing</h4>
          <p className="text-gray-700 text-sm">Breach of fiduciary obligation in which trustee makes a benefit for himself instead of the trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Settlor</h4>
          <p className="text-gray-700 text-sm">Trustor who creates a trust with personal property.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Sovereign Immunity</h4>
          <p className="text-gray-700 text-sm">Legal inability to sue the government.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Specific Performance</h4>
          <p className="text-gray-700 text-sm">Court order to perform a specific act.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Spendthrift Trust</h4>
          <p className="text-gray-700 text-sm">Trust designed to prevent the beneficiary from alienating his interest.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Spousal Lifetime Access Trust</h4>
          <p className="text-gray-700 text-sm">Marital deduction trust that permits the spouse to invade the corpus.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Spray Trust</h4>
          <p className="text-gray-700 text-sm">Discretionary trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Sprinkling Trust</h4>
          <p className="text-gray-700 text-sm">Discretionary trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Statute of Uses</h4>
          <p className="text-gray-700 text-sm">Feudal law concerned with trusts.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Statutory Trust</h4>
          <p className="text-gray-700 text-sm">Trust provided by specific state statute.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Testamentary Trust</h4>
          <p className="text-gray-700 text-sm">Trust created by a will.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Totten Trust</h4>
          <p className="text-gray-700 text-sm">Bank account "in trust for" a third party.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Trust Instrument</h4>
          <p className="text-gray-700 text-sm">Document creating a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Trustee</h4>
          <p className="text-gray-700 text-sm">Person who holds legal title to trust property.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Trustor</h4>
          <p className="text-gray-700 text-sm">Creator of a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Trust Property</h4>
          <p className="text-gray-700 text-sm">Property held in trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Use</h4>
          <p className="text-gray-700 text-sm">Feudal term for a trust.</p>
        </div>

        <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-lg font-bold text-purple-600 mb-2">Vested</h4>
          <p className="text-gray-700 text-sm">Moment at which a person has an enforceable right.</p>
        </div>
      </div>
    </div>
  );

  // Property Content Component
  const PropertyContent = () => (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">🏠 Trust Property Guide</h3>
        <p>Understanding what property can be held in trusts and how different asset types are managed for maximum wealth building.</p>
      </div>

      <div className="space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">🏛️ Property Law Fundamentals</h4>
          
          <div className="space-y-6">
            <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-500">
              <h5 className="font-bold text-blue-700 mb-3">Real Property vs. Personal Property</h5>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-blue-600 mb-2">Real Property</h6>
                  <p className="text-sm mb-2">Land and anything permanently attached to it</p>
                  <ul className="text-xs space-y-1">
                    <li>• Land itself and natural resources</li>
                    <li>• Buildings and structures</li>
                    <li>• Trees and vegetation</li>
                    <li>• Fixtures attached to buildings</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-blue-600 mb-2">Personal Property</h6>
                  <p className="text-sm mb-2">All property that is not real property</p>
                  <ul className="text-xs space-y-1">
                    <li>• Movable objects and possessions</li>
                    <li>• Vehicles, furniture, jewelry</li>
                    <li>• Stocks, bonds, bank accounts</li>
                    <li>• Intellectual property rights</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-green-50 p-4 rounded border-l-4 border-green-500">
              <h5 className="font-bold text-green-700 mb-3">Freeholds vs. Leaseholds</h5>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-green-600 mb-2">Freehold Estates</h6>
                  <p className="text-sm mb-2">Ownership interests of indefinite duration</p>
                  <ul className="text-xs space-y-1">
                    <li>• Fee simple absolute (complete ownership)</li>
                    <li>• Fee simple defeasible (conditional)</li>
                    <li>• Life estates (duration of someone's life)</li>
                    <li>• No predetermined expiration date</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-green-600 mb-2">Leasehold Estates</h6>
                  <p className="text-sm mb-2">Temporary rights to use and occupy property</p>
                  <ul className="text-xs space-y-1">
                    <li>• Term for years (fixed period)</li>
                    <li>• Periodic tenancy (month-to-month)</li>
                    <li>• Tenancy at will (indefinite)</li>
                    <li>• Predetermined expiration or termination</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded border-l-4 border-purple-500">
              <h5 className="font-bold text-purple-700 mb-3">Mortgages</h5>
              <div className="bg-white p-3 rounded">
                <p className="text-sm mb-3">A mortgage is a legal instrument that creates a security interest in real property to secure payment of a debt or obligation.</p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h6 className="font-bold text-purple-600 mb-2">Key Components:</h6>
                    <ul className="text-xs space-y-1">
                      <li>• Mortgagor (borrower/property owner)</li>
                      <li>• Mortgagee (lender)</li>
                      <li>• Principal amount of the loan</li>
                      <li>• Interest rate and payment terms</li>
                    </ul>
                  </div>
                  <div>
                    <h6 className="font-bold text-purple-600 mb-2">Legal Effect:</h6>
                    <ul className="text-xs space-y-1">
                      <li>• Creates lien on the property</li>
                      <li>• Secures repayment of debt</li>
                      <li>• Allows foreclosure if default occurs</li>
                      <li>• Property serves as collateral</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 p-4 rounded border-l-4 border-orange-500">
              <h5 className="font-bold text-orange-700 mb-3">Liens vs. Easements</h5>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-orange-600 mb-2">Lien</h6>
                  <p className="text-sm mb-2">A security interest or legal claim against property to secure payment of a debt</p>
                  <ul className="text-xs space-y-1">
                    <li>• Mortgage liens (voluntary)</li>
                    <li>• Tax liens (statutory)</li>
                    <li>• Mechanic's liens (construction)</li>
                    <li>• Judgment liens (court-ordered)</li>
                  </ul>
                  <p className="text-xs mt-2 font-bold">Purpose: Secure payment of money owed</p>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-orange-600 mb-2">Easement</h6>
                  <p className="text-sm mb-2">A right to use another person's property for a specific purpose</p>
                  <ul className="text-xs space-y-1">
                    <li>• Right-of-way for access</li>
                    <li>• Utility easements for services</li>
                    <li>• Conservation easements</li>
                    <li>• Appurtenant vs. in gross</li>
                  </ul>
                  <p className="text-xs mt-2 font-bold">Purpose: Grant specific use rights</p>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-4 rounded border-l-4 border-teal-500">
              <h5 className="font-bold text-teal-700 mb-3">Five Types of Concurrent Ownership</h5>
              <div className="grid md:grid-cols-1 gap-3">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-teal-600 mb-2">1. Joint Tenancy</h6>
                  <p className="text-xs">Multiple owners with right of survivorship; when one dies, their share automatically passes to surviving joint tenants</p>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-teal-600 mb-2">2. Tenancy in Common</h6>
                  <p className="text-xs">Multiple owners with separate, transferable interests; no right of survivorship; each can sell or will their share</p>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-teal-600 mb-2">3. Tenancy by the Entirety</h6>
                  <p className="text-xs">Ownership between married couples; includes right of survivorship and protection from individual creditors</p>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-teal-600 mb-2">4. Community Property</h6>
                  <p className="text-xs">Property acquired during marriage in community property states; each spouse owns 50% interest</p>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-teal-600 mb-2">5. Cooperative and Condominium</h6>
                  <p className="text-xs">Cooperative: ownership of shares in corporation; Condominium: individual ownership of units plus common areas</p>
                </div>
              </div>
            </div>

            <div className="bg-red-50 p-4 rounded border-l-4 border-red-500">
              <h5 className="font-bold text-red-700 mb-3">Life Estates</h5>
              <div className="space-y-4">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-red-600 mb-2">Regular Life Estate</h6>
                  <p className="text-sm mb-2">An ownership interest that lasts for the duration of a specific person's life (usually the life tenant's own life)</p>
                  <ul className="text-xs space-y-1">
                    <li>• Life tenant has right to use and profit from property</li>
                    <li>• Cannot commit waste or permanent alterations</li>
                    <li>• Responsible for taxes, insurance, and maintenance</li>
                    <li>• Interest terminates upon life tenant's death</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-red-600 mb-2">Life Estate Pur Autre Vie</h6>
                  <p className="text-sm mb-2">A life estate measured by the life of someone other than the life tenant</p>
                  <ul className="text-xs space-y-1">
                    <li>• Duration based on third party's life</li>
                    <li>• Life tenant may die before measuring life</li>
                    <li>• Estate continues until measuring person dies</li>
                    <li>• Can be inherited by life tenant's heirs</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-indigo-50 p-4 rounded border-l-4 border-indigo-500">
              <h5 className="font-bold text-indigo-700 mb-3">Tangible vs. Intangible Property</h5>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-indigo-600 mb-2">Tangible Property</h6>
                  <p className="text-sm mb-2">Property that has physical substance and can be touched</p>
                  <ul className="text-xs space-y-1">
                    <li>• Real estate and buildings</li>
                    <li>• Vehicles, machinery, equipment</li>
                    <li>• Furniture, artwork, jewelry</li>
                    <li>• Inventory and raw materials</li>
                  </ul>
                </div>
                <div className="bg-white p-3 rounded">
                  <h6 className="font-bold text-indigo-600 mb-2">Intangible Property</h6>
                  <p className="text-sm mb-2">Property that has value but no physical form</p>
                  <ul className="text-xs space-y-1">
                    <li>• Stocks, bonds, bank accounts</li>
                    <li>• Patents, trademarks, copyrights</li>
                    <li>• Contracts and lease agreements</li>
                    <li>• Business goodwill and reputation</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 p-4 rounded border-l-4 border-yellow-500">
              <h5 className="font-bold text-yellow-700 mb-3">Methods of Transferring Title to Property</h5>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Sale/Purchase</h6>
                    <p className="text-xs">Voluntary transfer for consideration via deed</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Gift</h6>
                    <p className="text-xs">Voluntary transfer without consideration</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Will/Inheritance</h6>
                    <p className="text-xs">Transfer upon death through estate planning</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Trust Transfer</h6>
                    <p className="text-xs">Transfer to trustee for benefit of beneficiaries</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Adverse Possession</h6>
                    <p className="text-xs">Involuntary transfer through continuous occupation</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Eminent Domain</h6>
                    <p className="text-xs">Government taking for public use with compensation</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Foreclosure</h6>
                    <p className="text-xs">Involuntary transfer due to mortgage default</p>
                  </div>
                  <div className="bg-white p-3 rounded">
                    <h6 className="font-bold text-yellow-600 mb-1">Tax Sale</h6>
                    <p className="text-xs">Transfer due to unpaid property taxes</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">📚 Property Law Glossary</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Accounts Receivable</h5>
              <p className="text-gray-700 text-sm">Money owed to a business from customers for property or services sold.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Annuity</h5>
              <p className="text-gray-700 text-sm">Periodic payments of fixed sums of money.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Bond</h5>
              <p className="text-gray-700 text-sm">Evidence of indebtedness secured by a specific piece of property, paying interest until the loan is repaid.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Chose in Action</h5>
              <p className="text-gray-700 text-sm">One form of intangible personal property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Closely Held</h5>
              <p className="text-gray-700 text-sm">Privately owned corporation.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Community Property</h5>
              <p className="text-gray-700 text-sm">Method of holding title to property acquired during marriage; each spouse owns one-half of the property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Concurrent Ownership</h5>
              <p className="text-gray-700 text-sm">Fee estate held by two or more persons.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Condominium</h5>
              <p className="text-gray-700 text-sm">Type of ownership of real estate with some attributes of a tenancy in common.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Conveyance</h5>
              <p className="text-gray-700 text-sm">Transfer of real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Co-operative</h5>
              <p className="text-gray-700 text-sm">Type of interest in realty evidenced by owning shares; considered personal property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Copyright</h5>
              <p className="text-gray-700 text-sm">Government grant of exclusive use of artistic and literary works given to the creator.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Curtesy</h5>
              <p className="text-gray-700 text-sm">Old form of widower's right in property of deceased wife.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Debenture</h5>
              <p className="text-gray-700 text-sm">Unsecured evidence of indebtedness similar to a bond.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Deed</h5>
              <p className="text-gray-700 text-sm">Document specifying title to real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Digital Assets</h5>
              <p className="text-gray-700 text-sm">Electronic resources that are electronically stored.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Dower</h5>
              <p className="text-gray-700 text-sm">Old form of widow's right in property of deceased husband.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Easement</h5>
              <p className="text-gray-700 text-sm">Right of access over or use of another person's land.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Elective Share</h5>
              <p className="text-gray-700 text-sm">Forced share.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Estate</h5>
              <p className="text-gray-700 text-sm">Right in real property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Face Value</h5>
              <p className="text-gray-700 text-sm">Amount appearing on a bond or debenture; amount of the loan.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Fee</h5>
              <p className="text-gray-700 text-sm">Estate in real property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Fee Simple</h5>
              <p className="text-gray-700 text-sm">Highest form of estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Fixture</h5>
              <p className="text-gray-700 text-sm">Property attached to buildings considered to be real property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Foreclosure</h5>
              <p className="text-gray-700 text-sm">Right of mortgagee to seize and attach real estate for nonpayment of the loan.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Forced Share</h5>
              <p className="text-gray-700 text-sm">Current right of surviving spouse to a portion of deceased spouse's property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Freehold</h5>
              <p className="text-gray-700 text-sm">Estate in land for an indefinite period.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Gift</h5>
              <p className="text-gray-700 text-sm">Method of acquiring property whereby the recipient gives no consideration.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Goodwill</h5>
              <p className="text-gray-700 text-sm">Intangible asset of a business based on the business' reputation.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Grantee</h5>
              <p className="text-gray-700 text-sm">Recipient of real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Grantor</h5>
              <p className="text-gray-700 text-sm">Transferor of real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Homestead Exemption</h5>
              <p className="text-gray-700 text-sm">Estate property not subject to creditors' claims.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Intangible</h5>
              <p className="text-gray-700 text-sm">Personal property that represents something of value but may have little intrinsic value itself.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Joint Tenancy</h5>
              <p className="text-gray-700 text-sm">Method of multiple ownership of property with right of survivorship.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Landlord</h5>
              <p className="text-gray-700 text-sm">Person who leases real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Leasehold</h5>
              <p className="text-gray-700 text-sm">Tenancy in real estate for a fixed period of time.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Lessee</h5>
              <p className="text-gray-700 text-sm">Tenant.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Lessor</h5>
              <p className="text-gray-700 text-sm">Landlord.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">License</h5>
              <p className="text-gray-700 text-sm">Grant of use of intellectual property given by the holder of the exclusive right to the property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Lien</h5>
              <p className="text-gray-700 text-sm">Creditor's attachment of real and personal property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Life Estate</h5>
              <p className="text-gray-700 text-sm">Tenancy for a period of a person's life.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Life Estate Pur Autre Vie</h5>
              <p className="text-gray-700 text-sm">Tenancy for the life of another person.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Mark</h5>
              <p className="text-gray-700 text-sm">Exclusive right to use a name or symbol that designates a service or trade.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Maturity Date</h5>
              <p className="text-gray-700 text-sm">Date on which debtor repays the bond or debenture.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Mortgage</h5>
              <p className="text-gray-700 text-sm">Security interest on real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Mortgagee</h5>
              <p className="text-gray-700 text-sm">Person who gives a mortgage to purchase real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Mortgagor</h5>
              <p className="text-gray-700 text-sm">Person who takes a mortgage to purchase real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Partition</h5>
              <p className="text-gray-700 text-sm">Method of dividing the interests of multiple owners of real estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Patent</h5>
              <p className="text-gray-700 text-sm">Government grant of exclusive use of a scientific invention given to the inventor.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Personal Property</h5>
              <p className="text-gray-700 text-sm">Property that is movable and or intangible, not real property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Power of Appointment</h5>
              <p className="text-gray-700 text-sm">Authority to select a successor beneficiary.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Promissory Note</h5>
              <p className="text-gray-700 text-sm">Evidence of indebtedness.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Prepaid Expense</h5>
              <p className="text-gray-700 text-sm">Right to receive goods or services previously paid for.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Real Property</h5>
              <p className="text-gray-700 text-sm">Land and anything permanently affixed to the land.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Remainderman</h5>
              <p className="text-gray-700 text-sm">Person in whom legal and equitable titles merge.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Rent</h5>
              <p className="text-gray-700 text-sm">Fee paid by a tenant to a landlord.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Royalty</h5>
              <p className="text-gray-700 text-sm">Fee paid by a licensee to the holder of a copyright.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Secured Interest</h5>
              <p className="text-gray-700 text-sm">Creditor's right to specific property which has been set aside to satisfy the creditor in case of default.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Securities</h5>
              <p className="text-gray-700 text-sm">Contractual, proprietary interests between an investor and a business, evidenced by stocks, bonds, etc.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Share</h5>
              <p className="text-gray-700 text-sm">Stock; portion of a corporation owned by an investor.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Sole Proprietorship</h5>
              <p className="text-gray-700 text-sm">Business owned by one person.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Statutory Share</h5>
              <p className="text-gray-700 text-sm">Forced share of the decedent's estate.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Stock</h5>
              <p className="text-gray-700 text-sm">Evidence of ownership in a corporation.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Straw Man</h5>
              <p className="text-gray-700 text-sm">Method of changing title held by multiple owners.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tangible Property</h5>
              <p className="text-gray-700 text-sm">Personal property that is moveable or touchable.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tenancy</h5>
              <p className="text-gray-700 text-sm">Right to real property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tenancy by the Entirety</h5>
              <p className="text-gray-700 text-sm">Joint ownership of property between legally married couples.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tenancy in Partnership</h5>
              <p className="text-gray-700 text-sm">Multiple ownership of property by business partners; property passes to surviving partners, heirs of deceased partner receive the value of the deceased partner's interest in the property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tenancy in Common</h5>
              <p className="text-gray-700 text-sm">Multiple ownership of property in which each cotenant owns a divisible portion of the whole.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Tenancy in Severalty</h5>
              <p className="text-gray-700 text-sm">Ownership in real estate by just one person.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Title</h5>
              <p className="text-gray-700 text-sm">Evidence of ownership or possession of property.</p>
            </div>

            <div className="bg-white p-4 rounded-lg shadow border border-gray-200">
              <h5 className="text-lg font-bold text-purple-600 mb-2">Virtual Assets</h5>
              <p className="text-gray-700 text-sm">Digital assets.</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">💰 Financial Assets</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-blue-50 p-4 rounded">
              <h5 className="font-bold text-blue-700 mb-2">Cash & Bank Accounts</h5>
              <p className="text-sm mb-2">Checking accounts, savings accounts, money market accounts, CDs</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Management:</strong> Trustee opens new accounts in trust name for FDIC protection
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded">
              <h5 className="font-bold text-blue-700 mb-2">Investment Securities</h5>
              <p className="text-sm mb-2">Stocks, bonds, mutual funds, ETFs, options</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Management:</strong> Retitle to trust name, continue professional investment strategy
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded">
              <h5 className="font-bold text-blue-700 mb-2">Retirement Accounts</h5>
              <p className="text-sm mb-2">401(k), IRA, pension benefits</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Special Rules:</strong> Complex tax implications, often trust named as beneficiary
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded">
              <h5 className="font-bold text-blue-700 mb-2">Life Insurance</h5>
              <p className="text-sm mb-2">Whole life, term life, universal life policies</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Strategy:</strong> Irrevocable Life Insurance Trusts (ILITs) for tax benefits
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">🏘️ Real Estate</h4>
          
          <div className="space-y-4">
            <div className="bg-green-50 p-4 rounded">
              <h5 className="font-bold text-green-700 mb-2">Residential Property</h5>
              <p className="mb-2">Primary residence, vacation homes, rental properties</p>
              <div className="bg-white p-3 rounded">
                <strong>Example:</strong> The Garcia family places their $2M commercial building in trust. Professional trustee manages property, handles leases, while family receives rental income and property appreciation benefits.
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded">
              <h5 className="font-bold text-green-700 mb-2">Commercial Real Estate</h5>
              <p className="mb-2">Office buildings, retail spaces, industrial properties, land</p>
              <div className="bg-white p-3 rounded">
                <strong>Benefits:</strong> Professional management, liability protection, efficient transfer to heirs
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">🏢 Business Interests</h4>
          
          <div className="space-y-4">
            <div className="bg-purple-50 p-4 rounded">
              <h5 className="font-bold text-purple-700 mb-2">Closely Held Businesses</h5>
              <p className="mb-2">Family businesses, partnerships, LLC interests</p>
              <div className="bg-white p-3 rounded">
                <strong>Strategy:</strong> Succession planning, valuation discounts, maintaining family control
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded">
              <h5 className="font-bold text-purple-700 mb-2">Professional Practices</h5>
              <p className="mb-2">Medical practices, law firms, consulting businesses</p>
              <div className="bg-white p-3 rounded">
                <strong>Considerations:</strong> Licensing requirements, professional liability, succession planning
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">🎨 Unique Assets</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-amber-50 p-4 rounded">
              <h5 className="font-bold text-amber-700 mb-2">Collectibles & Art</h5>
              <p className="text-sm mb-2">Artwork, antiques, jewelry, rare collections</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Management:</strong> Professional appraisals, insurance, storage, conservation
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded">
              <h5 className="font-bold text-amber-700 mb-2">Intellectual Property</h5>
              <p className="text-sm mb-2">Patents, copyrights, trademarks, royalties</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Income:</strong> Ongoing royalty payments, licensing fees, sale proceeds
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded">
              <h5 className="font-bold text-amber-700 mb-2">Digital Assets</h5>
              <p className="text-sm mb-2">Cryptocurrency, NFTs, digital accounts</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Challenge:</strong> Secure storage, access keys, regulatory compliance
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded">
              <h5 className="font-bold text-amber-700 mb-2">Personal Property</h5>
              <p className="text-sm mb-2">Vehicles, boats, household items, family heirlooms</p>
              <div className="bg-white p-2 rounded text-xs">
                <strong>Consideration:</strong> Practical management, sentimental value, family disputes
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Drafting Content Component
  const DraftingContent = () => (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">✍️ Professional Trust Drafting Guide</h3>
        <p>Essential components and practical guidance for creating legally sound, enforceable trust documents based on established legal practice.</p>
      </div>

      <div className="space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">⚖️ Modern Drafting Considerations</h4>
          
          <div className="bg-amber-50 p-4 rounded border-l-4 border-amber-500">
            <h5 className="font-bold text-amber-700 mb-2">Marriage Conditions & Modern Legal Context</h5>
            <p className="text-sm mb-3">Following recent judicial developments regarding marriage equality, estate planners must carefully consider how marriage-related provisions in trusts and wills might be interpreted by future courts.</p>
            <div className="bg-white p-3 rounded text-sm">
              <p>Marriage restrictions in trusts are typically viewed as invalid, though courts have occasionally upheld specific conditions such as age requirements, parental consent clauses, or requirements to marry within certain parameters.</p>
              <p className="mt-2"><strong>Modern Strategy:</strong> Rather than creating potentially invalid restrictions, planners often structure distributions as lifetime interests with specific conditions, allowing flexibility while maintaining the grantor's intent.</p>
            </div>
          </div>

          <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-500 mt-4">
            <h5 className="font-bold text-blue-700 mb-2">Client Intent Documentation</h5>
            <p className="text-sm">Thorough consultation and documentation of client objectives is essential before drafting any trust provisions to ensure accurate implementation of their wealth transfer goals.</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">📋 Essential Trust Components</h4>
          
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-500">
              <h5 className="font-bold text-blue-700 mb-2">1. Trust Identification</h5>
              <p className="text-sm mb-2">While not legally required, providing a distinctive name helps distinguish the trust from other family wealth management structures and simplifies administration.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Examples:</strong> "Smith Family Education Trust" or "Heritage Wealth Management Trust"
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded border-l-4 border-green-500">
              <h5 className="font-bold text-green-700 mb-2">2. Trustee Designation</h5>
              <p className="text-sm mb-2">A critical drafting requirement often overlooked: failing to name a trustee renders the trust unenforceable, regardless of how well other provisions are written.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Example:</strong> "We hereby designate Sarah Johnson, CPA, to serve as Trustee of this trust."<br/>
                <strong>Important:</strong> Trustees must have legal capacity and may need to post bonds per state requirements.
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded border-l-4 border-purple-500">
              <h5 className="font-bold text-purple-700 mb-2">3. Trust Objectives</h5>
              <p className="text-sm mb-2">Clear, specific purpose statements are essential and must comply with legal standards and public policy requirements.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Example:</strong> "This trust shall provide educational funding and living expenses for our descendants while preserving capital for future generations."
              </div>
            </div>
            
            <div className="bg-orange-50 p-4 rounded border-l-4 border-orange-500">
              <h5 className="font-bold text-orange-700 mb-2">4. Trustee Authority</h5>
              <p className="text-sm mb-2">Beyond basic legal powers, comprehensive trusts should detail specific authorities and limitations to guide trustee decision-making.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Sample Authority Clause:</strong><br/>
                "The Trustee may, without court approval, buy, sell, exchange, or lease any trust assets on terms deemed appropriate; invest in any securities or properties regardless of diversification requirements; and maintain any existing investments for any period deemed prudent."
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">🏠 Property and Beneficiary Provisions</h4>
          
          <div className="space-y-4">
            <div className="bg-teal-50 p-4 rounded border-l-4 border-teal-500">
              <h5 className="font-bold text-teal-700 mb-2">5. Asset Specification</h5>
              <p className="text-sm mb-2">Trusts require existing, transferable property in which the grantor holds clear ownership rights. Detailed asset descriptions using proper legal terminology are essential for effective administration.</p>
            </div>
            
            <div className="bg-pink-50 p-4 rounded border-l-4 border-pink-500">
              <h5 className="font-bold text-pink-700 mb-2">6. Beneficiary Identification</h5>
              <p className="text-sm mb-2">Proper beneficiary designation is crucial for private trusts. Without named beneficiaries, the trust may fail and assets revert to the grantor through resulting trust principles.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Individual Naming:</strong> "our children David, Emma, and Michael" (closed class)<br/>
                <strong>Class Designation:</strong> "our descendants" (includes future family members)
              </div>
            </div>
            
            <div className="bg-indigo-50 p-4 rounded border-l-4 border-indigo-500">
              <h5 className="font-bold text-indigo-700 mb-2">7. Distribution Authority</h5>
              <p className="text-sm mb-2">Trusts may include provisions allowing designated parties to select future beneficiaries or adjust distributions based on changing circumstances.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Example:</strong> "Upon trust termination, the Trustee may distribute remaining assets among our descendants based on their financial needs and circumstances at that time."
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">⏰ Termination and Final Provisions</h4>
          
          <div className="space-y-4">
            <div className="bg-red-50 p-4 rounded border-l-4 border-red-500">
              <h5 className="font-bold text-red-700 mb-2">8. Duration and Termination</h5>
              <p className="text-sm mb-2">Effective trusts specify clear termination events, whether based on beneficiary lifespans, time periods, or specific circumstances.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Sample Provisions:</strong><br/>
                • "This trust terminates when the youngest beneficiary reaches age 30"<br/>
                • "Trust duration shall be 21 years from the date of establishment"<br/>
                • "Termination occurs when our daughter graduates from college or reaches age 25, whichever happens first"
              </div>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded border-l-4 border-yellow-500">
              <h5 className="font-bold text-yellow-700 mb-2">9. Final Distribution</h5>
              <p className="text-sm mb-2">Every private trust should specify ultimate distribution of remaining assets. Without this provision, assets may revert to the grantor or their estate.</p>
              <div className="bg-white p-3 rounded text-sm">
                <strong>Example:</strong> "Upon trust termination, remaining assets shall be distributed equally among our living descendants, per stirpes."
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded border-l-4 border-gray-500">
              <h5 className="font-bold text-gray-700 mb-2">10. Execution Requirements</h5>
              <p className="text-sm">Proper execution includes grantor signature with appropriate witnessing or notarization according to state law requirements.</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
          <h4 className="text-xl font-bold mb-3">📝 Drafting Checklist Summary</h4>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Trust name (recommended)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Trustee appointment (required)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Clear trust purpose (required)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Detailed trustee powers</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Specific trust property</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Named beneficiaries (required)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Power of appointment (optional)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Termination provisions</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Remainderman designation</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>Proper execution/signatures</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h4 className="text-xl font-bold text-purple-600 mb-4">📄 Sample Trust Document</h4>
          
          <div className="bg-gray-50 p-6 rounded border border-gray-300">
            <div className="text-center mb-6">
              <h5 className="text-lg font-bold">The Michael Rodriguez Education Trust</h5>
            </div>
            
            <div className="space-y-4 text-sm">
              <p>I, <strong>Maria Rodriguez</strong>, by this Instrument of Trust, hereby establish the Michael Rodriguez Education Trust.</p>
              
              <p>I hereby appoint the <strong>First National Bank of Phoenix</strong> to act as Trustee of the Trust. Without limiting the Trustee's general powers, I authorize my Trustee to sell, lease, or otherwise dispose of any part of my real or personal property, at such time and upon such terms as it may deem best; to invest the assets of the Trust in such securities and properties as it, in its sole discretion, may determine, whether or not authorized by law for investment of trust funds; and to retain for any purpose any investments currently held.</p>
              
              <p>I hereby hold my Trustee harmless for any diminution in value of the Trust not caused by its willful, deliberate, or negligent action, or for any loss not due to a breach of its fiduciary obligations.</p>
              
              <p>As compensation for its services as Trustee, the Trustee shall receive a fee equal to <strong>five percent (5%)</strong> of the gross income generated by the Trust.</p>
              
              <p>I have this day deposited the sum of <strong>$250,000</strong> (Two Hundred Fifty Thousand Dollars) in the Trustee Bank as the corpus of the Trust herein established.</p>
              
              <p>The Trustee shall invest the corpus, make it productive, and use the income so generated to defray the expenses of raising and educating my son, <strong>Michael Rodriguez</strong>, the Beneficiary of this Trust. The Trustee shall disburse the income periodically, but in no event less frequently than four times per year, to the legal Guardian of my son, Michael Rodriguez, and shall receive from said Guardian records of how said income has been dispensed. Should my son require more money for his support than is generated by the Trust income, the Trustee is authorized to invade the principal as needed.</p>
              
              <p>This Trust shall terminate when my son, <strong>Michael Rodriguez</strong>, attains the age of twenty-five, or marries, whichever comes first. At the termination of the Trust, the Trustee shall distribute the corpus of the Trust then remaining to my son, Michael Rodriguez. Should Michael Rodriguez die before the termination of this Trust, the Trust shall terminate on his death and the corpus then remaining shall be distributed outright to Michael's issue; should Michael die without issue, the corpus shall be distributed to <strong>the American Red Cross</strong>.</p>
              
              <div className="mt-6 pt-4 border-t border-gray-400">
                <p>IN WITNESS WHEREOF I have hereunto set my hand and seal this _____ day of _______ 20___</p>
                <div className="mt-4 space-y-2">
                  <p>_________________________</p>
                  <p>Maria Rodriguez, Grantor</p>
                  <p className="text-xs mt-4">[witnessed and/or notarized]</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 bg-blue-50 p-4 rounded border-l-4 border-blue-500">
            <h5 className="font-bold text-blue-700 mb-2">Document Analysis</h5>
            <p className="text-sm mb-2">This sample demonstrates all essential trust components:</p>
            <div className="grid md:grid-cols-2 gap-2 text-xs">
              <div className="space-y-1">
                <div>✓ Trust name and identification</div>
                <div>✓ Grantor designation (Maria Rodriguez)</div>
                <div>✓ Trustee appointment (First National Bank)</div>
                <div>✓ Comprehensive trustee powers</div>
                <div>✓ Specific trust property ($250,000)</div>
              </div>
              <div className="space-y-1">
                <div>✓ Clear beneficiary (Michael Rodriguez)</div>
                <div>✓ Distribution provisions (education expenses)</div>
                <div>✓ Termination conditions (age 25 or marriage)</div>
                <div>✓ Remainder distribution (to beneficiary or heirs)</div>
                <div>✓ Proper execution format</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
          <h4 className="text-xl font-bold mb-3">⚠️ Professional Legal Requirement</h4>
          <p className="mb-3">Trust drafting requires professional legal expertise to ensure compliance with current laws and effective implementation of client objectives. This guide provides educational information only.</p>
          <p><strong>Always consult with:</strong> Qualified estate planning attorneys for drafting, experienced trust professionals for administration, and tax advisors for compliance and optimization strategies.</p>
        </div>
      </div>
    </div>
  );

  // Quiz sections
  if (activeSection === "quiz-fundamentals") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Fundamentals Quiz</h1>
            </div>
            <TrustQuiz moduleType="fundamentals" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "quiz-types") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Types Quiz</h1>
            </div>
            <TrustQuiz moduleType="types" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "quiz-creation") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Creation Quiz</h1>
            </div>
            <TrustQuiz moduleType="creation" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "quiz-administration") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Administration Quiz</h1>
            </div>
            <TrustQuiz moduleType="administration" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "quiz-taxation") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Taxation Quiz</h1>
            </div>
            <TrustQuiz moduleType="taxation" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "quiz-drafting") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="pt-16 px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <button
                onClick={showMainMenu}
                className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
              >
                <ArrowLeft className="w-5 h-5" />
                <span>Back to Trust Course</span>
              </button>
              <h1 className="text-3xl font-bold text-purple-600">Trust Drafting Quiz</h1>
            </div>
            <TrustQuiz moduleType="drafting" />
          </div>
        </div>
      </div>
    );
  }

  if (activeSection === "history") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">History of Trusts</h1>
          <HistoryContent />
        </div>
      </div>
    );
  }

  // Five Elements Content Component  
  const FiveElementsContent = () => (
    <div className="space-y-6">
      <Button onClick={showMainMenu} variant="outline" className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Menu
      </Button>
      
      <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white p-6 rounded-lg">
        <p className="text-lg">For a trust to be legally valid and enforceable, it MUST have all five of these elements. Missing even one can make the entire trust invalid!</p>
      </div>

      <div className="space-y-4">
        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">1. 👤 Trustor (Grantor/Settlor)</h3>
          <p className="mb-3">The person who creates the trust and has the legal capacity to do so. They must be of sound mind and of legal age (usually 18).</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Example:</strong> Maria, age 45, is a small business owner who wants to create a trust. She is mentally competent and legally able to make this decision.
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">2. 🎯 Trust Purpose</h3>
          <p className="mb-3">The trust must have a clear, legal purpose. It cannot be created for illegal activities or to defraud creditors.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Valid Purposes:</strong> Education funding, charitable giving, providing for disabled family members, asset protection for minors<br/>
            <strong>Invalid Purposes:</strong> Hiding assets from legitimate debts, avoiding taxes illegally, funding illegal activities
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">3. 🏠 Trust Property (Trust Res)</h3>
          <p className="mb-3">There must be identifiable property or assets transferred into the trust. You can't have an empty trust!</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Examples of Trust Property:</strong> Cash, real estate, stocks, bonds, business interests, life insurance policies, art collections, intellectual property
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">4. 👨‍💼 Trustee</h3>
          <p className="mb-3">A competent person or institution must be appointed to manage the trust. The trustee has legal title to the property.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Who Can Be a Trustee:</strong> Family members, friends, attorneys, banks, trust companies. They must be trustworthy, organized, and able to handle financial responsibilities.
          </div>
        </div>

        <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
          <h3 className="text-lg font-bold text-purple-700 mb-2">5. 👥 Beneficiaries</h3>
          <p className="mb-3">There must be identifiable beneficiaries who will receive benefits from the trust. They have equitable title to the property.</p>
          <div className="bg-blue-50 p-3 rounded border">
            <strong>Types of Beneficiaries:</strong> Named individuals (John Smith), classes of people (all my grandchildren), charitable organizations (Red Cross), or even pets in some states!
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-3">🏗️ Building a Trust: Step by Step</h3>
        <p>1. <strong>Trustor:</strong> Jennifer decides to create a trust (she's the trustor)<br/>
        2. <strong>Purpose:</strong> To provide for her daughter's future needs (valid purpose)<br/>
        3. <strong>Property:</strong> She transfers $200,000 and her vacation home into the trust<br/>
        4. <strong>Trustee:</strong> She appoints her brother David to manage everything<br/>
        5. <strong>Beneficiary:</strong> Her 12-year-old daughter Sarah will receive benefits</p>
        <p className="mt-3"><strong>Result:</strong> A valid, enforceable trust that will protect assets for Sarah's future!</p>
      </div>
    </div>
  );

  if (activeSection === "basics") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Trust Basics</h1>
          <TrustBasicsContent />
        </div>
      </div>
    );
  }

  if (activeSection === "elements") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Five Essential Elements of a Trust</h1>
          <FiveElementsContent />
        </div>
      </div>
    );
  }

  // Duties & Responsibilities Content
  if (activeSection === "duties") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Duties & Responsibilities</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <h2 className="text-2xl font-bold text-purple-600">🏦 Grantor's Duties & Rights</h2>
            <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
              <h3 className="text-lg font-bold text-purple-700 mb-2">Initial Responsibilities:</h3>
              <p>• Create a clear, legally compliant trust document<br/>
              • Transfer assets properly into the trust<br/>
              • Choose a competent trustee<br/>
              • Define clear terms and conditions<br/>
              • Fund the trust adequately</p>
            </div>

            <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
              <h3 className="text-lg font-bold text-purple-700 mb-2">Ongoing Rights (Revocable Trust):</h3>
              <p>• Modify or revoke the trust<br/>
              • Change beneficiaries<br/>
              • Add or remove assets<br/>
              • Replace the trustee</p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">👨‍💼 Trustee's Fiduciary Duties</h2>
            <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-6 rounded-lg">
              <p><strong>Fiduciary Duty:</strong> The highest standard of care under law. Trustees must put beneficiaries' interests above their own and act with complete loyalty and good faith.</p>
            </div>

            <div className="space-y-4">
              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h3 className="text-lg font-bold text-green-700 mb-2">Duty of Loyalty</h3>
                <p>• Never use trust assets for personal benefit<br/>
                • Avoid conflicts of interest<br/>
                • Don't compete with the trust<br/>
                • Disclose any potential conflicts</p>
                <div className="bg-blue-50 p-3 rounded border mt-3">
                  <strong>Example:</strong> If the trust owns stock in ABC Company, the trustee cannot use insider information from managing the trust to buy ABC stock for their personal account.
                </div>
              </div>

              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h3 className="text-lg font-bold text-green-700 mb-2">Duty of Care</h3>
                <p>• Manage assets prudently and responsibly<br/>
                • Make informed investment decisions<br/>
                • Keep detailed records<br/>
                • Monitor trust performance regularly</p>
                <div className="bg-blue-50 p-3 rounded border mt-3">
                  <strong>Example:</strong> A trustee cannot invest all trust money in risky cryptocurrency without considering the beneficiaries' needs and risk tolerance.
                </div>
              </div>

              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h3 className="text-lg font-bold text-green-700 mb-2">Duty to Follow Trust Terms</h3>
                <p>• Distribute assets according to trust document<br/>
                • Respect the grantor's wishes<br/>
                • Follow all specific instructions<br/>
                • Don't deviate from the trust terms</p>
              </div>

              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h3 className="text-lg font-bold text-green-700 mb-2">Administrative Duties</h3>
                <p>• File tax returns when required<br/>
                • Provide regular accounting to beneficiaries<br/>
                • Communicate important information<br/>
                • Maintain insurance on trust property<br/>
                • Keep trust and personal assets separate</p>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">👶 Beneficiary Rights</h2>
            <div className="space-y-4">
              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">Information Rights</h3>
                <p>• Receive regular accountings from the trustee<br/>
                • Know about trust assets and performance<br/>
                • Get copies of the trust document<br/>
                • Be informed of significant decisions</p>
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">Distribution Rights</h3>
                <p>• Receive distributions according to trust terms<br/>
                • Request reasonable distributions for permitted purposes<br/>
                • Challenge inappropriate trustee decisions<br/>
                • Petition court if trustee breaches duties</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
              <h3 className="text-xl font-bold mb-3">💡 Wealth Building Tip</h3>
              <p>Choose trustees carefully! A good trustee can grow your family's wealth for generations, while a poor trustee can destroy it. Consider using professional trustees (banks, trust companies) for large trusts, or co-trustees combining family members with professionals.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Required Documents Content
  if (activeSection === "documents") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Required Documents for Creating a Trust</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📋 Essential Documents Checklist</h3>
              <p>Having the right documents is crucial for creating a legally enforceable trust. Missing documents can invalidate your trust or cause costly legal problems later!</p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Core Trust Documents</h2>

            <div className="space-y-4">
              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">1. 📄 Trust Agreement (Trust Indenture)</h3>
                <p className="mb-3"><strong>Purpose:</strong> The main legal document that creates the trust</p>
                <p><strong>Must Include:</strong><br/>
                • Names and addresses of grantor, trustee, and beneficiaries<br/>
                • Clear description of trust property<br/>
                • Trust purpose and objectives<br/>
                • Distribution terms and conditions<br/>
                • Trustee powers and limitations<br/>
                • Duration of the trust<br/>
                • Successor trustee provisions</p>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">2. 📋 Asset Transfer Documents</h3>
                <p><strong>Real Estate:</strong> New deeds showing trust as owner<br/>
                <strong>Bank Accounts:</strong> New account agreements in trust name<br/>
                <strong>Investments:</strong> Retitling of stocks, bonds, mutual funds<br/>
                <strong>Business Interests:</strong> Assignment of partnership/corporate interests<br/>
                <strong>Personal Property:</strong> Bills of sale or assignment documents</p>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">3. 🆔 Tax Identification Documents</h3>
                <p><strong>Revocable Trust:</strong> Usually uses grantor's Social Security Number<br/>
                <strong>Irrevocable Trust:</strong> Requires separate Employer Identification Number (EIN) from IRS</p>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Supporting Documentation</h2>

            <div className="space-y-4">
              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">4. 💼 Trustee Acceptance Document</h3>
                <p>Written acceptance by the trustee acknowledging their appointment and agreeing to serve. Should include understanding of fiduciary duties.</p>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">5. 📊 Asset Valuation Records</h3>
                <p>• Professional appraisals for real estate<br/>
                • Financial statements for business interests<br/>
                • Market values for investments<br/>
                • Insurance appraisals for valuable personal property</p>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">6. 🏦 Financial Institution Forms</h3>
                <p>• Trust account opening documents<br/>
                • Investment account applications<br/>
                • Safe deposit box agreements<br/>
                • Online banking setup forms</p>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Legal and Administrative Documents</h2>

            <div className="space-y-4">
              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">7. ⚖️ Legal Compliance Documents</h3>
                <p>• State filing requirements (if any)<br/>
                • Court approval (for certain trust types)<br/>
                • Regulatory compliance forms<br/>
                • Professional licensing (for corporate trustees)</p>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">8. 🔄 Backup and Succession Plans</h3>
                <p>• Successor trustee appointment letters<br/>
                • Emergency procedures document<br/>
                • Contact information for all parties<br/>
                • Professional advisor contact list</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📝 Document Creation Timeline</h3>
              <p><strong>Week 1-2:</strong> Draft trust agreement with attorney<br/>
              <strong>Week 3:</strong> Obtain asset appraisals and valuations<br/>
              <strong>Week 4:</strong> Finalize trust document and get signatures<br/>
              <strong>Week 5-6:</strong> Transfer assets into trust name<br/>
              <strong>Week 7:</strong> Set up trust bank accounts and tax ID<br/>
              <strong>Week 8:</strong> Complete final documentation and file records</p>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
              <h3 className="text-xl font-bold mb-3">💡 Professional Tip</h3>
              <p>Always work with qualified professionals when creating trust documents. The cost of proper legal and tax advice upfront is minimal compared to the potential costs of fixing mistakes later. A poorly drafted trust can cost your family thousands in legal fees and lost wealth!</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Trust vs Title Types Content
  if (activeSection === "types") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Trust Types & Title Concepts</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <h2 className="text-2xl font-bold text-purple-600">🔄 Revocable vs. Irrevocable Trusts</h2>

            <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🔄 Revocable Trust (Living Trust)</h3>
                <p className="mb-3"><strong>Definition:</strong> A trust that can be changed, modified, or completely canceled by the grantor during their lifetime.</p>
                
                <p><strong>Advantages:</strong><br/>
                • Complete control and flexibility<br/>
                • Easy to modify as circumstances change<br/>
                • Avoids probate court<br/>
                • Privacy protection<br/>
                • Manages assets if you become incapacitated</p>

                <p className="mt-3"><strong>Disadvantages:</strong><br/>
                • No tax benefits<br/>
                • No asset protection from creditors<br/>
                • Assets still count for estate tax purposes</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Best For:</strong> People who want to avoid probate and manage assets efficiently while maintaining full control. Great for families with minor children or those concerned about incapacity planning.
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🔒 Irrevocable Trust</h3>
                <p className="mb-3"><strong>Definition:</strong> A trust that generally cannot be changed or revoked once created. The grantor gives up control over the assets.</p>
                
                <p><strong>Advantages:</strong><br/>
                • Significant tax benefits<br/>
                • Asset protection from creditors<br/>
                • Reduces estate tax liability<br/>
                • Protects government benefits eligibility<br/>
                • Charitable tax deductions (for charitable trusts)</p>

                <p className="mt-3"><strong>Disadvantages:</strong><br/>
                • Loss of control over assets<br/>
                • Difficult or impossible to change<br/>
                • Complex tax filing requirements<br/>
                • Potential gift tax consequences</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Best For:</strong> Wealthy individuals focused on estate tax planning, asset protection, or charitable giving. Also useful for special needs beneficiaries or those with creditor concerns.
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">🏡 Legal Title vs. Equitable Title</h2>

            <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">Understanding the Split: Who Owns What?</h3>
              <p>When assets are placed in a trust, ownership is split into two types of "title" or ownership rights. This split is what makes trusts so powerful for wealth building and protection!</p>
            </div>

            <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">⚖️ Legal Title</h3>
                <p className="mb-3"><strong>Who Has It:</strong> The Trustee<br/>
                <strong>What It Means:</strong> The right to control, manage, and make decisions about the property</p>
                
                <p><strong>Trustee's Legal Rights:</strong><br/>
                • Sign contracts and legal documents<br/>
                • Buy, sell, or transfer property<br/>
                • Manage investments and collect income<br/>
                • Pay taxes and handle legal matters<br/>
                • Make day-to-day decisions about the property</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> John puts his rental property in a trust with his sister Mary as trustee. Mary's name goes on the deed (legal title), so she can sign leases, collect rent, hire contractors, and handle all property management decisions.
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">💰 Equitable Title</h3>
                <p className="mb-3"><strong>Who Has It:</strong> The Beneficiaries<br/>
                <strong>What It Means:</strong> The right to benefit from and eventually receive the property</p>
                
                <p><strong>Beneficiary's Equitable Rights:</strong><br/>
                • Receive income or distributions<br/>
                • Benefit from property appreciation<br/>
                • Eventually inherit the property<br/>
                • Hold trustee accountable<br/>
                • Receive information about trust activities</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> Continuing the example above, John's children have equitable title to the rental property. They don't control it day-to-day, but they receive the rental income, benefit from property appreciation, and will inherit the property according to the trust terms.
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🏠 Real Estate Example: The Power of Split Title</h3>
              <p><strong>Situation:</strong> The Garcia family owns a $2 million commercial building</p>
              
              <p className="mt-3"><strong>Traditional Ownership Problems:</strong><br/>
              • If parents die, property goes through expensive probate<br/>
              • If parents get sued, property could be seized<br/>
              • Family disputes could force property sale</p>

              <p className="mt-3"><strong>Trust Solution:</strong><br/>
              • <strong>Legal Title:</strong> Professional trustee (bank) manages the property<br/>
              • <strong>Equitable Title:</strong> Three Garcia children are beneficiaries<br/>
              • <strong>Result:</strong> Property is professionally managed, protected from personal lawsuits, and passes efficiently to next generation without probate!</p>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
              <h3 className="text-xl font-bold mb-3">💡 Wealth Building Strategy</h3>
              <p>The split between legal and equitable title is why trusts are so powerful for building generational wealth. You can have professional management (legal title) while keeping benefits in the family (equitable title). This combination often results in better investment performance and lower costs than individual ownership!</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Types of Trusts Content
  if (activeSection === "trustTypes") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Types of Trusts</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🏗️ Trust Types Overview</h3>
              <p>Different trusts serve different purposes. Choosing the right type depends on your goals: tax savings, asset protection, charitable giving, or special family needs.</p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Basic Trust Categories</h2>

            <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">📋 Express Trust</h3>
                <p className="mb-3"><strong>Definition:</strong> A trust created intentionally and explicitly by the grantor, usually through a written document.</p>
                
                <p><strong>Characteristics:</strong><br/>
                • Created by deliberate action<br/>
                • Clear written terms and conditions<br/>
                • Specific beneficiaries named<br/>
                • Detailed trustee instructions</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> Lisa creates a written trust document stating that her brother Tom will manage her $300,000 investment portfolio for the benefit of her two daughters. The trust specifies exactly how the money should be invested and when distributions should be made.
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🔍 Implied Trust</h3>
                <p className="mb-3"><strong>Definition:</strong> A trust created by law or court action, not by explicit intention. Courts create these to prevent unfairness.</p>
                
                <p><strong>Two Types:</strong><br/>
                • <strong>Resulting Trust:</strong> Property returns to original owner<br/>
                • <strong>Constructive Trust:</strong> Court imposes trust to prevent unjust enrichment</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> Mike gives his nephew $50,000 to buy a house "for the family." The nephew puts the house in his own name but never intended to keep it personally. A court might create an implied trust, making the nephew hold the house for the family's benefit.
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Specialized Trust Types</h2>

            <div className="space-y-4">
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🛡️ Life Insurance Trust (ILIT)</h3>
                <p className="mb-3"><strong>Purpose:</strong> Owns life insurance policies to remove them from your taxable estate while providing benefits to family.</p>
                
                <p><strong>Key Benefits:</strong><br/>
                • Life insurance proceeds avoid estate taxes<br/>
                • Provides liquidity to pay estate taxes<br/>
                • Protects benefits from beneficiary creditors<br/>
                • Can leverage wealth transfer</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Wealth Building Example:</strong> Robert, age 45, creates an ILIT and gifts $15,000 annually to pay premiums on a $2 million life insurance policy. When he dies, his family receives $2 million tax-free, while he only used his annual gift tax exclusion!
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🏰 Asset Protection Trust</h3>
                <p className="mb-3"><strong>Purpose:</strong> Protects assets from future creditors, lawsuits, and financial disasters while allowing some access to benefits.</p>
                
                <p><strong>Protection Features:</strong><br/>
                • Assets protected from grantor's creditors<br/>
                • Discretionary distributions only<br/>
                • Independent trustee required<br/>
                • Often located in protective states</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> Dr. Martinez, a surgeon concerned about malpractice lawsuits, places $1 million in a Nevada Asset Protection Trust. Even if he faces a large lawsuit, these assets are protected while still available for his family's needs through trustee distributions.
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">💑 QTIP Trust (Qualified Terminal Interest Property)</h3>
                <p className="mb-3"><strong>Purpose:</strong> Provides for surviving spouse while ensuring assets eventually go to chosen beneficiaries (often children from first marriage).</p>
                
                <p><strong>How It Works:</strong><br/>
                • Surviving spouse receives all income for life<br/>
                • Principal protected for remainder beneficiaries<br/>
                • Qualifies for unlimited marital deduction<br/>
                • Estate tax deferred until surviving spouse dies</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Blended Family Example:</strong> William has children from his first marriage and remarries Patricia. He creates a QTIP trust: Patricia receives income for life from his $3 million estate, but when she dies, the assets go to his children, not Patricia's relatives.
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h3 className="text-lg font-bold text-blue-700 mb-2">🛡️ Spendthrift Trust</h3>
                <p className="mb-3"><strong>Purpose:</strong> Protects beneficiaries from their own poor financial decisions and from creditors.</p>
                
                <p><strong>Protection Features:</strong><br/>
                • Beneficiaries cannot sell or assign their interest<br/>
                • Creditors cannot reach trust assets<br/>
                • Trustee has discretion over distributions<br/>
                • Protects against gambling, addiction, poor spending</p>

                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> Grandma Helen knows her grandson Jake struggles with gambling addiction. She creates a spendthrift trust with $500,000 for Jake's benefit. The trustee can pay for Jake's housing, education, and medical needs, but Jake cannot access the principal or assign his rights to creditors.
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🎯 Choosing the Right Trust Type</h3>
              <p><strong>For Young Families:</strong> Revocable Living Trust + Life Insurance Trust<br/>
              <strong>For Business Owners:</strong> Asset Protection Trust + Business Succession Trust<br/>
              <strong>For Blended Families:</strong> QTIP Trust + Spendthrift provisions<br/>
              <strong>For Charitable Goals:</strong> Charitable Remainder Trust + Private Foundation<br/>
              <strong>For Wealthy Couples:</strong> A-B Trust + Generation-Skipping Trust</p>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
              <h3 className="text-xl font-bold mb-3">💡 Advanced Strategy</h3>
              <p>Many successful families use multiple trusts working together! For example: a revocable trust for flexibility, an irrevocable life insurance trust for tax-free wealth transfer, and spendthrift provisions to protect beneficiaries. This "trust ecosystem" approach can multiply your wealth-building power!</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Trust Restrictions Content
  if (activeSection === "restrictions") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Trust Restrictions & Limitations</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">⚠️ Important Notice</h3>
              <p>While trusts are powerful tools, they're not magic wands! Understanding restrictions helps you create effective, legal trusts that actually accomplish your goals.</p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Legal Restrictions</h2>

            <div className="space-y-4">
              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">🚫 Rule Against Perpetuities</h3>
                <p className="mb-3"><strong>What It Is:</strong> A legal rule that prevents trusts from lasting forever in most states.</p>
                <p><strong>Traditional Rule:</strong> Trust must end within 21 years after the death of someone alive when the trust was created.</p>
                <p><strong>Modern Variations:</strong> Many states now allow 90-1000 year trusts or have abolished the rule entirely.</p>
                
                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Example:</strong> You create a trust in 2024 for your newborn grandson. Under traditional rules, the trust must distribute all assets by about 2110 (roughly 21 years after your grandson's potential death). However, in states like Delaware or Nevada, your trust could continue for hundreds of years!
                </div>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">📋 Purpose Restrictions</h3>
                <p><strong>Illegal Purposes:</strong> Trusts cannot be created for illegal activities<br/>
                <strong>Fraudulent Transfers:</strong> Cannot move assets to avoid legitimate debts<br/>
                <strong>Public Policy:</strong> Cannot violate fundamental public policy<br/>
                <strong>Impossible Conditions:</strong> Cannot require impossible or illegal acts</p>
                
                <div className="bg-white p-3 rounded border mt-3">
                  <strong>Invalid Trust Examples:</strong><br/>
                  • "I leave money to my son only if he never gets married" (restricts fundamental right)<br/>
                  • "Use this money to bribe government officials" (illegal purpose)<br/>
                  • Moving assets to a trust the day before bankruptcy filing (fraudulent transfer)
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Practical Limitations</h2>

            <div className="space-y-4">
              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">💸 Self-Settled Spendthrift Restrictions</h3>
                <p className="mb-3"><strong>General Rule:</strong> You cannot protect your own assets from your creditors by putting them in a trust you control.</p>
                <p><strong>Exceptions:</strong> Some states (Nevada, Delaware, Alaska) allow limited self-settled asset protection trusts with strict requirements.</p>
                
                <div className="bg-white p-3 rounded border mt-3">
                  <strong>What Doesn't Work:</strong> Creating a trust for yourself where you can still access all the money whenever you want, then claiming creditors can't touch it.
                </div>
              </div>

              <div className="bg-pink-50 border-l-4 border-pink-500 p-4 rounded">
                <h3 className="text-lg font-bold text-pink-700 mb-2">🌍 Jurisdictional Considerations</h3>
                <p className="mb-3"><strong>Why It Matters:</strong> Different states have different trust laws, and you can often choose the most favorable state.</p>
                <p><strong>Trust-Friendly States:</strong><br/>
                • <strong>Delaware:</strong> No rule against perpetuities, strong privacy<br/>
                • <strong>Nevada:</strong> Asset protection, no state income tax<br/>
                • <strong>South Dakota:</strong> Privacy, no state taxes, long durations<br/>
                • <strong>Alaska:</strong> Self-settled spendthrift trusts allowed</p>
                
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-4 rounded mt-3">
                  <strong>Strategic Example:</strong> The Chen family lives in California (high taxes, restrictive trust laws) but creates their dynasty trust in South Dakota (no state taxes, can last 1,000 years). This choice saves hundreds of thousands in taxes over generations!
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Practical Compliance Tips</h2>

            <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">✅ Best Practices for Avoiding Problems</h3>
              <p>• Work with qualified attorneys who specialize in trust law<br/>
              • Understand your state's specific requirements<br/>
              • Keep detailed records of all trust activities<br/>
              • Don't try to "game the system" with overly aggressive strategies<br/>
              • Review and update trusts regularly as laws change<br/>
              • Consider using corporate trustees for complex trusts<br/>
              • Get independent appraisals for valuable assets<br/>
              • File all required tax returns on time</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Building Generational Wealth Content
  if (activeSection === "wealth") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto p-6">
          <h1 className="text-3xl font-bold text-purple-600 mb-6">Building Generational Wealth with Trusts</h1>
          <div className="space-y-6">
            <Button onClick={showMainMenu} variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Menu
            </Button>
            
            <div className="bg-gradient-to-r from-pink-500 to-red-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🌟 The Power of Trusts for Wealth Building</h3>
              <p>Trusts aren't just for the ultra-wealthy! They're powerful tools that can help any family build, protect, and transfer wealth across generations. The key is starting early and thinking long-term.</p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Wealth Building Strategies</h2>

            <div className="space-y-4">
              <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
                <h3 className="text-xl font-bold mb-3">🚀 Strategy 1: The Compound Growth Advantage</h3>
                <p className="mb-3"><strong>The Concept:</strong> Professional trust management often produces better long-term returns than individual management.</p>
                
                <div className="bg-white text-gray-800 p-4 rounded mt-3">
                  <strong>Real Example: The Johnson Family Trust</strong><br/>
                  • <strong>Started:</strong> 1995 with $100,000<br/>
                  • <strong>Strategy:</strong> Professional management, diversified investments<br/>
                  • <strong>Result:</strong> Worth $850,000 in 2024 (average 7.5% annual return)<br/>
                  • <strong>Comparison:</strong> Same amount in savings accounts would be worth $180,000<br/>
                  • <strong>Wealth Created:</strong> An extra $670,000 for the family!
                </div>
                
                <p className="mt-3"><strong>How Trusts Help:</strong><br/>
                • Professional investment management<br/>
                • Reduced emotional decision-making<br/>
                • Long-term perspective<br/>
                • Tax-efficient strategies<br/>
                • Economies of scale</p>
              </div>

              <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
                <h3 className="text-xl font-bold mb-3">💰 Strategy 2: Tax-Efficient Wealth Transfer</h3>
                <p className="mb-3"><strong>The Problem:</strong> Without planning, families can lose 40%+ of wealth to taxes when transferring between generations.</p>
                
                <div className="bg-white text-gray-800 p-4 rounded mt-3">
                  <strong>Smart Planning Example:</strong><br/>
                  <strong>The Garcia Family (Net Worth: $5 Million)</strong><br/>
                  • <strong>Without Trust:</strong> Estate taxes could cost $600,000+<br/>
                  • <strong>With A-B Trust:</strong> Zero estate taxes using both spouses' exemptions<br/>
                  • <strong>With Generation-Skipping Trust:</strong> Benefits pass to grandchildren without additional estate taxes<br/>
                  • <strong>Total Tax Savings:</strong> Over $1 million across two generations!
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Starting Your Wealth Building Journey</h2>

            <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">📈 Wealth Building Timeline by Age</h3>
              
              <p><strong>Ages 20-30: Foundation Building</strong><br/>
              • Start with simple revocable living trust<br/>
              • Focus on life insurance trust for young families<br/>
              • Begin regular contributions to build trust assets<br/>
              • <em>Goal: Establish habits and structure</em></p>

              <p className="mt-3"><strong>Ages 30-45: Acceleration Phase</strong><br/>
              • Add irrevocable trusts for tax benefits<br/>
              • Business succession planning if applicable<br/>
              • Increase funding as income grows<br/>
              • <em>Goal: Maximize wealth accumulation</em></p>

              <p className="mt-3"><strong>Ages 45-60: Optimization Phase</strong><br/>
              • Advanced trust strategies (GRATs, CLATs)<br/>
              • Multi-generational planning<br/>
              • Charitable giving integration<br/>
              • <em>Goal: Efficient wealth transfer planning</em></p>

              <p className="mt-3"><strong>Ages 60+: Legacy Phase</strong><br/>
              • Finalize wealth transfer strategies<br/>
              • Train next generation on trust management<br/>
              • Ensure smooth succession<br/>
              • <em>Goal: Secure family legacy</em></p>
            </div>

            <h2 className="text-2xl font-bold text-purple-600">Getting Started: Your Action Plan</h2>

            <div className="space-y-4">
              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">🎯 Step 1: Define Your Goals</h3>
                <p>• What do you want to accomplish?<br/>
                • Who do you want to benefit?<br/>
                • What's your timeline?<br/>
                • What are your biggest concerns?</p>
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">👥 Step 2: Build Your Team</h3>
                <p>• <strong>Estate Planning Attorney:</strong> Creates legal documents<br/>
                • <strong>CPA/Tax Advisor:</strong> Handles tax implications<br/>
                • <strong>Financial Advisor:</strong> Manages investments<br/>
                • <strong>Trustee:</strong> Manages day-to-day operations</p>
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">💡 Step 3: Start Simple</h3>
                <p>• Begin with revocable living trust<br/>
                • Add life insurance trust if you have dependents<br/>
                • Fund gradually over time<br/>
                • Learn and adapt as you go</p>
              </div>

              <div className="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                <h3 className="text-lg font-bold text-purple-700 mb-2">📊 Step 4: Monitor and Adjust</h3>
                <p>• Review trust performance annually<br/>
                • Update as family circumstances change<br/>
                • Take advantage of new opportunities<br/>
                • Educate family members about the trust</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white p-6 rounded-lg border-l-4 border-orange-400">
              <h3 className="text-xl font-bold mb-3">🔑 The Ultimate Wealth Building Secret</h3>
              <p className="mb-3">The families that build the most generational wealth through trusts share one common trait: <strong>they start before they think they're ready and contribute consistently over time.</strong></p>
              
              <p className="mb-3">You don't need millions to start. You need vision, commitment, and the right guidance. A trust funded with just $1,000 per month from age 25 to 65, earning 7% annually, will be worth over $2.4 million at retirement!</p>
              
              <p><strong>Remember:</strong> The best time to plant a tree was 20 years ago. The second-best time is today. The same is true for building generational wealth through trusts.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Main Menu with Tabs
  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Back to Academy Button */}
      <div className="bg-white border-b border-gray-200 py-4">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href="/">
            <Button 
              variant="outline" 
              className="bg-white text-purple-600 border-purple-200 hover:bg-purple-50 font-medium"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Academy
            </Button>
          </Link>
        </div>
      </div>

      {/* Course Header */}
      <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 text-white py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Trust for Starters</h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">Building Generational Wealth Through Understanding Trusts</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {menuTabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setActiveSection(null);
                  }}
                  className={`flex items-center px-4 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <IconComponent className="w-5 h-5 mr-2" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {activeTab === "modules" && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courseModules.map((module) => {
              const IconComponent = module.icon;
              return (
                <Card 
                  key={module.id}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer border border-gray-200 overflow-hidden"
                  onClick={() => showSection(module.id)}
                >
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-br ${module.color} flex items-center justify-center text-white mb-4 shadow-lg`}>
                      <IconComponent className="w-8 h-8" />
                    </div>
                    <CardTitle className="text-lg font-bold text-gray-900 mb-2">
                      {module.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {module.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {activeTab === "history" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">History of Trusts</h2>
            <HistoryContent />
          </div>
        )}

        {activeTab === "glossary" && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">Trust Glossary</h2>
            <GlossaryContent />
          </div>
        )}

        {activeTab === "property" && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">Trust Property Types</h2>
            <PropertyContent />
          </div>
        )}

        {activeTab === "drafting" && (
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">Trust Drafting Guide</h2>
            <DraftingContent />
          </div>
        )}

        {activeTab === "quiz" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">Test Your Trust Knowledge</h2>
            
            <div className="mb-8 bg-gradient-to-r from-purple-500 to-indigo-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🧠 Comprehensive Trust Law Quiz</h3>
              <p className="mb-3">Test your understanding of trust fundamentals, creation, administration, taxation, and drafting principles.</p>
              <div className="text-sm opacity-90">
                <p>• 24 questions covering all essential trust concepts</p>
                <p>• Immediate feedback with detailed explanations</p>
                <p>• Score tracking and performance analysis</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                    <Shield className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Fundamentals</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Test your knowledge of basic trust concepts, legal titles, and fiduciary duties.</p>
                <button 
                  onClick={() => setActiveSection("quiz-fundamentals")}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                    <FileText className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Trust Types</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Learn about different trust categories, inter vivos, testamentary, and implied trusts.</p>
                <button 
                  onClick={() => setActiveSection("quiz-types")}
                  className="w-full px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                    <BookOpen className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Creation</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Understand trust creation requirements, documentation, and enforceability.</p>
                <button 
                  onClick={() => setActiveSection("quiz-creation")}
                  className="w-full px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                    <Users className="w-6 h-6 text-orange-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Administration</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Master trust administration, Rule Against Perpetuities, and termination.</p>
                <button 
                  onClick={() => setActiveSection("quiz-administration")}
                  className="w-full px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                    <Scale className="w-6 h-6 text-red-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Taxation</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Learn trust tax obligations, generation skipping, and income distribution.</p>
                <button 
                  onClick={() => setActiveSection("quiz-taxation")}
                  className="w-full px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg border border-purple-200">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                    <Scroll className="w-6 h-6 text-indigo-600" />
                  </div>
                  <h4 className="font-bold text-purple-600">Drafting</h4>
                </div>
                <p className="text-sm text-gray-600 mb-4">Test knowledge of the 10 essential areas for professional trust drafting.</p>
                <button 
                  onClick={() => setActiveSection("quiz-drafting")}
                  className="w-full px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors text-sm"
                >
                  Start Quiz (4 Questions)
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === "builder" && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-purple-600 mb-6">Interactive Trust Builder</h2>
            
            <div className="mb-8 bg-gradient-to-r from-green-500 to-teal-600 text-white p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3">🔧 Personalized Trust Planning Tool</h3>
              <p className="mb-3">Get customized trust recommendations based on your specific needs, goals, and circumstances.</p>
              <div className="text-sm opacity-90">
                <p>• Answer 7 guided questions about your trust objectives</p>
                <p>• Receive personalized trust type recommendations</p>
                <p>• Get complete document checklist and cost estimates</p>
                <p>• Professional next steps and implementation guidance</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Settings className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Start Building Your Trust Plan</h3>
                <p className="text-gray-600 mb-6">Our interactive tool will guide you through the trust planning process and provide personalized recommendations based on your unique situation.</p>
                
                <div className="grid md:grid-cols-3 gap-4 mb-6 text-sm">
                  <div className="bg-blue-50 p-4 rounded">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                    </div>
                    <h4 className="font-bold text-blue-700">Step 1: Assessment</h4>
                    <p className="text-blue-600">Answer questions about your goals and assets</p>
                  </div>
                  
                  <div className="bg-purple-50 p-4 rounded">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Brain className="w-4 h-4 text-purple-600" />
                    </div>
                    <h4 className="font-bold text-purple-700">Step 2: Analysis</h4>
                    <p className="text-purple-600">Get customized trust recommendations</p>
                  </div>
                  
                  <div className="bg-green-50 p-4 rounded">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <h4 className="font-bold text-green-700">Step 3: Action Plan</h4>
                    <p className="text-green-600">Receive complete implementation guide</p>
                  </div>
                </div>

                <button 
                  onClick={() => setActiveSection("trust-builder")}
                  className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold"
                >
                  Start Trust Builder
                </button>
                
                <p className="text-xs text-gray-500 mt-4">
                  ⚠️ This tool provides educational guidance only. Always consult with qualified legal professionals for actual trust creation.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Trust Builder Section */}
      {activeSection === "trust-builder" && (
        <TrustBuilder onBack={showMainMenu} />
      )}

      {/* Quiz Sections */}
      {activeSection?.startsWith("quiz-") && (
        <TrustQuiz 
          moduleType={activeSection.replace("quiz-", "") as any}
          onBack={showMainMenu}
        />
      )}

      {/* Footer */}
      <div className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-purple-600 font-semibold text-lg">🌟 Generational Wealth Starts Now! 🌟</p>
          <p className="text-gray-600 mt-2">Master the fundamentals of trusts and build lasting family wealth</p>
          <p className="text-sm text-gray-500 mt-4">💡 <strong>Remember:</strong> This app provides educational information only. Always consult with qualified legal and financial professionals before creating trusts or making financial decisions.</p>
          <p className="text-sm text-gray-500">Building generational wealth takes time, patience, and the right guidance - but the results can benefit your family for centuries!</p>
        </div>
      </div>
      <BackToTop />
    </div>
  );
}