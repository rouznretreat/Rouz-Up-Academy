import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { useState } from "react";
import { ArrowLeft, PlayCircle, CheckCircle, Clock, Users, Star, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/components/Header";

export default function CourseDetail() {
  const [match, params] = useRoute("/course/:id");
  const { isAuthenticated } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const courseId = params?.id;

  const { data: course, isLoading } = useQuery({
    queryKey: ["/api/courses", courseId],
    enabled: !!courseId,
  });

  const { data: modules = [] } = useQuery({
    queryKey: ["/api/modules", courseId],
    enabled: !!courseId,
  });

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/enrollments"],
    enabled: isAuthenticated,
  });

  const isEnrolled = enrollments.some((e: any) => e.courseId === parseInt(courseId || '0'));

  const handlePurchase = () => {
    window.location.href = `/checkout?courseId=${courseId}`;
  };

  const handleEnroll = () => {
    if (!isAuthenticated) {
      window.location.href = '/api/login';
      return;
    }
    // Handle enrollment logic
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Course Not Found</h1>
          <Button onClick={() => window.history.back()} variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <Button 
                onClick={() => window.history.back()}
                variant="outline"
                className="mb-6 text-white border-white hover:bg-white hover:text-blue-600"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Courses
              </Button>
              
              <h1 className="text-4xl lg:text-5xl font-bold mb-4">{course.title}</h1>
              <p className="text-xl text-blue-100 mb-6">{course.description}</p>
              
              <div className="flex items-center space-x-6 mb-6">
                <div className="flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  <span>{course.studentCount || 1250} students</span>
                </div>
                <div className="flex items-center">
                  <Star className="w-5 h-5 mr-2 fill-yellow-400" />
                  <span>{course.rating || '4.8'}</span>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span className="text-3xl font-bold">${course.price}</span>
                {isEnrolled ? (
                  <Badge className="bg-green-500 text-white px-4 py-2">
                    Enrolled
                  </Badge>
                ) : (
                  <Button 
                    onClick={handlePurchase}
                    size="lg"
                    className="bg-yellow-400 text-black hover:bg-yellow-500 px-8"
                  >
                    Purchase Course
                  </Button>
                )}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={course.imageUrl || '/api/placeholder/600/400'} 
                alt={course.title}
                className="w-full rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Course Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-6 h-6 mr-2" />
                    What You'll Learn
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Understanding credit fundamentals and scoring systems</span>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Building credit from scratch or improving existing credit</span>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Strategic credit card management and optimization</span>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Debt management and elimination strategies</span>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Credit monitoring and protection techniques</span>
                    </div>
                    <div className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span>Long-term wealth building through credit leverage</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Course Modules */}
              <Card>
                <CardHeader>
                  <CardTitle>Course Curriculum</CardTitle>
                  <p className="text-gray-600">{modules.length || 8} modules • 24 lessons</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { title: "Credit Fundamentals", lessons: 3 },
                      { title: "Credit Scoring Deep Dive", lessons: 3 },
                      { title: "Building Credit from Zero", lessons: 3 },
                      { title: "Credit Card Strategies", lessons: 3 },
                      { title: "Debt Management Mastery", lessons: 3 },
                      { title: "Credit Monitoring & Protection", lessons: 3 },
                      { title: "Advanced Credit Techniques", lessons: 3 },
                      { title: "Building Wealth with Credit", lessons: 3 }
                    ].map((module, index) => (
                      <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-sm font-medium mr-3">
                              {index + 1}
                            </div>
                            <div>
                              <h3 className="font-medium">{module.title}</h3>
                              <p className="text-sm text-gray-600">{module.lessons} lessons</p>
                            </div>
                          </div>
                          <PlayCircle className="w-5 h-5 text-gray-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div>
              <Card className="sticky top-8">
                <CardContent className="p-6">
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-gray-900 mb-2">${course.price}</div>
                    <div className="text-sm text-gray-600">One-time payment • Lifetime access</div>
                  </div>

                  {isEnrolled ? (
                    <div className="space-y-4">
                      <Badge className="w-full justify-center bg-green-500 text-white py-2">
                        ✓ Enrolled
                      </Badge>
                      <Button className="w-full" size="lg">
                        Continue Learning
                      </Button>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Progress</span>
                          <span>25%</span>
                        </div>
                        <Progress value={25} className="h-2" />
                      </div>
                    </div>
                  ) : (
                    <Button 
                      onClick={handlePurchase}
                      className="w-full bg-blue-600 hover:bg-blue-700" 
                      size="lg"
                    >
                      Purchase Course
                    </Button>
                  )}

                  <div className="mt-6 space-y-3 text-sm">
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Lifetime access</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Mobile & desktop access</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>Certificate of completion</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span>30-day money-back guarantee</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}