import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  sector: string;
}

interface Portfolio {
  symbol: string;
  shares: number;
  buyPrice: number;
}

const initialStocks: Stock[] = [
  { symbol: "AAPL", name: "Apple Inc.", price: 150.25, change: 2.15, changePercent: 1.45, sector: "Technology" },
  { symbol: "MSFT", name: "Microsoft Corp.", price: 420.80, change: -5.20, changePercent: -1.22, sector: "Technology" },
  { symbol: "GOOGL", name: "Alphabet Inc.", price: 2750.00, change: 15.30, changePercent: 0.56, sector: "Technology" },
  { symbol: "TSLA", name: "Tesla Inc.", price: 245.67, change: -12.33, changePercent: -4.78, sector: "Automotive" },
  { symbol: "AMZN", name: "Amazon.com Inc.", price: 3380.50, change: 8.75, changePercent: 0.26, sector: "E-commerce" },
  { symbol: "NVDA", name: "NVIDIA Corp.", price: 875.12, change: 25.60, changePercent: 3.01, sector: "Technology" },
  { symbol: "SPY", name: "S&P 500 ETF", price: 455.20, change: 1.80, changePercent: 0.40, sector: "Index Fund" },
  { symbol: "VOO", name: "Vanguard S&P 500", price: 410.35, change: 1.25, changePercent: 0.31, sector: "Index Fund" }
];

export default function StockSimulator() {
  const [cash, setCash] = useState(10000);
  const [portfolio, setPortfolio] = useState<Portfolio[]>([]);
  const [stocks, setStocks] = useState<Stock[]>(initialStocks);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [tradeAmount, setTradeAmount] = useState("");
  const [gameDay, setGameDay] = useState(1);

  const simulateMarketMovement = () => {
    setStocks(prevStocks => 
      prevStocks.map(stock => {
        // Random market movement between -5% and +5%
        const randomChange = (Math.random() - 0.5) * 0.1;
        const newPrice = Math.max(stock.price * (1 + randomChange), 1);
        const change = newPrice - stock.price;
        const changePercent = (change / stock.price) * 100;
        
        return {
          ...stock,
          price: Number(newPrice.toFixed(2)),
          change: Number(change.toFixed(2)),
          changePercent: Number(changePercent.toFixed(2))
        };
      })
    );
    setGameDay(gameDay + 1);
  };

  const buyStock = (stock: Stock, shares: number) => {
    const totalCost = stock.price * shares;
    if (totalCost <= cash) {
      setCash(cash - totalCost);
      
      const existingHolding = portfolio.find(p => p.symbol === stock.symbol);
      if (existingHolding) {
        // Average the buy prices
        const totalShares = existingHolding.shares + shares;
        const avgPrice = ((existingHolding.buyPrice * existingHolding.shares) + (stock.price * shares)) / totalShares;
        
        setPortfolio(portfolio.map(p => 
          p.symbol === stock.symbol 
            ? { ...p, shares: totalShares, buyPrice: avgPrice }
            : p
        ));
      } else {
        setPortfolio([...portfolio, { 
          symbol: stock.symbol, 
          shares, 
          buyPrice: stock.price 
        }]);
      }
      setSelectedStock(null);
      setTradeAmount("");
    }
  };

  const sellStock = (stock: Stock, shares: number) => {
    const holding = portfolio.find(p => p.symbol === stock.symbol);
    if (holding && holding.shares >= shares) {
      const revenue = stock.price * shares;
      setCash(cash + revenue);
      
      if (holding.shares === shares) {
        // Sell all shares - remove from portfolio
        setPortfolio(portfolio.filter(p => p.symbol !== stock.symbol));
      } else {
        // Sell partial shares
        setPortfolio(portfolio.map(p => 
          p.symbol === stock.symbol 
            ? { ...p, shares: p.shares - shares }
            : p
        ));
      }
      setSelectedStock(null);
      setTradeAmount("");
    }
  };

  const getPortfolioValue = () => {
    return portfolio.reduce((total, holding) => {
      const currentStock = stocks.find(s => s.symbol === holding.symbol);
      return total + (currentStock ? currentStock.price * holding.shares : 0);
    }, 0);
  };

  const getTotalValue = () => {
    return cash + getPortfolioValue();
  };

  const getStockInPortfolio = (symbol: string) => {
    return portfolio.find(p => p.symbol === symbol);
  };

  const getProfitLoss = (holding: Portfolio) => {
    const currentStock = stocks.find(s => s.symbol === holding.symbol);
    if (!currentStock) return 0;
    return (currentStock.price - holding.buyPrice) * holding.shares;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100">
      <div className="bg-white shadow-sm border-b p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link href="/banking-course-fixed">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Return to Games
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">📈 Stock Market Simulator</h1>
          <div className="text-right">
            <div className="text-sm text-gray-600">Day {gameDay}</div>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              <span className="text-lg font-bold text-green-600">
                ${getTotalValue().toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Portfolio Summary */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">💼 Your Portfolio</h3>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Cash:</span>
                <span className="font-bold text-green-600">${cash.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Stocks Value:</span>
                <span className="font-bold">${getPortfolioValue().toLocaleString()}</span>
              </div>
              <div className="border-t pt-2 flex justify-between">
                <span className="font-bold">Total Value:</span>
                <span className="font-bold text-lg text-blue-600">${getTotalValue().toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Gain/Loss:</span>
                <span className={`font-bold ${getTotalValue() >= 10000 ? 'text-green-600' : 'text-red-600'}`}>
                  ${(getTotalValue() - 10000).toLocaleString()}
                </span>
              </div>
            </div>

            {portfolio.length > 0 && (
              <div className="mt-6">
                <h4 className="font-bold text-gray-900 mb-3">Your Holdings:</h4>
                <div className="space-y-2">
                  {portfolio.map((holding) => {
                    const currentStock = stocks.find(s => s.symbol === holding.symbol);
                    const profitLoss = getProfitLoss(holding);
                    return (
                      <div key={holding.symbol} className="bg-gray-50 rounded-lg p-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-semibold">{holding.symbol}</div>
                            <div className="text-sm text-gray-600">{holding.shares} shares</div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">${currentStock?.price || 0}</div>
                            <div className={`text-sm ${profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {profitLoss >= 0 ? '+' : ''}${profitLoss.toFixed(2)}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <Button 
              onClick={simulateMarketMovement}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700"
            >
              📅 Next Trading Day
            </Button>
          </div>

          {/* Stock Market */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">📊 Stock Market</h3>
            <div className="grid gap-4">
              {stocks.map((stock) => {
                const holding = getStockInPortfolio(stock.symbol);
                return (
                  <div 
                    key={stock.symbol}
                    className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                      selectedStock?.symbol === stock.symbol 
                        ? 'border-blue-400 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedStock(stock)}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-bold text-lg">{stock.symbol}</div>
                        <div className="text-sm text-gray-600">{stock.name}</div>
                        <div className="text-xs text-gray-500">{stock.sector}</div>
                        {holding && (
                          <div className="text-xs text-blue-600 mt-1">
                            You own {holding.shares} shares
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold">${stock.price}</div>
                        <div className={`flex items-center gap-1 ${
                          stock.change >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {stock.change >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                          <span className="text-sm">
                            {stock.change >= 0 ? '+' : ''}{stock.change} ({stock.changePercent}%)
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Trading Panel */}
        {selectedStock && (
          <div className="mt-6 bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Trade {selectedStock.symbol} - ${selectedStock.price}
            </h3>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Number of Shares
                </label>
                <input
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter shares to trade"
                  min="1"
                />
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600">Total Cost/Revenue</div>
                <div className="text-lg font-bold">
                  ${tradeAmount ? (selectedStock.price * Number(tradeAmount)).toLocaleString() : '0'}
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => buyStock(selectedStock, Number(tradeAmount))}
                  disabled={!tradeAmount || selectedStock.price * Number(tradeAmount) > cash}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-300"
                >
                  Buy
                </Button>
                <Button
                  onClick={() => sellStock(selectedStock, Number(tradeAmount))}
                  disabled={!tradeAmount || !getStockInPortfolio(selectedStock.symbol) || 
                    (getStockInPortfolio(selectedStock.symbol)?.shares || 0) < Number(tradeAmount)}
                  className="bg-red-600 hover:bg-red-700 disabled:bg-gray-300"
                >
                  Sell
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Educational Tips */}
        <div className="mt-6 bg-gradient-to-r from-purple-100 to-pink-100 rounded-xl p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">💡 Trading Tips for Beginners</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="font-semibold text-purple-700">🎯 Diversification:</div>
              <div className="text-gray-700">Don't put all your money in one stock. Spread risk across different companies and sectors.</div>
            </div>
            <div>
              <div className="font-semibold text-purple-700">📊 Index Funds (ETFs):</div>
              <div className="text-gray-700">SPY and VOO are safer options that track the entire market instead of individual companies.</div>
            </div>
            <div>
              <div className="font-semibold text-purple-700">⏰ Long-term Thinking:</div>
              <div className="text-gray-700">Real investing is about holding stocks for years, not trying to get rich quick.</div>
            </div>
            <div>
              <div className="font-semibold text-purple-700">🔍 Research:</div>
              <div className="text-gray-700">In real life, study companies before investing. Look at their business model and growth potential.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}