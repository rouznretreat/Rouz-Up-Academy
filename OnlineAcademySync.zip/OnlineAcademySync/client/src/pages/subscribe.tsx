import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Check, Crown, Star } from "lucide-react";
import MembershipTiers from "@/components/MembershipTiers";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = ({ selectedTier }: { selectedTier: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/dashboard`,
      },
    });

    setIsProcessing(false);

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Subscription Successful",
        description: `Welcome to ${selectedTier.name} membership!`,
      });
      
      setLocation('/dashboard');
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-6">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/')}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Subscription</h1>
        <p className="text-gray-600">Join thousands of learners building wealth</p>
      </div>

      {/* Subscription Summary */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Subscription Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              {selectedTier.name === 'Premium' && <Star className="w-6 h-6 text-blue-600" />}
              {selectedTier.name === 'VIP' && <Crown className="w-6 h-6 text-yellow-500" />}
              <div>
                <h3 className="font-semibold text-lg">{selectedTier.name} Membership</h3>
                <p className="text-gray-600 text-sm">{selectedTier.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">
                ${selectedTier.price}<span className="text-sm text-gray-600">/month</span>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="space-y-2 mb-4">
            {selectedTier.features.map((feature, index) => (
              <div key={index} className="flex items-center text-sm">
                <Check className="w-4 h-4 text-green-500 mr-2" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
          
          <div className="border-t pt-4">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Monthly Total</span>
              <span className="text-xl font-bold">${selectedTier.price}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Cancel anytime. No long-term commitments.</p>
          </div>
        </CardContent>
      </Card>

      {/* Payment Form */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Information</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <PaymentElement />
            
            <Button 
              type="submit" 
              disabled={!stripe || isProcessing}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg font-semibold"
            >
              {isProcessing ? 'Processing...' : `Subscribe for $${selectedTier.price}/month`}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <div className="mt-6 text-center text-sm text-gray-500">
        <p>🔒 Your payment information is secure and encrypted</p>
        <p>You can cancel your subscription at any time from your dashboard</p>
      </div>
    </div>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [selectedTier, setSelectedTier] = useState(null);
  const [, setLocation] = useLocation();

  // Membership tiers configuration
  const membershipTiers = [
    {
      name: 'Premium',
      price: 29,
      priceId: 'price_premium', // This would be the actual Stripe price ID
      description: 'Perfect for serious learners',
      features: [
        'Access to all courses',
        'Advanced progress tracking',
        'Live Q&A sessions',
        'Certificate of completion',
        'Priority support'
      ]
    },
    {
      name: 'VIP',
      price: 99,
      priceId: 'price_vip', // This would be the actual Stripe price ID
      description: 'Complete mastery package',
      features: [
        'Everything in Premium',
        '1-on-1 mentoring sessions',
        'Exclusive masterclasses',
        'Personal action plans',
        'Direct instructor access'
      ]
    }
  ];

  useEffect(() => {
    // Get selected tier from URL params
    const urlParams = new URLSearchParams(window.location.search);
    const tierName = urlParams.get('tier');
    
    if (!tierName) {
      // Show tier selection if no tier specified
      return;
    }

    const tier = membershipTiers.find(t => t.name.toLowerCase() === tierName.toLowerCase());
    if (!tier) {
      setLocation('/');
      return;
    }

    setSelectedTier(tier);

    // Create subscription
    apiRequest("POST", "/api/create-subscription", {
      priceId: tier.priceId,
      membershipTier: tier.name.toLowerCase()
    }).then((res) => res.json())
    .then((data) => {
      setClientSecret(data.clientSecret);
    }).catch((error) => {
      console.error('Error creating subscription:', error);
      setLocation('/');
    });
  }, []);

  // Show tier selection if no tier is selected
  if (!selectedTier) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Return to Academy
            </Button>
          </div>
          <div className="text-center mb-12">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Choose Your <span className="relative">Membership
                <div className="absolute bottom-0 left-0 w-full h-2 bg-yellow-400 rounded -z-10"></div>
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Unlock unlimited access to our course library and accelerate your financial education
            </p>
          </div>

          <MembershipTiers />
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <Elements stripe={stripePromise} options={{ clientSecret }}>
        <SubscribeForm selectedTier={selectedTier} />
      </Elements>
    </div>
  );
}
