import { useState } from 'react';
import { ArrowLeft, BookOpen, Calculator, Brain, Trophy, DollarSign, Shield, TrendingUp, Users, ChevronRight, ChevronLeft, Check, X, Clock, Award, Star } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";

export default function InsuranceForStarters() {
  const [currentModule, setCurrentModule] = useState('home');
  const [currentLesson, setCurrentLesson] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [userProgress, setUserProgress] = useState({
    modulesCompleted: [] as string[],
    totalScore: 0,
    badges: [] as string[]
  });

  const modules = [
    {
      id: 'basics',
      title: '🛡️ Insurance Basics',
      icon: Shield,
      color: 'from-blue-500 to-blue-600',
      description: 'Understanding the fundamentals of life insurance',
      duration: '25 min',
      lessons: [
        {
          title: 'What is Life Insurance?',
          content: `Life insurance is a contract between you and an insurance company. You pay premiums, and in return, the company provides a death benefit to your beneficiaries when you pass away.

Think of it like a financial safety net for your family. Just like you wear a seatbelt to protect yourself in a car, life insurance protects your family financially.

**Key Terms:**
• **Premium**: The amount you pay (monthly or yearly)
• **Death Benefit**: The money your family receives
• **Beneficiary**: The person who gets the money
• **Policy**: The insurance contract`,
          scenario: {
            title: 'Real-Life Example',
            text: 'Sarah, 25, pays $30/month for a $250,000 life insurance policy. If something happens to her, her family receives $250,000 to help with expenses, mortgage, and her children\'s education.'
          }
        },
        {
          title: 'Types of Life Insurance',
          content: `There are two main types of life insurance:

**Term Life Insurance:**
• Temporary coverage (10, 20, or 30 years)
• Lower cost when young
• No cash value
• Like renting an apartment

**Permanent Life Insurance:**
• Lifetime coverage
• Higher cost but builds cash value
• Can borrow against it
• Like owning a home

**Which is better?** It depends on your goals. Term is great for temporary needs (like protecting your mortgage). Permanent is better for long-term wealth building.`,
          scenario: {
            title: 'The Johnson Family Decision',
            text: 'The Johnsons have young kids and a mortgage. They choose term life insurance because it\'s affordable and covers their biggest risk period. Later, they plan to add permanent insurance for wealth building.'
          }
        }
      ]
    },
    {
      id: 'living-benefits',
      title: '📈 Living Benefits',
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      description: 'How to benefit from insurance while you\'re alive',
      duration: '30 min',
      lessons: [
        {
          title: 'Cash Value Growth',
          content: `Permanent life insurance isn't just about death benefits. It builds cash value you can use while alive!

**How Cash Value Works:**
• Part of your premium goes to insurance cost
• Part goes into a savings/investment account
• This cash value grows over time
• You can access it through loans or withdrawals

**Real Benefits:**
• Emergency fund that grows tax-free
• Retirement supplement
• College funding for kids
• Business opportunities`,
          scenario: {
            title: 'Marcus\'s Success Story',
            text: 'Marcus started a $500/month whole life policy at 25. By 40, he had $180,000 in cash value. He borrowed $50,000 to start his business and still kept his death benefit!'
          }
        },
        {
          title: 'Policy Loans & Withdrawals',
          content: `Your cash value is YOUR money. Here's how to access it:

**Policy Loans:**
• Borrow against your cash value
• No credit check needed
• Low interest rates
• Death benefit reduced by loan amount

**Withdrawals:**
• Take money directly from cash value
• May reduce death benefit
• Usually tax-free up to premiums paid

**Smart Strategies:**
• Use for emergencies instead of credit cards
• Fund education expenses
• Supplement retirement income
• Take advantage of market opportunities`,
          scenario: {
            title: 'The Emergency Fund Alternative',
            text: 'Instead of keeping $20,000 in a low-interest savings account, the Williams family uses their life insurance cash value as their emergency fund. It earns better returns and provides life insurance protection!'
          }
        }
      ]
    },
    {
      id: 'wealth-building',
      title: '👨‍👩‍👧‍👦 Generational Wealth',
      icon: Users,
      color: 'from-purple-500 to-purple-600',
      description: 'Building wealth that lasts for generations',
      duration: '35 min',
      lessons: [
        {
          title: 'The Wealth Transfer Strategy',
          content: `Life insurance is one of the most powerful wealth transfer tools available:

**Why It's So Powerful:**
• Death benefits are typically tax-free
• Can multiply your investment many times over
• Protects wealth from taxes and creditors
• Provides liquidity when needed

**The Multiplication Effect:**
A $500/month premium might provide a $1,000,000+ death benefit. That's creating wealth that didn't exist before!

**Generational Impact:**
• Your children receive substantial inheritance
• They can use it to buy their own policies
• Creates a family banking system
• Builds financial security for generations`,
          scenario: {
            title: 'The Martinez Family Legacy',
            text: 'Carlos pays $400/month for life insurance. When he passes, his three children each receive $300,000. They use this to pay off homes, start businesses, and buy their own policies, continuing the wealth-building cycle.'
          }
        },
        {
          title: 'Tax Advantages',
          content: `Life insurance offers incredible tax benefits:

**Tax-Free Growth:**
• Cash value grows without yearly taxes
• Like a Roth IRA but better

**Tax-Free Access:**
• Loans and withdrawals often tax-free
• No penalties like retirement accounts

**Tax-Free Death Benefit:**
• Beneficiaries receive money tax-free
• Avoid estate taxes with proper planning

**Estate Planning Power:**
• Can pay estate taxes for heirs
• Protects other assets from being sold
• Provides immediate liquidity`,
          scenario: {
            title: 'Avoiding the Tax Trap',
            text: 'The Chen family owns a $2 million business. Without life insurance, their children might have to sell the business to pay estate taxes. With a $1 million policy, the taxes are covered and the business stays in the family.'
          }
        }
      ]
    },
    {
      id: 'banking',
      title: '🏦 Be Your Own Bank',
      icon: DollarSign,
      color: 'from-orange-500 to-orange-600',
      description: 'Using insurance as your personal banking system',
      duration: '40 min',
      lessons: [
        {
          title: 'The Infinite Banking Concept',
          content: `Imagine having your own bank where YOU are the customer and the owner:

**How It Works:**
1. Build cash value in a whole life policy
2. Borrow against your cash value for purchases
3. Pay yourself back with interest
4. Your money continues to grow

**Why It's Powerful:**
• You pay interest to yourself, not a bank
• Your cash value keeps earning dividends
• No credit applications or approvals
• You control the repayment terms

**What You Can Finance:**
• Cars and major purchases
• Real estate investments
• Business opportunities
• Education expenses
• Vacations and lifestyle purchases`,
          scenario: {
            title: 'The Car Purchase Revolution',
            text: 'Instead of financing a $30,000 car at 8% interest, Maria borrows from her life insurance at 5%. She pays herself back over 5 years, keeping the interest in her policy instead of giving it to a bank!'
          }
        },
        {
          title: 'Building Your Banking System',
          content: `Creating your personal bank takes time and strategy:

**Phase 1: Foundation (Years 1-5)**
• Start with affordable premium
• Focus on building cash value
• Learn the system

**Phase 2: Growth (Years 6-15)**
• Increase premium when possible
• Start making policy loans
• Reinvest returns back into system

**Phase 3: Mastery (Years 15+)**
• Full banking replacement
• Multiple policies for family members
• Sophisticated wealth strategies

**Keys to Success:**
• Start early (time is your friend)
• Be consistent with premiums
• Reinvest policy loans back to yourself
• Work with knowledgeable agents`,
          scenario: {
            title: 'The Thompson Family Bank',
            text: 'Over 20 years, the Thompsons built $500,000 in combined cash value across family policies. They\'ve financed cars, funded college, and started a business - all while keeping their money in the family instead of giving it to banks!'
          }
        }
      ]
    }
  ];

  const quizQuestions = [
    {
      question: "What is the main purpose of life insurance?",
      options: [
        "To make you rich quickly",
        "To provide financial protection for your family",
        "To replace your job income",
        "To avoid paying taxes"
      ],
      correct: 1,
      explanation: "Life insurance primarily provides financial protection for your beneficiaries when you pass away."
    },
    {
      question: "Which type of insurance builds cash value?",
      options: [
        "Term life insurance",
        "Permanent life insurance",
        "Both types",
        "Neither type"
      ],
      correct: 1,
      explanation: "Only permanent life insurance builds cash value that you can access while alive."
    },
    {
      question: "What is a policy loan?",
      options: [
        "A loan from the bank using your policy as collateral",
        "Borrowing money against your cash value",
        "A loan to pay your premiums",
        "Money the insurance company owes you"
      ],
      correct: 1,
      explanation: "A policy loan lets you borrow against your own cash value, using your policy as collateral."
    },
    {
      question: "Death benefits are typically:",
      options: [
        "Fully taxable to beneficiaries",
        "Partially taxable",
        "Tax-free to beneficiaries",
        "Subject to capital gains tax"
      ],
      correct: 2,
      explanation: "Life insurance death benefits are generally received tax-free by beneficiaries."
    },
    {
      question: "The 'Infinite Banking Concept' involves:",
      options: [
        "Opening multiple bank accounts",
        "Using life insurance cash value as your personal bank",
        "Getting unlimited credit from banks",
        "Avoiding all banks completely"
      ],
      correct: 1,
      explanation: "Infinite Banking uses whole life insurance cash value to create your own banking system."
    }
  ];

  const handleQuizAnswer = (questionIndex: number, answerIndex: number) => {
    setQuizAnswers({...quizAnswers, [questionIndex]: answerIndex});
  };

  const calculateQuizScore = () => {
    let correct = 0;
    quizQuestions.forEach((q, index) => {
      if (quizAnswers[index] === q.correct) correct++;
    });
    return Math.round((correct / quizQuestions.length) * 100);
  };

  const submitQuiz = () => {
    const score = calculateQuizScore();
    setShowResults(true);
    setUserProgress(prev => ({
      ...prev,
      totalScore: Math.max(prev.totalScore, score),
      badges: score >= 80 ? [...prev.badges.filter(b => b !== 'Quiz Master'), 'Quiz Master'] : prev.badges
    }));
  };

  const resetQuiz = () => {
    setQuizAnswers({});
    setShowResults(false);
  };

  const getCurrentModule = () => modules.find(m => m.id === currentModule);
  const currentModuleData = getCurrentModule();

  // Home view
  if (currentModule === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Header */}
        <div className="bg-white shadow-sm border-b sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Link href="/">
                <Button variant="ghost" className="flex items-center">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-gray-900">🛡️ Insurance for Starters</h1>
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span className="font-semibold">{userProgress.totalScore}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-6">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-gray-800 mb-4">🛡️ Insurance for Starters</h1>
            <p className="text-xl text-gray-600 mb-8">Master life insurance to protect your family and build generational wealth</p>
            
            <div className="flex justify-center space-x-8 mb-8">
              <div className="text-center">
                <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Interactive Learning</div>
              </div>
              <div className="text-center">
                <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Family Protection</div>
              </div>
              <div className="text-center">
                <DollarSign className="w-8 h-8 text-green-500 mx-auto mb-2" />
                <div className="text-sm text-gray-600">Wealth Building</div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge className="bg-blue-100 text-blue-800 px-4 py-2">Ages 18+ • Adult Learning</Badge>
              <Badge className="bg-green-100 text-green-800 px-4 py-2">💰 Real-World Application</Badge>
              <Badge className="bg-purple-100 text-purple-800 px-4 py-2">🎯 Financial Security</Badge>
            </div>
          </div>

          {/* Progress Overview */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card>
              <CardContent className="pt-6 text-center">
                <Shield className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">4</div>
                <div className="text-sm text-gray-600">Learning Modules</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <Brain className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">{userProgress.totalScore}%</div>
                <div className="text-sm text-gray-600">Quiz Score</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 text-center">
                <Award className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                <div className="text-2xl font-bold text-gray-900">{userProgress.badges.length}</div>
                <div className="text-sm text-gray-600">Badges Earned</div>
              </CardContent>
            </Card>
          </div>

          {/* Course Modules */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {modules.map((module, index) => {
              const Icon = module.icon;
              return (
                <Card 
                  key={module.id}
                  className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
                  onClick={() => setCurrentModule(module.id)}
                >
                  <div className={`h-2 bg-gradient-to-r ${module.color} rounded-t-lg`}></div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Icon className="w-8 h-8 text-gray-700" />
                      <Badge variant="outline">Module {index + 1}</Badge>
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900">
                      {module.title}
                    </CardTitle>
                    <p className="text-gray-600 text-sm">{module.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <Clock className="w-4 h-4 mr-2" />
                      {module.duration}
                      <span className="mx-2">•</span>
                      <BookOpen className="w-4 h-4 mr-2" />
                      {module.lessons.length} lessons
                    </div>
                    <Button className="w-full">
                      Start Module
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Quick Actions */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-500" />
                  📝 Test Your Knowledge
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Take our comprehensive quiz to test your insurance knowledge and earn badges!</p>
                <Button onClick={() => setCurrentModule('quiz')} className="w-full">
                  Take Quiz
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="w-5 h-5 mr-2 text-green-500" />
                  💰 Premium Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">Calculate potential premiums and see how life insurance can fit your budget.</p>
                <Button variant="outline" className="w-full">
                  Coming Soon
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Quiz view
  if (currentModule === 'quiz') {
    if (showResults) {
      const score = calculateQuizScore();
      return (
        <div className="min-h-screen bg-gray-50 p-6">
          <div className="max-w-2xl mx-auto">
            <Card className="text-center">
              <CardContent className="pt-8">
                <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-3xl font-bold mb-4">Quiz Complete! 🎉</h2>
                <div className="text-6xl font-bold text-blue-600 mb-4">{score}%</div>
                <p className="text-lg text-gray-600 mb-6">
                  You scored {Object.values(quizAnswers).filter((answer, index) => answer === quizQuestions[index].correct).length} out of {quizQuestions.length} questions correctly!
                </p>
                
                {score >= 80 && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-center text-yellow-800">
                      <Star className="w-5 h-5 mr-2" />
                      <span className="font-semibold">Congratulations! You earned the "Quiz Master" badge!</span>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <Button onClick={resetQuiz} className="w-full">
                    Retake Quiz
                  </Button>
                  <Button onClick={() => setCurrentModule('home')} variant="outline" className="w-full">
                    Back to Home
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-6">
            <Button onClick={() => setCurrentModule('home')} variant="ghost">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>📝 Insurance Knowledge Quiz</CardTitle>
              <Progress value={(Object.keys(quizAnswers).length / quizQuestions.length) * 100} />
              <p className="text-sm text-gray-600">
                {Object.keys(quizAnswers).length} of {quizQuestions.length} questions answered
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              {quizQuestions.map((question, questionIndex) => (
                <div key={questionIndex} className="border-b pb-6 last:border-b-0">
                  <h3 className="font-semibold mb-4 text-lg">
                    {questionIndex + 1}. {question.question}
                  </h3>
                  <div className="space-y-2">
                    {question.options.map((option, optionIndex) => (
                      <button
                        key={optionIndex}
                        onClick={() => handleQuizAnswer(questionIndex, optionIndex)}
                        className={`w-full text-left p-3 rounded border transition-colors ${
                          quizAnswers[questionIndex] === optionIndex
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:bg-gray-50'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              
              {Object.keys(quizAnswers).length === quizQuestions.length && (
                <Button onClick={submitQuiz} className="w-full">
                  Submit Quiz
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Module lesson view
  if (currentModuleData) {
    const currentLessonData = currentModuleData.lessons[currentLesson];
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <Button onClick={() => setCurrentModule('home')} variant="ghost">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Modules
              </Button>
              <h1 className="text-lg font-semibold">{currentModuleData.title}</h1>
              <div className="text-sm text-gray-600">
                {currentLesson + 1} of {currentModuleData.lessons.length}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto p-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">{currentLessonData.title}</CardTitle>
                <Badge className={`bg-gradient-to-r ${currentModuleData.color} text-white`}>
                  Lesson {currentLesson + 1}
                </Badge>
              </div>
              <Progress value={((currentLesson + 1) / currentModuleData.lessons.length) * 100} />
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Main Content */}
              <div className="prose max-w-none">
                {currentLessonData.content.split('\n').map((paragraph, index) => {
                  if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                    return <h4 key={index} className="font-bold text-lg mt-4 mb-2">{paragraph.slice(2, -2)}</h4>;
                  }
                  if (paragraph.startsWith('• ')) {
                    return <li key={index} className="ml-4">{paragraph.slice(2)}</li>;
                  }
                  if (paragraph.trim()) {
                    return <p key={index} className="mb-4">{paragraph}</p>;
                  }
                  return null;
                })}
              </div>

              {/* Scenario Box */}
              {currentLessonData.scenario && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h4 className="font-bold text-blue-900 mb-3 flex items-center">
                    <Star className="w-5 h-5 mr-2" />
                    {currentLessonData.scenario.title}
                  </h4>
                  <p className="text-blue-800">{currentLessonData.scenario.text}</p>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between pt-6">
                <Button
                  onClick={() => setCurrentLesson(Math.max(0, currentLesson - 1))}
                  disabled={currentLesson === 0}
                  variant="outline"
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                
                {currentLesson < currentModuleData.lessons.length - 1 ? (
                  <Button
                    onClick={() => setCurrentLesson(currentLesson + 1)}
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={() => {
                      setCurrentModule('home');
                      setCurrentLesson(0);
                    }}
                  >
                    Complete Module
                    <Check className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return null;
}