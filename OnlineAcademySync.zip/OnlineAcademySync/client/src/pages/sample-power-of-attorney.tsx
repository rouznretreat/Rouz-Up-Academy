import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";

export default function SamplePowerOfAttorney() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-violet-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <Button 
          variant="outline" 
          onClick={() => setLocation("/estate-planning-course")}
          className="mb-4"
        >
          ← Back to Documents
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-purple-700">Sample Durable Power of Attorney</CardTitle>
            <p className="text-gray-600">Educational example of financial power of attorney</p>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-6 rounded border font-mono text-sm space-y-4">
              <div className="text-center font-bold text-lg mb-6">
                DURABLE POWER OF ATTORNEY<br/>
                FOR FINANCIAL AFFAIRS
              </div>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold mb-2">DESIGNATION OF AGENT</h4>
                  <p>I, ROBERT JAMES ANDERSON, of Dallas County, Texas, hereby designate and appoint STEPHANIE LYNN ANDERSON, my wife, as my attorney-in-fact (agent) to act for me and in my name in any way which I myself could act with respect to financial and property matters.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">SUCCESSOR AGENT</h4>
                  <p>If STEPHANIE LYNN ANDERSON is unable or unwilling to serve as my agent, I hereby designate JONATHAN PAUL ANDERSON, my son, as my successor agent.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">EFFECTIVENESS</h4>
                  <p>This Power of Attorney shall become effective immediately upon execution and shall remain in effect during any period of incapacity.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">POWERS GRANTED</h4>
                  <p>My agent is hereby authorized to:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>A. Buy, sell, lease, mortgage, or otherwise deal in real estate</li>
                    <li>B. Manage bank accounts, investments, and securities</li>
                    <li>C. File tax returns and handle tax matters</li>
                    <li>D. Manage business interests and employment benefits</li>
                    <li>E. Handle insurance claims and policies</li>
                    <li>F. Make gifts consistent with my gift-giving history</li>
                    <li>G. Hire professional advisors and pay reasonable fees</li>
                    <li>H. Take any action necessary to preserve and protect my assets</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">LIMITATIONS</h4>
                  <p>My agent may NOT:</p>
                  <ul className="ml-4 mt-2 space-y-1">
                    <li>• Make or change my will</li>
                    <li>• Make gifts exceeding $15,000 per recipient per year</li>
                    <li>• Change beneficiaries on my retirement accounts or insurance</li>
                    <li>• Make healthcare decisions (separate document required)</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold mb-2">DURABILITY CLAUSE</h4>
                  <p>This Power of Attorney shall not be affected by my subsequent incapacity or disability, and shall remain in full force and effect unless revoked by me in writing.</p>
                </div>

                <div>
                  <h4 className="font-bold mb-2">THIRD PARTY RELIANCE</h4>
                  <p>Any third party may rely upon this Power of Attorney without inquiry into whether it has been revoked or into the authority of my agent to take the action in question.</p>
                </div>

                <div className="mt-6">
                  <p>IN WITNESS WHEREOF, I have executed this Power of Attorney on __________, 2024.</p>
                  <div className="mt-4">
                    <p>_________________________________</p>
                    <p>ROBERT JAMES ANDERSON, Principal</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold mb-2">NOTARIZATION</h4>
                  <div className="border p-3 bg-white">
                    <p>State of Texas</p>
                    <p>County of Dallas</p>
                    <p className="mt-2">On this _____ day of __________, 2024, before me personally appeared ROBERT JAMES ANDERSON, who proved to me on the basis of satisfactory evidence to be the person whose name is subscribed to the within instrument.</p>
                    <div className="mt-4">
                      <p>_________________________________</p>
                      <p>Notary Public</p>
                      <p>My commission expires: __________</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-purple-50 p-4 rounded border border-purple-300">
              <h4 className="font-bold text-purple-700 mb-2">Power of Attorney Essentials:</h4>
              <ul className="text-sm text-purple-700 space-y-1">
                <li>• <strong>Durable</strong> - Remains effective during incapacity</li>
                <li>• <strong>Comprehensive Powers</strong> - Covers all financial matters</li>
                <li>• <strong>Clear Limitations</strong> - Specifies what agent cannot do</li>
                <li>• <strong>Successor Named</strong> - Backup agent designated</li>
                <li>• <strong>Third Party Protection</strong> - Encourages acceptance by institutions</li>
                <li>• <strong>Proper Execution</strong> - Notarized for legal validity</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}