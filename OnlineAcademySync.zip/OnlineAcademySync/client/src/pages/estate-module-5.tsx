import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Users, CheckCircle, Heart, Clock, FileText, Phone, AlertCircle, Shield } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule5() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-teal-700 flex items-center space-x-3">
              <Users className="w-8 h-8" />
              <span>Module 5: When Someone Dies</span>
            </CardTitle>
            <p className="text-gray-600">Essential guidance for families navigating estate administration with compassion and practical steps</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-teal-50 p-6 rounded border-l-4 border-teal-500">
              <h3 className="text-lg font-bold text-teal-700 mb-4">🎯 Learning Objectives</h3>
              <ul className="space-y-2 text-teal-700">
                <li>• Understand the immediate steps families need to take</li>
                <li>• Learn the estate administration process timeline</li>
                <li>• Discover how good planning makes this easier</li>
                <li>• Know when to seek professional help</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-6 rounded border border-blue-300">
              <h3 className="text-lg font-bold text-blue-700 mb-3 flex items-center space-x-2">
                <Heart className="w-6 h-6" />
                <span>A Message of Compassion</span>
              </h3>
              <p className="text-blue-700 text-sm leading-relaxed">
                Losing someone you love is one of life's most difficult experiences. This module provides practical guidance to help families navigate the necessary steps with less stress and confusion. Remember: you don't have to handle everything at once, and it's okay to ask for help.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">Immediate Steps (First 24-48 Hours)</h3>
              
              <div className="bg-red-50 p-4 rounded border border-red-300">
                <h4 className="font-bold text-red-700 mb-3 flex items-center space-x-2">
                  <AlertCircle className="w-5 h-5" />
                  <span>Time-Sensitive Actions</span>
                </h4>
                <div className="space-y-2 text-sm text-red-700">
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">1.</span>
                    <span><strong>Contact authorities if needed</strong> - If death occurred at home or unexpectedly, call 911 or local authorities</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">2.</span>
                    <span><strong>Notify the funeral home</strong> - They will help with immediate arrangements and obtaining death certificates</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">3.</span>
                    <span><strong>Secure the property</strong> - Make sure homes, vehicles, and valuables are protected</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-bold">4.</span>
                    <span><strong>Locate important documents</strong> - Find will, insurance policies, and contact information</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">First Week Actions</h3>
              
              <div className="grid gap-4">
                <Card className="border-l-4 border-blue-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-blue-100 p-2 rounded">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-blue-700 mb-2">Obtain Death Certificates</h4>
                        <p className="text-gray-700 text-sm mb-2">
                          Get multiple certified copies (usually 10-15). You'll need these for banks, insurance companies, and other institutions.
                        </p>
                        <div className="bg-blue-50 p-2 rounded">
                          <p className="text-xs text-blue-700"><strong>Tip:</strong> Order more than you think you need - getting additional copies later is more difficult.</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-green-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-green-100 p-2 rounded">
                        <Phone className="w-5 h-5 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-green-700 mb-2">Contact Key People</h4>
                        <div className="text-gray-700 text-sm space-y-2">
                          <div>• <strong>Employer:</strong> Notify HR department for final pay and benefits</div>
                          <div>• <strong>Insurance companies:</strong> Life insurance and health insurance providers</div>
                          <div>• <strong>Banks:</strong> Where the person had accounts</div>
                          <div>• <strong>Attorney:</strong> If there was an estate planning lawyer</div>
                          <div>• <strong>Accountant:</strong> For tax and financial matters</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-purple-500">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="bg-purple-100 p-2 rounded">
                        <Shield className="w-5 h-5 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-purple-700 mb-2">Protect Against Fraud</h4>
                        <div className="text-gray-700 text-sm space-y-2">
                          <div>• <strong>Credit monitoring:</strong> Contact credit bureaus to report the death</div>
                          <div>• <strong>Social Security:</strong> Notify Social Security Administration</div>
                          <div>• <strong>Mail forwarding:</strong> Set up with postal service if needed</div>
                          <div>• <strong>Identity protection:</strong> Monitor for fraudulent activity</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">The Estate Administration Process</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">📋 Step-by-Step Timeline</h4>
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded">
                    <h5 className="font-semibold text-yellow-700 mb-2">Month 1-2: Getting Organized</h5>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• File will with probate court (if required)</li>
                      <li>• Apply to be appointed executor/administrator</li>
                      <li>• Open estate bank account</li>
                      <li>• Begin inventory of assets</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-4 rounded">
                    <h5 className="font-semibold text-yellow-700 mb-2">Month 3-6: Administration</h5>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Complete asset inventory and valuations</li>
                      <li>• Pay debts and final expenses</li>
                      <li>• File final tax returns</li>
                      <li>• Manage ongoing assets and income</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-4 rounded">
                    <h5 className="font-semibold text-yellow-700 mb-2">Month 6-12: Distribution</h5>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Obtain court approval for distributions</li>
                      <li>• Distribute assets to beneficiaries</li>
                      <li>• Prepare final accounting</li>
                      <li>• Close estate formally</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">How Good Planning Makes This Easier</h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="border-l-4 border-green-500">
                  <CardContent className="p-4">
                    <h4 className="font-bold text-green-700 mb-2">✅ With Proper Planning</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Clear instructions in will</li>
                      <li>• Assets titled in trust (avoid probate)</li>
                      <li>• Updated beneficiary designations</li>
                      <li>• Life insurance for immediate needs</li>
                      <li>• Powers of attorney were in place</li>
                      <li>• Family knows the plan</li>
                    </ul>
                    <div className="mt-3 bg-green-50 p-2 rounded">
                      <p className="text-xs text-green-700"><strong>Result:</strong> Process takes 3-6 months, lower costs, less family stress</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-l-4 border-red-500">
                  <CardContent className="p-4">
                    <h4 className="font-bold text-red-700 mb-2">❌ Without Planning</h4>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>• No will or outdated documents</li>
                      <li>• Everything goes through probate</li>
                      <li>• Outdated beneficiary forms</li>
                      <li>• No immediate cash available</li>
                      <li>• Family doesn't know wishes</li>
                      <li>• Conflicts over decisions</li>
                    </ul>
                    <div className="mt-3 bg-red-50 p-2 rounded">
                      <p className="text-xs text-red-700"><strong>Result:</strong> Process takes 12-24 months, higher costs, significant family stress</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">When to Seek Professional Help</h3>
              
              <div className="bg-indigo-50 p-6 rounded border border-indigo-300">
                <h4 className="font-bold text-indigo-700 mb-4">🤝 Professional Support Team</h4>
                <div className="space-y-3 text-sm text-indigo-700">
                  <div>
                    <strong>Estate Attorney:</strong> For probate proceedings, complex estates, or family disputes
                  </div>
                  <div>
                    <strong>Accountant:</strong> For tax returns, estate tax issues, and financial record keeping
                  </div>
                  <div>
                    <strong>Financial Advisor:</strong> For managing investments and ongoing financial planning
                  </div>
                  <div>
                    <strong>Real Estate Agent:</strong> If property needs to be sold
                  </div>
                  <div>
                    <strong>Appraiser:</strong> For valuing valuable assets like art, jewelry, or business interests
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">Essential Documents Checklist</h3>
              
              <div className="bg-gray-50 p-6 rounded">
                <h4 className="font-bold text-gray-700 mb-4">📋 What Families Need to Locate</h4>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-700">
                  <div>
                    <h5 className="font-semibold mb-2">Legal Documents:</h5>
                    <ul className="space-y-1">
                      <li>□ Original will and any codicils</li>
                      <li>□ Trust documents</li>
                      <li>□ Powers of attorney</li>
                      <li>□ Healthcare directives</li>
                      <li>□ Marriage/divorce certificates</li>
                      <li>□ Birth certificate</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Financial Documents:</h5>
                    <ul className="space-y-1">
                      <li>□ Bank account statements</li>
                      <li>□ Investment account records</li>
                      <li>□ Insurance policies</li>
                      <li>□ Property deeds</li>
                      <li>□ Vehicle titles</li>
                      <li>□ Tax returns (last 3 years)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">Supporting Your Family</h3>
              
              <div className="bg-pink-50 p-6 rounded border border-pink-300">
                <h4 className="font-bold text-pink-700 mb-4">💝 Remember What Matters Most</h4>
                <div className="space-y-3 text-pink-700">
                  <div>
                    <strong>Take care of yourself:</strong> Grief is exhausting. Rest, eat well, and ask for help when you need it.
                  </div>
                  <div>
                    <strong>Communicate with family:</strong> Keep everyone informed about the process and decisions being made.
                  </div>
                  <div>
                    <strong>Honor their memory:</strong> The administrative tasks are important, but don't forget to grieve and celebrate the person's life.
                  </div>
                  <div>
                    <strong>Be patient:</strong> Estate administration takes time. Don't rush important decisions.
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-teal-600">Test Your Understanding</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">1. What should families do in the first 24-48 hours?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Contact authorities if needed, notify funeral home, secure property, and locate important documents.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">2. How does good estate planning make administration easier?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> It provides clear instructions, may avoid probate through trusts, ensures current beneficiary designations, and reduces family stress and costs.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">3. When should families seek professional help?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> For probate proceedings, complex estates, family disputes, tax issues, and when they feel overwhelmed by the process.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Module 5 Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                You now understand the estate administration process and how to support families during difficult times. You've learned the immediate steps, timeline, and how proper planning makes everything easier for loved ones.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-planning-course">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Back to Course Overview
                  </Button>
                </Link>
                <Button 
                  variant="outline"
                  className="border-teal-500 text-teal-600"
                  onClick={() => window.location.href = "/estate-planning-course#quiz"}
                >
                  Take Full Course Quiz
                </Button>
              </div>
            </div>

            {/* Quiz Section */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Test Your Knowledge!</h3>
                  <p className="mb-4">Ready to test your understanding of what happens when someone dies?</p>
                  <Link href="/estate-quiz-5">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 5 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-module-4">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Previous: Understanding Wills
                  </Button>
                </Link>
                <Link href="/estate-module-6">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Next Module: Getting Started →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}