import { Link } from "wouter";
import { ArrowLeft, TrendingUp, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function SavingsGrowthCalculator() {
  const [principal, setPrincipal] = useState(1000);
  const [monthlyDeposit, setMonthlyDeposit] = useState(100);
  const [interestRate, setInterestRate] = useState(5);
  const [years, setYears] = useState(10);

  const calculateGrowth = () => {
    const monthlyRate = interestRate / 100 / 12;
    const months = years * 12;
    
    // Future value of initial principal
    const futureValuePrincipal = principal * Math.pow(1 + monthlyRate, months);
    
    // Future value of monthly deposits (annuity)
    const futureValueDeposits = monthlyDeposit * 
      ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate);
    
    const totalFutureValue = futureValuePrincipal + futureValueDeposits;
    const totalDeposits = principal + (monthlyDeposit * months);
    const totalInterest = totalFutureValue - totalDeposits;
    
    return {
      futureValue: totalFutureValue,
      totalDeposits,
      totalInterest
    };
  };

  const results = calculateGrowth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Link href="/tools">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2 text-white border-white/30 hover:bg-white/10 mr-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Return to Calculators
                </Button>
              </Link>
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 mr-3" />
                <div>
                  <h1 className="text-2xl font-bold">Savings Growth Calculator</h1>
                  <p className="text-green-100">See how your money grows over time</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Calculator Card */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center mb-6">
              <Calculator className="w-6 h-6 mr-3 text-green-600" />
              <h2 className="text-2xl font-bold text-gray-900">Growth Calculator</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Input Section */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Starting Amount ($)
                  </label>
                  <input
                    type="number"
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Monthly Deposit ($)
                  </label>
                  <input
                    type="number"
                    value={monthlyDeposit}
                    onChange={(e) => setMonthlyDeposit(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Annual Interest Rate (%)
                  </label>
                  <input
                    type="number"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="0"
                    step="0.1"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Time Period (Years)
                  </label>
                  <input
                    type="number"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    min="1"
                  />
                </div>
              </div>
              
              {/* Results Section */}
              <div className="space-y-4">
                <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                  <h3 className="font-bold text-green-700 mb-2">Final Amount</h3>
                  <p className="text-2xl font-bold text-green-600">
                    ${results.futureValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                  <h3 className="font-bold text-blue-700 mb-2">Total Deposits</h3>
                  <p className="text-xl font-bold text-blue-600">
                    ${results.totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-400">
                  <h3 className="font-bold text-purple-700 mb-2">Interest Earned</h3>
                  <p className="text-xl font-bold text-purple-600">
                    ${results.totalInterest.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h3 className="font-bold text-yellow-700 mb-2">Growth Percentage</h3>
                  <p className="text-lg font-bold text-yellow-600">
                    {((results.totalInterest / results.totalDeposits) * 100).toFixed(1)}% growth
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Understanding Compound Growth</h2>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl mb-2">🌱</div>
                <h3 className="font-bold text-green-700 mb-2">Start Early</h3>
                <p className="text-gray-700 text-sm">Time is your biggest advantage when growing money</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl mb-2">💰</div>
                <h3 className="font-bold text-blue-700 mb-2">Regular Deposits</h3>
                <p className="text-gray-700 text-sm">Consistent monthly savings build wealth steadily</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl mb-2">📈</div>
                <h3 className="font-bold text-purple-700 mb-2">Compound Interest</h3>
                <p className="text-gray-700 text-sm">Your money earns money, which then earns more money</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}