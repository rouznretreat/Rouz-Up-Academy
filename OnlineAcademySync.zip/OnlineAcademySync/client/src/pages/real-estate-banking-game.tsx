import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import RealEstateBankingGame from "@/components/RealEstateBankingGame";

export default function RealEstateBankingGamePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/">
              <Button variant="ghost" className="flex items-center">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Real Estate Banking Game</h1>
            <div></div>
          </div>
        </div>
      </div>

      {/* Game Content */}
      <div className="py-8">
        <RealEstateBankingGame />
      </div>

      {/* Educational Info */}
      <div className="max-w-4xl mx-auto px-6 pb-8">
        <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
          <h3 className="text-lg font-bold text-blue-900 mb-2">What You'll Learn</h3>
          <ul className="text-blue-800 space-y-1">
            <li>• How real estate investing works</li>
            <li>• Different types of financing options</li>
            <li>• Understanding cash flow and ROI</li>
            <li>• Making smart investment decisions</li>
            <li>• Building wealth through real estate</li>
          </ul>
        </div>
      </div>
    </div>
  );
}