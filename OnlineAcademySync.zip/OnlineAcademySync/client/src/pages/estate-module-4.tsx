import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Scroll, CheckCircle, Shield, Users, FileText, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule4() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-orange-700 flex items-center space-x-3">
              <Scroll className="w-8 h-8" />
              <span>Module 4: Understanding Wills</span>
            </CardTitle>
            <p className="text-gray-600">Learn why wills are the most formal legal documents and their essential requirements</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-orange-50 p-6 rounded border-l-4 border-orange-500">
              <h3 className="text-lg font-bold text-orange-700 mb-4">🎯 Learning Objectives</h3>
              <ul className="space-y-2 text-orange-700">
                <li>• Understand why wills have extensive formality requirements</li>
                <li>• Learn the essential elements that make a will legally valid</li>
                <li>• Discover how these requirements protect everyone involved</li>
                <li>• See real examples of what happens when requirements aren't met</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-orange-600">Why Wills Are Special Legal Documents</h3>
              
              <p className="text-gray-700 leading-relaxed">
                <strong>A will is one of the most formal legal documents that exists in the modern legal system.</strong> Because the person who created the will (the testator) cannot speak for themselves after death, the law requires extensive formality to ensure the document truly represents their wishes and wasn't the result of fraud, coercion, or mistake.
              </p>

              <div className="bg-blue-50 p-4 rounded border border-blue-300">
                <h4 className="font-bold text-blue-700 mb-2">🛡️ Protection Through Formality</h4>
                <p className="text-blue-700 text-sm">
                  The strict requirements for wills aren't designed to make things difficult - they exist to protect you, your family, and your wishes. These formalities ensure that only legitimate wills are honored and prevent fraud or manipulation.
                </p>
              </div>
            </div>

            <div className="grid gap-6">
              <Card className="border-l-4 border-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-blue-100 p-2 rounded">
                      <span className="text-2xl">📜</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-blue-700 mb-2">1. Last Will and Testament</h4>
                      <p className="text-gray-700 mb-3">
                        The foundation document that specifies how your assets should be distributed, names guardians for minor children, and designates an executor to manage your estate.
                      </p>
                      <div className="bg-blue-50 p-3 rounded">
                        <h5 className="font-semibold text-blue-700 mb-2">Critical Protection:</h5>
                        <p className="text-sm text-blue-700">
                          Without a will, state intestacy laws determine asset distribution - which may not match your wishes at all.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-green-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-green-100 p-2 rounded">
                      <span className="text-2xl">🏛️</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-green-700 mb-2">2. Trust Documents</h4>
                      <p className="text-gray-700 mb-3">
                        Revocable living trusts can help avoid probate, provide privacy, and offer more control over asset distribution. Irrevocable trusts serve specialized purposes like tax reduction or asset protection.
                      </p>
                      <div className="bg-green-50 p-3 rounded">
                        <h5 className="font-semibold text-green-700 mb-2">Key Benefits:</h5>
                        <ul className="text-sm text-green-700 space-y-1">
                          <li>• Avoid probate court processes</li>
                          <li>• Maintain privacy for your family</li>
                          <li>• Provide specialized tax advantages</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-purple-100 p-2 rounded">
                      <span className="text-2xl">💰</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-purple-700 mb-2">3. Financial Power of Attorney</h4>
                      <p className="text-gray-700 mb-3">
                        Allows a trusted person to make financial decisions on your behalf if you become incapacitated. This covers banking, investment, and property management decisions.
                      </p>
                      <div className="bg-purple-50 p-3 rounded">
                        <h5 className="font-semibold text-purple-700 mb-2">Essential Coverage:</h5>
                        <ul className="text-sm text-purple-700 space-y-1">
                          <li>• Banking and investment management</li>
                          <li>• Property and real estate decisions</li>
                          <li>• Business and financial obligations</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-red-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-red-100 p-2 rounded">
                      <span className="text-2xl">🏥</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-red-700 mb-2">4. Healthcare Power of Attorney</h4>
                      <p className="text-gray-700 mb-3">
                        Designates someone to make medical decisions for you when you cannot. This person should understand your values and healthcare preferences.
                      </p>
                      <div className="bg-red-50 p-3 rounded">
                        <h5 className="font-semibold text-red-700 mb-2">Critical Decisions:</h5>
                        <ul className="text-sm text-red-700 space-y-1">
                          <li>• Treatment options and procedures</li>
                          <li>• Hospital and care facility choices</li>
                          <li>• End-of-life medical decisions</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-teal-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-teal-100 p-2 rounded">
                      <span className="text-2xl">📋</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-teal-700 mb-2">5. Advance Healthcare Directive (Living Will)</h4>
                      <p className="text-gray-700 mb-3">
                        Documents your wishes regarding life-sustaining treatment, end-of-life care, and other medical preferences when you cannot communicate them yourself.
                      </p>
                      <div className="bg-teal-50 p-3 rounded">
                        <h5 className="font-semibold text-teal-700 mb-2">Your Voice When You Can't Speak:</h5>
                        <ul className="text-sm text-teal-700 space-y-1">
                          <li>• Life-sustaining treatment preferences</li>
                          <li>• Pain management and comfort care</li>
                          <li>• Organ donation decisions</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-indigo-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-indigo-100 p-2 rounded">
                      <span className="text-2xl">👥</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-indigo-700 mb-2">6. Beneficiary Designations</h4>
                      <p className="text-gray-700 mb-3">
                        These forms for retirement accounts, life insurance policies, and other financial accounts often supersede your will, so keeping them current is crucial.
                      </p>
                      <div className="bg-indigo-50 p-3 rounded">
                        <h5 className="font-semibold text-indigo-700 mb-2">⚠️ Critical Note:</h5>
                        <p className="text-sm text-indigo-700">
                          Beneficiary designations override your will! An outdated beneficiary form can send assets to the wrong person regardless of your will's instructions.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-pink-500">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-pink-100 p-2 rounded">
                      <span className="text-2xl">🔒</span>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-bold text-pink-700 mb-2">7. HIPAA Authorization</h4>
                      <p className="text-gray-700 mb-3">
                        Allows designated individuals to access your medical information, which can be vital for healthcare decision-making.
                      </p>
                      <div className="bg-pink-50 p-3 rounded">
                        <h5 className="font-semibold text-pink-700 mb-2">Essential Access:</h5>
                        <p className="text-sm text-pink-700">
                          Without HIPAA authorization, even your spouse may be denied access to your medical information when making critical healthcare decisions.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-orange-600">How These Tools Work Together</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">🔗 Integrated Protection System:</h4>
                <div className="space-y-3 text-sm text-yellow-700">
                  <div>
                    <strong>During Your Lifetime:</strong> Powers of attorney and HIPAA authorization protect you if you become incapacitated.
                  </div>
                  <div>
                    <strong>Healthcare Crisis:</strong> Healthcare power of attorney and advance directive guide medical decisions while you recover.
                  </div>
                  <div>
                    <strong>After Your Death:</strong> Will, trusts, and beneficiary designations ensure your assets go to the right people quickly and efficiently.
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-orange-600">Test Your Knowledge</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">1. Which document can override your will's instructions?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> Beneficiary designations on retirement accounts and life insurance policies often supersede your will's instructions.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">2. What happens if you don't have a will?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> State intestacy laws determine how your assets are distributed, which may not match your personal wishes.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">3. Why do you need both financial and healthcare powers of attorney?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> They cover different aspects of your life - financial power of attorney handles money and property decisions, while healthcare power of attorney handles medical decisions.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Module 4 Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                Excellent! You now understand the seven essential tools for complete estate planning protection. You've learned how each document serves a specific purpose and how they work together to protect you and your family in all situations.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-planning-course">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Back to Course Overview
                  </Button>
                </Link>
                <Button 
                  variant="outline"
                  className="border-teal-500 text-teal-600"
                  onClick={() => window.location.href = "/estate-planning-course#quiz"}
                >
                  Take Full Course Quiz
                </Button>
              </div>
            </div>

            {/* Quiz Section */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Test Your Knowledge!</h3>
                  <p className="mb-4">Ready to test your understanding of wills and their requirements?</p>
                  <Link href="/estate-quiz-4">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 4 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-module-3">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Previous: Essential Estate Planning Tools
                  </Button>
                </Link>
                <Link href="/estate-module-5">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Next Module: When Someone Dies →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}