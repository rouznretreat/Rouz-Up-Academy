import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, FileText, CheckCircle, Calendar, Users, Building, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";

export default function EstateModule2() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link href="/estate-planning-course">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Estate Planning Course
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-green-700 flex items-center space-x-3">
              <FileText className="w-8 h-8" />
              <span>Module 2: Estate Planning vs Estate Administration</span>
            </CardTitle>
            <p className="text-gray-600">Understanding the crucial difference between planning and administration</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-green-50 p-6 rounded border-l-4 border-green-500">
              <h3 className="text-lg font-bold text-green-700 mb-4">🎯 Learning Objectives</h3>
              <ul className="space-y-2 text-green-700">
                <li>• Understand the difference between estate planning and estate administration</li>
                <li>• Learn when each process happens and who's involved</li>
                <li>• Discover why planning during life is crucial for wealth building</li>
                <li>• See real scenarios showing both processes in action</li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-green-600">Two Different Worlds: Planning vs Administration</h3>
              
              <p className="text-gray-700 leading-relaxed">
                <strong>Understanding the difference between estate planning and estate administration is crucial for building generational wealth.</strong> These are two completely different processes that happen at different times, involve different people, and serve different purposes. Let's explore both so you understand when and why each matters.
              </p>

              <div className="bg-blue-50 p-4 rounded border border-blue-300">
                <h4 className="font-bold text-blue-700 mb-2">🔍 Key Insight</h4>
                <p className="text-blue-700 text-sm">
                  Estate planning happens during your life and is about building wealth. Estate administration happens after death and is about distributing assets. Smart planning makes administration easier and preserves more wealth for your family.
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-l-4 border-green-500">
                <CardHeader>
                  <CardTitle className="text-green-700 flex items-center space-x-2">
                    <Calendar className="w-6 h-6" />
                    <span>Estate Planning</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-green-50 p-3 rounded">
                    <h4 className="font-bold text-green-700 mb-2">WHEN:</h4>
                    <p className="text-sm text-green-700">During your lifetime - while you're alive and well</p>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded">
                    <h4 className="font-bold text-green-700 mb-2">WHO:</h4>
                    <p className="text-sm text-green-700">You, your family, and your advisors working together</p>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded">
                    <h4 className="font-bold text-green-700 mb-2">PURPOSE:</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Build and protect wealth</li>
                      <li>• Minimize taxes</li>
                      <li>• Create financial security</li>
                      <li>• Plan for the unexpected</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 p-3 rounded">
                    <h4 className="font-bold text-green-700 mb-2">ACTIVITIES:</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Creating wills and trusts</li>
                      <li>• Setting up business structures</li>
                      <li>• Tax planning strategies</li>
                      <li>• Investment planning</li>
                      <li>• Insurance planning</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-purple-500">
                <CardHeader>
                  <CardTitle className="text-purple-700 flex items-center space-x-2">
                    <Building className="w-6 h-6" />
                    <span>Estate Administration</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-purple-50 p-3 rounded">
                    <h4 className="font-bold text-purple-700 mb-2">WHEN:</h4>
                    <p className="text-sm text-purple-700">After death - when someone has passed away</p>
                  </div>
                  
                  <div className="bg-purple-50 p-3 rounded">
                    <h4 className="font-bold text-purple-700 mb-2">WHO:</h4>
                    <p className="text-sm text-purple-700">Executors, trustees, lawyers, and court officials</p>
                  </div>
                  
                  <div className="bg-purple-50 p-3 rounded">
                    <h4 className="font-bold text-purple-700 mb-2">PURPOSE:</h4>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>• Distribute assets to heirs</li>
                      <li>• Pay final debts and taxes</li>
                      <li>• Close accounts and affairs</li>
                      <li>• Follow legal requirements</li>
                    </ul>
                  </div>
                  
                  <div className="bg-purple-50 p-3 rounded">
                    <h4 className="font-bold text-purple-700 mb-2">ACTIVITIES:</h4>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>• Probate court proceedings</li>
                      <li>• Asset valuation and inventory</li>
                      <li>• Paying debts and taxes</li>
                      <li>• Distributing inheritances</li>
                      <li>• Filing final tax returns</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-green-600">Real-World Scenarios</h3>
              
              <div className="space-y-4">
                <div className="bg-yellow-50 p-4 rounded border border-yellow-300">
                  <h4 className="font-bold text-yellow-700 mb-3">🏠 Scenario 1: The Williams Family - Smart Planning</h4>
                  <div className="space-y-3">
                    <div>
                      <h5 className="font-semibold text-yellow-700">Estate Planning (During Life):</h5>
                      <p className="text-yellow-700 text-sm">
                        Mr. Williams creates a revocable trust, transfers his home and investments into it, and names his wife as successor trustee. He also updates all beneficiary designations and creates powers of attorney.
                      </p>
                    </div>
                    <div>
                      <h5 className="font-semibold text-yellow-700">Estate Administration (After Death):</h5>
                      <p className="text-yellow-700 text-sm">
                        When Mr. Williams passes away, his wife simply takes over as trustee. No probate court required. Assets transfer immediately. Total cost: minimal. Time: days instead of months.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 p-4 rounded border border-red-300">
                  <h4 className="font-bold text-red-700 mb-3">⚠️ Scenario 2: The Garcia Family - No Planning</h4>
                  <div className="space-y-3">
                    <div>
                      <h5 className="font-semibold text-red-700">Estate Planning (During Life):</h5>
                      <p className="text-red-700 text-sm">
                        Mr. Garcia never created any estate planning documents. Everything remained in his name only, with no clear instructions for his family.
                      </p>
                    </div>
                    <div>
                      <h5 className="font-semibold text-red-700">Estate Administration (After Death):</h5>
                      <p className="text-red-700 text-sm">
                        His family faces 12-18 months of probate court proceedings, thousands in legal fees, public records of all assets, and significant stress during their grief. Much of the estate's value is lost to costs and delays.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-teal-50 p-4 rounded border border-teal-300">
                  <h4 className="font-bold text-teal-700 mb-3">💡 Scenario 3: The Chen Business - Advanced Planning</h4>
                  <div className="space-y-3">
                    <div>
                      <h5 className="font-semibold text-teal-700">Estate Planning (During Life):</h5>
                      <p className="text-teal-700 text-sm">
                        The Chen family uses advanced trust strategies to gradually transfer their business to their children while minimizing taxes. They also establish education trusts for grandchildren.
                      </p>
                    </div>
                    <div>
                      <h5 className="font-semibold text-teal-700">Estate Administration (After Death):</h5>
                      <p className="text-teal-700 text-sm">
                        The business transition is seamless because ownership was already transferred. The next generation continues the business without interruption, and significant wealth is preserved for future generations.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-green-600">Why the Timing Matters</h3>
              
              <div className="bg-indigo-50 p-6 rounded border border-indigo-300">
                <h4 className="font-bold text-indigo-700 mb-4">⏰ The Power of Planning During Life:</h4>
                <div className="space-y-3 text-sm text-indigo-700">
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>You're in Control:</strong> Make decisions based on your values and wishes</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Tax Advantages:</strong> Use strategies only available during your lifetime</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Flexibility:</strong> Change plans as your life and goals evolve</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Family Harmony:</strong> Discuss plans with family and avoid conflicts</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span><strong>Wealth Building:</strong> Structure assets to grow and compound over time</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-green-600">Test Your Understanding</h3>
              
              <div className="bg-yellow-50 p-6 rounded border border-yellow-300">
                <h4 className="font-bold text-yellow-700 mb-4">Quick Check Questions:</h4>
                <div className="space-y-3">
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">1. When does estate planning happen?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> During your lifetime, while you're alive and well, so you can make informed decisions and use strategies only available during life.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">2. What's the main purpose of estate administration?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> To distribute assets to heirs, pay final debts and taxes, and close the deceased person's affairs according to legal requirements.
                    </div>
                  </div>
                  
                  <div className="bg-white p-3 rounded">
                    <p className="font-semibold text-gray-800 mb-2">3. Why is planning during life better than waiting?</p>
                    <div className="text-sm text-gray-600">
                      <strong>Answer:</strong> You maintain control, can use tax advantages, have flexibility to change plans, and can structure assets for wealth building rather than just distribution.
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-teal-50 p-6 rounded border border-teal-300">
              <h3 className="text-lg font-bold text-teal-700 mb-4 flex items-center space-x-2">
                <CheckCircle className="w-6 h-6" />
                <span>Module 2 Complete!</span>
              </h3>
              <p className="text-teal-700 mb-4">
                Excellent! You now understand the crucial difference between estate planning (wealth building during life) and estate administration (asset distribution after death). You've seen how smart planning makes administration easier and preserves more wealth for families.
              </p>
              <div className="flex space-x-3">
                <Link href="/estate-module-3">
                  <Button className="bg-teal-600 hover:bg-teal-700">
                    Next: Essential Estate Planning Tools →
                  </Button>
                </Link>
                <Link href="/estate-planning-course">
                  <Button variant="outline" className="border-teal-500 text-teal-600">
                    Back to Course Overview
                  </Button>
                </Link>
              </div>
            </div>

            {/* Quiz Section */}
            <div className="mt-8 pt-6 border-t border-teal-200">
              <div className="text-center mb-6">
                <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-3">🎯 Test Your Knowledge!</h3>
                  <p className="mb-4">Ready to test your understanding of planning vs administration?</p>
                  <Link href="/estate-quiz-2">
                    <Button className="bg-white text-green-600 hover:bg-gray-100 font-bold px-6 py-3">
                      Take Module 2 Quiz (3 Questions)
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="flex justify-between items-center">
                <Link href="/estate-module-1">
                  <Button variant="outline" className="border-gray-300 text-gray-600">
                    ← Previous: What is Estate Planning?
                  </Button>
                </Link>
                <Link href="/estate-module-3">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Next Module: Essential Estate Planning Tools →
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}