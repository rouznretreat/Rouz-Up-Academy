import { useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function CoinFlipGame() {
  const [balance, setBalance] = useState(100);
  const [betAmount, setBetAmount] = useState(10);
  const [prediction, setPrediction] = useState<"heads" | "tails">("heads");
  const [lastFlipResult, setLastFlipResult] = useState<"heads" | "tails" | null>(null);
  const [isFlipping, setIsFlipping] = useState(false);
  const [gameHistory, setGameHistory] = useState<Array<{
    bet: number;
    prediction: "heads" | "tails";
    result: "heads" | "tails";
    won: boolean;
    balanceAfter: number;
  }>>([]);

  const flipCoin = () => {
    if (betAmount > balance || betAmount <= 0) {
      alert("Invalid bet amount!");
      return;
    }

    setIsFlipping(true);

    // Simulate coin flip animation delay
    setTimeout(() => {
      const result = Math.random() < 0.5 ? "heads" : "tails";
      const won = result === prediction;
      const newBalance = won ? balance + betAmount : balance - betAmount;

      setLastFlipResult(result);
      setBalance(newBalance);
      setGameHistory(prev => [...prev, {
        bet: betAmount,
        prediction,
        result,
        won,
        balanceAfter: newBalance
      }]);
      setIsFlipping(false);
    }, 1000);
  };

  const resetGame = () => {
    setBalance(100);
    setBetAmount(10);
    setPrediction("heads");
    setLastFlipResult(null);
    setGameHistory([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-orange-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <Link href="/games">
            <Button variant="outline" className="text-yellow-600 border-yellow-600 hover:bg-yellow-50 bg-white transition-colors mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Games
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Coin Flip Challenge</h1>
          <p className="text-lg text-yellow-100">Test your luck and learn about probability and risk!</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Learning Objectives */}
        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-600">What You'll Learn:</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">
              This game teaches you about probability, risk management, and how to make smart bets with your money.
            </p>
          </CardContent>
        </Card>

        {/* Game Interface */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Balance and Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Your Balance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-600 mb-4">
                  ${balance.toFixed(2)}
                </div>
                {balance <= 0 && (
                  <div className="text-red-600 font-medium">Game Over! Reset to play again.</div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Your Bet Amount:</label>
                <input
                  type="number"
                  min="1"
                  max={balance}
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseInt(e.target.value) || 1)}
                  className="w-full p-3 border rounded-lg text-center text-xl font-bold"
                  disabled={isFlipping || balance <= 0}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Your Prediction:</label>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    onClick={() => setPrediction("heads")}
                    variant={prediction === "heads" ? "default" : "outline"}
                    className={`p-4 ${prediction === "heads" ? "bg-blue-600 text-white" : ""}`}
                    disabled={isFlipping || balance <= 0}
                  >
                    Heads
                  </Button>
                  <Button
                    onClick={() => setPrediction("tails")}
                    variant={prediction === "tails" ? "default" : "outline"}
                    className={`p-4 ${prediction === "tails" ? "bg-blue-600 text-white" : ""}`}
                    disabled={isFlipping || balance <= 0}
                  >
                    Tails
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  onClick={flipCoin}
                  disabled={isFlipping || balance <= 0 || betAmount > balance}
                  className="w-full bg-yellow-600 hover:bg-yellow-700 text-lg py-3"
                >
                  {isFlipping ? "Flipping..." : "Flip Coin"}
                </Button>
                <Button
                  onClick={resetGame}
                  variant="outline"
                  className="w-full"
                >
                  Reset Game
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Coin and Result */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Coin Flip Result</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-4">
                <div className={`text-8xl transition-transform duration-1000 ${isFlipping ? "animate-spin" : ""}`}>
                  {isFlipping ? "🪙" : lastFlipResult === "heads" ? "🟡" : lastFlipResult === "tails" ? "⚪" : "🪙"}
                </div>
                
                {lastFlipResult && !isFlipping && (
                  <div className="space-y-2">
                    <div className="text-2xl font-bold">
                      {lastFlipResult === "heads" ? "HEADS!" : "TAILS!"}
                    </div>
                    <div className={`text-lg font-medium ${
                      gameHistory[gameHistory.length - 1]?.won ? "text-green-600" : "text-red-600"
                    }`}>
                      {gameHistory[gameHistory.length - 1]?.won ? "You Won!" : "You Lost!"}
                    </div>
                    <div className="text-sm text-gray-600">
                      {gameHistory[gameHistory.length - 1]?.won ? "+" : "-"}${betAmount}
                    </div>
                  </div>
                )}
                
                {!lastFlipResult && !isFlipping && (
                  <div className="text-gray-500">
                    Make your prediction and flip the coin!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Statistics */}
        {gameHistory.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Game Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{gameHistory.length}</div>
                  <div className="text-sm text-gray-600">Total Flips</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {gameHistory.filter(h => h.won).length}
                  </div>
                  <div className="text-sm text-gray-600">Wins</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-600">
                    {gameHistory.filter(h => !h.won).length}
                  </div>
                  <div className="text-sm text-gray-600">Losses</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">
                    {gameHistory.length > 0 ? ((gameHistory.filter(h => h.won).length / gameHistory.length) * 100).toFixed(1) : 0}%
                  </div>
                  <div className="text-sm text-gray-600">Win Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent History */}
        {gameHistory.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Flips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {gameHistory.slice(-10).reverse().map((flip, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                    <span className="text-sm">
                      Bet ${flip.bet} on {flip.prediction}
                    </span>
                    <span className="text-sm">
                      Result: {flip.result} - {flip.won ? "🟢 Won" : "🔴 Lost"}
                    </span>
                    <span className="text-sm font-medium">
                      ${flip.balanceAfter.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Family Discussion */}
        <Card className="bg-orange-50 border-orange-200">
          <CardHeader>
            <CardTitle className="text-orange-800">Family Discussion Prompt:</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-orange-700">
              Talk about how a coin flip is a 50/50 chance. How is investing different from gambling? 
              What kinds of financial risks are smart to take, and which ones should be avoided?
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}