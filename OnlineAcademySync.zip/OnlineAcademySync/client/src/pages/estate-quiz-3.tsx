import EstateQuiz from "@/components/EstateQuiz";

export default function EstateQuiz3() {
  return <EstateQuiz moduleType="module-3" />;
}