import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Courses from "@/pages/courses";
import CourseDetail from "@/pages/course-detail";
import BusinessCourse from "@/pages/business-course-fixed";
import BankingCourse from "@/pages/banking-course-fixed";
import BankingBasics from "@/pages/banking-basics";
import SavingVsGrowing from "@/pages/saving-vs-growing";
import AccountTypes from "@/pages/account-types";
import CompoundInterest from "@/pages/compound-interest";
import InvestingBasics from "@/pages/investing-basics";
import SettingGoals from "@/pages/setting-goals";
import AllowanceCalculatorPage from "@/pages/allowance-calculator";
import SavingsGrowthCalculator from "@/pages/savings-growth-calculator";
import SavingsGoalCalculator from "@/pages/savings-goal-calculator";
import GraduationCalculator from "@/pages/graduation-calculator";
import CarSavingsCalculator from "@/pages/car-savings-calculator";
import EmergencyFundCalculator from "@/pages/emergency-fund-calculator";
import StockSimulator from "@/pages/stock-simulator";
import CashFlowQuiz from "@/pages/cash-flow-quiz";
import RealEstateBankingGamePage from "@/pages/real-estate-banking-game";
import CoinFlipGame from "@/pages/coin-flip-game";
import BabyStepsChallenge from "@/pages/baby-steps-challenge";
import CareerIncomeGame from "@/pages/career-income-game";
import BudgetBlaster from "@/pages/budget-blaster";
import DebtEscapeRoom from "@/pages/debt-escape-room";
import MoneyTimeTravel from "@/pages/money-time-travel";
import BankingTriviaShowdown from "@/pages/banking-trivia-showdown";
import SavingsChallengeGame from "@/pages/savings-challenge-game";
import BuildHouseGame from "@/pages/build-house-game";
import RealEstateGame from "@/pages/real-estate-game";
import Banking from "@/pages/banking";
import Goals from "@/pages/goals";
import Tools from "@/pages/tools";
import TrustCourse from "@/pages/trust-course";
import EstatePlanningCourse from "@/pages/estate-planning-course";
import InsuranceForStarters from "@/pages/insurance-for-starters";
import InsuranceStandalone from "@/pages/insurance-standalone";
import InsuranceCourse from "@/pages/insurance-course";
import CreditCourse from "@/pages/credit-course";
import CourseDescription from "@/pages/course-description";
import Membership from "@/pages/membership";
import EstateModule1 from "@/pages/estate-module-1";
import EstateModule2 from "@/pages/estate-module-2";
import EstateModule3 from "@/pages/estate-module-3";
import EstateModule4 from "@/pages/estate-module-4";
import EstateModule5 from "@/pages/estate-module-5";
import EstateModule6 from "@/pages/estate-module-6";
import EstateQuiz1 from "@/pages/estate-quiz-1";
import EstateQuiz2 from "@/pages/estate-quiz-2";
import EstateQuiz3 from "@/pages/estate-quiz-3";
import EstateQuiz4 from "@/pages/estate-quiz-4";
import EstateQuiz5 from "@/pages/estate-quiz-5";
import EstateQuiz6 from "@/pages/estate-quiz-6";
import SampleWill from "@/pages/sample-will";
import SampleTrust from "@/pages/sample-trust";
import SamplePowerOfAttorney from "@/pages/sample-power-of-attorney";
import SampleHealthcareDirective from "@/pages/sample-healthcare-directive";
import Games from "@/pages/games";
import Dashboard from "@/pages/dashboard";
import Checkout from "@/pages/checkout";
import Subscribe from "@/pages/subscribe";
import Privacy from "@/pages/privacy";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import Zoom from "@/pages/zoom";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/courses" component={Courses} />
          <Route path="/course/:id" component={CourseDetail} />
          <Route path="/business-course" component={BusinessCourse} />
          <Route path="/business-for-starters" component={BusinessCourse} />
          <Route path="/banking-course" component={BankingCourse} />
          <Route path="/banking-basics" component={BankingBasics} />
          <Route path="/saving-vs-growing" component={SavingVsGrowing} />
          <Route path="/account-types" component={AccountTypes} />
          <Route path="/compound-interest" component={CompoundInterest} />
          <Route path="/investing-basics" component={InvestingBasics} />
          <Route path="/setting-goals" component={SettingGoals} />
          <Route path="/allowance-calculator" component={AllowanceCalculatorPage} />
          <Route path="/savings-growth-calculator" component={SavingsGrowthCalculator} />
          <Route path="/savings-goal-calculator" component={SavingsGoalCalculator} />
          <Route path="/graduation-calculator" component={GraduationCalculator} />
          <Route path="/car-savings-calculator" component={CarSavingsCalculator} />
          <Route path="/emergency-fund-calculator" component={EmergencyFundCalculator} />
          <Route path="/tools" component={Tools} />
          <Route path="/stock-simulator" component={StockSimulator} />
          <Route path="/budget-blaster" component={BudgetBlaster} />
          <Route path="/career-income-game" component={CareerIncomeGame} />
          <Route path="/debt-escape-room" component={DebtEscapeRoom} />
          <Route path="/money-time-travel" component={MoneyTimeTravel} />
          <Route path="/banking-trivia-showdown" component={BankingTriviaShowdown} />
          <Route path="/savings-challenge-game" component={SavingsChallengeGame} />
          <Route path="/cash-flow-quiz" component={CashFlowQuiz} />
          <Route path="/baby-steps-challenge" component={BabyStepsChallenge} />
          <Route path="/real-estate-banking-game" component={RealEstateBankingGamePage} />
          <Route path="/trust-course" component={TrustCourse} />
          <Route path="/estate-planning-course" component={EstatePlanningCourse} />
          <Route path="/insurance-course" component={InsuranceCourse} />
          <Route path="/credit-course" component={CreditCourse} />
          <Route path="/credit-for-starters" component={CreditCourse} />
          <Route path="/estate-module-1" component={EstateModule1} />
          <Route path="/estate-module-2" component={EstateModule2} />
          <Route path="/estate-module-3" component={EstateModule3} />
          <Route path="/estate-module-4" component={EstateModule4} />
          <Route path="/estate-module-5" component={EstateModule5} />
          <Route path="/estate-module-6" component={EstateModule6} />
          <Route path="/estate-quiz-1" component={EstateQuiz1} />
          <Route path="/estate-quiz-2" component={EstateQuiz2} />
          <Route path="/estate-quiz-3" component={EstateQuiz3} />
          <Route path="/estate-quiz-4" component={EstateQuiz4} />
          <Route path="/estate-quiz-5" component={EstateQuiz5} />
          <Route path="/estate-quiz-6" component={EstateQuiz6} />
          <Route path="/sample-will" component={SampleWill} />
          <Route path="/sample-trust" component={SampleTrust} />
          <Route path="/sample-power-of-attorney" component={SamplePowerOfAttorney} />
          <Route path="/sample-healthcare-directive" component={SampleHealthcareDirective} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/subscribe" component={Subscribe} />
          <Route path="/membership" component={Membership} />
          <Route path="/privacy" component={Privacy} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/zoom" component={Zoom} />
        </>
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/courses" component={Courses} />
          <Route path="/course/:id" component={CourseDetail} />
          <Route path="/course-description/:id" component={CourseDescription} />
          <Route path="/membership" component={Membership} />
          <Route path="/business-course" component={BusinessCourse} />
          <Route path="/business-for-starters" component={BusinessCourse} />
          <Route path="/banking-course" component={BankingCourse} />
          <Route path="/banking-basics" component={BankingBasics} />
          <Route path="/saving-vs-growing" component={SavingVsGrowing} />
          <Route path="/account-types" component={AccountTypes} />
          <Route path="/compound-interest" component={CompoundInterest} />
          <Route path="/investing-basics" component={InvestingBasics} />
          <Route path="/setting-goals" component={SettingGoals} />
          <Route path="/allowance-calculator" component={AllowanceCalculatorPage} />
          <Route path="/savings-growth-calculator" component={SavingsGrowthCalculator} />
          <Route path="/savings-goal-calculator" component={SavingsGoalCalculator} />
          <Route path="/stock-simulator" component={StockSimulator} />
          <Route path="/cash-flow-quiz" component={CashFlowQuiz} />
          <Route path="/coin-flip-game" component={CoinFlipGame} />
          <Route path="/baby-steps-challenge" component={BabyStepsChallenge} />
          <Route path="/career-income-game" component={CareerIncomeGame} />
          <Route path="/budget-blaster" component={BudgetBlaster} />
          <Route path="/build-house-game" component={BuildHouseGame} />
          <Route path="/real-estate-game" component={RealEstateGame} />
          <Route path="/banking" component={Banking} />
          <Route path="/goals" component={Goals} />
          <Route path="/tools" component={Tools} />
          <Route path="/trust-course" component={TrustCourse} />
          <Route path="/estate-planning-course" component={EstatePlanningCourse} />
          <Route path="/insurance-for-starters" component={InsuranceStandalone} />
          <Route path="/insurance-course" component={InsuranceCourse} />
          <Route path="/credit-course" component={CreditCourse} />
          <Route path="/credit-for-starters" component={CreditCourse} />
          <Route path="/estate-module-1" component={EstateModule1} />
          <Route path="/estate-module-2" component={EstateModule2} />
          <Route path="/estate-module-3" component={EstateModule4} />
          <Route path="/estate-module-4" component={EstateModule3} />
          <Route path="/estate-module-5" component={EstateModule5} />
          <Route path="/estate-module-6" component={EstateModule6} />
          <Route path="/estate-quiz-1" component={EstateQuiz1} />
          <Route path="/estate-quiz-2" component={EstateQuiz2} />
          <Route path="/estate-quiz-3" component={EstateQuiz3} />
          <Route path="/estate-quiz-4" component={EstateQuiz4} />
          <Route path="/estate-quiz-5" component={EstateQuiz5} />
          <Route path="/estate-quiz-6" component={EstateQuiz6} />
          <Route path="/sample-will" component={SampleWill} />
          <Route path="/sample-trust" component={SampleTrust} />
          <Route path="/sample-power-of-attorney" component={SamplePowerOfAttorney} />
          <Route path="/sample-healthcare-directive" component={SampleHealthcareDirective} />
          <Route path="/games" component={Games} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/subscribe" component={Subscribe} />
          <Route path="/privacy" component={Privacy} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/zoom" component={Zoom} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
