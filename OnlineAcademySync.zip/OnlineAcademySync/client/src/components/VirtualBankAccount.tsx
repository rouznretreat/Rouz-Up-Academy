import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { RefreshCcw, DollarSign, ArrowUpDown, Calendar, CreditCard } from "lucide-react";

interface Transaction {
  id: string;
  date: string;
  description: string;
  category: string;
  amount: number;
  type: 'income' | 'expense';
}

interface AutoPayment {
  id: string;
  name: string;
  amount: number;
  frequency: 'weekly' | 'monthly';
  nextPayment: string;
}

export default function VirtualBankAccount() {
  const [checkingBalance, setCheckingBalance] = useState(585.00);
  const [savingsBalance, setSavingsBalance] = useState(150.00);
  const [selectedAccount, setSelectedAccount] = useState<'checking' | 'savings'>('checking');
  const [actionType, setActionType] = useState<'deposit' | 'withdraw' | 'transfer' | 'autopay' | null>(null);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [transferTo, setTransferTo] = useState<'checking' | 'savings'>('savings');

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      date: 'May 20, 2025',
      description: 'BIRTHDAY GIFT',
      category: 'income',
      amount: 35.00,
      type: 'income'
    },
    {
      id: '2',
      date: 'May 18, 2025',
      description: 'Bus Fare',
      category: 'transportation',
      amount: -2.50,
      type: 'expense'
    },
    {
      id: '3',
      date: 'May 17, 2025',
      description: 'Coffee Shop',
      category: 'food',
      amount: -5.75,
      type: 'expense'
    },
    {
      id: '4',
      date: 'May 13, 2025',
      description: 'Paycheck',
      category: 'income',
      amount: 500.00,
      type: 'income'
    }
  ]);

  const [autoPayments, setAutoPayments] = useState<AutoPayment[]>([
    {
      id: '1',
      name: 'Allowance',
      amount: 25.00,
      frequency: 'weekly',
      nextPayment: 'May 27, 2025'
    }
  ]);

  const handleTransaction = () => {
    const transactionAmount = parseFloat(amount);
    if (isNaN(transactionAmount) || transactionAmount <= 0) return;

    const newTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      }),
      description: description || 'Transaction',
      category: category || 'other',
      amount: actionType === 'deposit' ? transactionAmount : -transactionAmount,
      type: actionType === 'deposit' ? 'income' : 'expense'
    };

    if (actionType === 'deposit') {
      if (selectedAccount === 'checking') {
        setCheckingBalance(prev => prev + transactionAmount);
      } else {
        setSavingsBalance(prev => prev + transactionAmount);
      }
    } else if (actionType === 'withdraw') {
      if (selectedAccount === 'checking') {
        if (checkingBalance >= transactionAmount) {
          setCheckingBalance(prev => prev - transactionAmount);
        } else {
          alert('Insufficient funds in checking account!');
          return;
        }
      } else {
        if (savingsBalance >= transactionAmount) {
          setSavingsBalance(prev => prev - transactionAmount);
        } else {
          alert('Insufficient funds in savings account!');
          return;
        }
      }
    }

    setTransactions(prev => [newTransaction, ...prev]);
    setAmount('');
    setDescription('');
    setCategory('');
    setActionType(null);
  };

  const handleTransfer = () => {
    const transferAmount = parseFloat(amount);
    if (isNaN(transferAmount) || transferAmount <= 0) return;

    if (selectedAccount === 'checking' && transferTo === 'savings') {
      if (checkingBalance >= transferAmount) {
        setCheckingBalance(prev => prev - transferAmount);
        setSavingsBalance(prev => prev + transferAmount);
      } else {
        alert('Insufficient funds in checking account!');
        return;
      }
    } else if (selectedAccount === 'savings' && transferTo === 'checking') {
      if (savingsBalance >= transferAmount) {
        setSavingsBalance(prev => prev - transferAmount);
        setCheckingBalance(prev => prev + transferAmount);
      } else {
        alert('Insufficient funds in savings account!');
        return;
      }
    }

    const transferTransaction: Transaction = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      }),
      description: `Transfer to ${transferTo}`,
      category: 'transfer',
      amount: selectedAccount === 'checking' ? -transferAmount : transferAmount,
      type: selectedAccount === 'checking' ? 'expense' : 'income'
    };

    setTransactions(prev => [transferTransaction, ...prev]);
    setAmount('');
    setActionType(null);
  };

  const resetAccounts = () => {
    setCheckingBalance(585.00);
    setSavingsBalance(150.00);
    setTransactions([
      {
        id: '1',
        date: 'May 20, 2025',
        description: 'BIRTHDAY GIFT',
        category: 'income',
        amount: 35.00,
        type: 'income'
      },
      {
        id: '2',
        date: 'May 18, 2025',
        description: 'Bus Fare',
        category: 'transportation',
        amount: -2.50,
        type: 'expense'
      },
      {
        id: '3',
        date: 'May 17, 2025',
        description: 'Coffee Shop',
        category: 'food',
        amount: -5.75,
        type: 'expense'
      },
      {
        id: '4',
        date: 'May 13, 2025',
        description: 'Paycheck',
        category: 'income',
        amount: 500.00,
        type: 'income'
      }
    ]);
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">🏦 Virtual Bank Account</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          This simulator lets you practice managing a checking and savings account. You can make deposits, withdrawals, transfers, and set up automatic payments. Learn how to build good banking habits in a risk-free environment!
        </p>
      </div>

      {/* Bank Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-6 rounded-lg">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">🏦 My Virtual Bank</h2>
          <Button onClick={resetAccounts} variant="secondary" size="sm">
            <RefreshCcw className="w-4 h-4 mr-2" />
            Refresh Accounts
          </Button>
        </div>
      </div>

      {/* Account Overview */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center text-green-800">
              <DollarSign className="w-5 h-5 mr-2" />
              Checking Account
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-700">${checkingBalance.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center text-blue-800">
              <DollarSign className="w-5 h-5 mr-2" />
              Savings Account
              <Badge variant="secondary" className="ml-2">0.75% APY</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-700">${savingsBalance.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Transfer Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ArrowUpDown className="w-5 h-5 mr-2" />
            Transfer Between Accounts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">From Account</label>
              <Select value={selectedAccount} onValueChange={(value: 'checking' | 'savings') => setSelectedAccount(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="checking">Checking</SelectItem>
                  <SelectItem value="savings">Savings</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">To Account</label>
              <Select value={transferTo} onValueChange={(value: 'checking' | 'savings') => setTransferTo(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="checking">Checking</SelectItem>
                  <SelectItem value="savings">Savings</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Amount</label>
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <Button onClick={handleTransfer} className="w-full">
                Transfer
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Account Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Account Actions</CardTitle>
          <p className="text-sm text-gray-600">Selected: {selectedAccount === 'checking' ? 'Checking' : 'Savings'} Account</p>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4 mb-4">
            <Button 
              onClick={() => setActionType('deposit')}
              variant={actionType === 'deposit' ? 'default' : 'outline'}
            >
              Deposit Money
            </Button>
            <Button 
              onClick={() => setActionType('withdraw')}
              variant={actionType === 'withdraw' ? 'default' : 'outline'}
            >
              Withdraw Money
            </Button>
            <Button 
              onClick={() => setActionType('autopay')}
              variant={actionType === 'autopay' ? 'default' : 'outline'}
            >
              Set Up Automatic Payment
            </Button>
          </div>

          {(actionType === 'deposit' || actionType === 'withdraw') && (
            <div className="grid md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
              <div>
                <label className="block text-sm font-medium mb-2">Amount</label>
                <Input
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <Input
                  placeholder="e.g., Lunch money"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="income">Income</SelectItem>
                    <SelectItem value="food">Food</SelectItem>
                    <SelectItem value="transportation">Transportation</SelectItem>
                    <SelectItem value="entertainment">Entertainment</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={handleTransaction} className="w-full">
                  {actionType === 'deposit' ? 'Deposit' : 'Withdraw'}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Automatic Payments */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Automatic Payments
          </CardTitle>
          <p className="text-sm text-gray-600">Your recurring transactions</p>
        </CardHeader>
        <CardContent>
          {autoPayments.map((payment) => (
            <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium">{payment.name}</div>
                <div className="text-sm text-gray-600">
                  ${payment.amount.toFixed(2)} • {payment.frequency}
                </div>
              </div>
              <div className="text-sm text-gray-600">
                Next: {payment.nextPayment}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <CreditCard className="w-5 h-5 mr-2" />
            {selectedAccount === 'checking' ? 'Checking' : 'Savings'} Account
          </CardTitle>
          <p className="text-sm text-gray-600">Account overview and transaction history</p>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold mb-6">
            ${selectedAccount === 'checking' ? checkingBalance.toFixed(2) : savingsBalance.toFixed(2)}
            <span className="text-sm font-normal text-gray-600 ml-2">Current Balance</span>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Recent Transactions</h4>
            <p className="text-sm text-gray-600 mb-4">Showing {Math.min(transactions.length, 10)} most recent transactions</p>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Date</th>
                    <th className="text-left py-2">Description</th>
                    <th className="text-left py-2">Category</th>
                    <th className="text-right py-2">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.slice(0, 10).map((transaction) => (
                    <tr key={transaction.id} className="border-b">
                      <td className="py-3">{transaction.date}</td>
                      <td className="py-3 font-medium">{transaction.description}</td>
                      <td className="py-3">
                        <Badge variant="secondary">{transaction.category}</Badge>
                      </td>
                      <td className={`py-3 text-right font-medium ${
                        transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.amount > 0 ? '+' : ''}${transaction.amount.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}