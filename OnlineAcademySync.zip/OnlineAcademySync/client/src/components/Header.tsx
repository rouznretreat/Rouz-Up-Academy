import React, { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import academyLogo from "@assets/Rouz up academy logo-tm.jpg";

interface HeaderProps {
  isMenuOpen: boolean;
  setIsMenuOpen: (open: boolean) => void;
}

export default function Header({ isMenuOpen, setIsMenuOpen }: HeaderProps) {
  const { isAuthenticated, user } = useAuth();

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50 border-b border-gray-100">
      <div className="px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Mobile Logo */}
          <Link href={isAuthenticated ? "/" : "/"}>
            <div className="flex items-center space-x-2">
              <img 
                src={academyLogo} 
                alt="Rouz Up Academy" 
                className="h-10 w-10 rounded-lg"
              />
              <span className="font-bold text-lg text-gray-900">Rouz Up Academy</span>
            </div>
          </Link>

          {/* Mobile Profile/Auth */}
          <div className="flex items-center space-x-3">
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-medium text-sm">
                    {user?.firstName?.[0] || 'S'}
                  </span>
                </div>
                <Button 
                  onClick={() => window.location.href = '/api/logout'}
                  variant="ghost"
                  size="sm"
                  className="text-xs text-gray-600"
                >
                  Sign Out
                </Button>
              </div>
            ) : (
              <Button 
                onClick={() => window.location.href = '/api/login'}
                className="bg-blue-600 text-white px-4 py-2 rounded-full font-medium text-sm hover:bg-blue-700 transition-colors"
              >
                Sign In
              </Button>
            )}
            
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-700 rounded-full"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Simple Menu */}
        {isMenuOpen && (
          <div className="bg-white border-t border-gray-200 p-4">
            <div className="space-y-3">
              <Link href="/" className="block text-gray-700 hover:text-blue-600">
                Home
              </Link>
              <Link href="/courses" className="block text-gray-700 hover:text-blue-600">
                Courses
              </Link>
              <Link href="/membership" className="block text-gray-700 hover:text-blue-600">
                Pricing
              </Link>
              <Link href="/zoom" className="block text-gray-700 hover:text-blue-600">
                Live
              </Link>
              <Link href="/about" className="block text-gray-700 hover:text-blue-600">
                About
              </Link>
              <Link href="/contact" className="block text-gray-700 hover:text-blue-600">
                Contact
              </Link>
              <Link href="/privacy" className="block text-gray-600 text-sm hover:text-blue-600">
                Privacy
              </Link>
              {isAuthenticated && (
                <Link href="/dashboard" className="block text-blue-600 font-medium hover:text-blue-800">
                  My Dashboard
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
