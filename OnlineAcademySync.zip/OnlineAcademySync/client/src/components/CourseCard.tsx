import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Star, Clock, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
// Using direct URLs for reliable image loading

interface CourseCardProps {
  course: any;
  showEnrollButton?: boolean;
  isEnrolled?: boolean;
}

export default function CourseCard({ course, showEnrollButton = false, isEnrolled = false }: CourseCardProps) {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEnrolling, setIsEnrolling] = useState(false);

  const enrollMutation = useMutation({
    mutationFn: (courseId: number) => 
      apiRequest("POST", "/api/enrollments", { courseId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      toast({
        title: "Enrollment Successful",
        description: `You're now enrolled in ${course.title}!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Enrollment Failed",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  const handleEnroll = async () => {
    if (!isAuthenticated) {
      window.location.href = '/api/login';
      return;
    }

    if (course.isFree || user?.membershipTier === 'premium' || user?.membershipTier === 'vip') {
      setIsEnrolling(true);
      await enrollMutation.mutateAsync(course.id);
      setIsEnrolling(false);
    } else {
      // Redirect to purchase page
      window.location.href = `/checkout?courseId=${course.id}`;
    }
  };

  const handlePurchase = () => {
    window.location.href = `/checkout?courseId=${course.id}`;
  };

  const getCourseImage = () => {
    // Always use course.image first if it exists
    if (course.image) {
      return course.image;
    }
    
    // Use course.imageUrl from database schema
    if (course.imageUrl) {
      return course.imageUrl;
    }
    
    // Fallback to a nice gradient background
    return null; // Will trigger the gradient fallback in onError
  };

  const canAccessCourse = () => {
    if (course.isFree) return true;
    if (user?.membershipTier === 'premium' || user?.membershipTier === 'vip') return true;
    return false;
  };

  const getCourseFrontPageUrl = (title: string) => {
    const urls: { [key: string]: string } = {
      "Credit for Starters": "https://rouzup-credit-for-starters.replit.app/",
      "Banking for Starters": "https://banking-for-starters-rouzupacademy.replit.app/",
      "Business for Starters": "https://business-for-starters-rouzupacademy.replit.app/",
      "Trust for Starters": "https://trust-for-starters-rouznretreat.replit.app/",
    };
    return urls[title];
  };

  const handleCourseAccess = () => {
    console.log("Course clicked:", course.title); // Debug log
    
    // Check if course has a direct href property first
    if (course.href) {
      window.location.href = course.href;
      return;
    }
    
    if (course.title === "🛡️ Insurance for Starters" || course.title === "Insurance for Starters") {
      window.location.href = "/insurance-course";
    } else if (course.title === "💼 Business for Starters" || course.title === "Business for Starters") {
      window.location.href = "/business-course";
    } else if (course.title === "🏦 Banking for Starters" || course.title === "Banking for Starters") {
      console.log("Redirecting to Banking course"); // Debug log
      window.location.href = "/banking-course";
    } else if (course.title === "Credit for Starters") {
      console.log("Redirecting to Credit for Starters page");
      window.location.href = "/credit-for-starters";
    } else if (course.title === "⚖️ Trust for Starters" || course.title === "Trust for Starters") {
      window.location.href = "/trust-course";
    } else if (course.title === "📋 Estate Planning Course" || course.title === "Estate Planning for Starters") {
      window.location.href = "/estate-planning-course";
    } else {
      const frontPageUrl = getCourseFrontPageUrl(course.title);
      if (frontPageUrl) {
        window.open(frontPageUrl, "_blank");
      } else {
        window.location.href = `/course/${course.id}`;
      }
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden active:scale-95 transition-all duration-200 group">
      {/* Course Image Header */}
      <div className="relative h-48 overflow-hidden">
        {getCourseImage() ? (
          <img 
            src={getCourseImage()}
            alt={course.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              // Fallback to gradient if image fails to load
              e.currentTarget.style.display = 'none';
              if (e.currentTarget.parentElement) {
                e.currentTarget.parentElement.className += ' bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50';
              }
            }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
            <div className="text-6xl">
              {course.title.includes('Credit') ? '💳' : 
               course.title.includes('Business') ? '🏢' : 
               course.title.includes('Trust') ? '📜' : 
               course.title.includes('Estate') ? '🏛️' : 
               course.title.includes('Banking') ? '🏦' : 
               course.title.includes('Insurance') ? '🛡️' : '📚'}
            </div>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
        <div className="absolute top-3 left-3">
          <Badge 
            className={course.isFree 
              ? "bg-green-500 text-white text-xs px-3 py-1 rounded-full font-medium" 
              : "bg-gradient-to-r from-blue-500 to-purple-500 text-white text-xs px-3 py-1 rounded-full font-medium"
            }
          >
            {course.isFree ? '✨ FREE' : '⭐ PREMIUM'}
          </Badge>
        </div>
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm text-gray-700 px-2 py-1 rounded-full text-xs flex items-center">
          <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
          {course.rating || '4.8'}
        </div>
        <div className="mt-6 text-center">
          <div className="w-16 h-16 bg-white/80 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg">
            <span className="text-2xl">
              {course.title.includes('Credit') ? '💳' : 
               course.title.includes('Business') ? '🏢' : 
               course.title.includes('Trust') ? '📜' : 
               course.title.includes('Estate') ? '🏛️' : 
               course.title.includes('Banking') ? '🏦' : '📚'}
            </span>
          </div>
          <h3 className="font-bold text-xl text-white leading-tight shadow-lg">{course.title}</h3>
        </div>
      </div>
      
      <div className="p-5">
        <p className="text-blue-600 font-bold text-sm mb-4 line-clamp-2 leading-relaxed">{course.title}</p>
        
        <div className="flex items-center justify-between mb-3 text-xs text-gray-500">
          <div className="flex items-center">
            <Users className="w-3 h-3 mr-1" />
            <span>{course.studentCount || 0}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Star className="w-3 h-3 text-yellow-400 fill-current" />
            <span className="text-xs text-gray-600">{course.rating || '4.8'}</span>
          </div>
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <span className="font-bold text-base text-gray-900">
              {course.isFree ? 'Free' : `$${course.price}`}
            </span>
            {!course.isFree && <span className="text-xs text-gray-500 ml-2">per month</span>}
          </div>
          <span className="text-xs bg-gray-100 text-gray-600 px-3 py-1 rounded-full font-medium">{course.level}</span>
        </div>
        
        <div className="space-y-2">
          <Button 
            onClick={() => window.location.href = `/course-description/${course.id}`}
            variant="outline"
            className="w-full border-2 border-blue-500 text-blue-600 hover:bg-blue-50 text-sm py-2 rounded-xl font-semibold transition-all duration-200"
          >
            📖 Learn More
          </Button>
          <Button 
            onClick={handleCourseAccess}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:from-blue-600 hover:to-purple-600 text-sm py-3 rounded-xl font-semibold shadow-lg active:scale-95 transition-all duration-200"
          >
            🎯 Access Course
          </Button>
        </div>
      </div>
    </div>
  );
}
