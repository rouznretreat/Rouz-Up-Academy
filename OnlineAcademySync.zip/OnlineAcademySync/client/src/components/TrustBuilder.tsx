import { useState } from "react";
import { ArrowLeft, ArrowRight, FileText, Users, DollarSign, Clock, Shield, CheckCircle, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TrustBuilderProps {
  onBack: () => void;
}

interface Answer {
  question: string;
  answer: string;
}

export default function TrustBuilder({ onBack }: TrustBuilderProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      id: "purpose",
      question: "What is the primary purpose of your trust?",
      options: [
        "Education funding for children/grandchildren",
        "Asset protection from creditors",
        "Tax reduction and estate planning",
        "Charitable giving and philanthropy",
        "Family business succession",
        "Providing for disabled family member"
      ]
    },
    {
      id: "assets",
      question: "What types of assets will you place in the trust?",
      options: [
        "Cash and bank accounts ($50K - $500K)",
        "Real estate (primary residence)",
        "Investment portfolio ($100K - $1M)",
        "Business interests or shares",
        "High-value assets ($1M+)",
        "Mixed asset portfolio"
      ]
    },
    {
      id: "control",
      question: "How much control do you want to retain?",
      options: [
        "Full control - ability to change or revoke",
        "Some control - limited modification rights",
        "Minimal control - professional management",
        "No control - irrevocable for tax benefits"
      ]
    },
    {
      id: "beneficiaries",
      question: "Who are your intended beneficiaries?",
      options: [
        "My children only",
        "My children and grandchildren",
        "Spouse and children",
        "Multiple generations (dynasty approach)",
        "Charitable organizations",
        "Special needs family member"
      ]
    },
    {
      id: "timing",
      question: "When should beneficiaries receive distributions?",
      options: [
        "Immediately upon my death",
        "At specific ages (18, 25, 30, etc.)",
        "For specific purposes (education, home purchase)",
        "At trustee's discretion based on need",
        "Income only, preserve principal",
        "After multiple generations"
      ]
    },
    {
      id: "protection",
      question: "What level of asset protection do you need?",
      options: [
        "Basic protection from poor decisions",
        "Protection from creditors and lawsuits",
        "Maximum protection including divorce",
        "Tax protection and estate reduction",
        "Generation-skipping tax protection",
        "No specific protection needs"
      ]
    },
    {
      id: "jurisdiction",
      question: "Where do you want the trust governed?",
      options: [
        "My current state of residence",
        "State with no income tax (TX, FL, NV)",
        "Dynasty trust state (DE, SD, NV)",
        "Asset protection state (AK, DE, NV)",
        "I need guidance on this decision",
        "Offshore jurisdiction"
      ]
    }
  ];

  const handleAnswer = (answer: string) => {
    const newAnswer = {
      question: questions[currentStep].question,
      answer: answer
    };
    
    const newAnswers = [...answers];
    newAnswers[currentStep] = newAnswer;
    setAnswers(newAnswers);

    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResults(true);
    }
  };

  const goBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const generateRecommendations = () => {
    const purposeAnswer = answers[0]?.answer || "";
    const assetsAnswer = answers[1]?.answer || "";
    const controlAnswer = answers[2]?.answer || "";
    const beneficiariesAnswer = answers[3]?.answer || "";
    const timingAnswer = answers[4]?.answer || "";
    const protectionAnswer = answers[5]?.answer || "";
    const jurisdictionAnswer = answers[6]?.answer || "";

    // Determine trust type based on answers
    let trustType = "Revocable Living Trust";
    let taxBenefits = "Moderate";
    let assetProtection = "Basic";
    let complexity = "Medium";

    // Logic for trust type determination
    if (controlAnswer.includes("No control") || protectionAnswer.includes("Maximum protection")) {
      trustType = "Irrevocable Trust";
      taxBenefits = "High";
      assetProtection = "Maximum";
      complexity = "High";
    } else if (purposeAnswer.includes("Charitable")) {
      trustType = "Charitable Remainder Trust";
      taxBenefits = "Very High";
      assetProtection = "High";
      complexity = "High";
    } else if (beneficiariesAnswer.includes("Multiple generations") || timingAnswer.includes("multiple generations")) {
      trustType = "Dynasty Trust";
      taxBenefits = "Very High";
      assetProtection = "High";
      complexity = "Very High";
    } else if (purposeAnswer.includes("disabled") || beneficiariesAnswer.includes("Special needs")) {
      trustType = "Special Needs Trust";
      taxBenefits = "High";
      assetProtection = "Maximum";
      complexity = "High";
    } else if (protectionAnswer.includes("creditors") || protectionAnswer.includes("lawsuits")) {
      trustType = "Asset Protection Trust";
      taxBenefits = "High";
      assetProtection = "Maximum";
      complexity = "High";
    }

    return {
      trustType,
      taxBenefits,
      assetProtection,
      complexity,
      recommendedJurisdiction: jurisdictionAnswer.includes("Dynasty") ? "Delaware or South Dakota" : 
                               jurisdictionAnswer.includes("Asset protection") ? "Nevada or Alaska" :
                               jurisdictionAnswer.includes("no income tax") ? "Texas or Florida" : "Your home state"
    };
  };

  const generateDocumentList = () => {
    const recommendations = generateRecommendations();
    
    const baseDocuments = [
      "Trust Agreement/Declaration of Trust",
      "Pour-Over Will",
      "Durable Power of Attorney",
      "Advance Healthcare Directive",
      "Asset Transfer Documents (deeds, account transfers)"
    ];

    const additionalDocuments = [];

    if (recommendations.trustType.includes("Irrevocable") || recommendations.trustType.includes("Asset Protection")) {
      additionalDocuments.push("Gift Tax Returns (Form 709)");
      additionalDocuments.push("Irrevocable Trust Tax Returns (Form 1041)");
    }

    if (recommendations.trustType.includes("Charitable")) {
      additionalDocuments.push("Charitable Deduction Documentation");
      additionalDocuments.push("Qualified Appraisal for Donated Assets");
    }

    if (recommendations.trustType.includes("Dynasty")) {
      additionalDocuments.push("Generation-Skipping Transfer Tax Returns");
      additionalDocuments.push("Dynasty Trust Administrative Documents");
    }

    if (recommendations.trustType.includes("Special Needs")) {
      additionalDocuments.push("Special Needs Trust Compliance Documents");
      additionalDocuments.push("Government Benefits Coordination Letters");
    }

    return [...baseDocuments, ...additionalDocuments];
  };

  const getEstimatedCosts = () => {
    const recommendations = generateRecommendations();
    
    let legalFees = "$2,500 - $5,000";
    let ongoingCosts = "$500 - $1,500/year";
    
    if (recommendations.complexity === "High") {
      legalFees = "$5,000 - $15,000";
      ongoingCosts = "$1,500 - $5,000/year";
    } else if (recommendations.complexity === "Very High") {
      legalFees = "$10,000 - $25,000+";
      ongoingCosts = "$3,000 - $10,000+/year";
    }

    return { legalFees, ongoingCosts };
  };

  if (showResults) {
    const recommendations = generateRecommendations();
    const documents = generateDocumentList();
    const costs = getEstimatedCosts();

    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-6">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Trust Course</span>
          </button>
          <h1 className="text-3xl font-bold text-purple-600">Your Personalized Trust Recommendations</h1>
        </div>

        <div className="space-y-6">
          <Card className="border-l-4 border-green-500">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-700">
                <CheckCircle className="w-6 h-6" />
                <span>Recommended Trust Type</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold text-green-800 mb-2">{recommendations.trustType}</h3>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <strong>Tax Benefits:</strong> {recommendations.taxBenefits}
                  </div>
                  <div>
                    <strong>Asset Protection:</strong> {recommendations.assetProtection}
                  </div>
                  <div>
                    <strong>Complexity:</strong> {recommendations.complexity}
                  </div>
                </div>
                <p className="mt-3 text-sm text-green-700">
                  <strong>Recommended Jurisdiction:</strong> {recommendations.recommendedJurisdiction}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-blue-500">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-blue-700">
                <FileText className="w-6 h-6" />
                <span>Required Documents Checklist</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {documents.map((doc, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm">{doc}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-purple-700">
                <DollarSign className="w-6 h-6" />
                <span>Estimated Costs</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-purple-50 p-4 rounded">
                  <h4 className="font-bold text-purple-700">Initial Legal Fees</h4>
                  <p className="text-lg font-semibold">{costs.legalFees}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded">
                  <h4 className="font-bold text-purple-700">Ongoing Administration</h4>
                  <p className="text-lg font-semibold">{costs.ongoingCosts}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-orange-500">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-orange-700">
                <Clock className="w-6 h-6" />
                <span>Next Steps</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2 text-sm">
                <li className="flex items-start space-x-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">1</span>
                  <span>Consult with an estate planning attorney in your chosen jurisdiction</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">2</span>
                  <span>Gather all financial documents and asset information</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">3</span>
                  <span>Discuss family goals and beneficiary needs in detail</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">4</span>
                  <span>Review and execute the trust documents</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">5</span>
                  <span>Transfer assets into the trust</span>
                </li>
              </ol>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-yellow-500">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-yellow-700">
                <Shield className="w-6 h-6" />
                <span>Important Disclaimer</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700">
                This tool provides educational guidance only and does not constitute legal advice. Trust planning involves complex legal and tax considerations that vary by state and individual circumstances. Always consult with qualified estate planning attorneys, tax professionals, and financial advisors before making any trust-related decisions.
              </p>
            </CardContent>
          </Card>

          <div className="flex justify-center space-x-4">
            <Button 
              onClick={() => {
                setCurrentStep(0);
                setAnswers([]);
                setShowResults(false);
              }}
              variant="outline"
            >
              Start Over
            </Button>
            <Button 
              onClick={() => window.print()}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Download className="w-4 h-4 mr-2" />
              Print/Save Results
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-purple-600 hover:text-purple-700 mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Trust Course</span>
        </button>
        <h1 className="text-3xl font-bold text-purple-600 mb-2">Interactive Trust Builder</h1>
        <p className="text-gray-600">Answer a few questions to get personalized trust recommendations</p>
      </div>

      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-500">Question {currentStep + 1} of {questions.length}</span>
          <span className="text-sm text-gray-500">{Math.round(((currentStep + 1) / questions.length) * 100)}% Complete</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{questions[currentStep].question}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {questions[currentStep].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(option)}
                className="w-full p-4 text-left border border-gray-200 rounded-lg hover:bg-purple-50 hover:border-purple-300 transition-colors"
              >
                {option}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between mt-6">
        <Button
          onClick={goBack}
          disabled={currentStep === 0}
          variant="outline"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>
        <Button
          onClick={() => handleAnswer(questions[currentStep].options[0])}
          variant="outline"
        >
          Skip Question
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}