import { CheckCircle, Shield, AlertTriangle } from "lucide-react";

export default function SalvageDoctrineContent() {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-teal-600 mb-4">🛟 Salvage Doctrines: Saving Trusts from Perpetuity Violations</h3>
      
      <div className="bg-teal-50 p-4 rounded border-l-4 border-teal-500 mb-6">
        <h4 className="text-lg font-bold text-teal-700 mb-2">What Are Salvage Doctrines?</h4>
        <p className="text-teal-800 mb-3">Salvage doctrines are state statutory rules designed to "save" trusts from violating the Rule Against Perpetuities by reforming or modifying problematic provisions rather than invalidating the entire trust.</p>
        <p className="text-sm text-teal-700">These doctrines recognize that grantors rarely intend to create invalid trusts and work to preserve the grantor's intent while ensuring legal compliance.</p>
      </div>

      <div className="space-y-4">
        <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-500">
          <h5 className="font-bold text-blue-700 mb-3 flex items-center">
            <Shield className="w-5 h-5 mr-2" />
            Types of Salvage Doctrines
          </h5>
          
          <div className="space-y-4">
            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-blue-600 mb-2">1. Cy Pres Doctrine</h6>
              <p className="text-sm mb-2">Courts reform trust provisions to come as close as possible ("cy pres" means "as near as") to the original intent while complying with perpetuity rules.</p>
              <div className="bg-blue-50 p-3 rounded text-xs">
                <strong>Example:</strong> Original: "To my descendants who become Supreme Court Justices"<br/>
                <strong>Reformed:</strong> "To my descendants living at my death who become federal judges by age 45"
              </div>
            </div>

            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-blue-600 mb-2">2. Reduction of Age Contingencies</h6>
              <p className="text-sm mb-2">Automatically reduces problematic age requirements to the highest age that would comply with perpetuity rules.</p>
              <div className="bg-blue-50 p-3 rounded text-xs">
                <strong>Example:</strong> "To my grandchildren who reach age 40" becomes "To my grandchildren who reach age 21" to ensure vesting within the perpetuity period.
              </div>
            </div>

            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-blue-600 mb-2">3. Administrative Contingency Reform</h6>
              <p className="text-sm mb-2">Eliminates or modifies administrative contingencies that could extend beyond the perpetuity period.</p>
              <div className="bg-blue-50 p-3 rounded text-xs">
                <strong>Example:</strong> "When all estate litigation is resolved" becomes "21 years after my death or when litigation is resolved, whichever occurs first."
              </div>
            </div>

            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-blue-600 mb-2">4. Class Gift Reformation</h6>
              <p className="text-sm mb-2">Closes classes at appropriate times to prevent perpetuity violations by limiting future members.</p>
              <div className="bg-blue-50 p-3 rounded text-xs">
                <strong>Example:</strong> "To my great-grandchildren" becomes "To my great-grandchildren born before my death" to create a closed, identifiable class.
              </div>
            </div>

            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-blue-600 mb-2">5. Infectious Invalidity Prevention</h6>
              <p className="text-sm mb-2">Prevents one invalid interest from invalidating the entire trust by severing problematic provisions.</p>
              <div className="bg-blue-50 p-3 rounded text-xs">
                <strong>Example:</strong> If a remainder interest violates the rule, only that specific interest is eliminated while the income interests and other remainders remain valid.
              </div>
            </div>
          </div>
        </div>

        <div className="bg-green-50 p-4 rounded border-l-4 border-green-500">
          <h5 className="font-bold text-green-700 mb-3 flex items-center">
            <CheckCircle className="w-5 h-5 mr-2" />
            Real-World Salvage Examples
          </h5>
          
          <div className="space-y-4">
            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-green-600 mb-2">Case Study: The Martinez Education Trust</h6>
              <p className="text-sm mb-2"><strong>Original Provision:</strong> "To my descendants who earn doctoral degrees from any accredited university."</p>
              <p className="text-sm mb-2"><strong>Problem:</strong> Could vest in remote descendants far beyond the perpetuity period.</p>
              <p className="text-sm mb-2"><strong>Salvage Solution:</strong> "To my descendants living at my death who earn doctoral degrees by age 35."</p>
              <div className="bg-green-100 p-2 rounded text-xs">
                <strong>Result:</strong> Educational incentive preserved, perpetuity violation eliminated, grantor's intent respected.
              </div>
            </div>

            <div className="bg-white p-4 rounded border">
              <h6 className="font-bold text-green-600 mb-2">Case Study: The Thompson Family Business Trust</h6>
              <p className="text-sm mb-2"><strong>Original Provision:</strong> "Income to my son, then to his children who actively manage the family business."</p>
              <p className="text-sm mb-2"><strong>Problem:</strong> Children could start managing the business decades after the son's death.</p>
              <p className="text-sm mb-2"><strong>Salvage Solution:</strong> "Income to my son, then to his children who are actively managing the family business at the time of his death."</p>
              <div className="bg-green-100 p-2 rounded text-xs">
                <strong>Result:</strong> Business continuity incentive maintained with clear vesting at the son's death.
              </div>
            </div>
          </div>
        </div>

        <div className="bg-purple-50 p-4 rounded border-l-4 border-purple-500">
          <h5 className="font-bold text-purple-700 mb-3">🗺️ State Adoption of Salvage Doctrines</h5>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-white p-3 rounded border">
              <h6 className="font-bold text-purple-600 mb-2">Comprehensive Salvage States</h6>
              <p className="text-xs mb-2">States with broad salvage doctrines:</p>
              <ul className="text-xs space-y-1">
                <li>• California (extensive cy pres authority)</li>
                <li>• New York (broad judicial reformation)</li>
                <li>• Illinois (comprehensive savings rules)</li>
                <li>• Florida (multiple salvage mechanisms)</li>
                <li>• Texas (modernized salvage statutes)</li>
              </ul>
            </div>
            
            <div className="bg-white p-3 rounded border">
              <h6 className="font-bold text-purple-600 mb-2">Limited Salvage States</h6>
              <p className="text-xs mb-2">States with more restrictive approaches:</p>
              <ul className="text-xs space-y-1">
                <li>• Traditional common law jurisdictions</li>
                <li>• States requiring express savings clauses</li>
                <li>• Jurisdictions with narrow cy pres application</li>
                <li>• States with limited judicial reform powers</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-orange-50 p-4 rounded border-l-4 border-orange-500">
          <h5 className="font-bold text-orange-700 mb-3 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Judicial vs. Statutory Salvage
          </h5>
          
          <div className="space-y-3">
            <div className="bg-white p-3 rounded border">
              <h6 className="font-bold text-orange-600 mb-1">Judicial Reformation</h6>
              <p className="text-xs">Courts use inherent equity powers to reform trusts, but this requires litigation and court approval, which can be expensive and time-consuming.</p>
            </div>
            
            <div className="bg-white p-3 rounded border">
              <h6 className="font-bold text-orange-600 mb-1">Statutory Salvage</h6>
              <p className="text-xs">Automatic reformation rules built into state law that operate without court intervention, providing certainty and reducing administrative costs.</p>
            </div>
          </div>
        </div>

        <div className="bg-yellow-50 p-4 rounded border-l-4 border-yellow-500">
          <h5 className="font-bold text-yellow-700 mb-3">⚡ How Salvage Doctrines Work with Modern Law</h5>
          
          <div className="space-y-2 text-sm">
            <p><strong>USRAP Integration:</strong> Salvage doctrines work alongside the "wait and see" approach to provide multiple layers of protection.</p>
            <p><strong>Dynasty Trust Compatibility:</strong> Even in dynasty trust states, salvage doctrines protect against drafting errors in traditional trust provisions.</p>
            <p><strong>Judicial Efficiency:</strong> Automatic statutory salvage reduces the need for expensive court proceedings to save trusts.</p>
            <p><strong>Grantor Intent Preservation:</strong> Modern salvage doctrines prioritize maintaining the grantor's fundamental objectives while ensuring legal compliance.</p>
          </div>
        </div>
      </div>

      <div className="bg-teal-100 p-4 rounded border mt-6">
        <h5 className="font-bold text-teal-700 mb-2">🎯 Strategic Implications for Trust Planning</h5>
        <p className="text-sm text-teal-800 mb-2">Salvage doctrines provide essential safety nets, but they should not replace careful drafting. The best practice remains including comprehensive savings clauses and choosing favorable jurisdictions.</p>
        <p className="text-xs text-teal-700">These doctrines represent the legal system's recognition that trust creation serves important family and social purposes that should be preserved whenever possible within legal boundaries.</p>
      </div>
    </div>
  );
}