import { useState } from "react";
import { CheckCircle, XCircle, RotateCcw, Award } from "lucide-react";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface TrustQuizProps {
  moduleType: "fundamentals" | "types" | "creation" | "administration" | "taxation" | "drafting";
}

const quizData: Record<string, QuizQuestion[]> = {
  fundamentals: [
    {
      id: 1,
      question: "What are the two component parts of property title in a trust?",
      options: [
        "Personal title and real title",
        "Legal title and equitable title", 
        "Active title and passive title",
        "Express title and implied title"
      ],
      correctAnswer: 1,
      explanation: "In a trust, property title is divided into legal title (held by the trustee) and equitable title (held by the beneficiary)."
    },
    {
      id: 2,
      question: "Who holds the legal title in a trust relationship?",
      options: [
        "The beneficiary",
        "The trustor/grantor",
        "The trustee",
        "The remainderman"
      ],
      correctAnswer: 2,
      explanation: "The trustee holds the legal title and has the obligation to preserve, protect, and defend the trust property."
    },
    {
      id: 3,
      question: "What must a trust contain to be enforceable?",
      options: [
        "Only property and a trustee",
        "Property, trustee, beneficiary, and valid purpose",
        "Just a written document",
        "Only a trustor and beneficiary"
      ],
      correctAnswer: 1,
      explanation: "For a trust to be enforceable, it must have a valid purpose, property capable of producing income, a trustee, and a beneficiary."
    },
    {
      id: 4,
      question: "What is a fiduciary?",
      options: [
        "A type of trust document",
        "Someone who holds the highest standard of care and loyalty",
        "A beneficiary of a trust",
        "A legal document creator"
      ],
      correctAnswer: 1,
      explanation: "A trustee is a fiduciary who must be loyal to the trust and beneficiary, maintaining the highest standard of care."
    }
  ],
  types: [
    {
      id: 1,
      question: "What is an inter vivos trust?",
      options: [
        "A trust created after death",
        "A trust created during the trustor's lifetime",
        "A trust that cannot be revoked",
        "A charitable trust only"
      ],
      correctAnswer: 1,
      explanation: "An inter vivos (living) trust is created during the trustor's lifetime by a Declaration of Trust or Deed of Trust."
    },
    {
      id: 2,
      question: "What type of trust comes into existence at the trustor's death?",
      options: [
        "Inter vivos trust",
        "Living trust",
        "Testamentary trust",
        "Express trust"
      ],
      correctAnswer: 2,
      explanation: "A testamentary trust is established by the last will and testament of the trustor and takes effect upon death."
    },
    {
      id: 3,
      question: "Which type of trust comes about by operation of law rather than deliberate action?",
      options: [
        "Express trust",
        "Implied trust",
        "Private trust",
        "Public trust"
      ],
      correctAnswer: 1,
      explanation: "Implied trusts come about by operation of law, not by the deliberate actions of the trustor."
    },
    {
      id: 4,
      question: "What are the two types of implied trusts?",
      options: [
        "Active and passive trusts",
        "Private and public trusts",
        "Resulting and constructive trusts",
        "Living and testamentary trusts"
      ],
      correctAnswer: 2,
      explanation: "The two types of implied trusts are resulting trusts and constructive trusts, both created by operation of law."
    }
  ],
  creation: [
    {
      id: 1,
      question: "How must trusts be created?",
      options: [
        "Orally only",
        "By written documents",
        "Through court proceedings",
        "By verbal agreement"
      ],
      correctAnswer: 1,
      explanation: "Trusts must be created by written documents to be legally enforceable."
    },
    {
      id: 2,
      question: "What document creates an inter vivos trust?",
      options: [
        "Last will and testament",
        "Power of attorney",
        "Declaration of Trust or Deed of Trust",
        "Trust certificate"
      ],
      correctAnswer: 2,
      explanation: "An inter vivos trust is created by a Declaration of Trust or Deed of Trust during the trustor's lifetime."
    },
    {
      id: 3,
      question: "Can the trustor also serve as the trustee or beneficiary?",
      options: [
        "No, never allowed",
        "Yes, the trustor may be either the trustee or beneficiary",
        "Only as trustee",
        "Only as beneficiary"
      ],
      correctAnswer: 1,
      explanation: "The trustor may also serve as the trustee or the beneficiary in appropriate circumstances."
    },
    {
      id: 4,
      question: "What type of duties must a trustee have for the trust to be enforceable?",
      options: [
        "Passive duties only",
        "Active duties to perform",
        "No specific duties required",
        "Administrative duties only"
      ],
      correctAnswer: 1,
      explanation: "The trustee must have active duties to perform - passive trusts are not enforceable under trust law."
    },
    {
      id: 5,
      question: "What distinguishes a valid trust from an invalid one?",
      options: [
        "The amount of money involved",
        "The active duties imposed on the trustee",
        "The age of the beneficiaries",
        "The location of the property"
      ],
      correctAnswer: 1,
      explanation: "A trust is only valid and enforceable if it imposes active duties on the trustee. Passive trusts are void."
    },
    {
      id: 6,
      question: "Who created the original concept of trusts?",
      options: [
        "Ancient Greeks",
        "Roman civil law",
        "Medieval French law",
        "Modern American courts"
      ],
      correctAnswer: 1,
      explanation: "The original concept of trusts was developed under Roman civil law over 2,000 years ago."
    },
    {
      id: 7,
      question: "What was the feudal form of a trust called?",
      options: [
        "A deed",
        "A will",
        "A use",
        "A charter"
      ],
      correctAnswer: 2,
      explanation: "In feudal England, the early form of trusts was called a 'use' which allowed lords to transfer property across generations."
    },
    {
      id: 8,
      question: "According to the Statute of Uses, what type of duties must a trustee have?",
      options: [
        "Passive duties only",
        "Active duties to perform",
        "No duties required",
        "Ceremonial duties only"
      ],
      correctAnswer: 1,
      explanation: "The Statute of Uses established that trustees must have active duties - no use was valid unless it imposed active duties on the trustee."
    }
  ],
  administration: [
    {
      id: 1,
      question: "What does the Rule Against Perpetuities state?",
      options: [
        "Trusts can exist forever",
        "All interests must vest within 21 years after death of a life in being, plus gestation",
        "Trusts must terminate after 50 years",
        "Only applies to charitable trusts"
      ],
      correctAnswer: 1,
      explanation: "The Rule Against Perpetuities states that all interests must vest, if at all, within 21 years after the death of a life in being, plus the period of gestation."
    },
    {
      id: 2,
      question: "When do legal and equitable titles merge?",
      options: [
        "At trust creation",
        "During trust administration",
        "At trust termination",
        "Never merge"
      ],
      correctAnswer: 2,
      explanation: "At trust termination, the legal and equitable titles merge into one person or group of persons."
    },
    {
      id: 3,
      question: "How can a trust terminate?",
      options: [
        "Only by accomplishing its purpose",
        "By accomplishing its purpose, being incapable of accomplishing its purpose, or at a specified time",
        "Only at the trustor's death",
        "Only by court order"
      ],
      correctAnswer: 1,
      explanation: "A trust may terminate by accomplishing its purpose, being incapable of accomplishing its purpose, or at the end of a period specified by the creator."
    },
    {
      id: 4,
      question: "What is required of trustees regarding trust management?",
      options: [
        "They can do whatever they want",
        "They must make the trust profitable and act in the beneficiary's best interest",
        "They only need to preserve the property",
        "They have no specific obligations"
      ],
      correctAnswer: 1,
      explanation: "Trustees must be loyal to the trust and beneficiary, making sure that the trust is profitable and acting as fiduciaries."
    }
  ],
  taxation: [
    {
      id: 1,
      question: "Who is generally liable for income taxes on trust income not distributed to beneficiaries?",
      options: [
        "The beneficiaries",
        "The trustor",
        "The trust itself",
        "No one pays taxes"
      ],
      correctAnswer: 2,
      explanation: "Generally, a trust is liable for income taxes on all income produced by the trust not otherwise distributed as expenses or income to beneficiaries."
    },
    {
      id: 2,
      question: "Who is obligated to ensure trust income taxes are paid?",
      options: [
        "The beneficiaries",
        "The trustor",
        "The trustee",
        "The government"
      ],
      correctAnswer: 2,
      explanation: "The trustee is obligated to see that all trust income taxes are paid."
    },
    {
      id: 3,
      question: "What is a generation skipping transfer?",
      options: [
        "Any trust with multiple beneficiaries",
        "A trust that benefits persons two or more generations removed from the trustor",
        "A trust that skips over one child",
        "A charitable trust"
      ],
      correctAnswer: 1,
      explanation: "A generation skipping transfer is any trust that provides benefits to persons two or more generations removed from the trustor."
    },
    {
      id: 4,
      question: "Who may be liable for income tax on reversionary trusts?",
      options: [
        "Only the beneficiaries",
        "Only the trustee",
        "The grantor, especially if they receive benefits",
        "No one"
      ],
      correctAnswer: 2,
      explanation: "Income from reversionary trusts may be the tax responsibility of the grantor, especially if the grantor receives benefits from the trust operation."
    }
  ],
  drafting: [
    {
      id: 1,
      question: "How many essential areas must be covered when drafting a trust?",
      options: [
        "5 areas",
        "8 areas", 
        "10 areas",
        "15 areas"
      ],
      correctAnswer: 2,
      explanation: "When drafting a trust, 10 essential areas must be covered: name, trustee appointment, purpose, powers, property, beneficiary, power of appointment, termination, remainderman, and signatures."
    },
    {
      id: 2,
      question: "Which of these is NOT one of the 10 essential drafting areas?",
      options: [
        "Trust property",
        "Trustee powers",
        "Trust location",
        "Remainderman"
      ],
      correctAnswer: 2,
      explanation: "Trust location is not one of the 10 essential drafting areas. The essential areas focus on legal structure and administration."
    },
    {
      id: 3,
      question: "What must be included regarding trust property in drafting?",
      options: [
        "Just mention property exists",
        "Specific identification of the trust property",
        "Property value only",
        "Property location only"
      ],
      correctAnswer: 1,
      explanation: "The trust must specifically identify the trust property being placed into the trust."
    },
    {
      id: 4,
      question: "Why is naming a trustee critical in trust drafting?",
      options: [
        "It's just a formality",
        "Banks require it",
        "Without a trustee, the trust cannot be enforced",
        "It helps with taxes"
      ],
      correctAnswer: 2,
      explanation: "Naming a trustee is critical because without a trustee, a court could not enforce the trust, making it invalid."
    }
  ]
};

export default function TrustQuiz({ moduleType }: TrustQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [shuffledQuestions, setShuffledQuestions] = useState<QuizQuestion[]>([]);

  // Shuffle questions on component mount to ensure variety
  useEffect(() => {
    const availableQuestions = quizData[moduleType] || quizData.fundamentals;
    const shuffled = [...availableQuestions].sort(() => Math.random() - 0.5);
    setShuffledQuestions(shuffled.slice(0, Math.min(5, shuffled.length))); // Take 5 random questions
  }, [moduleType]);

  const questions = shuffledQuestions;

  const handleAnswerSelect = (answerIndex: number) => {
    if (showExplanation) return;
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;

    setShowExplanation(true);
    const newUserAnswers = [...userAnswers, selectedAnswer];
    setUserAnswers(newUserAnswers);

    if (selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setQuizCompleted(false);
    setUserAnswers([]);
  };

  const getScoreColor = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage >= 90) return "Outstanding! You've mastered trust law fundamentals!";
    if (percentage >= 80) return "Excellent work! You have a strong understanding of trusts.";
    if (percentage >= 70) return "Good job! You're on the right track with trust concepts.";
    if (percentage >= 60) return "Not bad! Review the material and try again to improve.";
    return "Keep studying! Trust law takes time to master.";
  };

  if (quizCompleted) {
    return (
      <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
        <div className="text-center">
          <Award className="w-16 h-16 mx-auto mb-4 text-yellow-500" />
          <h2 className="text-2xl font-bold text-purple-600 mb-4">Quiz Complete!</h2>
          
          <div className={`text-4xl font-bold mb-2 ${getScoreColor()}`}>
            {score}/{questions.length}
          </div>
          <div className="text-lg text-gray-600 mb-4">
            {Math.round((score / questions.length) * 100)}% Correct
          </div>
          
          <p className="text-lg mb-6">{getScoreMessage()}</p>
          
          <button
            onClick={resetQuiz}
            className="flex items-center space-x-2 mx-auto px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
            <span>Take Quiz Again</span>
          </button>
        </div>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm text-gray-500">
            Question {currentQuestion + 1} of {questions.length}
          </span>
          <span className="text-sm text-gray-500">
            Score: {score}/{currentQuestion + (showExplanation ? 1 : 0)}
          </span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + (showExplanation ? 1 : 0)) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <h2 className="text-xl font-bold text-gray-800 mb-6">{question.question}</h2>

      <div className="space-y-3 mb-6">
        {question.options.map((option, index) => {
          let buttonClass = "w-full p-4 text-left border rounded-lg transition-colors ";
          
          if (showExplanation) {
            if (index === question.correctAnswer) {
              buttonClass += "bg-green-100 border-green-500 text-green-800";
            } else if (index === selectedAnswer && index !== question.correctAnswer) {
              buttonClass += "bg-red-100 border-red-500 text-red-800";
            } else {
              buttonClass += "bg-gray-100 border-gray-300 text-gray-600";
            }
          } else if (selectedAnswer === index) {
            buttonClass += "bg-purple-100 border-purple-500 text-purple-800";
          } else {
            buttonClass += "bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100";
          }

          return (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              className={buttonClass}
              disabled={showExplanation}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {showExplanation && index === question.correctAnswer && (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                )}
                {showExplanation && index === selectedAnswer && index !== question.correctAnswer && (
                  <XCircle className="w-5 h-5 text-red-600" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {showExplanation && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-bold text-blue-800 mb-2">Explanation:</h3>
          <p className="text-blue-700">{question.explanation}</p>
        </div>
      )}

      <div className="flex justify-center">
        {!showExplanation ? (
          <button
            onClick={handleSubmitAnswer}
            disabled={selectedAnswer === null}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            Submit Answer
          </button>
        ) : (
          <button
            onClick={handleNextQuestion}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            {currentQuestion < questions.length - 1 ? "Next Question" : "View Results"}
          </button>
        )}
      </div>
    </div>
  );
}