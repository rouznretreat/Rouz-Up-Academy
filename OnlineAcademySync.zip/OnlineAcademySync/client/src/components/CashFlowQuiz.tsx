import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, DollarSign, TrendingUp, Award } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Property {
  id: number;
  name: string;
  price: number;
  downPayment: number;
  monthlyRent: number;
  monthlyExpenses: number;
  description: string;
  image: string;
}

const cashFlowQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What motivates you most in your work?",
    options: [
      { text: "Job security and steady paycheck", quadrant: 'E', points: 3 },
      { text: "Being my own boss and controlling my schedule", quadrant: 'S', points: 3 },
      { text: "Building systems that work without me", quadrant: 'B', points: 3 },
      { text: "Making money work for me", quadrant: 'I', points: 3 }
    ]
  },
  {
    id: 2,
    question: "How do you prefer to learn new skills?",
    options: [
      { text: "Company training programs and workshops", quadrant: 'E', points: 2 },
      { text: "Learning on my own through trial and error", quadrant: 'S', points: 2 },
      { text: "Hiring experts and learning from systems", quadrant: 'B', points: 2 },
      { text: "Studying market trends and investment strategies", quadrant: 'I', points: 2 }
    ]
  },
  {
    id: 3,
    question: "What's your biggest fear about money?",
    options: [
      { text: "Losing my job and not having income", quadrant: 'E', points: 3 },
      { text: "Not being able to find enough clients", quadrant: 'S', points: 3 },
      { text: "My business failing without good systems", quadrant: 'B', points: 3 },
      { text: "Market crashes affecting my investments", quadrant: 'I', points: 3 }
    ]
  },
  {
    id: 4,
    question: "How do you handle risk?",
    options: [
      { text: "Prefer stability and avoid unnecessary risks", quadrant: 'E', points: 2 },
      { text: "Take calculated risks based on my expertise", quadrant: 'S', points: 2 },
      { text: "Take strategic risks with proper systems in place", quadrant: 'B', points: 2 },
      { text: "Diversify to manage and minimize risk", quadrant: 'I', points: 2 }
    ]
  },
  {
    id: 5,
    question: "What does financial freedom mean to you?",
    options: [
      { text: "Having a good pension and benefits", quadrant: 'E', points: 3 },
      { text: "Earning enough to work when I want", quadrant: 'S', points: 3 },
      { text: "Having passive income from my business systems", quadrant: 'B', points: 3 },
      { text: "Living off investment returns", quadrant: 'I', points: 3 }
    ]
  }
];

const quadrantDescriptions = {
  E: {
    title: "Employee (E)",
    description: "You value security and stability. You prefer working for others with steady income and benefits.",
    characteristics: ["Job security focused", "Steady paycheck", "Benefits and pension", "Less financial risk"],
    color: "border-red-500"
  },
  S: {
    title: "Self-Employed (S)", 
    description: "You value independence and control. You prefer to be your own boss and control your own destiny.",
    characteristics: ["Independence focused", "Control over schedule", "Personal expertise", "Higher income potential"],
    color: "border-orange-500"
  },
  B: {
    title: "Business Owner (B)",
    description: "You think in systems and leverage. You build businesses that can run without your constant involvement.",
    characteristics: ["Systems thinking", "Leverage others", "Scalable income", "Leadership focused"],
    color: "border-blue-500"
  },
  I: {
    title: "Investor (I)",
    description: "You focus on making money work for you. You understand markets and build wealth through investments.",
    characteristics: ["Money works for you", "Market understanding", "Passive income", "Wealth building"],
    color: "border-green-500"
  }
};

export default function CashFlowQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [quizComplete, setQuizComplete] = useState(false);
  const [result, setResult] = useState<{ quadrant: keyof typeof quadrantDescriptions; scores: any } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = { ...answers, [currentQuestion]: optionIndex };
    setAnswers(newAnswers);

    if (currentQuestion < cashFlowQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResult(newAnswers);
    }
  };

  const calculateResult = async (finalAnswers: { [key: number]: number }) => {
    const scores = { E: 0, S: 0, B: 0, I: 0 };
    
    // Calculate scores for each quadrant
    cashFlowQuestions.forEach((question, qIndex) => {
      const answerIndex = finalAnswers[qIndex];
      if (answerIndex !== undefined) {
        const selectedOption = question.options[answerIndex];
        scores[selectedOption.quadrant] += selectedOption.points;
      }
    });

    // Find the dominant quadrant
    const dominantQuadrant = Object.keys(scores).reduce((a, b) => 
      scores[a as keyof typeof scores] > scores[b as keyof typeof scores] ? a : b
    ) as keyof typeof quadrantDescriptions;

    const quizResult = { quadrant: dominantQuadrant, scores };
    setResult(quizResult);
    setQuizComplete(true);

    // Submit result to backend if user is authenticated
    if (isAuthenticated) {
      setIsSubmitting(true);
      try {
        await apiRequest('POST', '/api/cash-flow-quiz', {
          answers: finalAnswers,
          scores,
          quadrant: dominantQuadrant
        });
        toast({
          title: "Quiz Completed!",
          description: `Your result has been saved. You're a ${dominantQuadrant}-quadrant person!`,
        });
      } catch (error) {
        toast({
          title: "Quiz completed",
          description: "Your result couldn't be saved, but you can still see your quadrant!",
          variant: "destructive",
        });
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setQuizComplete(false);
    setResult(null);
  };

  if (quizComplete && result) {
    const quadrantInfo = quadrantDescriptions[result.quadrant];
    
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card className={`${quadrantInfo.color} border-2`}>
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <Trophy className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
              <h2 className="text-3xl font-bold mb-2">Your Cash Flow Quadrant</h2>
              <h3 className="text-2xl font-semibold text-gray-700 mb-4">{quadrantInfo.title}</h3>
            </div>
            
            <p className="text-lg mb-6 text-gray-600">{quadrantInfo.description}</p>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h4 className="font-semibold mb-2">Your Characteristics:</h4>
              <ul className="text-sm space-y-1">
                {quadrantInfo.characteristics.map((char, index) => (
                  <li key={index} className="flex items-center justify-center">
                    <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                    {char}
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
              {Object.entries(result.scores).map(([quad, score]) => (
                <div key={quad} className="bg-white p-3 rounded border">
                  <div className="font-semibold">{quad} Quadrant</div>
                  <div className="text-lg">{score} points</div>
                </div>
              ))}
            </div>
            
            <div className="space-y-3">
              <Button onClick={restartQuiz} variant="outline" className="w-full">
                Take Quiz Again
              </Button>
              {isAuthenticated && (
                <p className="text-xs text-gray-500">
                  {isSubmitting ? "Saving result..." : "✓ Result saved to your profile"}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / cashFlowQuestions.length) * 100;
  const question = cashFlowQuestions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {cashFlowQuestions.length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-green-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <Card>
        <CardContent className="p-8">
          <h2 className="text-2xl font-bold mb-6 text-center">{question.question}</h2>
          
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className="w-full h-auto p-4 text-left hover:bg-blue-50 hover:border-blue-300"
                onClick={() => handleAnswer(index)}
              >
                <div className="flex items-start w-full">
                  <div className="w-6 h-6 rounded-full border-2 border-gray-300 mr-3 mt-1 flex-shrink-0"></div>
                  <span className="text-gray-700">{option.text}</span>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="mt-6 text-center text-sm text-gray-500">
            Click an option to continue
          </div>
        </CardContent>
      </Card>
    </div>
  );
}