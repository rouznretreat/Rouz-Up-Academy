import { Check, Star, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function MembershipTiers() {
  const tiers = [
    {
      name: "Starter Package",
      price: "159",
      period: " one-time",
      description: "Perfect for teens and adults starting their financial journey",
      features: [
        "Credit for Starters ($59 value)",
        "Business for Starters ($59 value)",
        "Banking for Starters ($59 value)",
        "Lifetime access to all content",
        "Mobile & desktop access",
        "Certificate of completion"
      ],
      notIncluded: [],
      buttonText: "Get Starter Package",
      buttonVariant: "default" as const,
      buttonAction: () => window.location.href = '/checkout?package=starter',
      popular: true,
      icon: <Star className="w-5 h-5" />
    },
    {
      name: "Monthly Access",
      price: "22",
      period: "/month",
      description: "Flexible monthly access to all starter courses",
      features: [
        "Access to all 3 starter courses",
        "Credit for Starters",
        "Business for Starters", 
        "Banking for Starters",
        "Cancel anytime",
        "Mobile & desktop access"
      ],
      notIncluded: [],
      buttonText: "Start Monthly",
      buttonVariant: "default" as const,
      buttonAction: () => window.location.href = '/subscribe?tier=monthly',
      popular: false,
      icon: <Check className="w-5 h-5" />
    }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
      {tiers.map((tier, index) => (
        <Card 
          key={tier.name}
          className={`relative ${
            tier.popular 
              ? 'border-2 border-blue-500 shadow-xl scale-105' 
              : 'border-2 border-gray-200 shadow-lg'
          }`}
        >
          {tier.popular && (
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-blue-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                Most Popular
              </Badge>
            </div>
          )}
          
          <CardHeader className="text-center pb-6">
            <CardTitle className="flex items-center justify-center space-x-2 text-2xl font-bold text-gray-900 mb-2">
              {tier.icon && <span className={tier.name === 'VIP' ? 'text-yellow-500' : 'text-blue-600'}>{tier.icon}</span>}
              <span>{tier.name}</span>
            </CardTitle>
            <div className="mb-1">
              <span className={`text-4xl font-bold ${
                tier.name === 'Premium' ? 'text-blue-600' : 
                tier.name === 'VIP' ? 'text-yellow-500' : 
                'text-gray-900'
              }`}>
                {tier.price === 'Free' ? 'Free' : `$${tier.price}`}
              </span>
              {tier.period && <span className="text-lg text-gray-600">{tier.period}</span>}
            </div>
            <p className="text-gray-600">{tier.description}</p>
          </CardHeader>
          
          <CardContent className="pb-8">
            <ul className="space-y-4 mb-8">
              {tier.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
              {tier.notIncluded.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center text-gray-400">
                  <div className="w-5 h-5 mr-3 flex-shrink-0 flex items-center justify-center">
                    <div className="w-3 h-3 border border-gray-300 rounded"></div>
                  </div>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            
            <Button 
              onClick={tier.buttonAction}
              variant={tier.buttonVariant}
              className={`w-full py-3 font-semibold transition-colors ${
                tier.name === 'Premium' 
                  ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                  : tier.name === 'VIP'
                  ? 'bg-yellow-500 hover:bg-yellow-600 text-white'
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
              }`}
            >
              {tier.buttonText}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
