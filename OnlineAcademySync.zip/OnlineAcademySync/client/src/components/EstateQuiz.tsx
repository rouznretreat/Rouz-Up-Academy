import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface EstateQuizProps {
  moduleType: "module-1" | "module-2" | "module-3" | "module-4" | "module-5" | "module-6";
}

const quizData = {
  "module-1": {
    title: "Module 1: What is Estate Planning?",
    questions: [
      {
        id: 1,
        question: "What is the primary purpose of estate planning?",
        options: [
          "Planning for death and funeral arrangements",
          "A wealth-building discipline that enhances your life and creates generational wealth",
          "Avoiding taxes at all costs",
          "Only for wealthy people with large estates"
        ],
        correctAnswer: 1,
        explanation: "Estate planning is a wealth-building discipline that enhances your life and creates opportunities for generational wealth, not just planning for death."
      },
      {
        id: 2,
        question: "How does estate planning help build generational wealth?",
        options: [
          "By hiding money from taxes",
          "Through smart structures, tax efficiency, education, and values transfer",
          "By investing only in real estate",
          "It doesn't - that's a myth"
        ],
        correctAnswer: 1,
        explanation: "Generational wealth is built through smart structures, tax efficiency, education of heirs, and passing along values and work ethic."
      },
      {
        id: 3,
        question: "Which example best demonstrates estate planning as wealth building?",
        options: [
          "Writing a will after retirement",
          "Using trust strategies to transfer business ownership gradually while minimizing taxes",
          "Buying life insurance for funeral expenses",
          "Avoiding all estate planning until necessary"
        ],
        correctAnswer: 1,
        explanation: "Using advanced trust strategies to transfer business ownership while minimizing taxes demonstrates estate planning as an active wealth-building tool."
      },
      {
        id: 4,
        question: "What makes estate planning different from just 'death planning'?",
        options: [
          "Estate planning only deals with death",
          "Estate planning focuses on building and transferring wealth during your lifetime",
          "There is no difference between the two",
          "Estate planning is more expensive"
        ],
        correctAnswer: 1,
        explanation: "Estate planning is about building and transferring wealth during your lifetime, using strategies that create value while you're alive, not just distributing assets after death."
      },
      {
        id: 5,
        question: "Who should consider estate planning?",
        options: [
          "Only people over 65",
          "Only millionaires and wealthy families",
          "Anyone who wants to build wealth and protect their family",
          "Only business owners"
        ],
        correctAnswer: 2,
        explanation: "Estate planning is valuable for anyone who wants to build wealth, protect their family, and ensure their wishes are carried out, regardless of age or current wealth level."
      },
      {
        id: 6,
        question: "What is one key benefit of viewing estate planning as wealth building?",
        options: [
          "It eliminates all taxes",
          "It guarantees investment returns",
          "It helps you make strategic decisions that grow wealth while protecting your family",
          "It prevents all family disputes"
        ],
        correctAnswer: 2,
        explanation: "Viewing estate planning as wealth building helps you make strategic decisions that both grow your wealth during life and protect your family's financial future."
      }
    ]
  },
  "module-2": {
    title: "Module 2: Estate Planning vs Estate Administration",
    questions: [
      {
        id: 1,
        question: "When does estate planning happen?",
        options: [
          "Only after someone dies",
          "During your lifetime while you're alive and well",
          "Only when you're sick or elderly",
          "Only during probate proceedings"
        ],
        correctAnswer: 1,
        explanation: "Estate planning happens during your lifetime when you can make informed decisions and use strategies only available while living."
      },
      {
        id: 2,
        question: "What is the main purpose of estate administration?",
        options: [
          "To build wealth for the family",
          "To distribute assets, pay debts, and close the deceased's affairs",
          "To create new estate planning documents",
          "To avoid paying any taxes"
        ],
        correctAnswer: 1,
        explanation: "Estate administration's main purpose is to distribute assets to heirs, pay final debts and taxes, and close the deceased person's affairs."
      },
      {
        id: 3,
        question: "How does good estate planning affect administration?",
        options: [
          "It makes no difference",
          "It makes administration more complex",
          "It makes administration easier, faster, and preserves more wealth",
          "It eliminates the need for any administration"
        ],
        correctAnswer: 2,
        explanation: "Good estate planning makes administration easier, faster, less expensive, and preserves more wealth for families."
      },
      {
        id: 4,
        question: "What advantage does planning during your lifetime provide?",
        options: [
          "No advantages - timing doesn't matter",
          "You can use tax strategies and wealth-building techniques only available while living",
          "It's cheaper to plan after death",
          "Planning during life is only for tax avoidance"
        ],
        correctAnswer: 1,
        explanation: "Planning during your lifetime allows you to use tax strategies, wealth-building techniques, and make strategic decisions that are only available while you're alive and can actively participate."
      },
      {
        id: 5,
        question: "What happens during estate administration if there was poor planning?",
        options: [
          "Everything goes smoothly anyway",
          "The process becomes longer, more expensive, and more stressful for families",
          "The government takes over all decisions",
          "There are no consequences"
        ],
        correctAnswer: 1,
        explanation: "Poor planning leads to longer administration (12-24 months vs. 3-6 months), higher costs, family stress, and potentially less wealth preserved for heirs."
      },
      {
        id: 6,
        question: "Who is typically responsible for estate administration?",
        options: [
          "The deceased person",
          "Automatically handled by the government",
          "The executor named in the will or court-appointed administrator",
          "The oldest family member"
        ],
        correctAnswer: 2,
        explanation: "Estate administration is typically handled by an executor named in the will, or if there's no will, a court-appointed administrator who follows legal procedures."
      }
    ]
  },
  "module-3": {
    title: "Module 3: Essential Estate Planning Tools",
    questions: [
      {
        id: 1,
        question: "Which document can override your will's instructions?",
        options: [
          "Power of attorney",
          "Beneficiary designations on retirement accounts and life insurance",
          "Healthcare directive",
          "HIPAA authorization"
        ],
        correctAnswer: 1,
        explanation: "Beneficiary designations on retirement accounts and life insurance policies often supersede your will's instructions."
      },
      {
        id: 2,
        question: "How many essential estate planning tools are there?",
        options: [
          "Three",
          "Five",
          "Seven",
          "Ten"
        ],
        correctAnswer: 2,
        explanation: "There are seven essential estate planning tools: Will, Trusts, Financial Power of Attorney, Healthcare Power of Attorney, Living Will, Beneficiary Designations, and HIPAA Authorization."
      },
      {
        id: 3,
        question: "Why do you need both financial and healthcare powers of attorney?",
        options: [
          "They're the same document",
          "One covers money/property decisions, the other covers medical decisions",
          "You only need one or the other",
          "They're only needed after age 65"
        ],
        correctAnswer: 1,
        explanation: "Financial power of attorney handles money and property decisions, while healthcare power of attorney handles medical decisions - different aspects of your life."
      },
      {
        id: 4,
        question: "What is the main purpose of a living will?",
        options: [
          "To distribute your assets",
          "To name guardians for children",
          "To specify your wishes for end-of-life medical care",
          "To avoid probate"
        ],
        correctAnswer: 2,
        explanation: "A living will specifies your wishes for end-of-life medical care, such as life support decisions, when you cannot communicate these preferences yourself."
      },
      {
        id: 5,
        question: "What does HIPAA authorization allow in estate planning?",
        options: [
          "Access to medical records for estate planning purposes",
          "Tax planning benefits",
          "Asset protection",
          "Probate avoidance"
        ],
        correctAnswer: 0,
        explanation: "HIPAA authorization allows designated people to access your medical records for estate planning and healthcare decision-making purposes when you cannot do so yourself."
      },
      {
        id: 6,
        question: "Why are trusts considered powerful estate planning tools?",
        options: [
          "They eliminate all taxes",
          "They provide control, tax benefits, and can avoid probate",
          "They're only for wealthy families",
          "They replace the need for all other documents"
        ],
        correctAnswer: 1,
        explanation: "Trusts are powerful because they provide ongoing control over assets, potential tax benefits, probate avoidance, and protection for beneficiaries across multiple generations."
      }
    ]
  },
  "module-4": {
    title: "Module 4: Understanding Wills",
    questions: [
      {
        id: 1,
        question: "Why do wills have extensive formality requirements?",
        options: [
          "To make them difficult to create",
          "Because the testator cannot speak for themselves after death",
          "To generate fees for lawyers",
          "They don't - formalities are optional"
        ],
        correctAnswer: 1,
        explanation: "Extensive formalities exist because the testator cannot speak for themselves after death, so the law ensures the document truly represents their wishes."
      },
      {
        id: 2,
        question: "What are the four essential elements of a valid will?",
        options: [
          "Notarization, witnesses, signatures, and copies",
          "Testamentary capacity, testamentary intent, proper execution, and written form",
          "Age requirements, mental competency, asset listing, and beneficiary naming",
          "Legal representation, court filing, publication, and validation"
        ],
        correctAnswer: 1,
        explanation: "The four essential elements are testamentary capacity, testamentary intent, proper execution (signing and witnessing), and written form."
      },
      {
        id: 3,
        question: "What happens if a will doesn't meet all requirements?",
        options: [
          "It's still valid if the intent is clear",
          "The court may declare it invalid and apply intestacy laws",
          "The family can fix the problems after death",
          "Minor defects don't matter"
        ],
        correctAnswer: 1,
        explanation: "If a will doesn't meet all requirements, the court may declare it invalid and assets will be distributed according to state intestacy laws instead."
      },
      {
        id: 4,
        question: "What does 'testamentary capacity' mean?",
        options: [
          "The ability to write your own will",
          "Being mentally competent to understand what you're doing when making a will",
          "Having enough assets to justify a will",
          "Being over age 18"
        ],
        correctAnswer: 1,
        explanation: "Testamentary capacity means being mentally competent and understanding the nature of making a will, what assets you have, and who your beneficiaries are."
      },
      {
        id: 5,
        question: "What is 'testamentary intent'?",
        options: [
          "The intention to avoid taxes",
          "The clear intention that this document should serve as your will",
          "The intent to disinherit someone",
          "The intention to avoid probate"
        ],
        correctAnswer: 1,
        explanation: "Testamentary intent means you clearly intend for this specific document to serve as your will and govern the distribution of your property after death."
      },
      {
        id: 6,
        question: "Why is proper execution (signing and witnessing) so important?",
        options: [
          "It's not important - any signature works",
          "It provides legal proof that you signed the will voluntarily and without coercion",
          "It makes the document look more professional",
          "It's only required for wealthy people"
        ],
        correctAnswer: 1,
        explanation: "Proper execution with witnesses provides legal proof that you signed the will voluntarily, were mentally competent, and weren't under pressure or coercion from others."
      }
    ]
  },
  "module-5": {
    title: "Module 5: When Someone Dies",
    questions: [
      {
        id: 1,
        question: "What should families do in the first 24-48 hours after someone dies?",
        options: [
          "Immediately distribute all assets",
          "Contact authorities if needed, notify funeral home, secure property, locate documents",
          "Wait for the lawyer to handle everything",
          "File the will with probate court immediately"
        ],
        correctAnswer: 1,
        explanation: "In the first 24-48 hours, families should contact authorities if needed, notify the funeral home, secure property, and locate important documents."
      },
      {
        id: 2,
        question: "How long does estate administration typically take with good planning vs. no planning?",
        options: [
          "Same time regardless - about 6 months",
          "Good planning: 3-6 months; No planning: 12-24 months",
          "Good planning takes longer due to complexity",
          "No planning is actually faster"
        ],
        correctAnswer: 1,
        explanation: "Good planning typically results in 3-6 month administration, while no planning can take 12-24 months with higher costs and more stress."
      },
      {
        id: 3,
        question: "When should families seek professional help during estate administration?",
        options: [
          "Never - families should handle everything themselves",
          "Only if the estate is worth millions",
          "For probate proceedings, complex estates, family disputes, tax issues, or when overwhelmed",
          "Only after trying to handle it alone for a year"
        ],
        correctAnswer: 2,
        explanation: "Families should seek professional help for probate proceedings, complex estates, family disputes, tax issues, and when they feel overwhelmed by the process."
      },
      {
        id: 4,
        question: "What is one of the most important things to remember while handling estate administration?",
        options: [
          "Rush through everything quickly",
          "Handle everything alone without help",
          "Take care of yourself and communicate with family during this difficult time",
          "Avoid all professional assistance"
        ],
        correctAnswer: 2,
        explanation: "It's crucial to take care of yourself during the grief process, communicate openly with family members, and remember that administration takes time - don't rush important decisions."
      },
      {
        id: 5,
        question: "What makes estate administration easier for families?",
        options: [
          "Having no estate planning documents",
          "Good advance planning with organized documents and clear instructions",
          "Waiting until after the funeral to start anything",
          "Keeping all information secret from family"
        ],
        correctAnswer: 1,
        explanation: "Good advance planning with organized documents, clear instructions, and family communication makes estate administration much easier, faster, and less stressful."
      },
      {
        id: 6,
        question: "What should families focus on beyond just the administrative tasks?",
        options: [
          "Only completing paperwork as quickly as possible",
          "Avoiding any discussion of the deceased",
          "Honoring the person's memory while handling necessary tasks",
          "Rushing to sell all assets immediately"
        ],
        correctAnswer: 2,
        explanation: "While administrative tasks are important, families should also take time to grieve, honor the person's memory, and support each other through the process."
      }
    ]
  },
  "module-6": {
    title: "Module 6: Getting Started",
    questions: [
      {
        id: 1,
        question: "What's the first step in creating your estate plan?",
        options: [
          "Hire an attorney immediately",
          "Take inventory of what you own (assets and debts)",
          "Write your will",
          "Choose your beneficiaries"
        ],
        correctAnswer: 1,
        explanation: "The first step is taking inventory of what you own, including all assets and debts, to understand what needs to be planned for."
      },
      {
        id: 2,
        question: "When might you need professional help vs. doing estate planning yourself?",
        options: [
          "Everyone should always hire an attorney",
          "DIY for simple situations; professional help for complex estates, business ownership, or blended families",
          "Always do it yourself to save money",
          "Professional help is never necessary"
        ],
        correctAnswer: 1,
        explanation: "DIY might work for simple family structures with modest estates, while professional help is advisable for complex estates, business ownership, or blended families."
      },
      {
        id: 3,
        question: "What's the most important thing to remember about estate planning?",
        options: [
          "It must be perfect the first time",
          "You only need to do it once",
          "Starting is more important than perfection - you can always update and improve",
          "It's only for wealthy people"
        ],
        correctAnswer: 2,
        explanation: "Starting is more important than perfection. Estate planning is an ongoing process that you can always update and improve as your life changes."
      },
      {
        id: 4,
        question: "How often should you review and update your estate plan?",
        options: [
          "Never - once is enough",
          "Every 10 years",
          "Annually or when major life changes occur",
          "Only when you retire"
        ],
        correctAnswer: 2,
        explanation: "You should review your estate plan annually and update it whenever major life changes occur, such as marriage, divorce, births, deaths, or significant changes in assets."
      },
      {
        id: 5,
        question: "Where should you store your original estate planning documents?",
        options: [
          "In a random desk drawer",
          "Only with your attorney",
          "In a fireproof safe, bank deposit box, or with attorney - and inform key people of the location",
          "Don't worry about storage"
        ],
        correctAnswer: 2,
        explanation: "Store originals in a secure location like a fireproof safe, bank safe deposit box, or attorney's office, and make sure key people know where to find them."
      },
      {
        id: 6,
        question: "What mindset should you have when starting estate planning?",
        options: [
          "It's too complicated for most people",
          "Wait until you're older or wealthier",
          "Take action now - starting builds momentum and protects your family",
          "Only think about it during emergencies"
        ],
        correctAnswer: 2,
        explanation: "The best mindset is to take action now. Starting your estate plan, even if simple, builds momentum and immediately begins protecting your family. You can always improve it over time."
      }
    ]
  }
};

export default function EstateQuiz({ moduleType }: EstateQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);

  const currentModule = quizData[moduleType];
  const totalQuestions = currentModule.questions.length;

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setQuizCompleted(true);
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    currentModule.questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correct++;
      }
    });
    return { correct, total: totalQuestions };
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setQuizCompleted(false);
  };

  if (showResults) {
    const score = calculateScore();
    const percentage = Math.round((score.correct / score.total) * 100);

    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card className="bg-gradient-to-r from-green-500 to-teal-600 text-white">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h3 className="text-3xl font-bold mb-4">🎉 Quiz Complete!</h3>
              <div className="text-4xl font-bold mb-4">
                {score.correct}/{score.total}
              </div>
              <p className="text-xl mb-6">You scored {percentage}%</p>
              
              {percentage >= 80 && (
                <div className="bg-green-400 bg-opacity-30 p-4 rounded mb-6">
                  <p className="text-lg font-bold">🌟 Excellent Work!</p>
                  <p>You have mastered this module's concepts!</p>
                </div>
              )}
              
              {percentage >= 60 && percentage < 80 && (
                <div className="bg-yellow-400 bg-opacity-30 p-4 rounded mb-6">
                  <p className="text-lg font-bold">👍 Good Job!</p>
                  <p>You have a solid understanding. Review any missed questions to strengthen your knowledge.</p>
                </div>
              )}
              
              {percentage < 60 && (
                <div className="bg-orange-400 bg-opacity-30 p-4 rounded mb-6">
                  <p className="text-lg font-bold">📚 Keep Learning!</p>
                  <p>Consider reviewing the module content and retaking the quiz.</p>
                </div>
              )}
            </div>

            {/* Review Results */}
            <div className="space-y-4 mb-6">
              <h4 className="text-xl font-bold">Review Your Answers:</h4>
              {currentModule.questions.map((question, index) => {
                const isCorrect = selectedAnswers[index] === question.correctAnswer;
                return (
                  <div key={index} className={`p-4 rounded ${isCorrect ? 'bg-green-400 bg-opacity-20' : 'bg-red-400 bg-opacity-20'}`}>
                    <p className="font-bold mb-2">
                      {isCorrect ? '✓' : '✗'} Question {index + 1}: {question.question}
                    </p>
                    <p className="mb-2">
                      Your answer: {question.options[selectedAnswers[index]] || 'No answer'}
                    </p>
                    {!isCorrect && (
                      <p className="mb-2">
                        Correct answer: {question.options[question.correctAnswer]}
                      </p>
                    )}
                    <p className="text-sm italic">{question.explanation}</p>
                  </div>
                );
              })}
            </div>
            
            <div className="flex justify-center space-x-4">
              <Button 
                onClick={resetQuiz}
                className="bg-white text-green-600 hover:bg-gray-100"
              >
                Retake Quiz
              </Button>
              <Button 
                onClick={() => window.history.back()}
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-green-600"
              >
                Back to Module
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQ = currentModule.questions[currentQuestion];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-center text-blue-600">
            {currentModule.title}
          </CardTitle>
          <div className="text-center text-gray-600">
            Question {currentQuestion + 1} of {totalQuestions}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / totalQuestions) * 100}%` }}
            ></div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-blue-50 p-6 rounded">
            <h3 className="text-lg font-bold text-blue-800 mb-4">
              {currentQ.question}
            </h3>
            
            <div className="space-y-3">
              {currentQ.options.map((option, index) => (
                <label 
                  key={index}
                  className="flex items-start space-x-3 cursor-pointer p-3 rounded border hover:bg-blue-25 transition-colors"
                >
                  <input
                    type="radio"
                    name={`question-${currentQuestion}`}
                    value={index}
                    checked={selectedAnswers[currentQuestion] === index}
                    onChange={() => handleAnswerSelect(index)}
                    className="mt-1"
                  />
                  <span className="flex-1">
                    {String.fromCharCode(65 + index)}) {option}
                  </span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button 
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
              variant="outline"
            >
              ← Previous
            </Button>
            
            <Button 
              onClick={handleNext}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {currentQuestion === totalQuestions - 1 ? 'Finish Quiz' : 'Next →'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}