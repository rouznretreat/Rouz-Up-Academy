import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Target, Plus, Edit, Trash2, Calendar, DollarSign, Trophy, Star } from "lucide-react";

interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  category: string;
  emoji: string;
  priority: 'high' | 'medium' | 'low';
}

const goalPresets = [
  { name: "Gaming Setup", amount: 1000, emoji: "🎮", category: "Entertainment" },
  { name: "First Car", amount: 5000, emoji: "🚗", category: "Transportation" },
  { name: "College Fund", amount: 10000, emoji: "🎓", category: "Education" },
  { name: "Dream Vacation", amount: 2500, emoji: "✈️", category: "Travel" },
  { name: "Emergency Fund", amount: 3000, emoji: "🛡️", category: "Security" },
  { name: "Laptop", amount: 800, emoji: "💻", category: "Technology" },
  { name: "Concert Tickets", amount: 150, emoji: "🎵", category: "Entertainment" },
  { name: "Designer Sneakers", amount: 200, emoji: "👟", category: "Fashion" }
];

export default function VisualGoalTracker() {
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    targetAmount: '',
    currentAmount: '0',
    deadline: '',
    category: '',
    emoji: '🎯',
    priority: 'medium' as 'high' | 'medium' | 'low'
  });

  const createGoal = () => {
    if (!formData.name || !formData.targetAmount || !formData.deadline) return;

    const newGoal: SavingsGoal = {
      id: Date.now().toString(),
      name: formData.name,
      targetAmount: parseFloat(formData.targetAmount),
      currentAmount: parseFloat(formData.currentAmount) || 0,
      deadline: formData.deadline,
      category: formData.category || 'Other',
      emoji: formData.emoji,
      priority: formData.priority
    };

    setGoals(prev => [...prev, newGoal]);
    resetForm();
  };

  const updateGoalProgress = (goalId: string, newAmount: number) => {
    setGoals(prev => prev.map(goal => 
      goal.id === goalId 
        ? { ...goal, currentAmount: Math.min(newAmount, goal.targetAmount) }
        : goal
    ));
  };

  const deleteGoal = (goalId: string) => {
    setGoals(prev => prev.filter(goal => goal.id !== goalId));
  };

  const usePreset = (preset: typeof goalPresets[0]) => {
    setFormData({
      name: preset.name,
      targetAmount: preset.amount.toString(),
      currentAmount: '0',
      deadline: '',
      category: preset.category,
      emoji: preset.emoji,
      priority: 'medium'
    });
    setShowCreateForm(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      targetAmount: '',
      currentAmount: '0',
      deadline: '',
      category: '',
      emoji: '🎯',
      priority: 'medium'
    });
    setShowCreateForm(false);
    setEditingGoal(null);
  };

  const getProgressPercentage = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const getDaysUntilDeadline = (deadline: string) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const totalSaved = goals.reduce((sum, goal) => sum + goal.currentAmount, 0);
  const totalTarget = goals.reduce((sum, goal) => sum + goal.targetAmount, 0);
  const completedGoals = goals.filter(goal => goal.currentAmount >= goal.targetAmount).length;

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">🎯 Visual Goal Tracker</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Create savings goals and watch your progress with fun visualizations! Set targets, track progress, and celebrate achievements.
        </p>
      </div>

      {/* Summary Stats */}
      {goals.length > 0 && (
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-blue-600">{goals.length}</div>
              <div className="text-blue-700 font-medium">Active Goals</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-green-600">${totalSaved.toFixed(0)}</div>
              <div className="text-green-700 font-medium">Total Saved</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-purple-600">${totalTarget.toFixed(0)}</div>
              <div className="text-purple-700 font-medium">Total Target</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-200">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-yellow-600">{completedGoals}</div>
              <div className="text-yellow-700 font-medium">Completed</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Goal Presets */}
      {!showCreateForm && goals.length === 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="w-5 h-5 mr-2" />
              Standard Goals
            </CardTitle>
            <p className="text-gray-600">Choose from popular savings goals to get started quickly!</p>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              {goalPresets.map((preset, index) => (
                <div
                  key={index}
                  onClick={() => usePreset(preset)}
                  className="bg-gradient-to-br from-gray-50 to-gray-100 p-4 rounded-lg cursor-pointer hover:shadow-md transition-all border border-gray-200 hover:border-blue-300"
                >
                  <div className="text-3xl mb-2">{preset.emoji}</div>
                  <h3 className="font-bold text-gray-900 mb-1">{preset.name}</h3>
                  <p className="text-green-600 font-bold">${preset.amount.toLocaleString()}</p>
                  <p className="text-sm text-gray-500">{preset.category}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create Goal Form */}
      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="w-5 h-5 mr-2" />
              Create New Goal
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Goal Name</label>
                  <Input
                    placeholder="e.g., Gaming Setup"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Target Amount</label>
                  <Input
                    type="number"
                    placeholder="1000"
                    value={formData.targetAmount}
                    onChange={(e) => setFormData(prev => ({ ...prev, targetAmount: e.target.value }))}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Current Amount</label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={formData.currentAmount}
                    onChange={(e) => setFormData(prev => ({ ...prev, currentAmount: e.target.value }))}
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Deadline</label>
                  <Input
                    type="date"
                    value={formData.deadline}
                    onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Category</label>
                  <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Technology">Technology</SelectItem>
                      <SelectItem value="Transportation">Transportation</SelectItem>
                      <SelectItem value="Education">Education</SelectItem>
                      <SelectItem value="Entertainment">Entertainment</SelectItem>
                      <SelectItem value="Fashion">Fashion</SelectItem>
                      <SelectItem value="Travel">Travel</SelectItem>
                      <SelectItem value="Security">Security</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Priority</label>
                  <Select value={formData.priority} onValueChange={(value: 'high' | 'medium' | 'low') => setFormData(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="low">Low Priority</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4 mt-6">
              <Button onClick={createGoal} className="bg-blue-600 hover:bg-blue-700">
                Create Goal
              </Button>
              <Button variant="outline" onClick={resetForm}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Goals List */}
      {goals.length > 0 && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-gray-900">Your Savings Goals</h2>
            <Button onClick={() => setShowCreateForm(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Goal
            </Button>
          </div>
          
          <div className="grid gap-6">
            {goals.map((goal) => {
              const progress = getProgressPercentage(goal.currentAmount, goal.targetAmount);
              const daysLeft = getDaysUntilDeadline(goal.deadline);
              const isCompleted = goal.currentAmount >= goal.targetAmount;
              
              return (
                <Card key={goal.id} className={`relative overflow-hidden ${isCompleted ? 'bg-green-50 border-green-200' : ''}`}>
                  {isCompleted && (
                    <div className="absolute top-4 right-4">
                      <Trophy className="w-6 h-6 text-yellow-500" />
                    </div>
                  )}
                  
                  <CardContent className="p-6">
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="md:col-span-2">
                        <div className="flex items-center mb-4">
                          <span className="text-3xl mr-3">{goal.emoji}</span>
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">{goal.name}</h3>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge className={getPriorityColor(goal.priority)}>
                                {goal.priority} priority
                              </Badge>
                              <Badge variant="secondary">{goal.category}</Badge>
                            </div>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-lg font-medium">
                              ${goal.currentAmount.toFixed(0)} of ${goal.targetAmount.toFixed(0)}
                            </span>
                            <span className="text-lg font-bold text-blue-600">
                              {progress.toFixed(1)}%
                            </span>
                          </div>
                          
                          <Progress value={progress} className="h-3" />
                          
                          <div className="flex justify-between text-sm text-gray-600">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              {daysLeft > 0 ? `${daysLeft} days left` : daysLeft === 0 ? 'Due today' : `${Math.abs(daysLeft)} days overdue`}
                            </span>
                            <span className="flex items-center">
                              <DollarSign className="w-4 h-4 mr-1" />
                              ${(goal.targetAmount - goal.currentAmount).toFixed(0)} remaining
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium mb-2">Update Progress</label>
                          <div className="flex gap-2">
                            <Input
                              type="number"
                              placeholder="Add amount"
                              onChange={(e) => {
                                const newAmount = parseFloat(e.target.value) || 0;
                                if (newAmount >= 0) {
                                  updateGoalProgress(goal.id, goal.currentAmount + newAmount);
                                  e.target.value = '';
                                }
                              }}
                            />
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteGoal(goal.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty State */}
      {goals.length === 0 && !showCreateForm && (
        <Card className="text-center py-12">
          <CardContent>
            <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-700 mb-2">No Savings Goals Yet</h3>
            <p className="text-gray-500 mb-6">
              Create your first saving goal and watch your progress with fun visualizations!
            </p>
            <Button onClick={() => setShowCreateForm(true)} className="bg-blue-600 hover:bg-blue-700">
              Create Your First Goal
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}