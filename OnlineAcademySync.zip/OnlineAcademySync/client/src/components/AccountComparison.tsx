import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

type RiskLevel = "None" | "Very Low" | "Low" | "Low-Medium" | "Medium" | "Medium-High" | "High";

interface AccountInfo {
  id: string;
  name: string;
  interestFormatted: string;
  bestFor: string;
  riskLevel: RiskLevel;
}

const accountInfo: AccountInfo[] = [
  {
    id: "piggy-bank",
    name: "Piggy Bank",
    interestFormatted: "0%",
    bestFor: "Short-term cash needs",
    riskLevel: "None",
  },
  {
    id: "savings",
    name: "Basic Savings",
    interestFormatted: "0.05%",
    bestFor: "Emergency fund",
    riskLevel: "Very Low",
  },
  {
    id: "high-yield",
    name: "High-Yield Savings",
    interestFormatted: "0.70%",
    bestFor: "Short-term goals (1-2 years)",
    riskLevel: "Low",
  },
  {
    id: "CD",
    name: "Certificate of Deposit",
    interestFormatted: "1.50%",
    bestFor: "Medium-term goals (2-5 years)",
    riskLevel: "Low-Medium",
  },
  {
    id: "index-fund",
    name: "Index Fund",
    interestFormatted: "~7% (average)",
    bestFor: "Long-term growth (5+ years)",
    riskLevel: "Medium-High",
  },
];

const getRiskBadgeColor = (risk: RiskLevel) => {
  switch (risk) {
    case "None":
    case "Very Low":
      return "bg-green-100 text-green-800";
    case "Low":
      return "bg-emerald-100 text-emerald-800";
    case "Low-Medium":
      return "bg-yellow-100 text-yellow-800";
    case "Medium":
      return "bg-amber-100 text-amber-800";
    case "Medium-High":
      return "bg-orange-100 text-orange-800";
    case "High":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

export default function AccountComparison() {
  return (
    <div className="mt-8">
      <h3 className="font-bold text-lg mb-4">Account Type Comparison</h3>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Account Type</TableHead>
              <TableHead>Interest Rate</TableHead>
              <TableHead>Best For</TableHead>
              <TableHead>Risk Level</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {accountInfo.map((account) => (
              <TableRow key={account.id}>
                <TableCell className="font-medium">{account.name}</TableCell>
                <TableCell>{account.interestFormatted}</TableCell>
                <TableCell>{account.bestFor}</TableCell>
                <TableCell>
                  <Badge 
                    variant="outline"
                    className={`${getRiskBadgeColor(account.riskLevel)} border-0`}
                  >
                    {account.riskLevel}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}