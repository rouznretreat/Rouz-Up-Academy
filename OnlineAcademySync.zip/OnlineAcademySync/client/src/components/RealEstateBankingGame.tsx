import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, DollarSign, TrendingUp, Award, Building, Calculator } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Property {
  id: number;
  name: string;
  price: number;
  downPayment: number;
  monthlyRent: number;
  monthlyExpenses: number;
  description: string;
  cashFlow: number;
  roiPercent: number;
}

interface GameState {
  cash: number;
  monthlyIncome: number;
  creditScore: number;
  properties: Property[];
  month: number;
  totalNetWorth: number;
}

const availableProperties: Property[] = [
  {
    id: 1,
    name: "Starter Duplex",
    price: 150000,
    downPayment: 30000,
    monthlyRent: 2400,
    monthlyExpenses: 1800,
    description: "Great starter property in a growing neighborhood",
    cashFlow: 600,
    roiPercent: 24
  },
  {
    id: 2,
    name: "Single Family Home",
    price: 200000,
    downPayment: 40000,
    monthlyRent: 2800,
    monthlyExpenses: 2200,
    description: "Beautiful 3BR/2BA home perfect for families",
    cashFlow: 600,
    roiPercent: 18
  },
  {
    id: 3,
    name: "Small Apartment Building",
    price: 500000,
    downPayment: 100000,
    monthlyRent: 6000,
    monthlyExpenses: 4500,
    description: "4-unit building with steady rental income",
    cashFlow: 1500,
    roiPercent: 18
  },
  {
    id: 4,
    name: "Commercial Strip Mall",
    price: 800000,
    downPayment: 200000,
    monthlyRent: 8000,
    monthlyExpenses: 5500,
    description: "Prime commercial location with long-term tenants",
    cashFlow: 2500,
    roiPercent: 15
  }
];

const bankingOptions = [
  {
    id: 1,
    name: "Traditional Bank Loan",
    interestRate: 6.5,
    downPaymentPercent: 20,
    description: "Standard 30-year mortgage with good rates"
  },
  {
    id: 2,
    name: "Credit Union Loan",
    interestRate: 6.0,
    downPaymentPercent: 15,
    description: "Better rates but requires membership"
  },
  {
    id: 3,
    name: "Hard Money Loan",
    interestRate: 12.0,
    downPaymentPercent: 25,
    description: "Fast approval but higher rates"
  },
  {
    id: 4,
    name: "Cash Purchase",
    interestRate: 0,
    downPaymentPercent: 100,
    description: "No loan needed - pay full price in cash"
  }
];

export default function RealEstateBankingGame() {
  const [gameState, setGameState] = useState<GameState>({
    cash: 50000,
    monthlyIncome: 5000,
    creditScore: 720,
    properties: [],
    month: 1,
    totalNetWorth: 50000
  });
  
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [selectedLoan, setSelectedLoan] = useState<any>(null);
  const [gamePhase, setGamePhase] = useState<'overview' | 'shopping' | 'financing' | 'results'>('overview');
  const [gameComplete, setGameComplete] = useState(false);
  const { toast } = useToast();

  const purchaseProperty = () => {
    if (!selectedProperty || !selectedLoan) return;
    
    const totalCost = selectedProperty.price * (selectedLoan.downPaymentPercent / 100);
    
    if (gameState.cash < totalCost) {
      toast({
        title: "Insufficient Funds",
        description: `You need $${totalCost.toLocaleString()} but only have $${gameState.cash.toLocaleString()}`,
        variant: "destructive",
      });
      return;
    }

    const newGameState = {
      ...gameState,
      cash: gameState.cash - totalCost,
      monthlyIncome: gameState.monthlyIncome + selectedProperty.cashFlow,
      properties: [...gameState.properties, selectedProperty],
      totalNetWorth: gameState.totalNetWorth + (selectedProperty.price - totalCost)
    };

    setGameState(newGameState);
    setGamePhase('results');
    
    toast({
      title: "Property Purchased!",
      description: `You bought ${selectedProperty.name} and increased your monthly income by $${selectedProperty.cashFlow}!`,
    });
  };

  const nextMonth = () => {
    const newCash = gameState.cash + gameState.monthlyIncome;
    const newMonth = gameState.month + 1;
    
    setGameState({
      ...gameState,
      cash: newCash,
      month: newMonth
    });

    if (newMonth >= 12) {
      setGameComplete(true);
    } else {
      setGamePhase('overview');
      setSelectedProperty(null);
      setSelectedLoan(null);
    }
  };

  const restartGame = () => {
    setGameState({
      cash: 50000,
      monthlyIncome: 5000,
      creditScore: 720,
      properties: [],
      month: 1,
      totalNetWorth: 50000
    });
    setGamePhase('overview');
    setGameComplete(false);
    setSelectedProperty(null);
    setSelectedLoan(null);
  };

  if (gameComplete) {
    const finalScore = gameState.totalNetWorth + gameState.cash;
    let performance = "";
    if (finalScore > 200000) performance = "Real Estate Mogul! 🏆";
    else if (finalScore > 150000) performance = "Successful Investor! 🌟";
    else if (finalScore > 100000) performance = "Good Start! 👍";
    else performance = "Keep Learning! 📚";

    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card className="text-center">
          <CardHeader>
            <Award className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
            <CardTitle className="text-3xl">Game Complete!</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <h3 className="text-2xl font-bold mb-2">{performance}</h3>
              <p className="text-lg text-gray-600">Final Net Worth: ${finalScore.toLocaleString()}</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold">Properties Owned</h4>
                <p className="text-2xl font-bold">{gameState.properties.length}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold">Monthly Cash Flow</h4>
                <p className="text-2xl font-bold">${gameState.monthlyIncome.toLocaleString()}</p>
              </div>
            </div>

            <Button onClick={restartGame} className="w-full">
              Play Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Game Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-center mb-4">🏠 Real Estate Banking Game</h1>
        <div className="grid grid-cols-4 gap-4 text-center">
          <div className="bg-green-100 p-3 rounded-lg">
            <DollarSign className="w-6 h-6 mx-auto mb-1" />
            <p className="text-sm font-semibold">Cash</p>
            <p className="text-lg font-bold">${gameState.cash.toLocaleString()}</p>
          </div>
          <div className="bg-blue-100 p-3 rounded-lg">
            <TrendingUp className="w-6 h-6 mx-auto mb-1" />
            <p className="text-sm font-semibold">Monthly Income</p>
            <p className="text-lg font-bold">${gameState.monthlyIncome.toLocaleString()}</p>
          </div>
          <div className="bg-purple-100 p-3 rounded-lg">
            <Home className="w-6 h-6 mx-auto mb-1" />
            <p className="text-sm font-semibold">Properties</p>
            <p className="text-lg font-bold">{gameState.properties.length}</p>
          </div>
          <div className="bg-yellow-100 p-3 rounded-lg">
            <Building className="w-6 h-6 mx-auto mb-1" />
            <p className="text-sm font-semibold">Month</p>
            <p className="text-lg font-bold">{gameState.month}/12</p>
          </div>
        </div>
      </div>

      {gamePhase === 'overview' && (
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Month {gameState.month} - Choose Your Strategy</h2>
          <p className="mb-6 text-gray-600">
            You have ${gameState.cash.toLocaleString()} available. What would you like to do this month?
          </p>
          <div className="flex justify-center space-x-4">
            <Button onClick={() => setGamePhase('shopping')} className="bg-blue-600 hover:bg-blue-700">
              Shop for Properties
            </Button>
            <Button onClick={nextMonth} variant="outline">
              Save Money This Month
            </Button>
          </div>
        </div>
      )}

      {gamePhase === 'shopping' && (
        <div>
          <h2 className="text-2xl font-bold mb-4">🏠 Property Marketplace</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {availableProperties.map((property) => (
              <Card 
                key={property.id} 
                className={`cursor-pointer transition-all ${
                  selectedProperty?.id === property.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedProperty(property)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Home className="w-5 h-5 mr-2" />
                    {property.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{property.description}</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>Price: ${property.price.toLocaleString()}</div>
                    <div>Down Payment: ${property.downPayment.toLocaleString()}</div>
                    <div>Monthly Rent: ${property.monthlyRent.toLocaleString()}</div>
                    <div>Monthly Expenses: ${property.monthlyExpenses.toLocaleString()}</div>
                    <div className="font-bold text-green-600">Cash Flow: +${property.cashFlow}</div>
                    <div className="font-bold text-blue-600">ROI: {property.roiPercent}%</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {selectedProperty && (
            <div className="mt-6 text-center">
              <Button onClick={() => setGamePhase('financing')} className="bg-green-600 hover:bg-green-700">
                Choose Financing for {selectedProperty.name}
              </Button>
            </div>
          )}
        </div>
      )}

      {gamePhase === 'financing' && selectedProperty && (
        <div>
          <h2 className="text-2xl font-bold mb-4">🏦 Choose Your Financing</h2>
          <p className="mb-4 text-center">
            Selected Property: <strong>{selectedProperty.name}</strong> (${selectedProperty.price.toLocaleString()})
          </p>
          
          <div className="grid md:grid-cols-2 gap-6">
            {bankingOptions.map((option) => {
              const downPaymentAmount = selectedProperty.price * (option.downPaymentPercent / 100);
              const canAfford = gameState.cash >= downPaymentAmount;
              
              return (
                <Card 
                  key={option.id}
                  className={`cursor-pointer transition-all ${
                    selectedLoan?.id === option.id ? 'ring-2 ring-blue-500' : ''
                  } ${!canAfford ? 'opacity-50' : ''}`}
                  onClick={() => canAfford && setSelectedLoan(option)}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calculator className="w-5 h-5 mr-2" />
                      {option.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{option.description}</p>
                    <div className="space-y-2 text-sm">
                      <div>Interest Rate: {option.interestRate}%</div>
                      <div>Down Payment: {option.downPaymentPercent}% (${downPaymentAmount.toLocaleString()})</div>
                      <div className={`font-bold ${canAfford ? 'text-green-600' : 'text-red-600'}`}>
                        {canAfford ? '✅ You can afford this!' : '❌ Insufficient funds'}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {selectedLoan && (
            <div className="mt-6 text-center">
              <Button onClick={purchaseProperty} className="bg-green-600 hover:bg-green-700 mr-4">
                Purchase Property
              </Button>
              <Button onClick={() => setGamePhase('shopping')} variant="outline">
                Back to Properties
              </Button>
            </div>
          )}
        </div>
      )}

      {gamePhase === 'results' && (
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">🎉 Purchase Successful!</h2>
          <p className="mb-6">
            You successfully purchased <strong>{selectedProperty?.name}</strong>! 
            Your monthly cash flow increased by ${selectedProperty?.cashFlow}.
          </p>
          
          <div className="bg-green-50 p-6 rounded-lg mb-6">
            <h3 className="font-bold mb-2">Your Portfolio:</h3>
            <div className="space-y-2">
              {gameState.properties.map((property, index) => (
                <div key={index} className="text-sm">
                  {property.name} - Monthly Cash Flow: +${property.cashFlow}
                </div>
              ))}
            </div>
          </div>
          
          <Button onClick={nextMonth} className="bg-blue-600 hover:bg-blue-700">
            Continue to Next Month
          </Button>
        </div>
      )}
    </div>
  );
}