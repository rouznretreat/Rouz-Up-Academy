import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Trophy, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface BusinessQuizProps {
  moduleType: "business" | "structures" | "finance" | "marketing";
}

const businessQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What makes a corporation a separate legal entity?",
    options: [
      "It has employees working for it",
      "It can enter contracts, own property, and be sued independently of its owners",
      "It makes a profit every year", 
      "It has a business license"
    ],
    correctAnswer: 1,
    explanation: "A corporation is legally treated as a separate 'person' with its own rights and responsibilities, independent of its owners."
  },
  {
    id: 2,
    question: "What is the biggest advantage of establishing a formal business entity?",
    options: [
      "Lower taxes",
      "More customers",
      "Limited liability protection",
      "Government funding"
    ],
    correctAnswer: 2,
    explanation: "Limited liability means owners' personal assets are protected from business debts and lawsuits."
  },
  {
    id: 3,
    question: "How does the IRS distinguish between a business and a hobby?",
    options: [
      "Businesses make more money than hobbies",
      "Businesses operate with the intent to make a profit",
      "Businesses have more than one employee",
      "Businesses are incorporated"
    ],
    correctAnswer: 1,
    explanation: "The IRS looks at whether the activity is operated with a genuine intent to make a profit, not just for personal enjoyment."
  },
  {
    id: 4,
    question: "Which of these is NOT a characteristic of corporate personhood?",
    options: [
      "The business can own property",
      "The business can enter contracts",
      "The business owners are personally liable for all debts",
      "The business can continue to exist even if ownership changes"
    ],
    correctAnswer: 2,
    explanation: "Corporate personhood actually provides limited liability, meaning owners are NOT personally liable for business debts."
  }
];

const structuresQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What is the simplest business structure?",
    options: [
      "Corporation",
      "LLC",
      "Partnership", 
      "Sole Proprietorship"
    ],
    correctAnswer: 3,
    explanation: "Sole Proprietorship is the simplest structure where one person owns and operates the business."
  },
  {
    id: 2,
    question: "Which business structure combines pass-through taxation with limited liability?",
    options: [
      "Sole Proprietorship",
      "Partnership",
      "Limited Liability Company (LLC)",
      "Corporation"
    ],
    correctAnswer: 2,
    explanation: "An LLC combines the tax benefits of a partnership with the liability protection of a corporation."
  },
  {
    id: 3,
    question: "What is a major disadvantage of a sole proprietorship?",
    options: [
      "Too much paperwork",
      "High formation costs",
      "Unlimited personal liability",
      "Complex tax requirements"
    ],
    correctAnswer: 2,
    explanation: "In a sole proprietorship, the owner has unlimited personal liability for all business debts and obligations."
  },
  {
    id: 4,
    question: "Which structure is best for raising capital through stock sales?",
    options: [
      "Sole Proprietorship",
      "Partnership", 
      "LLC",
      "Corporation"
    ],
    correctAnswer: 3,
    explanation: "Corporations can issue stock to raise capital, making them ideal for businesses seeking investment."
  },
  {
    id: 5,
    question: "What should you consider when choosing a business structure?",
    options: [
      "Only the cost of formation",
      "Only tax implications",
      "Liability protection, taxes, costs, and future goals",
      "Only how many employees you'll have"
    ],
    correctAnswer: 2,
    explanation: "Multiple factors including liability, taxes, formation costs, fundraising needs, and future business goals should all be considered."
  }
];

const financeQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What does an Income Statement show?",
    options: [
      "What the business owns and owes",
      "Revenue, expenses, and profit over time",
      "Cash coming in and going out",
      "The business owner's personal finances"
    ],
    correctAnswer: 1,
    explanation: "An Income Statement (also called Profit & Loss Statement) shows your revenue, expenses, and profit over a specific period of time, telling you if your business is making money."
  },
  {
    id: 2,
    question: "What is the basic equation for a Balance Sheet?",
    options: [
      "Revenue - Expenses = Profit",
      "Cash In - Cash Out = Net Cash Flow",
      "Assets = Liabilities + Equity",
      "Sales - Costs = Gross Margin"
    ],
    correctAnswer: 2,
    explanation: "The fundamental accounting equation is Assets = Liabilities + Equity. This means what the business owns equals what it owes plus the owner's equity."
  },
  {
    id: 3,
    question: "Why is cash flow important for a business?",
    options: [
      "It shows how profitable the business is",
      "It determines the business structure",
      "It ensures the business can pay its bills",
      "It calculates tax obligations"
    ],
    correctAnswer: 2,
    explanation: "Cash flow is crucial because even profitable businesses can fail if they don't have enough cash to pay their bills when due. Cash is the lifeblood of any business."
  },
  {
    id: 4,
    question: "What is the difference between revenue and profit?",
    options: [
      "There is no difference",
      "Revenue is money coming in; profit is what's left after expenses",
      "Profit is money coming in; revenue is what's left after expenses",
      "Revenue and profit are both the same as cash flow"
    ],
    correctAnswer: 1,
    explanation: "Revenue is the total money generated from sales, while profit is what remains after subtracting all expenses from revenue. A business can have high revenue but low or no profit."
  },
  {
    id: 5,
    question: "Which financial statement is most important for day-to-day business operations?",
    options: [
      "Income Statement",
      "Balance Sheet",
      "Cash Flow Statement",
      "Tax Return"
    ],
    correctAnswer: 2,
    explanation: "While all financial statements are important, the Cash Flow Statement is crucial for day-to-day operations because it shows whether you have enough cash to meet immediate obligations."
  }
];

const marketingQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What are the 4 Ps of marketing?",
    options: [
      "People, Process, Physical, Promotion",
      "Product, Price, Place, Promotion",
      "Planning, Product, Price, Profit",
      "Purpose, People, Price, Place"
    ],
    correctAnswer: 1,
    explanation: "The 4 Ps of marketing are Product (what you're selling), Price (how much you charge), Place (where you sell), and Promotion (how you communicate with customers)."
  },
  {
    id: 2,
    question: "What is a target audience?",
    options: [
      "Everyone who might buy your product",
      "Only your current customers",
      "A specific group of people most likely to buy your product",
      "People who work in your industry"
    ],
    correctAnswer: 2,
    explanation: "A target audience is a specific group of people who are most likely to be interested in and buy your product or service. Focusing on a target audience makes marketing more effective and efficient."
  },
  {
    id: 3,
    question: "Which is the BEST way to understand your customers?",
    options: [
      "Guess what they might want",
      "Ask them directly through surveys and interviews",
      "Copy what competitors are doing",
      "Only use your own preferences"
    ],
    correctAnswer: 1,
    explanation: "Direct customer research through surveys, interviews, and feedback is the most reliable way to understand what customers actually want and need, rather than making assumptions."
  },
  {
    id: 4,
    question: "What is the main goal of marketing?",
    options: [
      "To spend as much money as possible on advertising",
      "To make products as expensive as possible",
      "To connect the right customers with the right products",
      "To copy what other businesses are doing"
    ],
    correctAnswer: 2,
    explanation: "Marketing's main goal is to identify customer needs and connect them with products or services that meet those needs, creating value for both customers and the business."
  },
  {
    id: 5,
    question: "Which marketing channel is most important for reaching teenagers today?",
    options: [
      "Newspaper advertisements",
      "Radio commercials",
      "Social media platforms",
      "Door-to-door sales"
    ],
    correctAnswer: 2,
    explanation: "Social media platforms are where most teenagers spend their time and discover new products and services, making them the most effective channel for reaching this demographic."
  }
];

export default function BusinessQuiz({ moduleType }: BusinessQuizProps) {
  const getQuestions = () => {
    switch (moduleType) {
      case "business":
        return businessQuestions;
      case "structures":
        return structuresQuestions;
      case "finance":
        return financeQuestions;
      case "marketing":
        return marketingQuestions;
      default:
        return businessQuestions;
    }
  };
  
  const questions = getQuestions();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      finishQuiz();
    }
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const finishQuiz = async () => {
    const score = selectedAnswers.reduce((total, answer, index) => {
      return total + (answer === questions[index].correctAnswer ? 1 : 0);
    }, 0);

    setShowResults(true);

    // Submit result to backend if user is authenticated
    if (isAuthenticated) {
      setIsSubmitting(true);
      try {
        await apiRequest('POST', '/api/quiz-result', {
          moduleType,
          score,
          totalQuestions: questions.length,
          answers: selectedAnswers
        });
        toast({
          title: "Quiz Completed!",
          description: `You scored ${score}/${questions.length}. Your result has been saved!`,
        });
      } catch (error) {
        toast({
          title: "Quiz completed",
          description: `You scored ${score}/${questions.length}. Result couldn't be saved but you can see your score!`,
          variant: "destructive",
        });
      } finally {
        setIsSubmitting(false);
      }
    } else {
      toast({
        title: "Quiz Completed!",
        description: `You scored ${score}/${questions.length}. Sign in to save your progress!`,
      });
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
  };

  if (showResults) {
    const score = selectedAnswers.reduce((total, answer, index) => {
      return total + (answer === questions[index].correctAnswer ? 1 : 0);
    }, 0);
    const percentage = Math.round((score / questions.length) * 100);
    
    return (
      <div className="max-w-3xl mx-auto p-6">
        <Card className="border-2 border-green-200">
          <CardContent className="p-8 text-center">
            <div className="animate-bounce">
              <Trophy className="w-20 h-20 mx-auto text-yellow-500 mb-4" />
            </div>
            <h2 className="text-4xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
              {percentage >= 80 ? "🎉 AMAZING! You're a Business Genius! 🚀" : 
               percentage >= 60 ? "👏 Great Job! You're Getting There! 💪" : 
               "🌟 Keep Learning! You've Got This! 📚"}
            </h2>
            <div className="text-7xl font-bold text-green-600 mb-2 animate-pulse">{score}/{questions.length}</div>
            <div className="text-2xl font-bold mb-6">
              <span className={`${percentage >= 80 ? 'text-green-600' : percentage >= 60 ? 'text-orange-500' : 'text-blue-500'}`}>
                {percentage}% Correct
              </span>
              {percentage >= 80 && <span className="ml-2">🏆✨</span>}
              {percentage >= 60 && percentage < 80 && <span className="ml-2">🎯💪</span>}
              {percentage < 60 && <span className="ml-2">📚🌟</span>}
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold mb-4">Review Your Answers:</h3>
              <div className="space-y-4 text-left">
                {questions.map((question, index) => (
                  <div key={index} className="border-b border-gray-200 pb-3">
                    <div className="font-medium mb-2">{question.question}</div>
                    <div className={`text-sm ${selectedAnswers[index] === question.correctAnswer ? 'text-green-600' : 'text-red-600'}`}>
                      Your answer: {question.options[selectedAnswers[index]]}
                      {selectedAnswers[index] === question.correctAnswer ? ' ✓' : ' ✗'}
                    </div>
                    {selectedAnswers[index] !== question.correctAnswer && (
                      <div className="text-sm text-green-600">
                        Correct: {question.options[question.correctAnswer]}
                      </div>
                    )}
                    <div className="text-xs text-gray-600 mt-1">{question.explanation}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <Button onClick={restartQuiz} className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </Button>
            
            {isAuthenticated && (
              <p className="text-xs text-gray-500 mt-4">
                {isSubmitting ? "Saving result..." : "✓ Result saved to your profile"}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <Card>
        <CardContent className="p-8">
          <h2 className="text-2xl font-bold mb-6">{currentQ.question}</h2>
          
          <div className="space-y-3 mb-8">
            {currentQ.options.map((option, index) => (
              <Button
                key={index}
                variant={selectedAnswers[currentQuestion] === index ? "default" : "outline"}
                className="w-full h-auto p-4 text-left justify-start"
                onClick={() => handleAnswerSelect(index)}
              >
                <div className="flex items-start w-full">
                  <div className={`w-6 h-6 rounded-full border-2 mr-3 mt-1 flex-shrink-0 flex items-center justify-center ${
                    selectedAnswers[currentQuestion] === index 
                      ? 'bg-blue-600 border-blue-600' 
                      : 'border-gray-300'
                  }`}>
                    {selectedAnswers[currentQuestion] === index && (
                      <CheckCircle className="w-4 h-4 text-white" />
                    )}
                  </div>
                  <span className="text-gray-700">{option}</span>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={previousQuestion}
              disabled={currentQuestion === 0}
            >
              Previous
            </Button>
            
            <Button 
              onClick={nextQuestion}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}