import { useState } from 'react';
import { Calculator, DollarSign, Shield, TrendingUp, Users, Heart, Briefcase } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function PremiumCalculator() {
  const [formData, setFormData] = useState({
    age: 25,
    gender: 'male',
    smoker: 'no',
    healthStatus: 'excellent',
    coverageAmount: 250000,
    term: 20,
    policyType: 'term'
  });

  const [results, setResults] = useState<any>(null);
  const [showComparison, setShowComparison] = useState(false);

  // Premium calculation logic based on industry standards
  const calculatePremium = () => {
    let basePremium = 0;
    
    // Base rate per $1000 of coverage
    let ratePerThousand = 0.50;
    
    // Age adjustments
    if (formData.age <= 30) ratePerThousand *= 0.8;
    else if (formData.age <= 40) ratePerThousand *= 1.0;
    else if (formData.age <= 50) ratePerThousand *= 1.5;
    else if (formData.age <= 60) ratePerThousand *= 2.5;
    else ratePerThousand *= 4.0;
    
    // Gender adjustments
    if (formData.gender === 'female') ratePerThousand *= 0.85;
    
    // Smoking adjustments
    if (formData.smoker === 'yes') ratePerThousand *= 2.5;
    
    // Health status adjustments
    switch (formData.healthStatus) {
      case 'excellent': ratePerThousand *= 0.9; break;
      case 'good': ratePerThousand *= 1.0; break;
      case 'average': ratePerThousand *= 1.3; break;
      case 'poor': ratePerThousand *= 2.0; break;
    }
    
    // Term adjustments
    if (formData.term === 10) ratePerThousand *= 0.8;
    else if (formData.term === 30) ratePerThousand *= 1.2;
    
    // Policy type adjustments
    if (formData.policyType === 'whole') {
      ratePerThousand *= 8; // Whole life is significantly more expensive
    }
    
    basePremium = (formData.coverageAmount / 1000) * ratePerThousand;
    
    const monthlyPremium = Math.round(basePremium);
    const annualPremium = monthlyPremium * 12;
    const totalPremiums = formData.policyType === 'term' ? annualPremium * formData.term : annualPremium * 30; // Assume 30 years for whole life
    
    // Calculate cash value for whole life
    let cashValue = 0;
    if (formData.policyType === 'whole') {
      // Simplified cash value calculation - typically starts building after year 2-3
      const years = 20; // Assume 20 years for illustration
      cashValue = Math.round(totalPremiums * 0.4); // Rough estimate of cash value accumulation
    }
    
    setResults({
      monthlyPremium,
      annualPremium,
      totalPremiums,
      cashValue,
      coverage: formData.coverageAmount,
      roi: formData.policyType === 'whole' ? Math.round((cashValue / totalPremiums) * 100) : 0
    });
    
    setShowComparison(true);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value });
    setShowComparison(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center">
          <Calculator className="w-8 h-8 mr-3 text-blue-600" />
          💰 Life Insurance Premium Calculator
        </h1>
        <p className="text-lg text-gray-600">
          Get instant estimates for your life insurance premiums and see how different factors affect your costs
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="w-5 h-5 mr-2 text-blue-600" />
              Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Age */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Age</label>
              <input
                type="range"
                min="18"
                max="75"
                value={formData.age}
                onChange={(e) => handleInputChange('age', parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>18</span>
                <span className="font-semibold text-blue-600">{formData.age} years old</span>
                <span>75</span>
              </div>
            </div>

            {/* Gender */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Gender</label>
              <div className="grid grid-cols-2 gap-3">
                {['male', 'female'].map((option) => (
                  <button
                    key={option}
                    onClick={() => handleInputChange('gender', option)}
                    className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                      formData.gender === option
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {option === 'male' ? '👨 Male' : '👩 Female'}
                  </button>
                ))}
              </div>
            </div>

            {/* Smoker Status */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Smoking Status</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: 'no', label: '🚭 Non-Smoker', desc: 'Lower rates' },
                  { value: 'yes', label: '🚬 Smoker', desc: 'Higher rates' }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleInputChange('smoker', option.value)}
                    className={`p-3 rounded-lg border-2 text-sm transition-colors ${
                      formData.smoker === option.value
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="font-medium">{option.label}</div>
                    <div className="text-xs text-gray-500">{option.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Health Status */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Health Status</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: 'excellent', label: '💪 Excellent', color: 'green' },
                  { value: 'good', label: '👍 Good', color: 'blue' },
                  { value: 'average', label: '⚖️ Average', color: 'yellow' },
                  { value: 'poor', label: '🏥 Poor', color: 'red' }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleInputChange('healthStatus', option.value)}
                    className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                      formData.healthStatus === option.value
                        ? `border-${option.color}-500 bg-${option.color}-50 text-${option.color}-700`
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Coverage Amount */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Coverage Amount</label>
              <div className="grid grid-cols-2 gap-3">
                {[100000, 250000, 500000, 1000000].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => handleInputChange('coverageAmount', amount)}
                    className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                      formData.coverageAmount === amount
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {formatCurrency(amount)}
                  </button>
                ))}
              </div>
            </div>

            {/* Policy Type */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Policy Type</label>
              <div className="space-y-3">
                {[
                  { 
                    value: 'term', 
                    label: '⏳ Term Life Insurance', 
                    desc: 'Lower cost, temporary coverage',
                    icon: '💰'
                  },
                  { 
                    value: 'whole', 
                    label: '🏠 Whole Life Insurance', 
                    desc: 'Higher cost, builds cash value',
                    icon: '💎'
                  }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleInputChange('policyType', option.value)}
                    className={`w-full p-4 rounded-lg border-2 text-left transition-colors ${
                      formData.policyType === option.value
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm">{option.label}</div>
                        <div className="text-xs text-gray-500">{option.desc}</div>
                      </div>
                      <span className="text-lg">{option.icon}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Term Length (only for term insurance) */}
            {formData.policyType === 'term' && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Term Length</label>
                <div className="grid grid-cols-3 gap-3">
                  {[10, 20, 30].map((term) => (
                    <button
                      key={term}
                      onClick={() => handleInputChange('term', term)}
                      className={`p-3 rounded-lg border-2 text-sm font-medium transition-colors ${
                        formData.term === term
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {term} years
                    </button>
                  ))}
                </div>
              </div>
            )}

            <Button onClick={calculatePremium} className="w-full" size="lg">
              <Calculator className="w-4 h-4 mr-2" />
              Calculate My Premium
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="space-y-6">
          {!results ? (
            <Card className="h-full">
              <CardContent className="flex items-center justify-center h-full text-center py-12">
                <div>
                  <Calculator className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">Ready to Calculate</h3>
                  <p className="text-gray-500">Fill out your information and click "Calculate My Premium" to see your estimated costs.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Premium Results */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="w-5 h-5 mr-2 text-green-600" />
                    Your Premium Estimate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                      <div>
                        <div className="text-sm text-gray-600">Monthly Premium</div>
                        <div className="text-2xl font-bold text-blue-600">{formatCurrency(results.monthlyPremium)}</div>
                      </div>
                      <div className="text-blue-500">
                        <Heart className="w-8 h-8" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600">Annual Premium</div>
                        <div className="font-bold text-gray-900">{formatCurrency(results.annualPremium)}</div>
                      </div>
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm text-gray-600">Coverage Amount</div>
                        <div className="font-bold text-gray-900">{formatCurrency(results.coverage)}</div>
                      </div>
                    </div>

                    {formData.policyType === 'whole' && results.cashValue > 0 && (
                      <div className="p-4 bg-green-50 rounded-lg">
                        <div className="text-sm text-green-700 mb-1">Estimated Cash Value (20 years)</div>
                        <div className="text-xl font-bold text-green-600">{formatCurrency(results.cashValue)}</div>
                        <div className="text-xs text-green-600">Living benefit you can access</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Key Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
                    Key Insights
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div>
                        <div className="text-sm font-medium">Cost per day</div>
                        <div className="text-xs text-gray-600">
                          Just {formatCurrency(results.monthlyPremium / 30)} per day for {formatCurrency(results.coverage)} in protection
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                      <div>
                        <div className="text-sm font-medium">Coverage Ratio</div>
                        <div className="text-xs text-gray-600">
                          Your coverage is {Math.round(results.coverage / results.annualPremium)}x your annual premium
                        </div>
                      </div>
                    </div>

                    {formData.policyType === 'whole' && (
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                        <div>
                          <div className="text-sm font-medium">Cash Value Growth</div>
                          <div className="text-xs text-gray-600">
                            Builds {formatCurrency(results.cashValue)} in cash value over 20 years
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Comparison */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2 text-orange-600" />
                    Compare Options
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 border border-blue-200 rounded-lg">
                      <div className="font-medium text-blue-700">💡 Ways to Lower Your Premium</div>
                      <ul className="mt-2 space-y-1 text-xs text-gray-600">
                        <li>• Choose term life over whole life for lower costs</li>
                        <li>• Maintain good health and don't smoke</li>
                        <li>• Buy coverage while you're young</li>
                        <li>• Consider a shorter term length</li>
                      </ul>
                    </div>
                    
                    <div className="p-3 border border-green-200 rounded-lg">
                      <div className="font-medium text-green-700">🎯 Consider This Coverage If</div>
                      <ul className="mt-2 space-y-1 text-xs text-gray-600">
                        <li>• You have dependents who rely on your income</li>
                        <li>• You have debts like a mortgage</li>
                        <li>• You want to leave an inheritance</li>
                        <li>• The premium fits comfortably in your budget</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>

      {/* Educational Note */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <div className="text-yellow-600">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="font-medium text-yellow-800 mb-1">📚 Educational Tool</div>
              <div className="text-sm text-yellow-700">
                This calculator provides educational estimates only. Actual premiums depend on detailed health evaluations, 
                medical exams, and underwriting by insurance companies. Always consult with licensed insurance professionals 
                for official quotes and personalized advice.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}