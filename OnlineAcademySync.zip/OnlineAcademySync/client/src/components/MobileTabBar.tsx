import { Link, useLocation } from "wouter";
import { Home, BookOpen, Video, User, MessageCircle } from "lucide-react";

export default function MobileTabBar() {
  const [location] = useLocation();

  const tabs = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      path: '/',
      isActive: location === '/'
    },
    {
      id: 'courses',
      label: 'Courses',
      icon: BookOpen,
      path: '/courses',
      isActive: location === '/courses'
    },
    {
      id: 'live',
      label: 'Live',
      icon: Video,
      path: '/zoom',
      isActive: location === '/zoom'
    },
    {
      id: 'chat',
      label: 'Contact',
      icon: MessageCircle,
      path: '/contact',
      isActive: location === '/contact'
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: User,
      path: '/dashboard',
      isActive: location === '/dashboard'
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-2xl z-50 safe-area-bottom">
      <div className="grid grid-cols-5 py-2">
        {tabs.map((tab) => {
          const IconComponent = tab.icon;
          return (
            <Link key={tab.id} href={tab.path}>
              <div className={`flex flex-col items-center justify-center py-2 px-1 transition-all duration-200 ${
                tab.isActive 
                  ? 'text-blue-500' 
                  : 'text-gray-400 active:text-gray-600'
              }`}>
                <div className={`p-2 rounded-xl transition-all duration-200 ${
                  tab.isActive 
                    ? 'bg-blue-50 scale-110' 
                    : 'active:bg-gray-50 active:scale-95'
                }`}>
                  <IconComponent 
                    className={`w-5 h-5 ${tab.isActive ? 'text-blue-500' : 'text-gray-400'}`}
                    strokeWidth={tab.isActive ? 2.5 : 2}
                  />
                </div>
                <span className={`text-xs font-medium mt-1 ${
                  tab.isActive ? 'text-blue-500' : 'text-gray-400'
                }`}>
                  {tab.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
      
      {/* iOS Safe Area Bottom Padding */}
      <div className="h-safe-bottom bg-white"></div>
    </div>
  );
}