import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Trophy, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface BankingQuizProps {
  moduleType: "banking-basics" | "saving-growing" | "account-types" | "compound-interest" | "investing-basics" | "setting-goals";
}

const bankingBasicsQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What is the primary function of a bank?",
    options: [
      "To make money for shareholders only",
      "To accept deposits and provide loans", 
      "To sell insurance products",
      "To invest in the stock market"
    ],
    correctAnswer: 1,
    explanation: "Banks primarily accept deposits from customers and use those funds to provide loans to other customers, earning money from the interest difference."
  },
  {
    id: 2,
    question: "Which account type is best for everyday transactions?",
    options: [
      "Savings Account",
      "Certificate of Deposit (CD)",
      "Checking Account",
      "Money Market Account"
    ],
    correctAnswer: 2,
    explanation: "Checking accounts are designed for frequent transactions like paying bills, making purchases, and withdrawing cash."
  },
  {
    id: 3,
    question: "What does FDIC insurance protect?",
    options: [
      "Your deposits up to $250,000 per bank",
      "Your credit score",
      "Your investment portfolio",
      "Your loan payments"
    ],
    correctAnswer: 0,
    explanation: "FDIC insurance protects deposits up to $250,000 per depositor, per bank, ensuring your money is safe even if the bank fails."
  },
  {
    id: 4,
    question: "How do banks make money?",
    options: [
      "By charging monthly fees only",
      "By investing customer deposits in stocks",
      "By charging higher interest on loans than they pay on deposits",
      "By selling bank buildings"
    ],
    correctAnswer: 2,
    explanation: "Banks make money primarily through the interest rate spread - they pay lower interest on deposits and charge higher interest on loans."
  },
  {
    id: 5,
    question: "Which service is NOT typically offered by banks?",
    options: [
      "Checking accounts",
      "Car insurance",
      "Personal loans", 
      "Credit cards"
    ],
    correctAnswer: 1,
    explanation: "While banks offer many financial services, car insurance is typically provided by insurance companies, not banks."
  }
];

const savingGrowingQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What is the main difference between saving and growing money?",
    options: [
      "Saving is for rich people, growing is for poor people",
      "Saving keeps money safe, growing helps it earn more",
      "Saving is illegal, growing is legal",
      "There is no difference"
    ],
    correctAnswer: 1,
    explanation: "Saving focuses on keeping money safe and accessible, while growing money focuses on earning returns through investments and compound interest."
  },
  {
    id: 2,
    question: "What is compound interest?",
    options: [
      "Interest paid only once",
      "Interest earned on both principal and previous interest",
      "Interest that decreases over time",
      "Interest paid by the government"
    ],
    correctAnswer: 1,
    explanation: "Compound interest is when you earn interest not just on your original money, but also on the interest you've already earned - it's 'interest on interest.'"
  },
  {
    id: 3,
    question: "If you had $1,000 and left it in a regular savings account for 10 years, approximately how much would you have?",
    options: [
      "$2,000",
      "$1,500", 
      "$1,050",
      "$1,000"
    ],
    correctAnswer: 2,
    explanation: "With typical low savings account rates, your money grows very slowly. This is why it's important to consider higher-yield options for long-term growth."
  },
  {
    id: 4,
    question: "Which is an example of making your money grow?",
    options: [
      "Keeping cash under your mattress",
      "Putting money in a regular checking account",
      "Investing in a high-yield savings account",
      "Spending all your money immediately"
    ],
    correctAnswer: 2,
    explanation: "High-yield savings accounts offer better interest rates than regular accounts, helping your money grow faster while staying relatively safe."
  },
  {
    id: 5,
    question: "What can help your money beat inflation?",
    options: [
      "Keeping it in a piggy bank",
      "Investing in growth-oriented options",
      "Hiding it in your room",
      "Spending it all quickly"
    ],
    correctAnswer: 1,
    explanation: "Growth-oriented investments like index funds or high-yield accounts can help your money grow faster than inflation, preserving and increasing your purchasing power."
  }
];

const accountTypesQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "Which account type is best for daily transactions?",
    options: [
      "Savings Account",
      "Checking Account", 
      "Certificate of Deposit",
      "Money Market Account"
    ],
    correctAnswer: 1,
    explanation: "Checking accounts are designed for frequent transactions like paying bills, making purchases, and accessing cash through ATMs and debit cards."
  },
  {
    id: 2,
    question: "What is the main purpose of a savings account?",
    options: [
      "Making frequent purchases",
      "Earning interest while keeping money accessible",
      "Getting a loan from the bank",
      "Paying monthly bills"
    ],
    correctAnswer: 1,
    explanation: "Savings accounts are designed to help you earn interest on your money while keeping it relatively accessible for emergencies or short-term goals."
  },
  {
    id: 3,
    question: "What is a Certificate of Deposit (CD)?",
    options: [
      "A type of credit card",
      "A time deposit with fixed interest rate",
      "A checking account with no fees",
      "A loan from the bank"
    ],
    correctAnswer: 1,
    explanation: "A CD is a time deposit where you agree to leave your money with the bank for a specific period in exchange for a higher, fixed interest rate."
  },
  {
    id: 4,
    question: "Which account typically offers the highest interest rates?",
    options: [
      "Regular Checking Account",
      "Basic Savings Account",
      "Certificate of Deposit (CD)",
      "Student Checking Account"
    ],
    correctAnswer: 2,
    explanation: "CDs typically offer the highest interest rates because you commit to leaving your money untouched for a specific time period, reducing the bank's risk."
  },
  {
    id: 5,
    question: "What happens if you withdraw money early from a CD?",
    options: [
      "You get bonus interest",
      "Nothing happens",
      "You pay an early withdrawal penalty",
      "The bank closes your account"
    ],
    correctAnswer: 2,
    explanation: "Early withdrawal from a CD typically results in a penalty, often forfeiting several months' worth of interest earnings."
  }
];

const compoundInterestQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What is compound interest often called?",
    options: [
      "Simple interest",
      "The eighth wonder of the world",
      "Bank interest",
      "Savings interest"
    ],
    correctAnswer: 1,
    explanation: "Albert Einstein allegedly called compound interest 'the eighth wonder of the world' because of its powerful wealth-building potential over time."
  },
  {
    id: 2,
    question: "How often does compound interest typically compound?",
    options: [
      "Only once per year",
      "Daily, monthly, quarterly, or annually",
      "Only when you make deposits",
      "Never automatically"
    ],
    correctAnswer: 1,
    explanation: "Compound interest can compound at different frequencies - daily, monthly, quarterly, or annually. More frequent compounding generally results in higher returns."
  },
  {
    id: 3,
    question: "What is the 'Rule of 72'?",
    options: [
      "A banking regulation",
      "A way to estimate how long it takes money to double",
      "The maximum interest rate allowed",
      "A type of savings account"
    ],
    correctAnswer: 1,
    explanation: "The Rule of 72 helps estimate how long it takes for money to double. Divide 72 by your interest rate to get the approximate number of years."
  },
  {
    id: 4,
    question: "Why is starting early important with compound interest?",
    options: [
      "Banks give better rates to young people",
      "Time allows your money to grow exponentially",
      "You can only use compound interest before age 30",
      "Interest rates are higher in the past"
    ],
    correctAnswer: 1,
    explanation: "Starting early gives compound interest more time to work its magic. Even small amounts invested early can grow to large sums over decades."
  },
  {
    id: 5,
    question: "If you invest $100 at 10% annual compound interest, approximately how much will you have after 10 years?",
    options: [
      "$200",
      "$259",
      "$300",
      "$500"
    ],
    correctAnswer: 1,
    explanation: "Using compound interest, $100 at 10% annually becomes approximately $259 after 10 years, demonstrating the power of compounding over time."
  }
];

const investingBasicsQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What is the main difference between saving and investing?",
    options: [
      "Saving is for short-term goals, investing is for long-term growth",
      "Saving is illegal, investing is legal",
      "There is no difference",
      "Saving is only for adults"
    ],
    correctAnswer: 0,
    explanation: "Saving focuses on preserving money for short-term needs and emergencies, while investing aims for long-term growth with the potential for higher returns."
  },
  {
    id: 2,
    question: "What is diversification in investing?",
    options: [
      "Putting all money in one investment",
      "Spreading investments across different types of assets",
      "Only investing in stocks",
      "Avoiding all investments"
    ],
    correctAnswer: 1,
    explanation: "Diversification means spreading your investments across different asset types (stocks, bonds, real estate) to reduce risk."
  },
  {
    id: 3,
    question: "What is an index fund?",
    options: [
      "A fund that tracks a specific market index",
      "A type of savings account",
      "A government bond",
      "A single company stock"
    ],
    correctAnswer: 0,
    explanation: "An index fund is a type of investment that tracks a market index (like the S&P 500), providing instant diversification at low cost."
  },
  {
    id: 4,
    question: "Why is time important in investing?",
    options: [
      "Investments only work during business hours",
      "Compound growth works better over longer periods",
      "You can only invest when you're young",
      "Time doesn't matter in investing"
    ],
    correctAnswer: 1,
    explanation: "Time allows compound growth to work its magic - the longer you invest, the more your money can grow through compounding returns."
  },
  {
    id: 5,
    question: "What should beginners focus on when starting to invest?",
    options: [
      "Day trading individual stocks",
      "Low-cost diversified index funds",
      "Complex derivatives",
      "Cryptocurrency only"
    ],
    correctAnswer: 1,
    explanation: "Beginners should start with low-cost, diversified index funds which provide broad market exposure with minimal risk and effort."
  }
];

const settingGoalsQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What makes a financial goal 'SMART'?",
    options: [
      "It involves technology",
      "Specific, Measurable, Achievable, Relevant, Time-bound",
      "It's approved by your parents",
      "It costs a lot of money"
    ],
    correctAnswer: 1,
    explanation: "SMART goals are Specific, Measurable, Achievable, Relevant, and Time-bound, making them more likely to be accomplished."
  },
  {
    id: 2,
    question: "Which is an example of a short-term financial goal?",
    options: [
      "Retirement savings",
      "Buying a house",
      "Saving for a concert ticket in 3 months",
      "College tuition"
    ],
    correctAnswer: 2,
    explanation: "Short-term goals are typically achieved within a year. A concert ticket in 3 months is a perfect example of a short-term goal."
  },
  {
    id: 3,
    question: "What should you do first when setting financial goals?",
    options: [
      "Start investing immediately",
      "Identify what's important to you",
      "Copy your friends' goals",
      "Set the highest goals possible"
    ],
    correctAnswer: 1,
    explanation: "The first step is identifying what's truly important to you and aligns with your values - this makes goals more meaningful and achievable."
  },
  {
    id: 4,
    question: "How often should you review your financial goals?",
    options: [
      "Never, once set they're permanent",
      "Only when you fail to meet them",
      "Regularly (monthly or quarterly)",
      "Only at the end of the year"
    ],
    correctAnswer: 2,
    explanation: "Regular review (monthly or quarterly) helps you track progress, stay motivated, and adjust goals as your life circumstances change."
  },
  {
    id: 5,
    question: "What's the best way to stay motivated with financial goals?",
    options: [
      "Set unrealistic goals to push yourself",
      "Break large goals into smaller milestones",
      "Compare yourself to others constantly",
      "Keep goals secret from everyone"
    ],
    correctAnswer: 1,
    explanation: "Breaking large goals into smaller, achievable milestones helps maintain motivation and provides regular opportunities to celebrate progress."
  }
];

export default function BankingQuiz({ moduleType }: BankingQuizProps) {
  const getQuestions = () => {
    switch (moduleType) {
      case "banking-basics":
        return bankingBasicsQuestions;
      case "saving-growing":
        return savingGrowingQuestions;
      case "account-types":
        return accountTypesQuestions;
      case "compound-interest":
        return compoundInterestQuestions;
      case "investing-basics":
        return investingBasicsQuestions;
      case "setting-goals":
        return settingGoalsQuestions;
      default:
        return bankingBasicsQuestions;
    }
  };
  
  const questions = getQuestions();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      finishQuiz();
    }
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const finishQuiz = async () => {
    const score = selectedAnswers.reduce((total, answer, index) => {
      return total + (answer === questions[index].correctAnswer ? 1 : 0);
    }, 0);

    setShowResults(true);

    // Submit result to backend if user is authenticated
    if (isAuthenticated) {
      setIsSubmitting(true);
      try {
        await apiRequest('POST', '/api/quiz-progress', {
          moduleSlug: moduleType,
          score,
          totalQuestions: questions.length,
          answers: selectedAnswers,
          completed: true
        });
        toast({
          title: "Quiz Completed!",
          description: `You scored ${score}/${questions.length}. Your result has been saved!`,
        });
      } catch (error) {
        toast({
          title: "Quiz completed",
          description: `You scored ${score}/${questions.length}. Result couldn't be saved but you can see your score!`,
          variant: "destructive",
        });
      } finally {
        setIsSubmitting(false);
      }
    } else {
      toast({
        title: "Quiz Completed!",
        description: `You scored ${score}/${questions.length}. Sign in to save your progress!`,
      });
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
  };

  if (showResults) {
    const score = selectedAnswers.reduce((total, answer, index) => {
      return total + (answer === questions[index].correctAnswer ? 1 : 0);
    }, 0);
    const percentage = Math.round((score / questions.length) * 100);
    
    return (
      <div className="max-w-2xl mx-auto p-4">
        <Card className="border-2 border-green-200">
          <CardContent className="p-6 text-center">
            <div className="animate-bounce">
              <Trophy className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
            </div>
            <h2 className="text-2xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-green-600">
              {percentage >= 80 ? "🎉 Banking Expert! 🏆" : 
               percentage >= 60 ? "👏 Great Progress! 💪" : 
               "🌟 Keep Learning! 📚"}
            </h2>
            <div className="text-4xl font-bold text-green-600 mb-2 animate-pulse">{score}/{questions.length}</div>
            <div className="text-xl font-bold mb-4">
              <span className={`${percentage >= 80 ? 'text-green-600' : percentage >= 60 ? 'text-orange-500' : 'text-blue-500'}`}>
                {percentage}% Correct
              </span>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-4">
              <h3 className="text-sm font-semibold mb-3">Review Your Answers:</h3>
              <div className="space-y-3 text-left">
                {questions.map((question, index) => (
                  <div key={index} className="border-b border-gray-200 pb-2">
                    <div className="font-medium text-xs mb-1">{question.question}</div>
                    <div className={`text-xs ${selectedAnswers[index] === question.correctAnswer ? 'text-green-600' : 'text-red-600'}`}>
                      Your answer: {question.options[selectedAnswers[index]]}
                      {selectedAnswers[index] === question.correctAnswer ? ' ✓' : ' ✗'}
                    </div>
                    {selectedAnswers[index] !== question.correctAnswer && (
                      <div className="text-xs text-green-600">
                        Correct: {question.options[question.correctAnswer]}
                      </div>
                    )}
                    <div className="text-xs text-gray-600 mt-1">{question.explanation}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <Button onClick={restartQuiz} className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </Button>
            
            {isAuthenticated && (
              <p className="text-xs text-gray-500 mt-4">
                {isSubmitting ? "Saving result..." : "✓ Result saved to your profile"}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const currentQ = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="mb-4">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-4">{currentQ.question}</h2>
          
          <div className="space-y-2 mb-6">
            {currentQ.options.map((option, index) => (
              <Button
                key={index}
                variant={selectedAnswers[currentQuestion] === index ? "default" : "outline"}
                className="w-full h-auto p-3 text-left justify-start text-sm"
                onClick={() => handleAnswerSelect(index)}
              >
                <div className="flex items-start w-full">
                  <div className={`w-5 h-5 rounded-full border-2 mr-3 mt-0.5 flex-shrink-0 flex items-center justify-center ${
                    selectedAnswers[currentQuestion] === index 
                      ? 'bg-blue-600 border-blue-600' 
                      : 'border-gray-300'
                  }`}>
                    {selectedAnswers[currentQuestion] === index && (
                      <CheckCircle className="w-3 h-3 text-white" />
                    )}
                  </div>
                  <span className="text-gray-700">{option}</span>
                </div>
              </Button>
            ))}
          </div>
          
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={previousQuestion}
              disabled={currentQuestion === 0}
              size="sm"
            >
              Previous
            </Button>
            
            <Button 
              onClick={nextQuestion}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="bg-blue-600 hover:bg-blue-700"
              size="sm"
            >
              {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}