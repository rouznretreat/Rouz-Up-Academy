import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { PiggyBank, TrendingUp, Target, Calculator } from "lucide-react";

export default function AllowanceCalculator() {
  const [weeklyAllowance, setWeeklyAllowance] = useState(15);
  const [savingsPercent, setSavingsPercent] = useState(30);
  const [spendingPercent, setSpendingPercent] = useState(60);
  const [givingPercent, setGivingPercent] = useState(10);
  const [activeTab, setActiveTab] = useState<'budget' | 'growth' | 'goal'>('budget');
  const [savingsGoal, setSavingsGoal] = useState(100);
  const [interestRate, setInterestRate] = useState(5);

  // Calculate amounts
  const savingsAmount = (weeklyAllowance * savingsPercent) / 100;
  const spendingAmount = (weeklyAllowance * spendingPercent) / 100;
  const givingAmount = (weeklyAllowance * givingPercent) / 100;

  // Calculate weeks to reach goal
  const weeksToGoal = savingsAmount > 0 ? Math.ceil(savingsGoal / savingsAmount) : 0;
  const monthsToGoal = Math.ceil(weeksToGoal / 4.33);

  // Calculate compound growth over 1 year
  const weeklyInterestRate = interestRate / 100 / 52;
  const weeksInYear = 52;
  let totalWithGrowth = 0;
  for (let week = 1; week <= weeksInYear; week++) {
    totalWithGrowth = (totalWithGrowth + savingsAmount) * (1 + weeklyInterestRate);
  }

  const adjustPercentages = (type: 'savings' | 'spending' | 'giving', value: number) => {
    if (type === 'savings') {
      setSavingsPercent(value);
      const remaining = 100 - value;
      setSpendingPercent(Math.round(remaining * 0.8));
      setGivingPercent(Math.round(remaining * 0.2));
    } else if (type === 'spending') {
      setSpendingPercent(value);
      const remaining = 100 - value;
      setSavingsPercent(Math.round(remaining * 0.75));
      setGivingPercent(Math.round(remaining * 0.25));
    } else if (type === 'giving') {
      setGivingPercent(value);
      const remaining = 100 - value;
      setSavingsPercent(Math.round(remaining * 0.75));
      setSpendingPercent(Math.round(remaining * 0.25));
    }
  };

  const TabButton = ({ tab, label, icon }: { tab: 'budget' | 'growth' | 'goal', label: string, icon: React.ReactNode }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
        activeTab === tab 
          ? 'bg-blue-600 text-white' 
          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Allowance Scenario Calculator</h1>
        <p className="text-gray-600">Plan your allowance and visualize how your money can grow with different savings approaches</p>
      </div>

      {/* Tab Navigation */}
      <div className="flex justify-center gap-2 mb-6 flex-wrap">
        <TabButton tab="budget" label="Basic Budget" icon={<Calculator className="w-4 h-4" />} />
        <TabButton tab="growth" label="Savings Growth" icon={<TrendingUp className="w-4 h-4" />} />
        <TabButton tab="goal" label="Savings Goal" icon={<Target className="w-4 h-4" />} />
      </div>

      {/* Basic Budget Tab */}
      {activeTab === 'budget' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PiggyBank className="w-5 h-5 text-blue-600" />
              Your Basic Allowance Budget
            </CardTitle>
            <p className="text-sm text-gray-600">See how your allowance breaks down for spending, saving, and giving</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Weekly Allowance Input */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Weekly Allowance ($)
              </label>
              <Slider
                value={[weeklyAllowance]}
                onValueChange={(value) => setWeeklyAllowance(value[0])}
                max={100}
                min={5}
                step={5}
                className="w-full"
              />
              <div className="text-center mt-2 text-2xl font-bold text-blue-600">
                ${weeklyAllowance}
              </div>
            </div>

            <div className="text-center text-lg font-semibold text-gray-700 mb-4">
              How will you divide your money?
            </div>

            {/* Percentage Sliders */}
            <div className="space-y-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium text-green-700">
                    Savings ({savingsPercent}%)
                  </label>
                  <span className="text-xl font-bold text-green-600">
                    ${savingsAmount.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[savingsPercent]}
                  onValueChange={(value) => adjustPercentages('savings', value[0])}
                  max={80}
                  min={0}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium text-blue-700">
                    Spending ({spendingPercent}%)
                  </label>
                  <span className="text-xl font-bold text-blue-600">
                    ${spendingAmount.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[spendingPercent]}
                  onValueChange={(value) => adjustPercentages('spending', value[0])}
                  max={80}
                  min={0}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium text-purple-700">
                    Giving ({givingPercent}%)
                  </label>
                  <span className="text-xl font-bold text-purple-600">
                    ${givingAmount.toFixed(2)}
                  </span>
                </div>
                <Slider
                  value={[givingPercent]}
                  onValueChange={(value) => adjustPercentages('giving', value[0])}
                  max={50}
                  min={0}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-2">Total Allocation</div>
                <div className="text-lg font-bold text-gray-900">
                  {savingsPercent + spendingPercent + givingPercent}% = ${(savingsAmount + spendingAmount + givingAmount).toFixed(2)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Savings Growth Tab */}
      {activeTab === 'growth' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              Savings Growth Calculator
            </CardTitle>
            <p className="text-sm text-gray-600">See how compound interest can grow your savings over time</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Weekly Savings Amount
                </label>
                <div className="text-2xl font-bold text-green-600">
                  ${savingsAmount.toFixed(2)}
                </div>
                <p className="text-xs text-gray-500">From your {savingsPercent}% savings rate</p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Annual Interest Rate (%)
                </label>
                <Slider
                  value={[interestRate]}
                  onValueChange={(value) => setInterestRate(value[0])}
                  max={15}
                  min={0}
                  step={0.5}
                  className="w-full"
                />
                <div className="text-center mt-2 text-lg font-bold text-blue-600">
                  {interestRate}%
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500 to-blue-600 text-white p-6 rounded-lg">
              <h3 className="text-lg font-bold mb-4">Growth Comparison (After 1 Year)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white bg-opacity-20 p-4 rounded-lg">
                  <div className="text-sm mb-1">Just Saving (No Interest)</div>
                  <div className="text-2xl font-bold">
                    ${(savingsAmount * 52).toFixed(2)}
                  </div>
                </div>
                <div className="bg-white bg-opacity-20 p-4 rounded-lg">
                  <div className="text-sm mb-1">With {interestRate}% Compound Interest</div>
                  <div className="text-2xl font-bold">
                    ${totalWithGrowth.toFixed(2)}
                  </div>
                  <div className="text-sm text-green-200">
                    +${(totalWithGrowth - savingsAmount * 52).toFixed(2)} extra!
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Savings Goal Tab */}
      {activeTab === 'goal' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-orange-600" />
              Savings Goal Calculator
            </CardTitle>
            <p className="text-sm text-gray-600">Plan how long it will take to reach your savings goals</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Savings Goal ($)
              </label>
              <Slider
                value={[savingsGoal]}
                onValueChange={(value) => setSavingsGoal(value[0])}
                max={1000}
                min={25}
                step={25}
                className="w-full"
              />
              <div className="text-center mt-2 text-2xl font-bold text-orange-600">
                ${savingsGoal}
              </div>
            </div>

            <div className="bg-orange-50 p-6 rounded-lg">
              <h3 className="text-lg font-bold text-orange-700 mb-4">Time to Reach Your Goal</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-orange-600">
                    {weeksToGoal}
                  </div>
                  <div className="text-sm text-gray-600">Weeks</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">
                    {monthsToGoal}
                  </div>
                  <div className="text-sm text-gray-600">Months</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">
                    ${savingsAmount.toFixed(2)}
                  </div>
                  <div className="text-sm text-gray-600">Per Week</div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-700 mb-2">Goal Examples:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <button 
                  onClick={() => setSavingsGoal(50)}
                  className="bg-white p-2 rounded border hover:bg-blue-100"
                >
                  🎮 Video Game ($50)
                </button>
                <button 
                  onClick={() => setSavingsGoal(100)}
                  className="bg-white p-2 rounded border hover:bg-blue-100"
                >
                  👟 New Shoes ($100)
                </button>
                <button 
                  onClick={() => setSavingsGoal(200)}
                  className="bg-white p-2 rounded border hover:bg-blue-100"
                >
                  📱 Phone Case ($200)
                </button>
                <button 
                  onClick={() => setSavingsGoal(500)}
                  className="bg-white p-2 rounded border hover:bg-blue-100"
                >
                  🚲 Bicycle ($500)
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Family Discussion Prompt */}
      <Card className="mt-6 bg-gradient-to-r from-purple-500 to-pink-600 text-white">
        <CardContent className="p-6">
          <h3 className="text-lg font-bold mb-2">👨‍👩‍👧‍👦 Family Discussion Prompt:</h3>
          <p className="text-sm">
            Try different scenarios with this calculator and discuss your results with your family. 
            Ask them how they budget their income, and why having a plan for your money is important.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}