import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface QuizQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    quadrant: 'E' | 'S' | 'B' | 'I';
  }[];
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What motivates you most when it comes to work?",
    options: [
      { text: "Job security and steady paycheck", quadrant: 'E' },
      { text: "Being my own boss and controlling my schedule", quadrant: 'S' },
      { text: "Building systems that work without me", quadrant: 'B' },
      { text: "Making money work for me", quadrant: 'I' }
    ]
  },
  {
    id: 2,
    question: "How do you prefer to handle risk?",
    options: [
      { text: "Avoid risk, prefer stability", quadrant: 'E' },
      { text: "Take calculated risks I can control", quadrant: 'S' },
      { text: "Take risks to build something bigger", quadrant: 'B' },
      { text: "Diversify investments to manage risk", quadrant: 'I' }
    ]
  },
  {
    id: 3,
    question: "What's your ideal income source?",
    options: [
      { text: "Regular salary with benefits", quadrant: 'E' },
      { text: "Income from my skills and expertise", quadrant: 'S' },
      { text: "Profits from business operations", quadrant: 'B' },
      { text: "Returns from investments", quadrant: 'I' }
    ]
  },
  {
    id: 4,
    question: "How do you view time and money?",
    options: [
      { text: "Trade time for money in a stable job", quadrant: 'E' },
      { text: "My time is directly tied to my income", quadrant: 'S' },
      { text: "Build systems so time creates more money", quadrant: 'B' },
      { text: "Money should work while I sleep", quadrant: 'I' }
    ]
  },
  {
    id: 5,
    question: "What's your approach to learning?",
    options: [
      { text: "Learn skills for job advancement", quadrant: 'E' },
      { text: "Master my craft to be the best", quadrant: 'S' },
      { text: "Learn about systems and leadership", quadrant: 'B' },
      { text: "Study markets and investment strategies", quadrant: 'I' }
    ]
  }
];

const quadrantDescriptions = {
  E: {
    title: "Employee",
    description: "You value security and stability. You prefer working for someone else and having a steady paycheck. Focus on developing skills that make you more valuable to employers.",
    color: "border-red-500 bg-red-50",
    textColor: "text-red-600"
  },
  S: {
    title: "Self-Employed", 
    description: "You're independent and want to be your own boss. You have valuable skills but may be trading time for money. Consider how to scale beyond just your personal efforts.",
    color: "border-orange-500 bg-orange-50",
    textColor: "text-orange-600"
  },
  B: {
    title: "Business Owner",
    description: "You think big and want to build systems. You understand the power of leverage and delegation. Focus on creating businesses that can run without you.",
    color: "border-blue-500 bg-blue-50", 
    textColor: "text-blue-600"
  },
  I: {
    title: "Investor",
    description: "You understand how to make money work for you. You think long-term and focus on building wealth through investments. Continue learning about different investment vehicles.",
    color: "border-green-500 bg-green-50",
    textColor: "text-green-600"
  }
};

export default function QuadrantQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, 'E' | 'S' | 'B' | 'I'>>({});
  const [showResults, setShowResults] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string>("");

  const handleAnswer = (quadrant: 'E' | 'S' | 'B' | 'I') => {
    setAnswers(prev => ({ ...prev, [currentQuestion]: quadrant }));
    setSelectedOption(quadrant);
  };

  const handleNext = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setSelectedOption(answers[currentQuestion + 1] || "");
    } else {
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
      setSelectedOption(answers[currentQuestion - 1] || "");
    }
  };

  const calculateResult = () => {
    const counts = { E: 0, S: 0, B: 0, I: 0 };
    Object.values(answers).forEach(answer => {
      counts[answer]++;
    });
    
    return Object.entries(counts).reduce((a, b) => 
      counts[a[0] as keyof typeof counts] > counts[b[0] as keyof typeof counts] ? a : b
    )[0] as 'E' | 'S' | 'B' | 'I';
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setSelectedOption("");
  };

  if (showResults) {
    const result = calculateResult();
    const quadrant = quadrantDescriptions[result];
    
    return (
      <Card className={`${quadrant.color} border-2`}>
        <CardHeader>
          <CardTitle className={`text-2xl ${quadrant.textColor}`}>
            Your Quadrant: {quadrant.title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-6">{quadrant.description}</p>
          
          <div className="space-y-2 mb-6">
            <h4 className="font-semibold">Your Answer Summary:</h4>
            {Object.entries({ E: 0, S: 0, B: 0, I: 0 }).map(([quad, _]) => {
              const count = Object.values(answers).filter(answer => answer === quad).length;
              return (
                <div key={quad} className="flex justify-between text-sm">
                  <span>{quadrantDescriptions[quad as keyof typeof quadrantDescriptions].title}:</span>
                  <span className="font-medium">{count} answers</span>
                </div>
              );
            })}
          </div>
          
          <div className="flex space-x-4">
            <Button onClick={resetQuiz} variant="outline">
              Retake Quiz
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              Continue Learning
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const question = quizQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Find Your Cash Flow Quadrant</CardTitle>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-green-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="text-sm text-gray-600">
          Question {currentQuestion + 1} of {quizQuestions.length}
        </p>
      </CardHeader>
      <CardContent>
        <h3 className="text-lg font-semibold mb-4">{question.question}</h3>
        
        <RadioGroup value={selectedOption} onValueChange={handleAnswer}>
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value={option.quadrant} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="cursor-pointer flex-1">
                  {option.text}
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>
        
        <div className="flex justify-between mt-6">
          <Button 
            variant="outline" 
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
          >
            Previous
          </Button>
          <Button 
            onClick={handleNext}
            disabled={!selectedOption}
            className="bg-green-600 hover:bg-green-700"
          >
            {currentQuestion === quizQuestions.length - 1 ? 'Get Results' : 'Next'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}