import {
  users,
  courses,
  modules,
  enrollments,
  purchases,
  moduleProgress,
  quizzes,
  quizResults,
  cashFlowResults,
  type User,
  type UpsertUser,
  type Course,
  type Module,
  type Enrollment,
  type Purchase,
  type ModuleProgress,
  type Quiz,
  type QuizResult,
  type CashFlowResult,
  type InsertCourse,
  type InsertModule,
  type InsertEnrollment,
  type InsertPurchase,
  type InsertQuiz,
  type InsertQuizResult,
  type InsertCashFlowResult,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, ilike, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, customerId: string, subscriptionId?: string): Promise<User>;
  
  // Course operations
  getCourses(filter?: { category?: string; isFree?: boolean; search?: string }): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Module operations
  getModulesByCourse(courseId: number): Promise<Module[]>;
  createModule(module: InsertModule): Promise<Module>;
  
  // Enrollment operations
  enrollUser(enrollment: InsertEnrollment): Promise<Enrollment>;
  getUserEnrollments(userId: string): Promise<(Enrollment & { course: Course })[]>;
  getUserEnrollment(userId: string, courseId: number): Promise<Enrollment | undefined>;
  updateEnrollmentProgress(userId: string, courseId: number, progress: number): Promise<void>;
  
  // Purchase operations
  createPurchase(purchase: InsertPurchase): Promise<Purchase>;
  getUserPurchases(userId: string): Promise<Purchase[]>;
  
  // Progress operations
  updateModuleProgress(userId: string, moduleId: number, completed: boolean): Promise<void>;
  getUserModuleProgress(userId: string, courseId: number): Promise<ModuleProgress[]>;
  
  // Quiz operations
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  getQuizzesByModule(moduleId: number): Promise<Quiz[]>;
  submitQuizResult(result: InsertQuizResult): Promise<QuizResult>;
  getUserQuizResults(userId: string): Promise<QuizResult[]>;
  
  // Cash Flow Quadrant operations
  submitCashFlowResult(result: InsertCashFlowResult): Promise<CashFlowResult>;
  getUserCashFlowResult(userId: string): Promise<CashFlowResult | undefined>;
  
  // Dashboard stats
  getUserStats(userId: string): Promise<{
    coursesCompleted: number;
    coursesInProgress: number;
    totalHours: number;
    certificates: number;
    overallProgress: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Course operations
  async getCourses(filter?: { category?: string; isFree?: boolean; search?: string }): Promise<Course[]> {
    let query = db.select().from(courses).where(eq(courses.isPublished, true));
    
    if (filter?.category) {
      query = query.where(eq(courses.category, filter.category));
    }
    
    if (filter?.isFree !== undefined) {
      query = query.where(eq(courses.isFree, filter.isFree));
    }
    
    if (filter?.search) {
      query = query.where(
        or(
          ilike(courses.title, `%${filter.search}%`),
          ilike(courses.description, `%${filter.search}%`)
        )
      );
    }
    
    return await query.orderBy(desc(courses.createdAt));
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  // Module operations
  async getModulesByCourse(courseId: number): Promise<Module[]> {
    return await db
      .select()
      .from(modules)
      .where(eq(modules.courseId, courseId))
      .orderBy(asc(modules.order));
  }

  async createModule(module: InsertModule): Promise<Module> {
    const [newModule] = await db.insert(modules).values(module).returning();
    return newModule;
  }

  // Enrollment operations
  async enrollUser(enrollment: InsertEnrollment): Promise<Enrollment> {
    const [newEnrollment] = await db
      .insert(enrollments)
      .values(enrollment)
      .onConflictDoNothing()
      .returning();
    return newEnrollment;
  }

  async getUserEnrollments(userId: string): Promise<(Enrollment & { course: Course })[]> {
    return await db
      .select({
        id: enrollments.id,
        userId: enrollments.userId,
        courseId: enrollments.courseId,
        enrolledAt: enrollments.enrolledAt,
        completedAt: enrollments.completedAt,
        progress: enrollments.progress,
        lastAccessedAt: enrollments.lastAccessedAt,
        course: courses,
      })
      .from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, userId))
      .orderBy(desc(enrollments.enrolledAt));
  }

  async getUserEnrollment(userId: string, courseId: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, userId), eq(enrollments.courseId, courseId)));
    return enrollment;
  }

  async updateEnrollmentProgress(userId: string, courseId: number, progress: number): Promise<void> {
    await db
      .update(enrollments)
      .set({
        progress,
        lastAccessedAt: new Date(),
        ...(progress === 100 && { completedAt: new Date() }),
      })
      .where(and(eq(enrollments.userId, userId), eq(enrollments.courseId, courseId)));
  }

  // Purchase operations
  async createPurchase(purchase: InsertPurchase): Promise<Purchase> {
    const [newPurchase] = await db.insert(purchases).values(purchase).returning();
    return newPurchase;
  }

  async getUserPurchases(userId: string): Promise<Purchase[]> {
    return await db
      .select()
      .from(purchases)
      .where(eq(purchases.userId, userId))
      .orderBy(desc(purchases.purchasedAt));
  }

  // Progress operations
  async updateModuleProgress(userId: string, moduleId: number, completed: boolean): Promise<void> {
    await db
      .insert(moduleProgress)
      .values({
        userId,
        moduleId,
        completed,
        completedAt: completed ? new Date() : null,
      })
      .onConflictDoUpdate({
        target: [moduleProgress.userId, moduleProgress.moduleId],
        set: {
          completed,
          completedAt: completed ? new Date() : null,
        },
      });
  }

  async getUserModuleProgress(userId: string, courseId: number): Promise<ModuleProgress[]> {
    return await db
      .select({
        id: moduleProgress.id,
        userId: moduleProgress.userId,
        moduleId: moduleProgress.moduleId,
        completed: moduleProgress.completed,
        completedAt: moduleProgress.completedAt,
      })
      .from(moduleProgress)
      .innerJoin(modules, eq(moduleProgress.moduleId, modules.id))
      .where(and(eq(moduleProgress.userId, userId), eq(modules.courseId, courseId)));
  }

  // Dashboard stats
  async getUserStats(userId: string): Promise<{
    coursesCompleted: number;
    coursesInProgress: number;
    totalHours: number;
    certificates: number;
    overallProgress: number;
  }> {
    const userEnrollments = await this.getUserEnrollments(userId);
    
    const coursesCompleted = userEnrollments.filter(e => e.progress === 100).length;
    const coursesInProgress = userEnrollments.filter(e => e.progress > 0 && e.progress < 100).length;
    
    // Calculate total hours from completed courses
    const completedCourses = userEnrollments.filter(e => e.progress === 100);
    const totalHours = completedCourses.reduce((total, enrollment) => {
      const duration = enrollment.course.duration;
      const hours = parseFloat(duration.replace(/[^\d.]/g, '')) || 0;
      return total + hours;
    }, 0);
    
    const certificates = coursesCompleted; // Assuming each completed course gives a certificate
    
    // Calculate overall progress
    const overallProgress = userEnrollments.length > 0 
      ? Math.round(userEnrollments.reduce((sum, e) => sum + e.progress, 0) / userEnrollments.length)
      : 0;

    return {
      coursesCompleted,
      coursesInProgress,
      totalHours: Math.round(totalHours),
      certificates,
      overallProgress,
    };
  }

  // Quiz operations
  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [newQuiz] = await db.insert(quizzes).values(quiz).returning();
    return newQuiz;
  }

  async getQuizzesByModule(moduleId: number): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.moduleId, moduleId));
  }

  async submitQuizResult(result: InsertQuizResult): Promise<QuizResult> {
    const [newResult] = await db.insert(quizResults).values(result).returning();
    return newResult;
  }

  async getUserQuizResults(userId: string): Promise<QuizResult[]> {
    return await db.select().from(quizResults).where(eq(quizResults.userId, userId));
  }

  // Cash Flow Quadrant operations
  async submitCashFlowResult(result: InsertCashFlowResult): Promise<CashFlowResult> {
    // Check if user already has a result, update if exists, insert if not
    const existing = await db.select().from(cashFlowResults).where(eq(cashFlowResults.userId, result.userId!));
    
    if (existing.length > 0) {
      const [updated] = await db
        .update(cashFlowResults)
        .set({
          quadrant: result.quadrant,
          scores: result.scores,
          answers: result.answers,
          completedAt: new Date(),
        })
        .where(eq(cashFlowResults.userId, result.userId!))
        .returning();
      return updated;
    } else {
      const [newResult] = await db.insert(cashFlowResults).values(result).returning();
      return newResult;
    }
  }

  async getUserCashFlowResult(userId: string): Promise<CashFlowResult | undefined> {
    const [result] = await db.select().from(cashFlowResults).where(eq(cashFlowResults.userId, userId));
    return result;
  }
}

// Temporarily using in-memory storage due to database connection issues
class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private courses: Course[] = [
    {
      id: 1,
      title: "💼 Business for Starters",
      description: "Essential business fundamentals covering structures, finance, marketing and entrepreneurship to build your business knowledge foundation.",
      category: "Business",
      level: "Beginner",
      duration: "2 hours",
      price: 0,
      isFree: false,
      rating: 4.8,
      students: 1800,
      image: "/attached_assets/business%20pic.jpg",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 2,
      title: "🏦 Banking for Starters",
      description: "Learn banking basics, account types, compound interest, and investment fundamentals to manage your money effectively.",
      category: "Banking",
      level: "Beginner",
      duration: "2.5 hours",
      price: 0,
      isFree: false,
      rating: 4.9,
      students: 3200,
      image: "/attached_assets/financial%20education%20(1).jpg",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 3,
      title: "⚖️ Trust for Starters",
      description: "Understand trust structures, estate planning basics, and wealth preservation strategies for long-term financial security.",
      category: "Estate Planning",
      level: "Intermediate",
      duration: "2 hours",
      price: 0,
      isFree: false,
      rating: 4.7,
      students: 1200,
      image: "/attached_assets/Trust%20for%20Starters.jpg",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 4,
      title: "📋 Estate Planning Course",
      description: "Comprehensive estate planning education covering wills, trusts, power of attorney, and healthcare directives.",
      category: "Estate Planning",
      level: "Advanced",
      duration: "3 hours",
      price: 0,
      isFree: false,
      rating: 4.8,
      students: 980,
      image: "/attached_assets/estate%20planning%20(1).png",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 5,
      title: "🛡️ Insurance for Starters",
      description: "Master the fundamentals of life insurance and wealth protection with 5 comprehensive modules covering death benefits, insurance basics, compound interest, insurance types, and infinite banking concepts.",
      category: "Insurance",
      level: "Beginner",
      duration: "1.5 hours",
      price: 0,
      isFree: false,
      rating: 4.9,
      students: 2500,
      image: "/attached_assets/life%20insurance%20policy.jpg",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: 6,
      title: "💳 Credit for Starters",
      description: "Learn credit basics today, succeed financially tomorrow! Interactive course designed for teens (12-18) to master credit scores through realistic scenarios and hands-on learning.",
      category: "Credit",
      level: "Beginner",
      duration: "2 hours",
      price: 0,
      isFree: false,
      rating: 4.9,
      students: 1500,
      image: "/attached_assets/Untitled%20design%20(3).jpg",
      content: "",
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ];
  private modules: Module[] = [];
  private enrollments: Enrollment[] = [];
  private purchases: Purchase[] = [];
  private moduleProgress: ModuleProgress[] = [];
  private quizzes: Quiz[] = [];
  private quizResults: QuizResult[] = [];
  private cashFlowResults: CashFlowResult[] = [];

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const user: User = {
      id: userData.id,
      username: userData.username,
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      avatarUrl: userData.avatarUrl,
      membershipTier: userData.membershipTier || "free",
      stripeCustomerId: userData.stripeCustomerId,
      stripeSubscriptionId: userData.stripeSubscriptionId,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUserStripeInfo(userId: string, customerId: string, subscriptionId?: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    user.stripeCustomerId = customerId;
    if (subscriptionId) user.stripeSubscriptionId = subscriptionId;
    user.updatedAt = new Date();
    this.users.set(userId, user);
    return user;
  }

  async getCourses(filter?: { category?: string; isFree?: boolean; search?: string }): Promise<Course[]> {
    let filtered = [...this.courses];
    
    if (filter?.category) {
      filtered = filtered.filter(c => c.category === filter.category);
    }
    
    if (filter?.isFree !== undefined) {
      filtered = filtered.filter(c => c.isFree === filter.isFree);
    }
    
    if (filter?.search) {
      const searchLower = filter.search.toLowerCase();
      filtered = filtered.filter(c => 
        c.title.toLowerCase().includes(searchLower) ||
        c.description.toLowerCase().includes(searchLower)
      );
    }
    
    return filtered;
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.find(c => c.id === id);
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const newCourse: Course = {
      id: Math.max(...this.courses.map(c => c.id), 0) + 1,
      ...course,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.courses.push(newCourse);
    return newCourse;
  }

  async getModulesByCourse(courseId: number): Promise<Module[]> {
    return this.modules.filter(m => m.courseId === courseId);
  }

  async createModule(module: InsertModule): Promise<Module> {
    const newModule: Module = {
      id: Math.max(...this.modules.map(m => m.id), 0) + 1,
      ...module,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.modules.push(newModule);
    return newModule;
  }

  async enrollUser(enrollment: InsertEnrollment): Promise<Enrollment> {
    const newEnrollment: Enrollment = {
      id: Math.max(...this.enrollments.map(e => e.id), 0) + 1,
      ...enrollment,
      enrolledAt: new Date(),
      progress: 0
    };
    this.enrollments.push(newEnrollment);
    return newEnrollment;
  }

  async getUserEnrollments(userId: string): Promise<(Enrollment & { course: Course })[]> {
    return this.enrollments
      .filter(e => e.userId === userId)
      .map(e => {
        const course = this.courses.find(c => c.id === e.courseId);
        if (!course) throw new Error("Course not found");
        return { ...e, course };
      });
  }

  async getUserEnrollment(userId: string, courseId: number): Promise<Enrollment | undefined> {
    return this.enrollments.find(e => e.userId === userId && e.courseId === courseId);
  }

  async updateEnrollmentProgress(userId: string, courseId: number, progress: number): Promise<void> {
    const enrollment = this.enrollments.find(e => e.userId === userId && e.courseId === courseId);
    if (enrollment) {
      enrollment.progress = progress;
    }
  }

  async createPurchase(purchase: InsertPurchase): Promise<Purchase> {
    const newPurchase: Purchase = {
      id: Math.max(...this.purchases.map(p => p.id), 0) + 1,
      ...purchase,
      purchasedAt: new Date()
    };
    this.purchases.push(newPurchase);
    return newPurchase;
  }

  async getUserPurchases(userId: string): Promise<Purchase[]> {
    return this.purchases.filter(p => p.userId === userId);
  }

  async updateModuleProgress(userId: string, moduleId: number, completed: boolean): Promise<void> {
    const existing = this.moduleProgress.find(mp => mp.userId === userId && mp.moduleId === moduleId);
    if (existing) {
      existing.completed = completed;
      existing.completedAt = completed ? new Date() : null;
    } else {
      this.moduleProgress.push({
        id: Math.max(...this.moduleProgress.map(mp => mp.id), 0) + 1,
        userId,
        moduleId,
        completed,
        completedAt: completed ? new Date() : null
      });
    }
  }

  async getUserModuleProgress(userId: string, courseId: number): Promise<ModuleProgress[]> {
    const courseModules = this.modules.filter(m => m.courseId === courseId);
    return this.moduleProgress.filter(mp => 
      mp.userId === userId && courseModules.some(m => m.id === mp.moduleId)
    );
  }

  async getUserStats(userId: string): Promise<{
    coursesCompleted: number;
    coursesInProgress: number;
    totalHours: number;
    certificates: number;
    overallProgress: number;
  }> {
    const enrollments = this.enrollments.filter(e => e.userId === userId);
    const completed = enrollments.filter(e => (e.progress || 0) >= 100);
    const inProgress = enrollments.filter(e => (e.progress || 0) < 100 && (e.progress || 0) > 0);
    
    return {
      coursesCompleted: completed.length,
      coursesInProgress: inProgress.length,
      totalHours: completed.length * 2,
      certificates: completed.length,
      overallProgress: enrollments.length > 0 ? 
        enrollments.reduce((sum, e) => sum + (e.progress || 0), 0) / enrollments.length : 0
    };
  }

  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const newQuiz: Quiz = {
      id: Math.max(...this.quizzes.map(q => q.id), 0) + 1,
      ...quiz,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.quizzes.push(newQuiz);
    return newQuiz;
  }

  async getQuizzesByModule(moduleId: number): Promise<Quiz[]> {
    return this.quizzes.filter(q => q.moduleId === moduleId);
  }

  async submitQuizResult(result: InsertQuizResult): Promise<QuizResult> {
    const newResult: QuizResult = {
      id: Math.max(...this.quizResults.map(qr => qr.id), 0) + 1,
      ...result,
      submittedAt: new Date()
    };
    this.quizResults.push(newResult);
    return newResult;
  }

  async getUserQuizResults(userId: string): Promise<QuizResult[]> {
    return this.quizResults.filter(qr => qr.userId === userId);
  }

  async submitCashFlowResult(result: InsertCashFlowResult): Promise<CashFlowResult> {
    const newResult: CashFlowResult = {
      id: Math.max(...this.cashFlowResults.map(cfr => cfr.id), 0) + 1,
      ...result,
      submittedAt: new Date()
    };
    this.cashFlowResults.push(newResult);
    return newResult;
  }

  async getUserCashFlowResult(userId: string): Promise<CashFlowResult | undefined> {
    return this.cashFlowResults.find(cfr => cfr.userId === userId);
  }
}

export const storage = new MemStorage();
