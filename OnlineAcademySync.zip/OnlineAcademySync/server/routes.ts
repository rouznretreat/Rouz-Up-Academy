import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertCourseSchema, insertEnrollmentSchema, insertPurchaseSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const { category, isFree, search } = req.query;
      const filter = {
        category: category as string,
        isFree: isFree ? isFree === 'true' : undefined,
        search: search as string,
      };
      
      const courses = await storage.getCourses(filter);
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.get('/api/courses/:id/modules', async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const modules = await storage.getModulesByCourse(courseId);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching modules:", error);
      res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  // Enrollment routes
  app.post('/api/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { courseId } = insertEnrollmentSchema.parse(req.body);
      
      // Check if course exists and is free or user has access
      const course = await storage.getCourse(courseId);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      // Check if user already enrolled
      const existingEnrollment = await storage.getUserEnrollment(userId, courseId);
      if (existingEnrollment) {
        return res.json(existingEnrollment);
      }
      
      // For paid courses, check if user has purchased or has appropriate membership
      if (!course.isFree) {
        const user = await storage.getUser(userId);
        const userPurchases = await storage.getUserPurchases(userId);
        const hasPurchased = userPurchases.some(p => p.courseId === courseId && p.status === 'completed');
        const hasAccess = user?.membershipTier === 'premium' || user?.membershipTier === 'vip' || hasPurchased;
        
        if (!hasAccess) {
          return res.status(403).json({ message: "Purchase required to access this course" });
        }
      }
      
      const enrollment = await storage.enrollUser({ userId, courseId });
      res.json(enrollment);
    } catch (error) {
      console.error("Error creating enrollment:", error);
      res.status(500).json({ message: "Failed to enroll in course" });
    }
  });

  app.get('/api/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const enrollments = await storage.getUserEnrollments(userId);
      res.json(enrollments);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.patch('/api/enrollments/:courseId/progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = parseInt(req.params.courseId);
      const { progress } = req.body;
      
      await storage.updateEnrollmentProgress(userId, courseId, progress);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    try {
      const { courseId, amount } = req.body;
      const userId = req.user.claims.sub;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId,
          courseId: courseId?.toString() || '',
        },
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Subscription route for membership tiers
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { priceId, membershipTier } = req.body;
      
      let user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        return res.json({
          subscriptionId: subscription.id,
          clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        });
      }
      
      if (!user.email) {
        return res.status(400).json({ message: "User email required" });
      }

      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
          metadata: { userId },
        });
        customerId = customer.id;
        user = await storage.updateUserStripeInfo(userId, customerId);
      }

      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          userId,
          membershipTier,
        },
      });

      await storage.updateUserStripeInfo(userId, customerId, subscription.id);
  
      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });

  // Purchase completion webhook
  app.post('/api/purchases', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const purchase = insertPurchaseSchema.parse({ ...req.body, userId });
      
      const newPurchase = await storage.createPurchase(purchase);
      
      // Auto-enroll user if it's a course purchase
      if (purchase.courseId) {
        await storage.enrollUser({ userId, courseId: purchase.courseId });
      }
      
      res.json(newPurchase);
    } catch (error) {
      console.error("Error creating purchase:", error);
      res.status(500).json({ message: "Failed to create purchase" });
    }
  });

  // Quiz routes for Banking modules
  app.post('/api/quiz-result', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const { moduleType, score, totalQuestions, answers } = req.body;
      
      const result = await storage.submitQuizResult({
        userId,
        moduleId: 0, // Will be updated when we add proper module IDs
        score,
        totalQuestions,
        answers,
        completed: true,
        moduleType // Store module type for now
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error submitting quiz result:", error);
      res.status(500).json({ message: "Failed to submit quiz" });
    }
  });

  app.get('/api/quiz-results', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const results = await storage.getUserQuizResults(userId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching quiz results:", error);
      res.status(500).json({ message: "Failed to fetch quiz results" });
    }
  });

  // Cash Flow Quadrant Quiz routes
  app.post('/api/cash-flow-quiz', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const { answers, scores, quadrant } = req.body;
      
      const result = await storage.submitCashFlowResult({
        userId,
        quadrant,
        scores,
        answers,
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error submitting cash flow quiz:", error);
      res.status(500).json({ message: "Failed to submit quiz" });
    }
  });

  app.get('/api/cash-flow-result', isAuthenticated, async (req, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const result = await storage.getUserCashFlowResult(userId);
      res.json(result || null);
    } catch (error) {
      console.error("Error fetching cash flow result:", error);
      res.status(500).json({ message: "Failed to fetch result" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
